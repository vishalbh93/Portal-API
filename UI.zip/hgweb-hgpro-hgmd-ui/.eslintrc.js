module.exports = {
  env: {
    browser: true,
    es6: true
  },
  extends: ['eslint:recommended', 'plugin:react/recommended', 'prettier'],
  globals: {
    Atomics: 'readonly',
    SharedArrayBuffer: 'readonly'
  },
  parserOptions: {
    ecmaFeatures: {
      jsx: true
    },
    ecmaVersion: 2018,
    sourceType: 'module'
  },
  plugins: ['react', 'prettier'],
  overrides: [
    {
      files: ['*.js', '*.jsx'],
      rules: {
        'no-console': 'warn',
        'no-extra-boolean-cast': 'warn',
        'no-sparse-arrays': 'warn',
        'no-undef': 'warn',
        'no-unused-vars': 'warn',
        'no-useless-escape': 'off',
        'no-var': 'warn',
        'object-curly-spacing': 'off'
      }
    }
  ],

  rules: {
    'linebreak-style': ['error', 'windows']
  }
};
