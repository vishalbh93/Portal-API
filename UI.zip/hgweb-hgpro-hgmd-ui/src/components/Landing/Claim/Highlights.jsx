import React from 'react';

//styling imports
import './_highlights.less';
import * as constant from '../constants.js';

const highlightData = [
  {
    Heading: 'Increase Visibility',
    Description: 'Personalize your profile and make it visible to more patients',
    ImageSrc: constant.iconperson
  },
  {
    Heading: 'Boost Physician Referrals',
    Description: 'Stand out to physicians making informed referrals',
    ImageSrc: constant.iconreferrals
  },
  {
    Heading: 'Connect with Patients',
    Description: 'Get twice the appointment requests with a complete profile',
    ImageSrc: constant.icondoctor
  },
  {
    Heading: 'Manage Your Profile',
    Description: 'Access tools to manage and respond to reviews',
    ImageSrc: constant.icondoctoronline
  }
];

const HighlightClaimSection = () => {
  return (
    <div className='highlight-section'>
      <div className='highlight-section-inner'>
        {highlightData.map((data,index) => (
          <div className={`${data.Heading.toLowerCase() ==='manage your profile'?'cols remove-down-space':'cols'}`} key={index}>
            <span className='count right-border'>
              <img src={data.ImageSrc} alt={data.Heading} />
            </span>
            <div className='heading-group'>
              <h2 className='heading'>{data.Heading}</h2>
              <p className='sub-heading'>{data.Description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HighlightClaimSection;
