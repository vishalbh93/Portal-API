import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux';

import './_claimNew.less';

import { AutoSuggestDropdown } from '../../ClaimYourProfileNew/AutoSuggestDropdown';
import SearchProfileNPIModel from '../../ClaimYourProfileNew/SearchProfileByNPIModel';
import { HG3Tracker } from '../../../utils/tracking';
import PropTypes from 'prop-types';
import Spinner from '../../Spinner/Spinner';

//helper imports
import _ from 'lodash';

//service
import * as service from '../../../utils/service';

const ClaimPage = (props) =>{
    const { providerName, isClaimProfile } = props;
    const { landingModelInfo } = useSelector((state) => state.loadLandingModel);
    
    const providerBaseurl = `/api/provider`;
    const locationBaseurl = `/api/location`;

    const [providerAutoSuggestData, setProviderAutoSuggestData] = useState([]);
    const [locationAutoSuggestData, setLocationAutoSuggestData] = useState([]);
    const [showProviderListClass, setShowProviderListClass] = useState('disable');
    const [showLocationListClass, setShowLocationListClass] = useState('disable');
    const [providerInfo, setProviderInfo] = useState({});
    const [locationInfo, setLocationInfo] = useState(landingModelInfo);
    const [toggleNPIModel, setToggleNPIModel] = useState(false);
    const [showSpinner, setShowSpinner] = useState(false);
    const [isButtonDisabled, setIsButtonDisabled] = useState(true);

    const refProviderName = useRef();
    const refLocation = useRef();

    const [isRegisteredProfile, setIsRegisteredProfile] = useState({
        isError: false,
        errorMessage: ''
    });

    
    const locationInputValueChangeHandler = () =>{
        refLocation.current.value.length >= 2
        ? fetchLocationAutoSuggestData()
        : clearlocationfields();
    };
    const clearlocationfields = ()=>{
        setLocationAutoSuggestData([]);
        setIsButtonDisabled(true)
    };
    const providerInputValueChangeHandler = () =>{
        refProviderName.current.value.length >= 2
        ? fetchProviderAutoSuggestData()
        : clearProviderfields();
    };
    const clearProviderfields = ()=>{
        setProviderAutoSuggestData([]);
        setIsButtonDisabled(true)
    };
    const closedNPIModel = () =>{
        setToggleNPIModel(false);
        pageTracker('close');
    };
    const onClickHandler = (e) =>{
        e.preventDefault();
        setToggleNPIModel(true);
        pageTracker('npi-search');
    };
    const pageTracker = (type) => {
        HG3Tracker.OmnitureTrackLink(type !== undefined && type !== null ? type : '');
    };
    const handleClickOutside = (event) => {
        if (refProviderName.current && !refProviderName.current.contains(event.target)) {
          setShowProviderListClass('disable');
        }
        if (refLocation.current && !refLocation.current.contains(event.target)) {
          setShowLocationListClass('disable');
        }
        if (
          document.getElementById('providerName') != null &&
          document.getElementById('providerName') != undefined &&
          document.getElementById('providerName').contains(event.target)
        ) {
          setShowProviderListClass('enable');
        }
        if (
          document.getElementById('locationDropdown') != null &&
          document.getElementById('locationDropdown') != undefined &&
          document.getElementById('locationDropdown').contains(event.target)
        ) {
          setShowLocationListClass('enable');
        }
    };
    //Bind the event listener
    document.addEventListener('mousedown', handleClickOutside);

    
    const fetchLocationAutoSuggestData = () => {
        service
          .get(`${locationBaseurl}?pt=${locationInfo.pt}&term=${refLocation.current.value}`)
          .then((res) => {
            setLocationAutoSuggestData(res);
          })
          .catch((err) => {
            console.log(err);
        });
    };
    const fetchProviderAutoSuggestData = () => {
        service
          .get(`${providerBaseurl}?pt=${locationInfo.pt}&term=${refProviderName.current.value}`)
          .then((res) => {
            setProviderAutoSuggestData(res.Suggestions);
          })
          .catch((err) => { 
            console.log(err);
          });
    };
    const checkRegisterProfile = (provider)=>{
        setIsButtonDisabled(false);

        setProviderInfo(provider);
    }
    const claimClickHandler = (providerId) => {
        if(!isRegisteredProfile.isError){
            pageTracker('getStartedRegistration');
            window.location.href = `${window.location.origin}/account/register/${providerId}`;
        }
    };
    useEffect(() => {
        if (refLocation.current != undefined) refLocation.current.value = locationInfo.location;
    },[]);
    return (
        <div id='claim-main-ul' className='claim-main-page'>
            {toggleNPIModel && <SearchProfileNPIModel closeModal={closedNPIModel} openModel={toggleNPIModel}/>}
            <div className='header-claim'>
                <h1 className='claim-header'>Find your profile</h1>
                {window.innerWidth > 768 && <div className='sub-header-txt'><h3 className={`${isClaimProfile?'claim-sub-header enabled': 'claim-sub-header'}`}>{`If you're not ${!_.isEmpty(providerName)?providerName:''}, you can find and claim your free Healthgrades for Professionals profile`}</h3></div>}
            </div>
            <div className='claim-note-txt'>
                Your <span className='claim-note-highlight'>DEA</span> or <span className='claim-note-highlight'>State license number</span> is required for verification.
            </div>
            <div>
                <div className='input-group' id='location-input-field' title='Enter City, State or Zip'>
                    <label htmlFor='txtLocation'>Location</label>
                    <input
                    id='txtLocation'
                    placeholder='Enter City, State or Zip'
                    type='text'
                    onChange={locationInputValueChangeHandler}
                    onFocus={(e) => setShowLocationListClass('enable')}
                    ref={refLocation}
                    autoComplete='off'
                    />
                    {locationAutoSuggestData.length > 0 && (
                    <AutoSuggestDropdown
                        dropDownName={'locationDropdown'}
                        keyWord={refLocation.current.value}
                        suggestions={locationAutoSuggestData.map((data) => {
                        return {
                            text: data.value,
                            value: data.pt,
                            data: data
                        };
                        })}
                        showList={showLocationListClass}
                        clickHandler={(locationData) => {
                            refLocation.current.value = locationData.value;
                            setLocationInfo(locationData);
                            setLocationAutoSuggestData([]);
                            pageTracker('location');
                        }}
                    />
                    )}
                </div>
                <div className='input-group' id='name-input-field' title='Medical Professional’s Name'>
                <label htmlFor='txtProviderName'>Medical Professional’s Name</label>
                    <input
                        id='txtProviderName'
                        placeholder='Medical Professional’s Name'
                        type='text'
                        // className={`${isRegisteredProfile.isError?'error':'search'}`}
                        onChange={providerInputValueChangeHandler}
                        onFocus={(e) => setShowProviderListClass('enable')}
                        ref={refProviderName}
                        autoComplete='off'
                    />
                    {providerAutoSuggestData.length > 0 && (
                        <AutoSuggestDropdown
                            dropDownName={'providerName'}
                            keyWord={refProviderName.current.value}
                            suggestions={providerAutoSuggestData.map((data) => {
                            return {
                                text: `${data.Text} - ${data.AdditionalFieldValues}`,
                                value: data.Id,
                                data: data
                            };
                            })}
                            showList={showProviderListClass}
                            clickHandler={(provider) => {
                                pageTracker('providername');
                                refProviderName.current.value = provider.Text;
                                setProviderAutoSuggestData([]);
                                checkRegisterProfile(provider);
                                
                            }}
                        />
                    )}
                
                </div>
                <div className='profile-claim-btn'>
                    <button
                        className={`${(refLocation.current==undefined || _.isEmpty(refLocation.current.value)) || isButtonDisabled?'claim-btn disabled':'claim-btn'}`}
                        disabled= {(refLocation.current==undefined || _.isEmpty(refLocation.current.value)) || isButtonDisabled}
                        type='button'
                        id='btn-claim'
                        name='claimtab'
                        title='Claimtab'
                        onClick={()=>claimClickHandler(providerInfo.Id)}>
                        Find Your Profile
                    </button>
                </div>
            </div>
            <div className={`${isClaimProfile?'dv-contact-us claim-page':'dv-contact-us'}`}>
                <span className='contact-us-txt'>
                    Unable to find your profile? {window.innerWidth <= 768 && <br/>} <a href='/' onClick={(e)=> onClickHandler(e)}>Try our NPI based search</a> or <a  onClick={(e)=>pageTracker('contact-us')} href='/contactus'>Contact us</a>
                </span>
            </div>
            <>{showSpinner && <Spinner />}</>
        </div>
    )
};

ClaimPage.defaultProps = {
    providerName: '',
    isClaimProfile: false
};

ClaimPage.propTypes = {
    providerName: PropTypes.string,
    isClaimProfile: PropTypes.bool
};

export default ClaimPage;