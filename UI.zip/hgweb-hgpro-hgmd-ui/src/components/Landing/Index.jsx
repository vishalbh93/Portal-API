import React,{ Fragment } from "react";

import './_index.less';

import '@hg/joy/src/globalstyles';

import LandingCard from './LandingCard';
import Footer from '../Common/Footer/Footer';

const Index = (props) => {
  
    return (
        <Fragment>
            <LandingCard />
            <Footer />
        </Fragment>
    );
};

export default Index;