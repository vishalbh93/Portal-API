import React, { useState } from "react";

import './_providerCard.less';

import PropTypes from 'prop-types';

import Cta from '../../Common/Form/CTA/Cta';

import * as Constant from '../constants';
import { HG3Tracker } from '../../../utils/tracking';

const ProviderCard = (props) =>{
    const {providerInfo} = props;
    const [isNotProfile, setIsNotProfile] = useState(true);

    const handleNotProfile = () =>{
        let element = document.getElementsByClassName("banner-claim-header");
        for(var i = 0; i < element.length; i++)
        {    
            element[i].classList.add('display-none');   
        }
        setIsNotProfile(false);
        HG3Tracker.OmnitureTrackLink('not-my-profile');
    };
    const handleClaimProfile = (e,providerId) => {
        HG3Tracker.OmnitureTrackLink('getStartedProfileRegistration');
        e.preventDefault();
        window.location.href = `${window.location.origin}/account/register/${providerId}`;
    };
    return (
        <div className='div-card-section' id='div-card-section-id'>
            <div className='banner-claim-header'>
                <span className='sub-header-section'>
                    {window.innerWidth > 768&& `Are you ${providerInfo.DisplayFullName2}? We noticed you came from their profile.` }
                </span>
            </div>
            <div className='main-provider-card'>
                {window.innerWidth <= 768 && <div className='banner-claim-header'>
                    <span className='sub-header-section'>
                            We noticed you came from {providerInfo.DisplayFullName2}’s profile. Is this you?
                    </span>
                </div>}
                {isNotProfile?<div className='card-wrapper'>
                    <div className='card-inner-main'>
                        <section id='provider-card-info' className='div-provider-card'>
                            <img 
                                className='provider-img'
                                src={providerInfo.ImageUrl}
                                alt={providerInfo.DisplayFullName}
                                title={providerInfo.DisplayFullName}/>
                            <div className='provider-info-desc' title={providerInfo.DisplayFullName}>
                                <div className='name-specialty-section'>
                                    <span className='provider-info-name'>{providerInfo.DisplayFullName2}</span> <div className='div-specialty'>{providerInfo.PrimarySpecialty}</div>
                                </div>
                                <span className='provider-address-section'>{providerInfo.Address}, {providerInfo.CityStateZip}</span>
                            </div>
                        </section>
                    </div>
                    <div className='card-button'>
                        <Cta
                            ctaValid={true}
                            cancelText={`Not My Profile`}
                            cancelClickHandler={handleNotProfile}
                            confirmText={`Claim Your Profile`}
                            confirmClickHandler={(e) =>handleClaimProfile(e,providerInfo.ProviderId)}
                        />
                    </div>
                </div>:
                <div className='feedback-msg'>
                    <div className='div-hg-logo'>
                        <img className='hg-logo-img' src={Constant.hgLandingLogo} alt='hg-logo-tag'/>
                    </div>
                    <div className='feedback-txt-section'>{`Thank you for letting us know! We value your feedback.`}</div>
                </div>}
            </div>
        </div>
    );
};

ProviderCard.defaultProps = {
    providerInfo: {}
};

ProviderCard.propTypes = {
    providerInfo: PropTypes.object
};

export default ProviderCard;