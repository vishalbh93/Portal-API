import React, { useState, useEffect, Fragment } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import './_login.less';

import * as actions from '../../../store/actions';
import isEmpty from '../../../utils/validation/isEmpty';
import TextValidation from '../../../utils/validation/isTextValid';
import ValidationErrorMessage from '../../FormComponents/ValidationErrorMessage';
import showPassword from '../../../assets/images/show_password.svg';
import hidePassword from '../../../assets/images/icon_hidepassword.svg';
import { getQueryStringsFragment } from '../../../utils/utils';

import Spinner from '../../Spinner/Spinner';
import { HG3Tracker } from '../../../utils/tracking';

const Login = () =>{
    const [displaySpinner, setDisplaySpinner] = useState(false);
    const dispatch = useDispatch();
    const {landingsuccess, landingerrorMsg ,landredirectUrl} = useSelector((state) => state.landingReducer);
    const { landingModelInfo } = useSelector((state) => state.loadLandingModel);
    const [showErrorModal, setShowErrorModal] = useState(false);
    const [togglePassword, setTogglePassword] = useState(true);
  
    const isPasswordEmptyField = { isValid: false, error: 'The password is required' };
    const isUserNameRequired = {
      isValid: false,
      error: 'The email or user name is required'
    };
  
    const [loginModel, setLoginModel] = useState({
      email: '',
      password: '',
      rememberMe: false,
      returnUrl: '',
      userName: ''
    });
    let queryString = getQueryStringsFragment();
  
    const [isEmailEmpty, setEmailValidation] = useState({
      isValid: true,
      error: ''
    });
  
    const [isPasswordEmpty, setPasswordValidation] = useState({
      isValid: true,
      error: ''
    });
  
    const validateInput = () => {
      if (isEmpty(loginModel.userName)) {
        setEmailValidation(isUserNameRequired);
      } else {
        userNameValidation(loginModel.userName.trim());
      }
  
      if (isEmpty(loginModel.password)) {
        setPasswordValidation(isPasswordEmptyField);
      }
  
      return !isEmpty(loginModel.userName) && !isEmpty(loginModel.password);
    };
  
    const userNameValidation = (userName) => {
      let regex = /[^0-9A-Za-zÀ-ÿ'_@.\+\\-]/g;
      const result = userName.match(regex);
      const isObject = (value) => typeof value === 'object' && value !== null;
      if (isObject(result) === true) {
        setEmailValidation({
          isValid: false,
          error: `Your username contains invalid characters ( ${result.join(' ')})`
        });
      } else if (userName.indexOf('@') != -1) {
        setEmailValidation(TextValidation(userName, 'emailaddress'));
      } else {
        setEmailValidation({
          isValid: false,
          error: ''
        });
      }
    };
  
    const changeHandler = (e) => {
      switch (e.target.id) {
        case 'userName':
          setLoginModel({ ...loginModel, email: e.target.value, userName: e.target.value });
          if (isEmpty(e.target.value)) {
            setEmailValidation(isUserNameRequired);
          } else {
            userNameValidation(e.target.value.trim());
          }
          break;
  
        case 'password':
          setLoginModel({ ...loginModel, password: e.target.value });
          if (isEmpty(e.target.value)) {
            setPasswordValidation(isPasswordEmptyField);
            setShowErrorModal(false);
          } else setPasswordValidation({ isValid: false, error: '' });
          break;
  
        case 'rememberMe':
          setLoginModel({ ...loginModel, rememberMe: e.currentTarget.checked });
          break;
      }
    };
  
    const loginClickHandler = (e) => {
      setDisplaySpinner(false);
      e.preventDefault();
      pageTracker('Login')
      if (validateInput()) {
        setDisplaySpinner(true);
        dispatch(actions.loginNew(loginModel, setDisplaySpinner));
      }
    };
  
    const onKeyPressed = (e) => {
      let code = e.keyCode || e.which;
      if (code === 13) {
        e.preventDefault();
        loginClickHandler(e);
      }
    };
  
    const isValidURL = (url) => {
      var regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
      if (!regex.test(url)) {
        return false;
      } else {
        return true;
      }
    };

    const pageTracker = (type) => {
      HG3Tracker.OmnitureTrackLink(type !== undefined && type !== null ? type : '');
    };
  
    useEffect(() =>{
      if (queryString != undefined && queryString != '')
        setLoginModel({ ...loginModel, returnUrl: queryString.returnurl });
    },[]);
  
    useEffect(() => {
      if (landingsuccess) {
        let url = landredirectUrl;
        url = decodeURIComponent(url);
        if (url.charAt(0) == '/') {
          url = url.slice(1);
        }
        setDisplaySpinner(false);
        if (isValidURL(url)) {
          window.location.replace(url);
        } else {
          window.location.href = `${window.location.origin}/${url}`;
        }
      } else if (landingerrorMsg != '') {
        setDisplaySpinner(false);
        setShowErrorModal(true);
      }
    }, [landingsuccess, landredirectUrl, landingerrorMsg]);
  
    useEffect(() => {
      if (landingModelInfo.userName != null) {
        setLoginModel({
          ...loginModel,
          rememberMe: false,
          userName: landingModelInfo.userName
        });
      } else {
        setLoginModel({
          ...loginModel,
          email: '',
          password: '',
          rememberMe: false,
          returnUrl: '',
          userName: ''
        });
      }
  
      if (queryString != undefined && queryString != '')
        setLoginModel({ ...loginModel, returnUrl: queryString });
    }, [landingModelInfo]);
    
    return (
        <div id='login-form' className='login-form-group'>
          <h1 className='login-header'>Log in</h1>
            <div className='input-group' title='Email or username'>
            <label htmlFor='userName'>Email or Username</label>
            <input
                id='userName'
                placeholder='Your Email or Username'
                type='text'
                autoComplete='off'
                onChange={changeHandler}
                value={loginModel.userName}
            />
            {!isEmailEmpty.isValid && <ValidationErrorMessage message={isEmailEmpty.error} />}
            </div>
            <div className='input-group' title='Password'>
              <label htmlFor='password'>Password</label>
              <input
                  id='password'
                  placeholder='Enter Password'
                  type={togglePassword ? 'password' : 'text'}
                  autoComplete='off'
                  className='password'
                  onKeyPress={onKeyPressed}
                  onChange={changeHandler}
                  value={loginModel.password}
              />
              <div className={`pswd-toggle`}>
                  <div className='toggle-password' id='togglePassword'>
                  <label htmlFor='togglePassword'>
                      <div>
                      {!togglePassword ? (
                          <img
                          className='hidePassword'
                          src={hidePassword}
                          alt='hidePassword'
                          onClick={() => setTogglePassword(!togglePassword)}
                          />
                      ) : (
                          <img
                          className='showPassword'
                          src={showPassword}
                          alt='showPassword'
                          onClick={() => setTogglePassword(!togglePassword)}
                          />
                      )}
                      </div>
                  </label>
                  </div>
              </div>
              <div className='password-error-msg'>
                {!isPasswordEmpty.isValid && !showErrorModal && <ValidationErrorMessage message={isPasswordEmpty.error} />}
              </div>
            </div>
            {showErrorModal && (
                    <Fragment>
                      <div className='warning-msg' dangerouslySetInnerHTML={{ __html: landingerrorMsg }}></div>
                    </Fragment>
            )}
            <div className='input-group' title='RememberMe' id='div-remember-me'>
              <div className='check-section'>
                <input
                    id='rememberMe'
                    type='checkbox'
                    onChange={changeHandler}
                    checked={loginModel.rememberMe}
                    value={loginModel.rememberMe}></input>
                <label id='rememberMeLabel' className='remember' htmlFor='rememberMe'>
                    Remember me for 30 days
                </label>
              </div>
              <div className='forgot-section'>
              <a href='/account/forgot-password' alt='Forgot Password' className='forgot-password'>
                  Forgot Password?
              </a>
            </div>
            </div>
            <div className='provider-info-button-section'>
            <button
                className='land-login-btn'
                type='button'
                id='btn-login'
                name='login'
                title='Login'
                onClick={loginClickHandler}>
                Login
            </button>
            </div>
            
            <>{displaySpinner && <Spinner />}</>
        </div>          
    );
};

export default Login;




