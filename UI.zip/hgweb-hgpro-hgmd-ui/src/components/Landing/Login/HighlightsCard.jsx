import React from "react";
import './_highlightsCard.less';
import PropTypes from 'prop-types';

import * as Constant from '../constants';

import HighLightSection from '../Claim/Highlights.jsx';

const HighlightsCard = (props) => {
    const {currentTab, onClickHandler} =props;

    return (
        <div id='a-graph-section' className='graph-section'>
            {currentTab?<><div className='div-hg-logo'>
                <img className='hg-logo-img' src={Constant.hgLandingLogo} alt='hg-logo-tag'/>
            </div>
            <div className='div-txt-msg'>{`Don't have an account with us yet? Join for free.`}</div>
            <div className='claim-btn'>
                <button
                    className='land-btn'
                    disabled={false}
                    type='button'
                    id='btn-login'
                    name='claim'
                    title='claim'
                    onClick={()=>onClickHandler()}>
                    Claim Your Profile
                </button>
            </div></>:
            <div className='claim-highlight-section'>
                <div className='heading-sec-gr'>
                    <div className='head-section-msg'>{`Join the leading destination of patients searching for healthcare professionals`}</div>
                    <HighLightSection />
                </div>
            </div>}
            <div className={`${ currentTab?'div-land-img': 'claim-land-img' }`}>
                <img className='msk-grp-img' src={Constant.maskLandImg} alt='msk-land-tag'/>
            </div>
        </div>
    );
};
HighlightsCard.propTypes = {
    currentTab: PropTypes.bool,
    onClickHandler: PropTypes.func
};
  
HighlightsCard.defaultProps = {
    currentTab: true,
    onClickHandler: ()=>{}
};

export default HighlightsCard;