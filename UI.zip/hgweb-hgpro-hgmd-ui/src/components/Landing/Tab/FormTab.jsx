import React, { useEffect, useState} from 'react';
import './_formTab.less';

import LayoutA from '../../Common/Layouts/LayoutA';
import NavTabs from '../../Common/Navigation/Tab/Tabs';

import * as trackingService from '../../ProviderProfile/trackingServices';

const FormTab = (props) =>{
    const {tabDetails, currentTab} = props;
    const [currentSelection, setCurrentSelection] = useState(currentTab);
    
    const tabSelectionhandler = (tab) => {
        trackingService.editPageTracking('landingpage', 'select', 'searchsection');
        setCurrentSelection(tab);
        props.selectHandler(tab);
    };

    const _header = (
        <NavTabs
          tabs={tabDetails}
          onSelectHandler={tabSelectionhandler}
          selectedTab={currentSelection}
        />
    );
    const _footer = <></>;

    useEffect(() => {
        setCurrentSelection(currentTab);
    },[currentTab]);

    return (
        <div id='form-section' className='form-g-sec'>
            <div className='content-section'>
                <LayoutA identifier='tab-selection' header={_header} footer={_footer}>
                    <div id='div-tab-selection-main'>
                    </div>
                </LayoutA>
            </div>
        </div>
    );
};

FormTab.defaultProps = {
    selectHandler: function () {}
};
export default FormTab;