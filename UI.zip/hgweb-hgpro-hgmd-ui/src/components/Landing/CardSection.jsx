import React,{useState, Suspense, lazy, useEffect } from "react";
import './_cardSection.less';

import TabSection from './Tab/FormTab';
import * as Constant from './constants';

import GraphSection from './Login/HighlightsCard';
import ClaimPage from './Claim/ClaimNew';

import PropTypes from 'prop-types';

const LoginForm = lazy(() => import('./Login/Login'));


const CardSection = (props) => {
    const {isClaimPage, isClaimProfile, providerName, tabState} = props;
    const [selectedTab, setSelectedTab] = useState(Constant.tabSection[0]);

    const selectHandler = (val) => {
        setSelectedTab(val);
    };
    const onContainerHandler = () =>{
        setSelectedTab(Constant.tabSection[1]);
    };
    useEffect(()=>{
         setSelectedTab(isClaimPage? Constant.tabSection[1]:Constant.tabSection[0]); 
    },[isClaimPage]);

    useEffect(() =>{
        tabState(selectedTab.label.toLowerCase() === 'log in');
    },[selectedTab]);

    return (
        <div id='main-section' className='div-main-section'>
            <div className={`${selectedTab.label =='Log in'?'content-div-section': 'content-div-section claim'}`}>
                {
                    Constant != undefined && Constant.tabSection != undefined && 
                        <TabSection 
                        tabDetails={Constant.tabSection}
                        currentTab={selectedTab}
                        selectHandler={selectHandler}/>
                }
                <div>
                    {
                        selectedTab != undefined && selectedTab.label == 'Log in'? 
                            <Suspense fallback=''>
                                <LoginForm />
                            </Suspense> :<ClaimPage providerName={providerName} isClaimProfile={isClaimProfile}/>
                    }
                </div>
            </div>
            <div className={`${selectedTab.label.toLowerCase() === 'log in'?'div-grp-sec':'div-grp-sec claim-grp'}`}>
                <GraphSection 
                    onClickHandler={onContainerHandler} 
                    currentTab={selectedTab != undefined && selectedTab.label.toLowerCase() === 'log in'}/>
            </div>
        </div>);
};

CardSection.defaultProps = {
    providerName: '',
    isClaimPage: false,
    isClaimProfile: false,
    tabState: () => {}
};

CardSection.propTypes = {
    providerName: PropTypes.string,
    isClaimPage: PropTypes.bool,
    isClaimProfile: PropTypes.bool,
    tabState: PropTypes.func
};
export default CardSection;