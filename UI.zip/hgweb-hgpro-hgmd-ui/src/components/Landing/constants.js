export const maskImg = '/public/images/landingPage/maskgroup.svg';
export const maskLandImg = '/public/images/landingPage/illustratelogo.png';
export const hgLandingLogo = '/public/images/landingPage/hglogo.png';
export const icondoctor = '/public/images/landingPage/icon-doctor.svg';
export const iconperson = '/public/images/landingPage/icon-person.svg';
export const iconreferrals = '/public/images/landingPage/icon-referrals.svg';
export const icondoctoronline = '/public/images/landingPage/icon-doctoronline.svg';

export const tabSection = [
    {
        label: 'Log in',
        badgeEnabled: false
    },
    {
        label: 'Find Your Profile',
        badgeEnabled: false
    }
    
];
