import React, { useEffect, useState } from "react";
import { useSelector } from 'react-redux';

import './_landingCard.less';
import * as service from '../../utils/service';
import * as constant from './constants.js';

import BrandingLogos from '../Common/BrandingLogos';
import CardSection from './CardSection.jsx';
import Spinner from '../Spinner/Spinner';

import ProviderCard from './Card/ProviderCard.jsx';

import _ from 'lodash';

const LandingCard = () => {
    const { landingModelInfo } = useSelector((state) => state.loadLandingModel);
    const [providerInfo, setProviderInfo] = useState({});
    const [showSpinner, setShowSpinner] = useState(false);

    const registerAccountBaseurl = `/api/account/register-provider`;
    const [tabChangeState, setTabChangeState] = useState(false);

    const fetchProviderInfo = (providerId, byNpi) => {
        setShowSpinner(true);
        service
          .get(
            `${registerAccountBaseurl}?pt=${landingModelInfo.pt}&providerId=${providerId}&byNpi=${byNpi}`
          )
          .then((res) => {
            if (res === null) setProviderInfo({});
            else setProviderInfo(res);
          })
          .catch((err) => { })
          .finally(() => setShowSpinner(false));
    };

    const onClickTabHandler =(currentState) => {
        setTabChangeState(currentState);
    };

    useEffect(()=>{
        if(landingModelInfo.claimProfile){
            fetchProviderInfo(landingModelInfo.providerValue, (landingModelInfo.providerType).toLowerCase() == 'npi');
        }
    },[landingModelInfo.claimProfile]);
    return (
    <>
        {landingModelInfo.claimProfile && <div className='provider-card-section'>
            <ProviderCard providerInfo={providerInfo}/>
        </div>}
        <div className={`${landingModelInfo.claimProfile?'body-section pad-off': 'body-section'}`}>
            <div className={`${tabChangeState?'landing-inner-section':'landing-inner-section ad-space'}`}>
                <div className={`${landingModelInfo.claimProfile? 'landing-main-wrapper card': 'landing-main-wrapper'}`}>
                    <CardSection 
                        isClaimPage={landingModelInfo.isClaimPage} 
                        isClaimProfile={landingModelInfo.claimProfile} 
                        providerName={!_.isEmpty(providerInfo)?providerInfo.DisplayFullName2:''}
                        tabState={onClickTabHandler}/>
                    <div className='div-img'>
                        <img className='msk-grp-img' src={constant.maskImg} alt='msk-tag'/>
                    </div>
                </div>
            </div>
            <>{showSpinner && <Spinner />}</>
        </div>
        <div className={`${landingModelInfo.claimProfile?'brand-logo-section move-up':'brand-logo-section move-down'}`}>
            <BrandingLogos />
        </div>
    </>
    );
};

export default LandingCard;