import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import React from 'react';
import Footer from '../Common/Footer/Footer';
import MenuComponent from '../Common/Menu/Menu';
import _ from 'lodash';
import LandingBanner from './LandingBanner/LandingBanner.jsx';

//stylesheet imports
import './_index.less';
import LandingPage from './LandingPage';
// import CinebodyBanner from './Cinebody/CinebodyBanner/CinebodyBanner.jsx';
// import Cinebodymain from './Cinebody/Cinebodymain.jsx';
import OutCareInner from './OutCare/OutCareInner';
import OutCareBanner from './OutCare/OutCareBanner';

const Index = () => {
  /* #region selector */
  const { marketPlaceData } = useSelector((state) => state.loadMarketPlace);
  /* #endregion */

  /* #region constants and states */

  let menuItems = marketPlaceData.model.Navigations;
  const providerCode = marketPlaceData.model.NavigationModel.ProviderId;
  const displaySelfServiceLink = marketPlaceData.displaySelfServiceLink;
  const isEnhanced =
    displaySelfServiceLink != undefined && displaySelfServiceLink == false ? true : false;
  const premiumSiteURL = marketPlaceData.premiumSiteURL;
  let isMobileView = window.innerWidth <= 768;

  const [currentStage, setCurrentStage] = useState('landing_page');

  const trustedPartnersHandler = (e, val) => {
    setCurrentStage(val);
    window.scrollTo(0, 0);
  };

  const _main = (state) => {
    switch (state) {
      case 'landing_page':
        return (
          <div className={isEnhanced ?'sec-detail-enhanced hide-bottom' : 'sec-detail-standard'}>
            <LandingPage trustedPartners={trustedPartnersHandler} />
          </div>
        );
      // Hide the below line under MD-1117 
      //case 'cinebody':
      //   return <Cinebodymain />;
      case 'outcare':
        return <OutCareInner trustedPartners={trustedPartnersHandler} />;
    }
  };

  const _banner = (state) => {
    switch (state) {
      case 'landing_page':
        return <LandingBanner premiumSiteURL={premiumSiteURL} isEnhanced={isEnhanced} />;
      // hide this below line under MD-1117
      //case 'cinebody':
      //   return (
      //     <CinebodyBanner trustedPartners={trustedPartnersHandler} providerCode={providerCode} />
      //   );
      case 'outcare':
        return (
          <OutCareBanner trustedPartners={trustedPartnersHandler} providerCode={providerCode} />
        );
    }
  };

  useEffect(() => {
    let hashposition = _.indexOf(window.location.href, '#');
    let sectionName =
      hashposition != -1 ? _.slice(window.location.href, hashposition + 1).join('') : null;
    !_.isEmpty(sectionName) ? setCurrentStage(sectionName) : null;
  }, []);
  //#region JSX
  return (
    <div className='section-provider-marketplace-tool'>
      <div className={`menu-banner ${isEnhanced && isMobileView && 'sm-enhanced-menu-banner'}`}>
        <MenuComponent
          showMenus={true}
          infoObject={marketPlaceData.model.NavigationModel}
          menuItems={menuItems}
          providerInfo={
            marketPlaceData.details != undefined && Object.keys(marketPlaceData.details).length > 0
              ? JSON.parse(marketPlaceData.details)
              : {}
          }
        />
        {_banner(currentStage)}
      </div>
      <div className='main-inner-content'>{_main(currentStage)}</div>
      <div className='footerNew'>
        <Footer />
      </div>
    </div>
  );
  // #endregion
};

export default Index;
