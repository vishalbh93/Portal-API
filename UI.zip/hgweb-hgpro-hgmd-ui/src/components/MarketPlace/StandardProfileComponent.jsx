import React from 'react';

//import stylesheet
import './_standardProfileComp.less';
import Button from '@hg/joy/src/components/Button/Button';

//media imports
import * as constants from './Constants/Constants';

import { HG3Tracker } from '../../utils/tracking';

const StandardProfileComponent = ({premiumSiteURL}) => {
  const checkmark =constants.landingBannerImage.checkMarkWhite;
  const stdMaskImage =constants.landingBannerImage.stdMaskImage;
  let isMobileView = window.innerWidth <= 768;

  const redirectToPremium = () => {
    HG3Tracker.OmnitureTrackLink('hgmd:selfservice:landing');
    let fullPath = premiumSiteURL;
    window.open(fullPath, '_blank') || window.location.replace(fullPath);
  };

  return (
    <div className='div-std-section'>
      <div className='div-compare-intro'>
        <div className='div-compare-intro-inner-head'>Do more with Healthgrades Profile</div>
        <div className='div-compare-intro-inner-plan'>
          {!isMobileView
            ? <><span>Millions of people search Healthgrades everyday.</span><br/>
            <span>Elevate your profile with an Enhanced program.</span>
            </>: 'Millions of people search Healthgrades everyday. Elevate your profile with an Enhanced program.'}
        </div>
        {false &&<div className='div-compare-intro-inner-plan'>
          Plans are as low as <b>$12 per month</b>.
        </div>}

        {!isMobileView && (
          <Button
            id='compare_plans'
            text='Compare Plans'
            color='Neutral'
            size='lg'
            variant='outlined'
            onClick={() => redirectToPremium()}
          />
        )}
        <div className='div-sub-enhanced-profile'></div>
      </div>
      {!isMobileView && <img className='stdMaskImage' src={stdMaskImage} alt='mask-Image'></img>}
      <div className='div-std-enhanced'>
        <div className='div-sub-std-profile'>
          <div className='div-s-std-tag'>
            <div className='div-sub-std-tag'>CURRENT PLAN</div>
          </div>
          <div className='div-sub-std-profile-inner'>
            <div className='div-sub-std-profile-inner-head'>Standard Profile</div>
            <div className='div-sub-std-profile-inner-plan'>Free Plan</div>
            <div className='div-sub-std-profile-inner-details'>
              Standard Profile misses out on additional features that come along Enhanced Profiles.
            </div>
          </div>
        </div>
        <div className='div-sub-enhanced-profile'>
          <div className='div-std-tag'>
            <div className='div-sub-enhanced-tag'>BEST VALUE</div>
          </div>
          <div className='div-sub-enhanced-profile-inner'>
            <div className='div-sub-enhanced-profile-inner-head'> Enhanced Profile</div>
            <div className='div-sub-enhanced-profile-inner-list'>
              <div className='div-sub-std-profile-inner-text'>
                <div className='checkmark'>
                  <img src={checkmark} alt='' className='checkmark'></img>
                </div>
                <div>Call-to-Action Buttons</div>
              </div>
              <div className='div-sub-std-profile-inner-text'>
                <div className='checkmark'>
                  <img src={checkmark} className='checkmark'></img>
                </div>
                <div>Removal of Consumer Ads</div>
              </div>
              <div className='div-sub-std-profile-inner-text'>
                <div className='checkmark'>
                  <img src={checkmark} className='checkmark'></img>
                </div>
                <div>Removal of Competitve Provider Ads</div>
              </div>
            </div>
            <a className='div-sub-enhanced-profile-kmore'  onClick={() => redirectToPremium()}>
              Know more
            </a>
          </div>
        </div>
      </div>
      
      {isMobileView && (
        <div className='mob-button'>
          <Button
            id='compare_plans'
            text='Compare Plans'
            color='Neutral'
            size='lg'
            variant='outlined'
            onClick={() => redirectToPremium()}
          />{' '}
        </div>
      )}
    </div>
  );
};

export default StandardProfileComponent;
