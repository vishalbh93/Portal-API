import React, { Fragment, useState } from 'react';

import './_cinebody-main.less';

import * as constant from '../Constants/Constants.js';
import Button from '@hg/joy/src/components/Button/Button';

const Cinebodymain = () => {
  const cinebodyPageDetail = constant.cinebodyPageDetailsArr;
  const row_3Content = cinebodyPageDetail.row_3.sections[0];
  const row_1Content = cinebodyPageDetail.row_1;
  const row_2Content = cinebodyPageDetail.row_2;
  let isMobileView = window.innerWidth <= 768;
  const col = _.map(row_1Content, (obj, key) => obj).filter((df, i) => i != 0);

   const IsReadMore = ({ content, maxLength }) => {
    const [isReadmore, setisReadmore] = useState(true);
  
    const toggleisReadmore = () => {
      setisReadmore(!isReadmore);
    };
  
    return (
      <div>
        {isReadmore ? (
          <div>
            {content.slice(0, maxLength)}
            <a className='read_more' onClick={toggleisReadmore}>..Read more</a>
          </div>
        ) : (
          <div>
            {content}
            <a className='read_more' onClick={toggleisReadmore}>..Show less</a>   
          </div>
        )}
      </div>
    );
  };

  return (
    <Fragment>
      <div className='cinebody-inner-container'>
        <div className='cinebody-benifits-1'>
          <div className='cinebody-benifits'>
            <div className='heading-1'>{row_1Content.heading}</div>
            <div className='cinebody-benifits-content'>
              <div className='cinebody-benifits-subcontent'>
                {col.map((card, index) => (
                  <div className='cinebody-benifits-card' key={index} >
                    {isMobileView && (
                      <div className='cinebody-benifits-card-heading'>{card.subheading}</div>
                    )}
                    <img className='cinebody-benifits-card-logo' src={card.image}></img>
                    <div className='cinebody-benifits-card-info'>
                      {!isMobileView && (
                        <div className='cinebody-benifits-card-heading'>{card.subheading}</div>
                      )}
                      <div id = {card.subheading} className='cinebody-benifits-card-text'>
                      {isMobileView ? <IsReadMore key={index} content={card.content} maxLength={105}/> :card.content}                        
                      </div>
                    </div>
                    <hr></hr>
                  </div>                  
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className='cinebodyAdv-description'>
          <div className='cinebodyAdv-description-1'>
            {!isMobileView && <img src={row_2Content.watermark} className='cinebodyAdv-description-dots' />}
            <img src={row_2Content.image} className='cinebodyAdv-description-image' />
            <div className='cinebodyAdv-description-text'>
            Looking to increase user engagement on your profile and to establish a connection with
    potential patients? Healthgrades has found that those who watched a video on a
    provider's profile were <span className='cinebodyAdv-description-fifty'>50</span>
    <span className='cinebodyAdv-description-perc'>%</span> more likely to contact their
    practice.
              
              
              </div>
          </div>
        </div>

        <div className='cinebody-personalizedHCare'>
          <div className='PersonalizedHCare-content-subsection'>
            <div className='PersonalizedHCare-detail-sub-section'>
              <div className='PersonalizedHCare-detail-sub-section-inner-details'>
                <div className='PersonalizedHCare-detail-sub-section-inner'>
                  <div className='PersonalizedHCare-details-sub-section-header'>
                    {row_3Content.header}
                    
                  </div>
                  {isMobileView && (                     
                        <img className='PersonalizedHCare-detail-sub-section-inner-doc'
                          src={row_3Content.img}></img>
                    )}
                  <div className='PersonalizedHCare-details-sub-section-list'>
                    <ul>
                      {row_3Content.content.map((content) => (
                        <li>{content}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className='PersonalizedHCare-button'>
                  <Button
                    size='xl'
                    style='secondary'
                    text='Get Started'
                    variant='outlined'
                    href={'https://www.filmoncinebody.com/?pCID=hgpro-trustedpartner-cinebody'}
                  />
                </div>
              </div>
            </div>
            {!isMobileView && (
              <div className='PersonalizedHCare-detail-sub-section-inner-doc'>
                <img src={row_3Content.img} alt={`PersonalizedHCare-detail-section-0`}></img>
              </div>
            )}
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default Cinebodymain;
