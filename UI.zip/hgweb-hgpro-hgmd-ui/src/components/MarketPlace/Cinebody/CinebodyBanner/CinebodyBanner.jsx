import React from 'react';
import { useState } from 'react';

//import stylesheet
import './_cinebody-banner.less';

//components imports
//media imports

import Button from '@hg/joy/src/components/Button/Button';
import * as constant from '../../Constants/Constants.js';

const CinebodyBanner = ({ trustedPartners, providerCode }) => {
  const bannerContent = constant.cinebodyPageDetailsArr.banner;
  const highlightsContent = bannerContent.highlightSection;
  let isMobileView = window.innerWidth <= 768;

  const [is_ReadMore, set_IsReadMore] = useState(true);
  const toggleReadMore = () => {
    set_IsReadMore(!is_ReadMore);
  };

  return (
    <div className='cinebody-banner'>
      <div className='cinebody-banner-container'>
        <div className='banner-inner-container'>
          <svg
            className='hero-background-svg'
            data-qa-target='hero-background-svg'
            preserveAspectRatio='none'
            viewBox='0 0 1442 149'>
            <path
              d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
              fill='#FFFFFF'></path>
          </svg>
          <svg
            className={`hero-background-svg-mobile ${'hero-background-svg-mobile-landing'}`}
            data-qa-target='hero-background-svg-mobile'
            preserveAspectRatio='none'
            viewBox='0 0 375 120'>
            <path
              d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
              fill='#FFFFFF'></path>
          </svg>
          {!isMobileView &&<img className='cinebody-banner-mask' src={bannerContent.bannerMaskImage}></img>}
        </div>
        <div className='cinebody-banner-content'>
          <div className='cinbody-header'>
            <div className='cinebody-header-content'>
              <div className='breadcrumb'>
                <a className={`breadcrumb-a-text`} href={`../provider/profile/${providerCode}`}>
                  {bannerContent.bannerCont.breadCrum[0]}
                </a>
                <img className='chevronright' src={bannerContent.bannerCont.chevronrightImg}></img>
                <a
                  className={`breadcrumb-a-text`}
                  onClick={(e) => {
                    trustedPartners(e, 'landing_page');
                  }}>
                  {bannerContent.bannerCont.breadCrum[1]}
                </a>
                <img className='chevronright' src={bannerContent.bannerCont.chevronrightImg}></img>
                <div className='breadcrumb-text'>{bannerContent.bannerCont.breadCrum[2]}</div>
              </div>
              <div className='full-logo'>
                <img className='hg-word-mark-white' src={bannerContent.bannerCont.logo[0]}></img>
                <div className='cine-word-mark'>
                  <img className='lineafter' src={bannerContent.bannerCont.logo[1]}></img>
                  <img
                    className='cinebody-Logo-word-mark'
                    src={bannerContent.bannerCont.logo[2]}></img>
                </div>
              </div>

              <div className='heading-1'>{bannerContent.bannerCont.subheader}</div>
              {isMobileView && (
                <img className='cinebody-banner-image-sub' src={bannerContent.bannerImage}></img>
              )}
              <div className='subtitle-1'>
                {isMobileView && is_ReadMore
                  ? bannerContent.bannerCont.content.slice(0, 85)
                  : bannerContent.bannerCont.content}
                {isMobileView && bannerContent.bannerCont.content.length > 85 && (
                  <span onClick={toggleReadMore} className='cineReadMore'>
                    {is_ReadMore ? '..Read_more' : ' ..Show_less'}
                  </span>
                )}
              </div>
              {isMobileView && (
                <div className='cinebody-content-button'>
                  <Button
                    size='xl'
                    style='secondary'
                    text='Get Started'
                    variant='outlined'
                    href='https://www.filmoncinebody.com/?pCID=hgpro-trustedpartner-cinebody'
                  />
                </div>
              )}
            </div>
            {!isMobileView && (
              <div className='cinebody-banner-image'>
                <img className='cinebody-banner-image-sub' src={bannerContent.bannerImage}></img>
                <img className='cinebody-banner-stroke' src={bannerContent.bannerStrokeImage}></img>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className='cinebody-how-works'>
        <div className='cinebody-works'>
          <div className='heading-1'>{highlightsContent.header}</div>
          <div className='cinebody-works-content'>
            <div className='cinebody-works-subcontent'>
              <div className='cinebody-works-card'>
                <div className='cinebody-works-card-logo'>
                  <img src={highlightsContent.col_1.image}></img>
                </div>
                <div className='cinebody-works-card-info'>
                  <div className='cinebody-works-card-heading'>
                    {highlightsContent.col_1.subheading}
                  </div>
                  <div className='cinebody-works-card-text'>{highlightsContent.col_1.content}</div>
                </div>
              </div>
              {!isMobileView ?<img className='verticalLine' src={highlightsContent.VerticalLine}></img>:<img className='horizontalLine' src={highlightsContent.HorizontalLine}></img>}

              <div className='cinebody-works-card'>
                
                <div className='cinebody-works-card-logo'>
                  <img src={highlightsContent.col_2.image}></img>
                </div>                
                <div className='cinebody-works-card-info'>
                  <div className='cinebody-works-card-heading'>
                    {highlightsContent.col_2.subheading}
                  </div>
                  <div className='cinebody-works-card-text'>{highlightsContent.col_2.content}</div>
                </div>
              </div>              
              {!isMobileView ?<img className='verticalLine' src={highlightsContent.VerticalLine}></img>:<img className='horizontalLine' src={highlightsContent.HorizontalLine}></img>}


              <div className='cinebody-works-card'>
                <div className='cinebody-works-card-logo'>
                  <img src={highlightsContent.col_3.image}></img>
                </div>
                <div className='cinebody-works-card-info'>
                  <div className='cinebody-works-card-heading'>
                    {highlightsContent.col_3.subheading}
                  </div>
                  <div className='cinebody-works-card-text'>{highlightsContent.col_3.content}</div>
                </div>
              </div>
            </div>
            <div className='cinebody-works-button'>
              <Button
                size='xl'
                style='secondary'
                text='Get Started'
                variant='outlined'
                href='https://www.filmoncinebody.com/?pCID=hgpro-trustedpartner-cinebody'
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CinebodyBanner;
