import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../../../.storybook/store';
import CinebodyBanner from '../CinebodyBanner';

storiesOf('MarketPlace/Landing/cinebody', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('CinebodyBanner', () => <CinebodyBanner />);
