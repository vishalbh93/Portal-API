import React from 'react';
import _ from 'lodash';
import './_partnersLayout.less';

import Button from '@hg/joy/src/components/Button/Button';

const PartnersLayout = ({ content, onTabsChangeHandler }) => {
  const data = content;
  const i = data.sections[0];
  let isMobileView = window.innerWidth <= 768;

  return (
    <div className={`${data.sections[0].id % 2 == 0 ? 'sec-detail-even' : 'sec-detail-odd'}`}>
      <div
        className={`div-content-subsection ${
          data.sections[0].id % 2 == 0 ? 'row-reverse' : 'row'
        }`}>
        <div className='div-detail-sub-section'>
          <div className='div-detail-sub-section-inner-logo'>
            <img
              className='trustedparteners-logo'
              src={data.headerLogo.logo}
              alt={`div-header-logo`}></img>
          </div>
          <div className='div-detail-sub-section-inner-details'>
            <div className='div-detail-sub-section-inner'>
              <div className='div-details-sub-section-header'>{i.header}</div>
              {isMobileView && (
                <div className='div-detail-sub-section-inner-doc'>
                  <img className='main-image' src={i.img} alt={`div-detail-section-0`}></img>
                </div>
              )}
              <div className='div-details-sub-section-list'>
                <ul>
                  {i.content.map((content) => (
                    <li>{content}</li>
                  ))}
                </ul>
              </div>
            </div>
            <div className='trusted-partener-button'>
              {i.sectionName != 'providerReferral' ? (
                <Button
                  id={i.sectionName}
                  text={i.button}
                  color='Neutral'
                  size='lg'
                  variant='outlined'
                  className='div-detail-sub-section-button'
                  onClick={(e) => {
                    onTabsChangeHandler(e, i.sectionName);
                  }}
                />
              ) : (
                <Button
                  id={i.sectionName}
                  text={i.button}
                  color='Neutral'
                  size='lg'
                  variant='outlined'
                  className='div-detail-sub-section-button'
                  href='../providerReferral/index'
                />
              )}
            </div>
          </div>
        </div>
        {!isMobileView && (
          <div className='div-detail-sub-section-inner-doc'>
            <img src={i.img} alt={`div-detail-section-0`}></img>
          </div>
        )}
      </div>{' '}
    </div>
  );
};

export default PartnersLayout;
