import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../../.storybook/store';
import LandingBanner from '../LandingBanner';

storiesOf('MarketPlace/Landing', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('LandingBanner', () => <LandingBanner />);
