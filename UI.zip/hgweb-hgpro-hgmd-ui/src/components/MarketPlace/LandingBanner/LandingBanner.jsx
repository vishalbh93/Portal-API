import React from 'react';

//import stylesheet
import './_landingBanner.less';

//components imports
import StdEnhanceComp from '../StandardProfileComponent';

//media imports

const LandingBanner = ({premiumSiteURL, isEnhanced}) => {
  let isMobileView = window.innerWidth <= 768;
  return (
    <div id={'marketplace-banner'} className= {`${(isMobileView && isEnhanced) ? 'landing-banner-cont-mob':'landing-banner-cont'}`}>
        <div className="banner-content-container">
        <div className='banner-container'>
          <div className={`banner-inner-container ${isEnhanced && 'banner-inner-isEnhanced-container'}`}>
            <svg
              className='hero-background-svg'
              data-qa-target='hero-background-svg'
              preserveAspectRatio='none'
              viewBox='0 0 1442 149'>
              <path
                d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
                fill='#FFFFFF'></path>
            </svg>

            <svg
              className={`hero-background-svg-mobile ${'hero-background-svg-mobile-landing'}`}
              data-qa-target='hero-background-svg-mobile'
              preserveAspectRatio='none'
              viewBox='0 0 375 120'>
              <path
                d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
                fill='#FFFFFF'></path>
            </svg>
          </div>
           
          <div className='welcome-container'>
            
          <div className='welcome-container-inner'>
          {/* {isEnhanced ? (
          <div className='enhanced-tag'>
            <span className='enhanced-text'>Enhanced Profile</span>
          </div>
        ) : (
          ''
        )} */}
          <div className='welcome-container-text'>
            Welcome to Healthgrades Marketplace <div className='rectangle'></div>
          </div>
        </div>
        </div>

      </div>{' '}
      {isEnhanced ? '' : <StdEnhanceComp premiumSiteURL={premiumSiteURL} />}

        </div>
        
        
    </div>
  );
};

export default LandingBanner;
