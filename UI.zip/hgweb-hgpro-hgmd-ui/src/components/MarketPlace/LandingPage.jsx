import React, { Fragment } from 'react';

import PartnersLayout from './PartnersLayout';
import * as constants from './Constants/Constants';

//stylesheet imports
import './_index.less';
import _ from 'lodash';

const LandingPage = ({ trustedPartners }) => {
  const _mainArray = constants.landingPageDetailsArr;
  const getSection = (object) => {
    return <PartnersLayout content={object} onTabsChangeHandler={trustedPartners} />;
  };

  //#region JSX
  return (
    <Fragment>
      {_.map(_mainArray, (obj) => {
        return getSection(obj);
      })}
    </Fragment>
  );
  // #endregion
};

export default LandingPage;
