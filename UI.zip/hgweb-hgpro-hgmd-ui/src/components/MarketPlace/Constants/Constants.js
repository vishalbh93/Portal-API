import React from 'react';
import headerLogo from '/public/images/marketPlace/Inner/icon-outcare-health.png';
import outcareImg from '/public/images/marketPlace/Inner/out-care.png';

import cinebodyLogo from '/public/images/marketPlace/Inner/icon-cinebody.png';
import cineBodyImg from '/public/images/marketPlace/Inner/cinebody.png';

import smartRefLogo from '/public/images/marketPlace/Inner/smart-referal-logo.png';
import smartreferralImg from '/public/images/marketPlace/Inner/smartreferral.png';
import stdMaskImage from '/public/images/marketPlace/Banner/stdmask.png';
import checkMarkWhite from '/public/images/marketPlace/Banner/checkmarkwhite.png';
import enhancedTagImage from '/public/images/marketPlace/Banner/enhancedimg.png';


import cinebodysignUp from '/public/images/marketPlace/Cinebody/signup.png';
import cinebodygetVideo from '/public/images/marketPlace/Cinebody/getvideo.png';
import cinebodystartFilming from '/public/images/marketPlace/Cinebody/startfilming.png';
import chevronrightImg from '/public/images/marketPlace/Cinebody/chevronright.png';
import hgwordmarkwhite_cineb from '/public/images/marketPlace/Cinebody/healthgrades-wordmark-white.png';
import vert_line_cineb from '/public/images/marketPlace/Cinebody/line2.svg';
import cinebodyLogowordmark from '/public/images/marketPlace/Cinebody/cinebody-logo-wordmark.png';
import cine_bannerStrokeImage from '/public/images/marketPlace/Cinebody/strokegroup.png';
import cine_bannerMaskImage from '/public/images/marketPlace/Cinebody/maskgroup.png';
import cine_bannerImage from '/public/images/marketPlace/Cinebody/cinebody-banner.png';

const outCare_LeftArrow = '/public/images/marketPlace/Outcare/BreadCrumb.svg';
const outCare_HealthgradesLogo = '/public/images/marketPlace/Outcare/HealthgradesWhiteLogo.svg';
const outCare_Line = '/public/images/marketPlace/Outcare/Line 2.svg';
const OutCareLogo = '/public/images/marketPlace/Outcare/OutcareLogo.svg';
const outCare_LgbtqImg = '/public/images/marketPlace/Outcare/LGBTQ.png';
const SideLogo = '/public/images/marketPlace/Outcare/SideBanner.png';

const VerticalLine = '/public/images/marketPlace/Outcare/VerticalLine-gray.svg';
const HorizontalLine = '/public/images/marketPlace/Outcare/HorizontalLine.svg';
const OutCareImg1 = '/public/images/marketPlace/Outcare/reading.svg';
const OutCareImg2 = '/public/images/marketPlace/Outcare/bubbles.svg';
const OutCareImg3 = '/public/images/marketPlace/Outcare/NoteBook.svg';
const CardImage1 = '/public/images/marketPlace/Outcare/Outcare1.png';
const CardImage2 = '/public/images/marketPlace/Outcare/Outcare2.png';
const CardImage3 = '/public/images/marketPlace/Outcare/Outcare3.png';
const quoteImg = '/public/images/marketPlace/Outcare/Icon_quote.svg';
const LgbtqImg = '/public/images/marketPlace/Outcare/Lgbtq2.png';

import personalizedHCareImg from '/public/images/marketPlace/Cinebody/cinebody_personalizedvid.png';
import resonate from '/public/images/providerProfile/TrustedPartners/cinebody-img1.png';
import personalized from '/public/images/providerProfile/TrustedPartners/cinebody-img2.png';
import Versatile from '/public/images/providerProfile/TrustedPartners/cinebody-img3.png';
import doctor from '/public/images/marketPlace/Cinebody/cinebodydoctor.png';
import dots from '/public/images/marketPlace/Cinebody/cinebody_dots.png';

/* #endregion */



export const outcareLink =
  'https://www.outcarehealth.org/login/?redirect_to=https%3A%2F%2Fwww.outcarehealth.org%2Fadd-provider-listing%2F/?pCID=hgpro-trustedpartner-outcarehealth';

export const cinebodyLink = 'https://www.filmoncinebody.com/?pCID=hgpro-trustedpartner-cinebody';

export const cinebodysignUpLink = 'https://www.outca';
export const cinebodystartFilmingLink = '';
export const cinebodygetVideoLink = '';

export const outcareHealthTip = `If you have training in gender-affirming care, include it in your care philosophy. If not and you would like training, Healthgrades has partnered with OutCare Health to give you that training. `;

export const cinebodyTip = `Don't have time to create your own video? Healthgrades has partnered with Cinebody, a video production company, to make informative videos for your patients. `;

export const outCareContent = {
  headerLogo: { logo: headerLogo },
  sections: [
    {
      id: 3,
      type: 'header-section',
      header: 'LGBTQ+ inclusive solutions Caring Beyond Medicine',
      content: [
        'Enhanced LGBTQ+ sorting capabilities',
        'LGBTQ+ support indicators on profile card',
        'Our "At a Glance" section highlights the OutCare\'s inclusion'
      ],
      img: outcareImg,
      className: 'div-detail-sub-section',
      sectionName: 'outcare',
      button: 'Learn More'
    }
  ]
};
export const cinebodyContent = {
  headerLogo: { logo: cinebodyLogo },
  sections: [
    {
      id: 2,
      type: 'header-section',
      header: 'Your Story in Motion',
      content: [
        'Resonate with audience and reach new patient',
        'Personalized and Engaging Content',
        'Versatile and Customizable Features'
      ],
      img: cineBodyImg,
      className: 'div-detail-sub-section',
      sectionName: 'cinebody',
      button: 'Learn More'
    }
  ]
};
export const smartreferralcontent = {
  headerLogo: { logo: smartRefLogo },
  sections: [
    {
      id: 1,
      type: 'header-section',
      header: `Smart referral system to recommend your patients`,
      content: [
        'Increased patient loyalty and trust',
        'Faster access to specialised care',
        'Better patient communication',
        'Better reach and increased knowledgee',
        'Better coordination of care'
      ],
      img: smartreferralImg,
      className: 'div-detail-sub-section',
      sectionName: 'providerReferral',
      button: 'Learn More'
    }
  ]
};

export const landingPageDetailsArr = {
  smartReferralContent: {
    headerLogo: { logo: smartRefLogo },
    sections: [
      {
        id: 1,
        type: 'header-section',
        header: `Smart referral system to recommend your patients`,
        content: [
          'Increased patient loyalty and trust',
          'Faster access to specialised care',
          'Better patient communication',
          'Better reach and increased knowledgee',
          'Better coordination of care'
        ],
        img: smartreferralImg,
        className: 'div-detail-sub-section',
        sectionName: 'providerReferral',
        button: 'Learn More'
      }
    ]
  },
  // As per the MD-1117 hide this cinebody option
  // cinebodyContent: {
  //   headerLogo: { logo: cinebodyLogo },
  //   sections: [
  //     {
  //       id: 2,
  //       type: 'header-section',
  //       header: 'Your Story in Motion',
  //       content: [
  //         'Resonate with audience and reach new patients',
  //         'Personalized and Engaging Content',
  //         'Versatile and Customizable Features'
  //       ],
  //       img: cineBodyImg,
  //       className: 'div-detail-sub-section',
  //       sectionName: 'cinebody',
  //       button: 'Learn More'
  //     }
  //   ]
  // },
  outcareContent: {
    headerLogo: { logo: headerLogo },
    sections: [
      {
        id: 2,
        type: 'header-section',
        header: 'LGBTQ+ inclusive solutions Caring Beyond Medicine',
        content: [
          'Enhanced LGBTQ+ sorting capabilities',
          'LGBTQ+ support indicators on profile card',
          'Our "At a Glance" section highlights the OutCare\'s inclusion'
        ],
        img: outcareImg,
        className: 'div-detail-sub-section',
        sectionName: 'outcare',
        button: 'Learn More'
      }
    ]
  },  
};

export const cinebodyPageDetailsArr = {
  banner: {
    bannerMaskImage: cine_bannerMaskImage,
    bannerStrokeImage: cine_bannerStrokeImage,
    bannerImage: cine_bannerImage,
    bannerCont: {
      breadCrum: ['My Profile', 'Marketplace', 'Cinebody'],
      chevronrightImg: chevronrightImg,
      logo: [hgwordmarkwhite_cineb, vert_line_cineb, cinebodyLogowordmark],
      subheader: 'Receive your video in as little as two weeks',
      content: `Our professional Cinebody team will work closely with you to ensure your video as
      high-quality and authentic as possible. The process to get started is as easy as 1, 2,
      3.`
    },
    highlightSection:{
      header:'How Cinebody works',
      VerticalLine:VerticalLine,
      HorizontalLine:HorizontalLine,
      
      col_1:{
        image:cinebodysignUp,
        imageNav:cinebodysignUpLink,
        subheading:'Sign up',
        content:`Once you sign up & submit payment, 
        the Cinebody team will connect with you to customize your filming experience
      `
      },
      col_2: {
        image: cinebodystartFilming,
        imageNav: cinebodystartFilmingLink,
        subheading: 'Start filming',
        content: `You’ll receive simple instructions 
        on how to film your video on your device, including suggested prompts & best practices`
      },
      col_3: {
        image: cinebodygetVideo,
        imageNav: cinebodygetVideoLink,
        subheading: 'Get your video',
        content: `Once you complete filming, the Cinebody team will 
        edit your professional video, including licensed music and titles`
      },

    buttonLink:'',

    }},
  
  row_1:{
    heading:'Benefits Healthcare Professionals get by using Cinebody',
    col_1:{
      id:'1',
      image:resonate,
      subheading:'Resonate with audience and reach new patients',
      content:`Looking to increase user engagement on your profile and to establish a
      connection with potential patients? Adding a clear video play icon to profile
      photos tripled the number of patients who watch a video. Additionally, those
      who watched a provider's video were 50% more likely to contact their practice.`
    },
    col_2:{
      id:'2',
      image:personalized,
      subheading:'Personalized and Engaging Content',
      content:`Cinebody's advanced system allows you to self-film with your smartphone or
      laptop with optimal video quality, so you can create a video at your
      convenience. Answer questions about who you are with the ability to film
      additional footage to visually showcase your individuality both in and outside
      of the office.`
    },
    col_3:{
      id:'3',
      image:Versatile,
      subheading:'Versatile and Customizable Features',
      content:`In addition to the streamlined production process, Cinebody offers a range of
      creative services to enhance your video content. Whether you require video
      editing, motion graphics, or other post-production needs, Cinebody's
      professional team is available to support you.`
    }
  },

  row_2: {
    image: doctor,
    watermark: dots,
    content: `Looking to increase user engagement on your profile and to establish a connection with
    potential patients? Healthgrades has found that those who watched a video on a
    provider's profile were ${<span className='cinebodyAdv-description-fifty'>50</span>}
    ${<span className='cinebodyAdv-description-perc'>%</span>} more likely to contact their
    practice.`
  },

  row_3:{    
      headerLogo: { logo: '' },
      sections: [
        {
          id: '1',
          type: 'header-section',
          header: `Create your personalized Healthgrades video today!`,
          content: [
            'Showcase who you are both inside & outside of the office to potential patients',
            'Film at your convenience on your smartphone or laptop, while following our custom prompts',
            'Have your authentic, professionally edited video produced in as little as two weeks'
          ],
          img: personalizedHCareImg,
          sectionName: 'personalizedHCare',
          button: 'Get Started'
        }
      ]
  }
};

export const outCarePageDetailsArr = {
  banner: {
    LeftArrow: outCare_LeftArrow,
    Line: outCare_Line,
    HealthgradesLogo: outCare_HealthgradesLogo,
    OutCareLogo: OutCareLogo,
    LgbtqImg: outCare_LgbtqImg,
    bannerCont: {
      breadCrum: ['My Profile', 'Marketplace', 'OutCare'],
      header: ' The Future of LGBTQ+ Healthcare is Here',
      subheaderFull:
        'Healthgrades partnered with OutCare to empower providers to deliver affirming care through patient exposure, training, mentorship, networking, and community resources, advancing LGBTQ+ health equity.',
      subheaderHalf:
        'Healthgrades partnered with OutCare to empower providers to deliver affirming',
      button: 'Join the Outlist'
    }
  },

  row_1: {
    heading: 'Provider Resources',
    VerticalLine: VerticalLine,
    HorizontalLine:HorizontalLine,

    col_1: {
      image: OutCareImg1,
      subheading: 'Join the Outlist',
      content: `Join the directory of affirming providers.`
    },
    col_2: {
      image: OutCareImg2,
      subheading: 'Attend an OutTalk',
      content: ` Participate in a discussion on improving health equity.`
    },
    col_3: {
      image: OutCareImg3,
      subheading: 'Take CEU Training',
      content: `Complete a provider health equity training course.`
    },
    button: 'Join the Outlist'
  },

  row_2: {
    header: ' Revolutionize healthcare with LGBTQ+ inclusive solutions and experiences',
    subHeader:
      'Login or register to manage or create your OutList healthcare professionals listing or take health equity training to improve your LGBTQ+ knowledge.',
     
    col_1: {
      image: CardImage1,
      header: 'Enhanced LGBTQ+ sorting capabilities',
      content: `Patients can sort and filter search results on Healthgrades to find exclusive LGBTQ+
      affirming healthcare professionals, prioritizing their ability to easily connect.`
    },
    col_2: {
      image: CardImage2,
      header: 'LGBTQ+ support indicators on profile cards',
      content: ` Healthgrades displays LGBTQ+ affirming indicators on healthcare professional's profile
      cards, facilitating easy identification and familiarity.`
    },
    col_3: {
      image: CardImage3,
      header: ' Our “At a Glance” section highlights the OutCare’s inclusion',
      content: `Under our "At a Glance" section, patients can easily view the healthcare
      professional's support for the LGBTQ+ community, allowing them to make informed
      decisions.`
    }
  },

  row_3: {
    image: quoteImg,
    commentContent: `${"    "}     Dr. Nowaskie recently provided a training to our home visiting nurses. Our site staff
    across the country has been raving about the experience and how much they learned.
    OutCare is an incredible resource that I’m looking forward to working with more in the
    future to continue serving ALL families with new babies and connecting them with
    culturally competent resources and providers in their communities.`,
    Name: ` - Mary Martin Vance, AASECT-Certified Sex Therapist, LLC`
  },
  row_4: {
    image: LgbtqImg,
    header: `OutCare for Healthcare Professionals`,
    button:'Join the Outlist',
    fullContent: [
      'Foster an inclusive provider community through educational training, resources, and events that promote cultural competency and LGBTQ+ health equity.',
      'Create and distribute accessible and informative healthcare materials to support providers in delivering quality care to LGBTQ+ patients.',
      'Develop and facilitate opportunities for professional development, such as seminars, conferences, and networking events, to connect providers and share best practices in LGBTQ+ healthcare.',
      'Offer personalized consultation services on LGBTQ+ patients and practices to enhance providers’ understanding and improve the quality of care, while showcasing providers’ education and experiences to the public through our OutList directory.'
    ],
    halfContent: [
      'Foster an inclusive provider community through educational training, resources, and events that promote cultural competency and LGBTQ+ health equity.',
      'Create and distribute accessible and informative healthcare materials to support providers in delivering quality care to LGBTQ+ patients.'
    ]
  }
};

export const landingBannerImage ={
  stdMaskImage:stdMaskImage,
  checkMarkWhite:checkMarkWhite,
  enhancedTagImage:enhancedTagImage
}