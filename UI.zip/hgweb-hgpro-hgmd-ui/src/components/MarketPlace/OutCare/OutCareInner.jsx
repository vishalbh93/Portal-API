import React, { Fragment, useState } from 'react';

import './_outcare.less';

import * as constant from '../Constants/Constants.js';



const OutCareInner = ({ trustedPartners }) => {
  const isMobileView = window.innerWidth <= 768;
  const [showMore, setShowMore] = useState(false);
  const row_2Content = constant.outCarePageDetailsArr.row_2;
  const row_3Content = constant.outCarePageDetailsArr.row_3;
  const row_4Content = constant.outCarePageDetailsArr.row_4;
  const commentLines = row_3Content.commentContent.split('\n');
  const toggleShowMore = () => {
    setShowMore(!showMore);
  };
  return (
    <>
     <div className='outcare-inner-container'>
      <div className='outCare-description'>
        <div className='description-header'>
        <div className='outCare-desc-header-content'>
          <div className='main-header'>{row_2Content.header}</div>
          <div className='second-header'>{row_2Content.subHeader}</div>
        </div>
        <div className='outCare-desc-main-content'>
          <div className='middle-card-1'>
            <div className='card-image'>
              <img src={row_2Content.col_1.image} />
            </div>
            <div className='card-header'>{row_2Content.col_1.header}</div>
            <div className='card-content'>{row_2Content.col_1.content}</div>
          </div>
          <div className='middle-card-2'>
            <div className='card-image'>
              <img src={row_2Content.col_2.image} />
            </div>
            <div className='card-header'>{row_2Content.col_2.header}</div>
            <div className='card-content'>{row_2Content.col_2.content}</div>
          </div>
          <div className='middle-card-3'>
            <div className='card-image'>
              <img src={row_2Content.col_3.image} />
            </div>
            <div className='card-header'>{row_2Content.col_3.header}</div>
            <div className='card-content'>{row_2Content.col_3.content}</div>
          </div>
        </div>
        </div>
      </div>
      <div className='outCare-professional-comment'>
        <div className='quote-Image'>
          <img src={row_3Content.image} />
        </div>
        <div className='writtent-content'>
          <div className='outcare-comment'>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span>{`${row_3Content.commentContent}`}</span>
          </div>
          <div className='professional-name'>{row_3Content.Name}</div>
        </div>
      </div>
      <div className='outCare-for-Healthcare-professionals'>
        <div className='outcare-inner-container'>
        <div className='Healthcare-professionals-main-content'>
          <div className='header'>{row_4Content.header}</div>
          {isMobileView && (
            <div className='Healthcare-professionals-image'>
              <img src={row_4Content.image} />
            </div>
          )}
          {!isMobileView ? (
            <div className='list-content'>
              {row_4Content.fullContent.map((content) => (
                <>
                  <ul>
                    <li>{content}</li>
                  </ul>
                </>
              ))}
            </div>
          ) : showMore ? (
            <div className='list-content'>
              {row_4Content.fullContent.map((content) => (
                <>
                  <ul>
                    <li>{content}</li>
                  </ul>
                </>
              ))}
            </div>
          ) : (
            <div className='list-content'>
              {row_4Content.halfContent.map((content) => (
                <>
                  <ul>
                    <li>{content}</li>
                  </ul>
                </>
              ))}
            </div>
          )}
          {isMobileView && (
            <button className='Read-more-less' onClick={toggleShowMore}>
              {showMore ? 'Read less' : 'Read more'}
            </button>
          )}
          <div className='join-outlist-button'>
            <a href='https://www.outcarehealth.org/membership/'>{row_4Content.button}</a>
          </div>
        </div>
        {!isMobileView && (
          <div className='Healthcare-professionals-image'>
            <img src={row_4Content.image} />
          </div>
        )}
      </div>
      </div>
      </div>
    </>
  );
};
export default OutCareInner;
