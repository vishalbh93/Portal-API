import React, { Fragment, useState } from 'react';
import './_outcareBanner.less';
import * as constant from '../Constants/Constants.js';

const OutCareBanner = ({ trustedPartners,providerCode }) => {
  const isMobileView = window.innerWidth <= 768;
  const bannerContent = constant.outCarePageDetailsArr.banner;
  const [showMore, setShowMore] = useState(false);
  const [showMoreOption, setShowMoreOption] = useState(false);

  const bannerImage = constant.cinebodyPageDetailsArr.banner;
  const row_1Content = constant.outCarePageDetailsArr.row_1;

  const toggleShowMore = () => {
    setShowMore(!showMore);
    setShowMoreOption(!showMoreOption);
  };
  return (
    <div className='outcare-banner'>
      <div className='outcate-banner-container'>
        <div
          className={
            !isMobileView
              ? 'banner-inner-container'
              : !showMoreOption
              ? 'banner-outcare-container-mobile'
              : 'banner-outcare-container-mobile expanded'
          }>
          {!isMobileView ? (
            <svg
              className='hero-background-svg'
              data-qa-target='hero-background-svg'
              preserveAspectRatio='none'
              viewBox='0 0 1442 149'>
              <path
                d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
                fill='#FFFFFF'></path>
            </svg>
          ) : (
            <svg
              className={`hero-background-svg-mobile ${'hero-background-svg-mobile-landing'}`}
              data-qa-target='hero-background-svg-mobile'
              preserveAspectRatio='none'
              viewBox='0 0 375 120'>
              <path
                d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
                fill='#FFFFFF'></path>
            </svg>
          )}
        </div>
        <div className='outcare-banner-content'>
          <div className='outcare-header'>
            <div className='outcare-top-content'>
              <div className='outcare-header-content'>
                <a href={`../provider/profile/${providerCode}`} >
                  {bannerContent.bannerCont.breadCrum[0]} <img src={bannerContent.LeftArrow} />{' '}
                </a>
                <a
                  onClick={(e) => {
                    trustedPartners(e, 'landing_page');
                  }}>
                  {bannerContent.bannerCont.breadCrum[1]} <img src={bannerContent.LeftArrow} />{' '}
                </a>
                {bannerContent.bannerCont.breadCrum[2]}
              </div>
              <div className='herobanner-container-images'>
                <div className='healthgrades-logo'>
                  <img src={bannerContent.HealthgradesLogo} />
                </div>
                <div className='Line-image'>
                  <img src={bannerContent.Line} />
                </div>
                <div className='OutCareLogo'>
                  <img src={bannerContent.OutCareLogo} />
                </div>
              </div>
              <div className='herobanner-container-content'>{bannerContent.bannerCont.header}</div>
              {isMobileView && (
                <div className='hero-banner-images-mobile'>
                  <img src={bannerContent.LgbtqImg} />
                </div>
              )}
              <span className='herobanner-container-footer'>
                {!isMobileView ? (
                  <p>{bannerContent.bannerCont.subheaderFull}</p>
                ) : (
                  <>
                    {showMoreOption ? (
                      <span>{bannerContent.bannerCont.subheaderFull}</span>
                    ) : (
                      <span>{bannerContent.bannerCont.subheaderHalf}</span>
                    )}{' '}
                    <u>
                      <span className='Read-more-less' onClick={toggleShowMore}>
                        {showMoreOption ? 'Read less' : 'Read more'}
                      </span>
                    </u>
                  </>
                )}
                {isMobileView && (
                  <div className='card-button'>
                    <a href='https://www.outcarehealth.org/membership/'>
                      {bannerContent.bannerCont.button}
                    </a>
                  </div>
                )}
              </span>
            </div>
            <div className='outcare-images'>
              {!isMobileView && (
                <div className='hero-banner-images'>
                  <img src={bannerContent.LgbtqImg} className='lqbtq-img' />
                  {!isMobileView && (
                    <img className='outcare-side-banner' src={bannerImage.bannerStrokeImage} />
                  )}
                </div>
              )}
            </div>
          </div>
          {!isMobileView && (
            <img className='outcare-side-bannerMaskImage' src={bannerImage.bannerMaskImage} />
          )}
        </div>
      </div>
      <div className='Outcare-card-content'>
        <div className='provider-resources'>{row_1Content.heading}</div>
        <div className='main-card-content'>
          <div className='card-content-1'>
            <div className='image'>
              <img src={row_1Content.col_3.image} />
            </div>
            <div className='content'>{row_1Content.col_1.subheading}</div>
            <div className='description'>{row_1Content.col_1.content}</div>
          </div>
          <div className={isMobileView ? 'horizontal-line' : 'vertical-Line'}>
            <img src={isMobileView ? row_1Content.HorizontalLine : row_1Content.VerticalLine} />
          </div>
          <div className='card-content-2'>
            <div className='image'>
              <img src={row_1Content.col_2.image} />
            </div>
            <div className='content'>{row_1Content.col_2.subheading}</div>
            <div className='description'>{row_1Content.col_2.content}</div>
          </div>
          <div className={isMobileView ? 'horizontal-line' : 'vertical-Line'}>
            <img src={isMobileView ? row_1Content.HorizontalLine : row_1Content.VerticalLine} />
          </div>
          <div className='card-content-3'>
            <div className='image'>
              <img src={row_1Content.col_1.image} alt='Image'/>
            </div>
            <div className='content'>{row_1Content.col_3.subheading}</div>
            <div className='description'>{row_1Content.col_3.content}</div>
          </div>
        </div>
        <div className='card-button'>
          <a href='https://www.outcarehealth.org/membership/'>{row_1Content.button}</a>
        </div>
      </div>
    </div>
  );
};

export default OutCareBanner;
