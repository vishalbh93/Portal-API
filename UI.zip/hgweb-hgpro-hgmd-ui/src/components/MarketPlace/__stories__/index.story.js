import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../.storybook/store';
import Index from '../Index';

storiesOf('MarketPlace/Landing', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Landing Page', () => <Index />);
