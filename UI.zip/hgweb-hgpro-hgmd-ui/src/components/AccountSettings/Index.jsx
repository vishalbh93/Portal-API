import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';

/* #region styles */
import '@hg/joy/src/globalstyles';
import './_index.less';
/* #endregion */

/* #region components*/
import AccountSettings from './AccountSettings';
import Footer from '../Common/Footer/Footer';
import MenuComponent from '../Common/Menu/Menu';
/* #endregion */

const Index = () => {
  /* #region selector*/
  const { accountSettingsInfo } = useSelector((state) => state.loadAccountSettingsData);
  const navigations = accountSettingsInfo != undefined ? accountSettingsInfo.Navigations : [];
  const navigationObj = accountSettingsInfo != undefined ? accountSettingsInfo.NavigationModel : {};
  /* #endregion */

  /* #region states */
  const [currentTab, setCurrentTab] = useState('');
  /* #endregion */

  /* #region Handler */
  const menuClick = (section) => {
    setCurrentTab(section);
  };

  const providerDetails = () => {
    let details = {
      DisplayFullName: accountSettingsInfo.NavigationModel.DisplayName,
      ImageUrl: accountSettingsInfo.NavigationModel.ImageUrl,
      PrimarySpecialty: '',
      Gender: '',
      Age: '',
      Pwid: accountSettingsInfo.NavigationModel.ProviderId
    };
    return details;
  };
  /* #endregion */

  return (
    <>
      <>
        <MenuComponent
          menuClick={menuClick}
          showMenus={true}
          menuItems={navigations}
          infoObject={navigationObj}
          providerInfo={providerDetails()}
        />
        <div className='banner-container'>
          <div className='banner-inner-container'>
            <svg
              className='hero-background-svg'
              data-qa-target='hero-background-svg'
              preserveAspectRatio='none'
              viewBox='0 0 1442 149'>
              <path
                d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
                fill='#FFFFFF'></path>
            </svg>

            <svg
              className={`hero-background-svg-mobile ${'hero-background-svg-mobile-landing'}`}
              data-qa-target='hero-background-svg-mobile'
              preserveAspectRatio='none'
              viewBox='0 0 375 120'>
              <path
                d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
                fill='#FFFFFF'></path>
            </svg>
          </div>
        </div>
      </>

      <AccountSettings />
      <Footer />
    </>
  );
};

export default Index;
