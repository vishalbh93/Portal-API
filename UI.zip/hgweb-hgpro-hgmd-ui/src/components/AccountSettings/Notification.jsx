import React, { useState, useEffect } from 'react';
import * as service from './../../utils/service';

/* #region styles */
import './_notification.less';
/* #endregion */

/* #region components*/
import Toggle from '../Common/ToggleButton/Toggle';
import Spinner from '../Spinner/Spinner';
/* #endregion */

const Notification = ({ accountInfo, showToastHandler, showNewsUpdate }) => {
  /* #region states */
  const [isSendNewsReviews, setIsSendNewsReviews] = useState(accountInfo.SendNewReviews);
  const [isSendUpdatesAboutNewFeatures, setSendUpdatesAboutNewFeatures] = useState(
    accountInfo.SendUpdatesAboutNewFeatures
  );
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  /* #endregion */

  const updateNotificationSection = (flag, val) => {
    setSpinnerVisibility(true);
    let payload = {
      SendUpdatesAboutNewFeatures:
        val === 'newFeature' ? !isSendUpdatesAboutNewFeatures : isSendUpdatesAboutNewFeatures,
      SendNewReviews: val === 'review' ? !isSendNewsReviews : isSendNewsReviews
    };
    service
      ._post(`/api/account/notifications`, payload, true)
      .then((res) => {
        if (res.status == 200) {
          showToastHandler(payload, true, 'notification');
        } else {
          showToastHandler({}, false, 'notification');
        }
      })
      .catch((err) => console.log(err));
    setSpinnerVisibility(false);
  };

  useEffect(() => {
    setIsSendNewsReviews(accountInfo.SendNewReviews);
    setSendUpdatesAboutNewFeatures(accountInfo.SendUpdatesAboutNewFeatures);
  }, [accountInfo]);

  return (
    <div id='div-news-update-notifications'>
      <section id='section-news-update'>
        <div id='div-news-update'>
          {showNewsUpdate && (
            <div className='news-review flex-row'>
              <span>New reviews</span>
              <span className='span-toggle'>
                <Toggle
                  selected={accountInfo.SendNewReviews}
                  toggleSelected={() => {
                    updateNotificationSection(isSendNewsReviews, 'review');
                  }}
                />
              </span>
            </div>
          )}

          <div className='news-feed flex-row'>
            <span>Notify updates about the new features</span>
            <span className='span-toggle'>
              <Toggle
                selected={accountInfo.SendUpdatesAboutNewFeatures}
                toggleSelected={() => {
                  updateNotificationSection(isSendUpdatesAboutNewFeatures, 'newFeature');
                }}
              />
            </span>
          </div>
        </div>
      </section>

      {spinnerVisibility && <Spinner cta={true} />}
    </div>
  );
};

export default Notification;
