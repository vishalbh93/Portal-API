import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../.storybook/store';
import Index from '../Index';

const accountSettingsInfo = {
  NavigationJson:
    '{"PageType":8,"CurrentPage":"settings","UserIsProvider":false,"UserIsAdmin":true,"UserIsClientAdmin":false,"ProviderCount":75,"ProviderId":"GGKLD","SubNav":{"MyProfile":[{"ScrollValue":"#general-info","NavName":"Basic Information","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#specialty","NavName":"Specialties","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#insurance","NavName":"Insurance","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#patient-experience","NavName":"Response to Patient Surveys","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#practice-locations","NavName":"Practice & Office Locations","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#telehealth","NavName":"Telehealth","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#procedures-performed","NavName":"Procedures Performed","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#conditions","NavName":"Conditions Treated","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#hospitals","NavName":"Hospital Affiliations","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#availability","NavName":"Appointment Availability","ShowIndicator":true,"IndicatorValue":0},{"ScrollValue":"#education","NavName":"Education","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#credentials","NavName":"Credentials","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#board-certification","NavName":"Board Certifications","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#languages","NavName":"Languages Spoken","ShowIndicator":false,"IndicatorValue":0}],"PatientExperience":[{"ScrollValue":"/patientexperience/reviews/","NavName":"Patient Reviews","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"/patientexperience/analytics/","NavName":"Analytics","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"/patientexperience/resources/","NavName":"Resources","ShowIndicator":false,"IndicatorValue":0}]},"PesPagesOn":true,"SponsoredUser":true,"BetaMode":false,"OptOutUrl":null,"BetaSignOutUrl":"http://update-testaws.healthgrades.com","NewCommentsCount":0,"ShowPracticeRoster":true,"HasSponsorship":false,"SponsorCode":null,"HasProviderReporting":false,"ProfileViewsText":null,"ProfileViewsString":null,"FirstName":"Dinakaran","LastName":"G","DisplayName":"Dinakaran G","ImageUrl":"//d1ffafozi03i4l.cloudfront.net/img/silhouettes/silhouette-male_w120h160_v1.jpg","IsApplicableForPremium":false,"HasEnhancedSubcription":false,"HasPremiumSubcription":false,"PremiumSiteURL":"http://selfservetest.healthgrades.com/","ProviderEmail":"dg@healthgrades.com","DesignationType":0,"SponsorImg":"","SponsorName":""}',
  NavigationModel: {
    PageType: 8,
    CurrentPage: 'settings',
    UserIsProvider: false,
    UserIsAdmin: true,
    UserIsClientAdmin: false,
    ProviderCount: 75,
    ProviderId: 'GGKLD',
    SubNav: {
      MyProfile: [
        {
          ScrollValue: '#general-info',
          NavName: 'Basic Information',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#specialty',
          NavName: 'Specialties',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#insurance',
          NavName: 'Insurance',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#patient-experience',
          NavName: 'Response to Patient Surveys',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#practice-locations',
          NavName: 'Practice & Office Locations',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#telehealth',
          NavName: 'Telehealth',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#procedures-performed',
          NavName: 'Procedures Performed',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#conditions',
          NavName: 'Conditions Treated',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#hospitals',
          NavName: 'Hospital Affiliations',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#availability',
          NavName: 'Appointment Availability',
          ShowIndicator: true,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#education',
          NavName: 'Education',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#credentials',
          NavName: 'Credentials',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#board-certification',
          NavName: 'Board Certifications',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#languages',
          NavName: 'Languages Spoken',
          ShowIndicator: false,
          IndicatorValue: 0
        }
      ],
      PatientExperience: [
        {
          ScrollValue: '/patientexperience/reviews/',
          NavName: 'Patient Reviews',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '/patientexperience/analytics/',
          NavName: 'Analytics',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '/patientexperience/resources/',
          NavName: 'Resources',
          ShowIndicator: false,
          IndicatorValue: 0
        }
      ]
    },
    PesPagesOn: true,
    SponsoredUser: true,
    BetaMode: false,
    OptOutUrl: null,
    BetaSignOutUrl: 'http://update-testaws.healthgrades.com',
    NewCommentsCount: 0,
    ShowPracticeRoster: true,
    HasSponsorship: false,
    SponsorCode: null,
    HasProviderReporting: false,
    ProfileViewsText: null,
    ProfileViewsString: null,
    FirstName: 'Dinakaran',
    LastName: 'G',
    DisplayName: 'Dinakaran G',
    ImageUrl: '//d1ffafozi03i4l.cloudfront.net/img/silhouettes/silhouette-male_w120h160_v1.jpg',
    IsApplicableForPremium: false,
    HasEnhancedSubcription: false,
    HasPremiumSubcription: false,
    PremiumSiteURL: 'http://selfservetest.healthgrades.com/',
    ProviderEmail: 'dg@healthgrades.com',
    DesignationType: 0,
    SponsorImg: '',
    SponsorName: ''
  },
  PageTracking: {
    Account: 'hgspadev',
    PageName: 'hgmd: account settings',
    Channel: 'general',
    CampaignId: null,
    Server: 'hgmd: desktop',
    ContextData: {
      'hg.VisitorID': '2551298f-513c-4194-866e-7e21d0761b15',
      'hg.VisitorType': 'practice administrator',
      'hg.VisitorStatus': 'authenticated',
      'hg.AuthorizationStatus': 'authorized',
      'hg.Login': '1'
    }
  },
  FullStoryData: null,
  SignOutModel: {
    BetaMode: false,
    OptOutUrl: null,
    BetaSignOutUrl: null
  },
  SessionTimeout: 3480000,
  SettingsJson:
    '{"Email":"dg@healthgrades.com","UserName":"SCNETI\\\\dg","FirstName":"Dinakaran","LastName":"G","WorkPhone":"111-111-5555","MobilePhone":"987-898-7777","SendUpdatesAboutNewFeatures":false,"SendNewReviews":null}',
  Navigations: [
    {
      Id: 11,
      ParentId: 11,
      Name: 'Support Portal',
      Url: '/admin/index',
      IsExternal: false,
      IconClass: '',
      Order: 3,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 12,
      ParentId: 12,
      Name: 'Audits',
      Url: '/audit/index',
      IsExternal: false,
      IconClass: '',
      Order: 4,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 1,
      ParentId: 1,
      Name: 'Providers',
      Url: '/roster',
      IsExternal: false,
      IconClass: '',
      Order: 5,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 15,
      ParentId: 15,
      Name: 'My Tools',
      Url: '',
      IsExternal: false,
      IconClass: '',
      Order: 8,
      IsActive: false,
      SubMenu: [
        {
          Id: 1,
          ParentId: 14,
          Name: 'Help Center',
          Url: 'https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center',
          IsExternal: true,
          IconClass: '',
          Order: 0,
          IsActive: false
        }
      ]
    },
    {
      Id: 16,
      ParentId: 16,
      Name: 'Patient Reviews',
      Url: '/patientexperience/provider-reviews',
      IsExternal: false,
      IconClass: '',
      Order: 10,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 8,
      ParentId: 8,
      Name: 'Setting',
      Url: '#',
      IsExternal: false,
      IconClass: '',
      Order: 9,
      IsActive: false,
      SubMenu: [
        {
          Id: 7,
          ParentId: 8,
          Name: 'My Account Settings',
          Url: '/account/settings',
          IsExternal: false,
          IconClass: '',
          Order: 7,
          IsActive: false
        },
        {
          Id: 8,
          ParentId: 8,
          Name: 'Change Password',
          Url: '/account/ChangePassword',
          IsExternal: false,
          IconClass: '',
          Order: 8,
          IsActive: false
        },
        {
          Id: 9,
          ParentId: 8,
          Name: 'Sign Out',
          Url: '/account/hgmd-sign-out',
          IsExternal: false,
          IconClass: '',
          Order: 9,
          IsActive: false
        }
      ]
    }
  ],
  NavigationsJson: null
};

storiesOf('Account Settings|Account Settings', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Account Settings', () => <Index {...accountSettingsInfo} />);
