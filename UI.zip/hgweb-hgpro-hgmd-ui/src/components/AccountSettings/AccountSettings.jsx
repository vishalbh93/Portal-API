import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../utils/service';
import * as actions from '../../store/actions';

/* #region components*/
import Notification from './Notification';
import EditAccount from './EditAccount';
import Toast from '../Common/Toast/Toast';
/* #endregion */

/* #region styles */
import '@hg/joy/src/globalstyles';
import './_accountSettings.less';
/* #endregion */

/* #region media */
import imageAccountSettingsBackground from '../../assets/images/AccountSettings/icon_setting.png';
/* #endregion */

const AccountSettings = () => {
  /* #region selector*/
  const { accountSettingsInfo } = useSelector((state) => state.loadAccountSettingsData);
  const _accountInfo =
    accountSettingsInfo != undefined ? JSON.parse(accountSettingsInfo.SettingsJson) : {};
  const [accountInfo, setAccountInfo] = useState(_accountInfo);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const showNewsUpdate =
    accountSettingsInfo != undefined &&
    accountSettingsInfo.NavigationModel != undefined &&
    accountSettingsInfo.NavigationModel.UserIsProvider &&
    accountSettingsInfo.NavigationModel.ProviderCount <= 1;
  /* #endregion */

  const dispatch = useDispatch();

  /* #region handlers */
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const showToastHandler = (data, val, section) => {
    let tempAccountInfoObj =
      section === 'notification'
        ? {
            ...accountInfo,
            SendUpdatesAboutNewFeatures:
              data.SendUpdatesAboutNewFeatures != undefined
                ? data.SendUpdatesAboutNewFeatures
                : _accountInfo.SendUpdatesAboutNewFeatures,
            SendNewReviews:
              data.SendNewReviews != undefined ? data.SendNewReviews : _accountInfo.SendNewReviews
          }
        : {
            ...data,
            SendUpdatesAboutNewFeatures:
              data.SendUpdatesAboutNewFeatures != undefined
                ? data.SendUpdatesAboutNewFeatures
                : _accountInfo.SendUpdatesAboutNewFeatures,
            SendNewReviews:
              data.SendNewReviews != undefined ? data.SendNewReviews : _accountInfo.SendNewReviews
          };
    val
      ? (setAccountInfo(tempAccountInfoObj), toaster.Success('Success'))
      : toaster.Error('Some error occurred, please try again!!');
  };
  /* #endregion */

  useEffect(() => {
    let tempAccountInfo = JSON.stringify(accountInfo);
    let tempNavigationModel = {
      ...accountSettingsInfo.NavigationModel,
      FirstName: accountInfo.FirstName,
      LastName: accountInfo.LastName
    };
    let tempTotalObj = {
      ...accountSettingsInfo,
      SettingsJson: tempAccountInfo,
      NavigationModel: tempNavigationModel
    };
    dispatch(actions.loadAccountSettings(tempTotalObj));
  }, [accountInfo]);

  return (
    <>
      <div id='div-account-settings'>
        <h1 className='header'>Account Settings</h1>
        <div id='div-account-settings-inner'>
          <div className='div-left'>
            <Notification
              accountInfo={accountInfo}
              showToastHandler={showToastHandler}
              showNewsUpdate={showNewsUpdate}
            />

            <EditAccount accountInfo={accountInfo} showToastHandler={showToastHandler} />
          </div>
          <div className='div-right'>
            <img src={imageAccountSettingsBackground} className='account-settings-icon' alt='image-Accountsettingsbackground'/>
          </div>
        </div>
      </div>

      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </>
  );
};

export default AccountSettings;
