import React, { useState, useEffect } from 'react';

/* #region services */
import * as service from '../../utils/service';
/* #endregion */

/* #region components*/
import Cta from '../Common/Form/CTA/Cta';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
/* #endregion */

/* #region styles */
import './_editAcccount.less';
/* #endregion */

/* #region validation */
import isEmpty from '../../utils/validation/isEmpty';
/* #endregion */

const EditAcccount = ({ accountInfo, showToastHandler }) => {
  /* #region  states and variable*/
  const [INIT_STATE_AS, UPDATE_INIT_STATE_AS] = useState({
    firstName: accountInfo.FirstName,
    lastName: accountInfo.LastName,
    workPhone: accountInfo.WorkPhone,
    phone: accountInfo.MobilePhone,
    email: accountInfo.Email,
    userId: accountInfo.UserId,
    errors: {
      firstName: isEmpty(accountInfo.FirstName) ? 'Your first name is required' : '',
      lastName: isEmpty(accountInfo.LastName) ? 'Your last name is required' : '',
      email: isEmpty(accountInfo.Email) ? 'Your email address is required' : '',
      workPhone:
        (accountInfo.WorkPhone !== '' && accountInfo.WorkPhone.length !== 12) ||
        isNaN(accountInfo.WorkPhone.replace(/[^\d]/g, ''))
          ? 'Please enter a 10 digit work phone number or leave blank'
          : '',
      phone:
        (accountInfo.MobilePhone !== '' && accountInfo.MobilePhone.length !== 12) ||
        isNaN(accountInfo.MobilePhone.replace(/[^\d]/g, ''))
          ? 'Please enter a 10 digit cell phone number or leave blank'
          : ''
    }
  });
  const [accountSettingsInfo, setAccountSettingsInfo] = useState(INIT_STATE_AS);
  const [validating, setValidating] = useState({
    firstName: false,
    lastName: false,
    email: false,
    workPhone: false,
    phone: false
  });
  const [PAGE_HAS_ERRORS, SET_PAGE_HAS_ERRORS] = useState(
    document.querySelectorAll('[id$=error-message]').length > 0
  );



  const _ctaIsEqual =
    accountInfo.FirstName === accountSettingsInfo.firstName &&
    accountInfo.LastName === accountSettingsInfo.lastName &&
    accountInfo.WorkPhone === accountSettingsInfo.workPhone &&
    accountInfo.MobilePhone === accountSettingsInfo.phone &&
    accountInfo.Email === accountSettingsInfo.email;

  const _ctaValid =
    Object.values(accountSettingsInfo.errors).every((item) => item == '') &&
    !PAGE_HAS_ERRORS &&
    !_ctaIsEqual;
  /* #endregion */

  /* #region handlers */
  const handlePersonalInformationInputChange = (event) => {
    const { value, name } = event.target;
    let _errors = accountSettingsInfo.errors;
    switch (name) {
      case 'firstName':
        _errors.firstName = value.length > 0 ? '' : 'Your first name is required';
        break;
      case 'lastName':
        _errors.lastName = value.length > 0 ? '' : 'Your last name is required';
        break;
      case 'email':
        _errors.email = value.length > 0 ? '' : 'Your email address is required';
        break;
      case 'workPhone':
        _errors.workPhone =
          isEmpty(value) || value.length == 12
            ? ''
            : 'Please enter a 10 digit work phone number or leave blank';
        break;
      case 'phone':
        _errors.phone =
          isEmpty(value) || value.length == 12
            ? ''
            : 'Please enter a 10 digit work phone number or leave blank';
        break;
      default:
        break;
    }
    setAccountSettingsInfo((prev) => ({
      ...prev,
      errors: _errors,
      [name]: value
    }));
  };

  const phoneFormatHandler = (value) => {
    if (!value) return '';
    const phoneNumber = value.replace(/[^\d]/g, '');
    const phoneNumberLength = phoneNumber.length;
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `${phoneNumber.slice(0, 3)}-${phoneNumber.slice(3)}`;
    }
    return `${phoneNumber.slice(0, 3)}-${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
  };

  const cancelClickHandler = () => {
    setAccountSettingsInfo(INIT_STATE_AS);
  };

  const saveClickHandler = () => {
    let payload = {
      FirstName: accountSettingsInfo.firstName.trim(),
      LastName: accountSettingsInfo.lastName.trim(),
      WorkPhone: accountSettingsInfo.workPhone.trim(),
      MobilePhone: accountSettingsInfo.phone.trim(),
      Email: accountSettingsInfo.email.trim(),
      UserId: accountSettingsInfo.userId.trim()
    };
    service
      ._post(`/api/account/account-settings`, payload, true)
      .then((res) => {
        if (res.status == 200) {
          showToastHandler(payload, true, '');
        } else {
          showToastHandler({}, false, '');
        }
      })
      .catch((err) => console.log(err));
      //fetchUserDetails();
  };
  /* #endregion */

  /* #region effects */
  useEffect(() => {
    if (document.querySelectorAll('[id$=error-message]').length > 0) SET_PAGE_HAS_ERRORS(true);
    else {
      SET_PAGE_HAS_ERRORS(false);
    }
  }, [accountSettingsInfo]);
  /* #endregion */
  
  /* #region JSX */
  return (
    <>
      <div id='div-edit-account-settings'>
        <section id='section-account-settings'>
          <TextInput
            id='input-account-settings-email'
            name='email'
            label='Email Address*'
            placeholder='Email Address'
            onChange={(name, value) =>
              handlePersonalInformationInputChange({ target: { name: name, value: value } })
            }
            value={accountSettingsInfo.email}
            required={true}
            requiredErrorMessage='Your email address is required'
            onBlur={() => {
              setValidating((prev) => ({
                ...prev,
                email: true
              }));
            }}
            validating={validating.email}
            valid={
              !isEmpty(accountSettingsInfo.email) &&
              accountSettingsInfo.email.match(
                /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/g
              ) !== null
            }
          />
          <TextInput
            id='input-account-settings-fname'
            name='firstName'
            label='Your First Name*'
            placeholder='First Name'
            onChange={(name, value) =>
              handlePersonalInformationInputChange({
                target: { name: name, value: value }
              })
            }
            value={accountSettingsInfo.firstName}
            required={true}
            requiredErrorMessage='Your first name is required'
            onBlur={() => {
              setValidating((prev) => ({
                ...prev,
                firstName: true
              }));
            }}
            validating={validating.firstName}
            valid={
              !isEmpty(accountSettingsInfo.firstName) &&
              accountSettingsInfo.firstName.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/g) == null
            }
          />
          <TextInput
            id='input-account-settings-lname'
            name='lastName'
            label='Your Last Name*'
            placeholder='Last Name'
            onChange={(name, value) =>
              handlePersonalInformationInputChange({ target: { name: name, value: value } })
            }
            value={accountSettingsInfo.lastName}
            required={true}
            requiredErrorMessage='Your Last Name is required'
            onBlur={() => {
              setValidating((prev) => ({
                ...prev,
                lastName: true
              }));
            }}
            validating={validating.lastName}
            valid={
              !isEmpty(accountSettingsInfo.lastName) &&
              accountSettingsInfo.lastName.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/g) == null
            }
          />

          <TextInput
            id='input-account-settings-work-phone'
            name='workPhone'
            label='Work Phone'
            placeholder='Work Phone'
            onChange={(name, value) =>
              handlePersonalInformationInputChange({
                target: { name: name, value: phoneFormatHandler(value) }
              })
            }
            value={accountSettingsInfo.workPhone}
            required={false}
            requiredErrorMessage=''
            onBlur={() => {
              setValidating((prev) => ({
                ...prev,
                workPhone: true
              }));
            }}
            validating={validating.workPhone}
            valid={
              accountSettingsInfo.workPhone == '' ||
              (accountSettingsInfo.workPhone != '' &&
                accountSettingsInfo.workPhone.replace(/[^\d]/g, '').match(/[^ 0-9]/) == null &&
                accountSettingsInfo.workPhone.replace(/[^\d]/g, '').length == 10 &&
                accountSettingsInfo.workPhone.length == 12)
            }
          />

          <TextInput
            id='input-account-settings-phone'
            name='phone'
            label='Phone Number'
            placeholder='Phone Number (Used for Two-Factor Authentication)'
            onChange={(name, value) =>
              handlePersonalInformationInputChange({
                target: { name: name, value: phoneFormatHandler(value) }
              })
            }
            value={accountSettingsInfo.phone}
            required={false}
            requiredErrorMessage=''
            onBlur={() => {
              setValidating((prev) => ({
                ...prev,
                phone: true
              }));
            }}
            validating={validating.phone}
            valid={
              accountSettingsInfo.phone == '' ||
              (accountSettingsInfo.phone != '' &&
                accountSettingsInfo.phone.replace(/[^\d]/g, '').match(/[^ 0-9]/) == null &&
                accountSettingsInfo.phone.replace(/[^\d]/g, '').length == 10 &&
                accountSettingsInfo.phone.length == 12)
            }
          />
        </section>
      </div>

      <Cta
        ctaValid={_ctaValid}
        cancelText='Cancel'
        cancelClickHandler={cancelClickHandler}
        confirmText='Save'
        confirmClickHandler={saveClickHandler}
      />
    </>
  );
  /* #endregion */
};

export default EditAcccount;
