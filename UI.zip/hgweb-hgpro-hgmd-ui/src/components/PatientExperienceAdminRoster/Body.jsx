import React from 'react';
import PatientReview from '../PatientExperience/PatientReviews/PatientReview';

//stylesheet imports
import './_body.less';

const Body = (props) => {
  return (
    <>
      <div className='body-section'>
        <div className='body-inner-section-patient-exper'>
          <PatientReview userFlag={true} patientReviewsJson={props.patientReviewsJson} />
        </div>
      </div>
    </>
  );
};

export default Body;
