import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

//------------------------- Stylesheet import -----------------------
import '@hg/joy/src/globalstyles';
import './../../styles/_dashboardglobalstyle.less';
import './../Spinner/Spinner';
import './_index.less';

//------------------------- Components import -----------------------
import MenuComponent from '../Common/Menu/Menu';
import HeroSection from '../Common/HeroSection';
import Footer from '../Common/Footer/Footer';
import Body from './Body';

const Index = (props) => {
  //------------------------- Props destructuring --------
  const { patientExperienceInfo } = useSelector((state) => state.loadPatientExperienceData);

  let menuItems = patientExperienceInfo.Navigations;
  let navigationModelObject = patientExperienceInfo.NavigationModel;

 
  const menuClick = (section) => {
    //  setCurrentTab(section);
  };

  //------------------------- JSX code -----------------------
  return (
    <>
      <MenuComponent
        menuClick={menuClick}
        showMenus={true}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        providerInfo={JSON.parse(patientExperienceInfo.ProviderDetailsJson)}
      />
      <div className='banner-container-patient-exp-admin'>
        <div className='banner-inner-container-patient-exp-admin'>
          <HeroSection 
              showDoctorImage={false}
              src=''
              header1='Patient Reviews'
              backgroundColor='#FFFFFF' />
        </div>
      </div>
      <Body patientReviewsJson={patientExperienceInfo.ReviewsJson}/>
      <Footer />
    </>
  );
};

Index.propTypes = {};

export default Index;
