import React from "react";
// import ForgotPassword from "../ForgotPasswordForm";
import AdminStore from "../../../../.storybook/store";
import { storiesOf } from "@storybook/react";
import Index from "../Index";
// const forgotPasswordinfo = {
//   UserEmail : '',
//   EmailSent : false,
//   ErrorMessage : ''
// }
 storiesOf('MessagePassword', module)
   .addDecorator((story) => <AdminStore story={story()} />)
    .add('MessagePassword', () => <Index />);