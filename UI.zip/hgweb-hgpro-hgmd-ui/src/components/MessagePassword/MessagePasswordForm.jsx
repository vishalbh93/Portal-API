//Import react component
import React from 'react';

//Import supported components
import './MessagePasswordForm.less';
import notification from '../../assets/images/ForgotPassword/notification-circle.png';

const clickHandler = () => {
  var url = 'account/forgot-password';
  window.location.href = `${window.location.origin}/${url}`;
};

const MessagePassword = () => {
  return (
    <div className='email-confirm-main'>
      <div className='email-confirmation-form-box'>
        <div className='forgot-error-message'>
          <img className='notification-symbol' src={notification} alt='one' />
          Your password reset link has expired,{' '}
          <span className='message-body'>
            please
            <a
              className='message-link'
              href='#'
              onClick={(e) => {
                e.preventDefault();
                clickHandler();
              }}>
              <u>click here</u>
            </a>
            to generate a new link.
          </span>
        </div>
      </div>
    </div>
  );
};
export default MessagePassword;
