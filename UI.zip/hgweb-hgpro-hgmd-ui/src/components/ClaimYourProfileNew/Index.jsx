import React from 'react';

//styling imports
import './_index.less';
import '@hg/joy/src/globalstyles';

//component imports
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import HeroSection from './HeroSection';
import Body from './Body';
import { BodyBackground } from '../Common/BodyBackground';

const Index = () => {
    return (
        <>
            <MenuComponent showMenus={false} />
            <BodyBackground />          
            <HeroSection />
            <Body />
            <Footer />
        </>
    )
}

export default Index;