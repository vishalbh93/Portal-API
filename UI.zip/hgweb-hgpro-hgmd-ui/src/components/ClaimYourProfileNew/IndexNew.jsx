import React from 'react';

//styling imports
import './_index.less';
import '@hg/joy/src/globalstyles';

//component imports
import Footer from '../Common/Footer/Footer';
import HeroSection from './HeroSection';
import Body from './Body';

const IndexNew = () => {
    return (
        <>                
            <HeroSection />
            <Body />
            <Footer />
        </>
    )
}

export default IndexNew;