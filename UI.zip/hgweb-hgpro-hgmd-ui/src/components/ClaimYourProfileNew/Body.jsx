import React from 'react';

//stylesheet imports
import './_body.less';

import BrandingLogos from '../Common/BrandingLogos';
import HighlightSection from '../Common/HighlightSection';
import FindProfile from './FindProfile';

const Body = () => {
  return (
    <>
      <div className='body-section'>
        <div className='body-inner-section'>
          {/* <h2 className='header'>Let’s get started in 3 simple steps</h2> */}
          <div className='main-wrapper'>
            <FindProfile />
          </div>
        </div>
      </div>
      <div className='hl-cont mobile-view'>
        <HighlightSection />
      </div>
      <BrandingLogos />
    </>
  );
};

export default Body;
