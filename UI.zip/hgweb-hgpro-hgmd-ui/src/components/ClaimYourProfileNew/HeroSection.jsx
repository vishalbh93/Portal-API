import React from 'react';

import './_heroSection.less';
import HighlightSection from '../Common/HighlightSection';

const HeroSection = () => {
  return (
    <div className='hg-container hero-container'>
      <div className='highlight-container'>
        <h3 className='highlight-header'>Here are some of the benefits of owning a free Healthgrades Profile.</h3>
        <HighlightSection />
      </div>
    </div>
  )
}

export default HeroSection;