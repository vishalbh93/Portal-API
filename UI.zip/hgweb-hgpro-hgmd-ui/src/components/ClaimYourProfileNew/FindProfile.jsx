import React from 'react';

//styling imports
import './_findProfile.less';
import SearchProviderForm from './SearchProviderForm';

const FindProfile = () => {
  return (
    <div className='fp-container'>
      <h1 className='fp-h1 pb-32 mar-unset'>Find your profile to get started!</h1>
      <h3 className='fp-h3 pb-32 mar-unset'>Your <strong>DEA</strong> or <strong>State license number</strong> is required for verification purpose.</h3>
      <SearchProviderForm className="pb-32" />
    </div>
  )
}

export default FindProfile;