import React, { useState, useRef } from 'react';
import LayoutA from '../Common/Layouts/LayoutA';
import ReactModal from 'react-modal';

import * as service from '../../utils/service';

//Stylesheet import
import './_searchProfileNPIModel.less';

//helper
import _ from 'lodash';

//Component import
import { TextBox } from '../FormComponents/TextBox';
import { ProviderInfo } from './ProviderInfo';

//Media imports
import cross from '../../assets/images/ProviderProfile/Vector.svg';

import { HG3Tracker } from '../../utils/tracking';

const SearchProfileByNPIModel = (props) => {
  const {openModel} = props;

  const providerAccountRegister = `/api/provider/providerprofiledata`;
  const [inputValue, setinputValue] = useState('');
  const [providerInfo, setProviderInfo] = useState({});
  const [isClearData, setIsClearData] = useState(false);
  const [isError, setIsError] = useState(false);
  const refProviderCard = useRef(null);

  const textBoxClasses = 'search_input_box input-field width-100';


    const onCloseHandler = () => {
        props.closeModal();
      };

    const setSearchValue = (e) => {
      setIsError(false);
      if(e.target.value != inputValue){
        setIsClearData(false);
      }
      setinputValue(e.target.value);
    };

    const onKeyPressed = (e) => {
      let code = e.keyCode || e.which;
      if (code === 13) {
      fetchProviderInfo(inputValue)
      }
    };
    const cancelClickHandler = () => {
      setProviderInfo({});
      pageTracker('');
      HG3Tracker.OmnitureTrackLink('cancel-npi');
    };
    const clearText = (e) => {
      e.preventDefault();
      setinputValue('');
      setIsClearData(false);
      setIsError(false);
      HG3Tracker.OmnitureTrackLink('clear-npi'); 
    };

    const fetchProviderInfo = (providerId) => {
      setIsClearData(true);
      setIsError(false);
      let payload = {
        ProviderId : providerId,
        searchType : 'npi',
        DisplayStatusData : 'H'
      }
      HG3Tracker.OmnitureTrackLink('npi');
      service
        ._post(`${providerAccountRegister}`, payload)
        .then((res) => {
          if (res === null) {
            setProviderInfo({});
            setIsClearData(false);
          }
          else {
            if(_.isEmpty(res.data)){
              setProviderInfo({});
            }
            var loadJsonData = !_.isEmpty(res.data.ReturnData) && JSON.parse(res.data.ReturnData);
            if(!_.isEmpty(loadJsonData.ProviderNPI)){
              setProviderInfo(loadJsonData);
            }
            else{
              setIsError(true);
            }
          } 
        })
        .catch((err) => {}) 
    };

    return (
      <>
      <LayoutA>
        <ReactModal
          overlayClassName='roster-modal-overlay search-npi-modal-popup'
          className='modal-dialog'
          ariaHideApp={false}
          isOpen={openModel}
          contentLabel='hospital-model'
          onRequestClose={onCloseHandler}
          shouldCloseOnOverlayClick={false}>
          <div className='model-window-section'>
            <div className='model-container'>
              <div className='close'>
                <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
              </div>
              <div className='modal-row'>
                <div className='model-title'>
                  <div className='header'>Search by NPI</div>
                </div>
                <div className='main-container'>
                    <div className='input-field-name'>
                      <span className='field-name'>NPI Number</span>
                    </div>
                    <div className='search-inner-wrapper-npi-model'>
                      <TextBox
                        textValue={inputValue}
                        onChangeHandler={setSearchValue}
                        onKeyPressed={onKeyPressed}
                        classes={textBoxClasses}
                        maxlength={10}
                      />
                      {<span className='search-icon-npi-model'>
                        <i className={`${isClearData?'icon-close':'icon-model'}`} onClick={(e) => isClearData?clearText(e):fetchProviderInfo(inputValue)}></i>
                      </span>}
                    </div>
                    {isError && <div className='div-error-msg'>
                        <span className='alrt-msg'>NPI is not valid : {inputValue}</span>
                    </div>}
                    {!_.isEmpty(providerInfo) &&
                      <>
                        <div className='separator'></div>
                        <div className={`${!_.isEmpty(providerInfo.PrimarySpecialty) || !_.isEmpty(providerInfo.Address) || !_.isEmpty(providerInfo.CityStateZip)?'pi-card-container npi-search':'pi-card-container'}`} ref={refProviderCard}>
                          <ProviderInfo providerInfo={providerInfo} cancel={cancelClickHandler} isNPISearch={true}/></div>
                      </>
                    }
                </div>
                <div className='dv-contact-us'>
                  <span>
                    Unable to find your profile? {window.innerWidth <= 768 && <br/>} <a onClick={()=> HG3Tracker.OmnitureTrackLink('contact-us')} href='/contactus'>Contact us</a>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </ReactModal>
      </LayoutA>
      </>
    );
};

export default SearchProfileByNPIModel;