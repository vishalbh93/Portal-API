import React from 'react';
import PropTypes from 'prop-types';

//stylesheet import
import './_providerInfo.less';

//helper
import _ from 'lodash';

//tracker import
import { HG3Tracker } from '../../utils/tracking';

export const ProviderInfo = (props) => {
  const { providerInfo, cancel, isNPISearch } = props;

  const getStartedClickHandler = () => {
    HG3Tracker.OmnitureTrackLink('getStartedRegistration');
    window.location.href = `${window.location.origin}/account/register/${providerInfo.ProviderId}`;
  };

  return (
    <>
      <section id={`${isNPISearch? 'provider-card' :'provider-info'}`} className={`${isNPISearch? 'provider-info-section npi-search-sec':'provider-info-section'}`}>
        <img 
        className={`${!_.isEmpty(providerInfo.PrimarySpecialty) || !_.isEmpty(providerInfo.Address) || !_.isEmpty(providerInfo.CityStateZip)? 'provider-img':'npi-provider-img'}`}
          src={providerInfo.ImageUrl}
          alt={providerInfo.DisplayFullName}
          title={providerInfo.DisplayFullName}
        />
        <div className={`${isNPISearch? 'provider-info-desc search-desc' :'provider-info-desc'}`} title={isNPISearch ? providerInfo.DisplayName: providerInfo.DisplayFullName}>
          <strong className='provider-info-name'>{isNPISearch ? providerInfo.DisplayName : providerInfo.DisplayFullName}</strong>
          <br />
          {!isNPISearch? <><span>
            {providerInfo.PrimarySpecialty} | {providerInfo.Gender}
          </span>
          <br />
          <span>{providerInfo.Address}</span>
          <br />
          <span>{providerInfo.CityStateZip}</span></> :
           <>
           {!_.isEmpty(providerInfo.PrimarySpecialty) &&
            !_.isEmpty(providerInfo.Gender) && 
            !_.isEmpty(providerInfo.PrimarySpecialty) ? <span>{providerInfo.PrimarySpecialty} | {providerInfo.Gender}</span>: 
            <><span>{!_.isEmpty(providerInfo.Gender)? providerInfo.Gender: ''}</span><br /></>}
           {!_.isEmpty(providerInfo.Address) && <><span>{providerInfo.Address}, {providerInfo.CityStateZip}</span><br /></>}
           <span className='provider-npi'>{!_.isEmpty(providerInfo.ProviderNPI)? providerInfo.ProviderNPI: ''}</span>
           </>}
        </div>
      </section>
      <div className={`${isNPISearch? 'provider-info-button-section btn-section':'provider-info-button-section'}`}>
        <button
          type='button'
          id='get-started'
          name='get-started'
          title='Get Started' 
          onClick={getStartedClickHandler}>
          Claim Your Profile
        </button>
      </div>
    </>
  );
};

ProviderInfo.defaultProps = {
  isNPISearch: false
};

ProviderInfo.propTypes = {
  isNPISearch: PropTypes.bool
};