import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux';
//service
import * as service from '../../utils/service';
import { getQueryStringArray } from '../../utils/utils';

//stylesheet import
import './_searchProviderForm.less';

//component import
import Spinner from '../Spinner/Spinner';
import { ProviderInfo } from './ProviderInfo';
import { AutoSuggestDropdown } from './AutoSuggestDropdown';
import SearchProfileNPIModel from './SearchProfileByNPIModel';

//helper imports
import _ from 'lodash';

//tracker import
import { HG3Tracker } from '../../utils/tracking';

const SearchProviderForm = () => {
  const registerAccountBaseurl = `/api/account/register-provider`;
  const providerBaseurl = `/api/provider`;
  const locationBaseurl = `/api/location`;

  //state variables
  const [providerAutoSuggestData, setProviderAutoSuggestData] = useState([]);
  const [locationAutoSuggestData, setLocationAutoSuggestData] = useState([]);
  const [providerInfo, setProviderInfo] = useState({});
  const [locationInfo, setLocationInfo] = useState(
    useSelector((state) => state.getClaimPageParamsReducer)
  );
  const [showSpinner, setShowSpinner] = useState(false);
  const [showProviderListClass, setShowProviderListClass] = useState('disable');
  const [showLocationListClass, setShowLocationListClass] = useState('disable');
  const [toggleNPIModel, setToggleNPIModel] = useState(false);

  let queryString = getQueryStringArray();

  //element reference
  const refProviderName = useRef();
  const refLocation = useRef();
  const refProviderCard = useRef(null);

  const handleClickOutside = (event) => {
    if (refProviderName.current && !refProviderName.current.contains(event.target)) {
      setShowProviderListClass('disable');
    }
    if (refLocation.current && !refLocation.current.contains(event.target)) {
      setShowLocationListClass('disable');
    }
    if (
      document.getElementById('providerName') != null &&
      document.getElementById('providerName') != undefined &&
      document.getElementById('providerName').contains(event.target)
    ) {
      setShowProviderListClass('enable');
    }
    if (
      document.getElementById('locationDropdown') != null &&
      document.getElementById('locationDropdown') != undefined &&
      document.getElementById('locationDropdown').contains(event.target)
    ) {
      setShowLocationListClass('enable');
    }
  };

  //Bind the event listener
  document.addEventListener('mousedown', handleClickOutside);

  //event handlers
  const providerInputValueChangeHandler = () => {
    refProviderName.current.value.length >= 2
      ? fetchProviderAutoSuggestData()
      : setProviderAutoSuggestData([]);
  };
  const locationInputValueChangeHandler = () => {
    refLocation.current.value.length >= 2
      ? fetchLocationAutoSuggestData()
      : setLocationAutoSuggestData([]);
  };
  const cancelClickHandler = () => {
    setProviderAutoSuggestData([]);
    setProviderInfo({});
    pageTracker('');
  };

  const pageTracker = (type) => {
    HG3Tracker.OmnitureTrackLink(type !== undefined && type !== null ? type : '');
  };

  //API call(s)
  const fetchProviderAutoSuggestData = () => {
    service
      .get(`${providerBaseurl}?pt=${locationInfo.pt}&term=${refProviderName.current.value}`)
      .then((res) => {
        setProviderAutoSuggestData(res.Suggestions);
      })
      .catch((err) => { });
  };
  const fetchLocationAutoSuggestData = () => {
    service
      .get(`${locationBaseurl}?pt=${locationInfo.coOrdinates}&term=${refLocation.current.value}`)
      .then((res) => {
        setLocationAutoSuggestData(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const fetchProviderInfo = (providerId, byNpi) => {
    setShowSpinner(true);
    service
      .get(
        `${registerAccountBaseurl}?pt=${locationInfo.pt}&providerId=${providerId}&byNpi=${byNpi}`
      )
      .then((res) => {
        if (res === null) setProviderInfo({});
        else setProviderInfo(res);

        refProviderName.current.value = '';
        setProviderAutoSuggestData([]);
      })
      .catch((err) => { })
      .finally(() => setShowSpinner(false));
  };
  const onClickHandler = (e) =>{
    e.preventDefault();
    setToggleNPIModel(true);
    pageTracker('npi-search');
  };
  const closedNPIModel = () =>{
    setToggleNPIModel(false);
    pageTracker('close');
  };

  // Use Effects
  useEffect(() => {
    if (!_.isEmpty(providerInfo)) refProviderCard.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [providerInfo])

  useEffect(() => {
    if (refLocation.current != undefined) refLocation.current.value = locationInfo.value;
    if (queryString.pwid != undefined && queryString.pwid != '') {
      fetchProviderInfo(queryString.pwid, false);
    } else if (queryString.npi != undefined && queryString.npi != '') {
      fetchProviderInfo(queryString.npi, true);
    }
  }, []);

  return (
    <>
    {toggleNPIModel && <SearchProfileNPIModel closeModal={closedNPIModel} openModel={toggleNPIModel}/>}
      <div id='search-provider-form' className='form-group'>
        <>
          <div className='input-group' title='Medical Professional’s Name'>
            <label htmlFor='txtProviderName'>Medical Professional’s Name</label>
            <input
              id='txtProviderName'
              placeholder='Medical Professional’s Name'
              type='text'
              className='search'
              onChange={providerInputValueChangeHandler}
              onFocus={(e) => setShowProviderListClass('enable')}
              ref={refProviderName}
              autoComplete='off'
            />
            {providerAutoSuggestData.length > 0 && (
              <AutoSuggestDropdown
                dropDownName={'providerName'}
                keyWord={refProviderName.current.value}
                suggestions={providerAutoSuggestData.map((data) => {
                  return {
                    text: `${data.Text} - ${data.AdditionalFieldValues}`,
                    value: data.Id,
                    data: data
                  };
                })}
                showList={showProviderListClass}
                clickHandler={(provider) => {
                  pageTracker('providername');
                  fetchProviderInfo(provider.Id, false);
                }}
              />
            )}
          </div>
          <div className='input-group' title='Enter City, State or Zip'>
            <label htmlFor='txtLocation'>City, State or Zip</label>
            <input
              id='txtLocation'
              placeholder='Enter City, State or Zip'
              type='text'
              onChange={locationInputValueChangeHandler}
              onFocus={(e) => setShowLocationListClass('enable')}
              ref={refLocation}
              autoComplete='off'
            />
            {locationAutoSuggestData.length > 0 && (
              <AutoSuggestDropdown
                dropDownName={'locationDropdown'}
                keyWord={refLocation.current.value}
                suggestions={locationAutoSuggestData.map((data) => {
                  return {
                    text: data.value,
                    value: data.pt,
                    data: data
                  };
                })}
                showList={showLocationListClass}
                clickHandler={(locationData) => {
                  refLocation.current.value = locationData.value;
                  setLocationInfo(locationData);
                  setLocationAutoSuggestData([]);
                  pageTracker('location');
                }}
              />
            )}
          </div>
        </>
        <div className='dv-contact-us'>
          <span>
            Unable to find your profile? {window.innerWidth <= 768 && <br/>} <a href='/' onClick={(e)=> onClickHandler(e)}>Try our NPI based search</a> or <a  onClick={(e)=>pageTracker('contact-us')} href='/contactus'>Contact us</a>
          </span>
        </div>
        <>{showSpinner && <Spinner />}</>
      </div>
      {!_.isEmpty(providerInfo) &&
        <>
          <div className='separator'></div>
          <div className='pi-card-container' ref={refProviderCard}>
            <ProviderInfo providerInfo={providerInfo} cancel={cancelClickHandler} /></div>
        </>
      }
    </>
  );
};

export default SearchProviderForm;
