import React from 'react';
import ClaimYourProfileFlow from './ClaimYourProfileFlow';
import SearchProviderForm from './SearchProviderForm';
import BrandingLogos from '../Common/BrandingLogos';

//stylesheet imports
import './_body.less';
import HighlightSection from '../Common/HighlightSection';

const Body = () => {
  return (
    <>
      <div className='body-section'>
        <div className='body-inner-section'>
          <h2 className='header'>Let’s get started in 3 simple steps</h2>
          <div className='main-wrapper'>
            <div className='workflow-section workflow-section-mobile'>
              <ClaimYourProfileFlow />
            </div>
            <div className='search-provider-section search-provider-mobile'>
              <SearchProviderForm />
            </div>
          </div>
        </div>
      </div>
      <div className='mobile-view'>
        <HighlightSection />
      </div>
      <BrandingLogos />
    </>
  );
};

export default Body;
