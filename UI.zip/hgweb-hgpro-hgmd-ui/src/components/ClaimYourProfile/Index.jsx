import React, { useState, Fragment } from 'react';
import './_index.less';

//styling imports
import '@hg/joy/src/globalstyles';

//media imports

//components imports
import HeroSection from '../Common/HeroSection';
import Body from './Body';
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';

const Index = (props) => {
  const [currentTab, setCurrentTab] = useState('landing');
  const menuClick = (section) => {
    setCurrentTab(section);
  };

  // This can be removed once API is done
  let menubar = [
    {
      Id: 1,
      ParentId: 0,
      Name: 'Health Feeds',
      Url: 'http://update-alpha-testaws.healthgrades.com/dashboard/Index/Y2Y9R',
      IsExternal: false,
      IconClass: '',
      SubMenu: []
    },
    {
      Id: 2,
      ParentId: 0,
      Name: 'Dashboard',
      Url: 'http://update-alpha-testaws.healthgrades.com/dashboard/Index/Y2Y9R',
      IsExternal: false,
      IconClass: '',
      SubMenu: []
    },
    {
      Id: 3,
      ParentId: 0,
      Name: 'My Profile',
      Url: 'http://update-alpha-testaws.healthgrades.com/provider/profile/Y2Y9R',
      IsExternal: false,
      IconClass: '',
      SubMenu: []
    },
    {
      Id: 4,
      ParentId: 0,
      Name: 'My Tools',
      Url: '#',
      IsExternal: false,
      IconClass: '',
      SubMenu: [
        {
          Id: 5,
          ParentId: 4,
          Name: 'Help Center',
          Url: 'https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        }
      ]
    },
    {
      Id: 6,
      ParentId: 0,
      Name: 'Patient Experience',
      Url: '#',
      IsExternal: false,
      IconClass: '',
      SubMenu: [
        {
          Id: 7,
          ParentId: 6,
          Name: 'Patient Reviews',
          Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/provider-reviews',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        },
        {
          Id: 8,
          ParentId: 6,
          Name: 'Analytics',
          Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/analytics',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        },
        {
          Id: 9,
          ParentId: 6,
          Name: 'Resources',
          Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/resources',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        }
      ]
    },
    {
      Id: 7,
      ParentId: 0,
      Name: 'Setting',
      Url: '#',
      IsExternal: false,
      IconClass: '',
      SubMenu: [
        {
          Id: 8,
          ParentId: 7,
          Name: 'My Account Settings',
          Url: 'http://update-alpha-testaws.healthgrades.com/account/settings',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        },
        {
          Id: 9,
          ParentId: 7,
          Name: 'Change Password',
          Url: 'http://update-alpha-testaws.healthgrades.com/account/ChangePassword',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        },
        {
          Id: 10,
          ParentId: 7,
          Name: 'Sign Out',
          Url: 'http://update-alpha-testaws.healthgrades.com/account/sign-out',
          IsExternal: true,
          IconClass: '',
          SubMenu: []
        }
      ]
    }
  ];

  return (
    <Fragment>
      <MenuComponent menuClick={menuClick} showMenus={false} menubar={menubar} />
      <HeroSection
        header1='Claim Your'
        header2='Free Profile'
        subHeading='Healthgrades is the leading destination for patients looking for healthcare professionals'
        displayHighlight='true'
      />
      <Body />
      <Footer />
    </Fragment>
  );
};

Index.propTypes = {};

export default Index;
