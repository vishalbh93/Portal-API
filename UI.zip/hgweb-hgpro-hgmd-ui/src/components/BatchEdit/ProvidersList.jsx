import React, { useEffect, useState } from 'react';
import './_providersList.less';
import Header from '../Header/Header';
import EditIcon from '../../assets/images/ProfileEdit/PracticeAndLocation/icon-edit.svg';
import _ from 'lodash';
import specialtyIcon from '../../assets/images/icon-license.svg';
import genderIcon from '../../assets/images/icon-user.svg';
import locationIcon from '../../assets/images/icon-map-marker.svg';
import EditModal from './Modal/EditModal';
import ProviderImage from '@hg/joy/src/components/ProviderImage';
import { getGenderCode } from '../../utils/utils';
import Button from '@hg/joy/src/components/Button/Button';

import TrashSVG from '../../assets/images/trash.svg';
import UploadSVG from '../../assets/images/upload2.svg';
import RemoveConfirmationPopup from './InsuranceBatchEdit/RemoveConfirmationPopup';
import InsuranceListData from './InsuranceBatchEdit/InsuranceListData';
import CommonBatchData from './CommonBatchData';

const ProvidersList = (props) => {
  const {
    providersCount,
    batchEditType,
    batchText,
    currentBatchData,
    setCurrentProvider,
    providerIds,
    setOpenModal,
    setOpenAddPopupFlag,
    setSelectedProviders,
    setProvidersCountOnFilterChange
  } = props;

  /* #region consts and states */
  const [type, setEditType] = useState(batchEditType);
  const [_batchText, setBatchText] = useState(batchText);
  const [_initProvidersArray, setInitProvidersArray] = useState(currentBatchData);
  const [batchProvidersArray, setBatchProvidersArray] = useState(currentBatchData);
  const [selectedProvidersCount, setSelectedProvidersCount] = useState();
  const [hoveredID, setHoveredID] = useState('');
  const headerColumnsForBatchEdit = [
    {
      ColumnName: `Providers (${(selectedProvidersCount)})`,
      IsSortBy: false,
      ClassName: 'provider-search name',
      IsSorted: false,
      isShow: true
    },
    {
      ColumnName: 'Location',
      IsSortBy: false,
      ClassName: 'provider-search location',
      IsSorted: false,
      isShow: true
    },
    {
      ColumnName: batchEditType,
      IsSortBy: false,
      ClassName: `provider-search ${batchEditType.toLowerCase()}`,
      IsSorted: false,
      isShow: true
    }
  ];
  const [openEditPopup, setEditPopup] = useState(false);
  const [batchData, setBatchData] = useState([]);
  const [removeConfirmation, setRemoveConfirmation] = useState(false);
  const [selectInsurance, setSelectInsurance] = useState([]);
  /* #endregion */

  /* #region handlers */
  const genderText = (gender) =>
    _.isEmpty(gender) ? '' : gender.toLowerCase() === 'f' ? 'Female' : 'Male';

  const handleSelectChange = (e) => {
    const { id, checked } = e.target;
    let temp = batchProvidersArray.map((data, index) => {
      if (data.Provider.ProviderCode === id)
        return { ...data, Provider: { ...data.Provider, Selected: checked } };
      else {
        return { ...data };
      }
    });
    setBatchProvidersArray([...temp]);
    setSelectedProviders([...temp.filter((d) => d.Provider.Selected)]);
    let _count = temp.filter((j) => j.Provider.Selected === true).length;
    let providerIds =
      _count >= 1
        ? temp
            .filter((j) => (j.Provider.Selected ? j.Provider.ProviderCode : ''))
            .map((i) => i.Provider.ProviderCode)
        : [];
    setSelectedProvidersCount(_count);
    props.getDetailsOfSelectedProviders(_count, providerIds);
  };

  const handleSelectAllChange = (e) => {
    const { name, checked } = e.target;
    if (name == 'AllSelect') {
      let temp = batchProvidersArray.map((i) => {
        return { ...i, Provider: { ...i.Provider, Selected: checked } };
      });
      setBatchProvidersArray([...temp]);
      setSelectedProviders([...temp.filter((d) => d.Provider.Selected)]);
      setSelectedProvidersCount(checked ? providersCount : 0);
      let _count = temp.filter((j) => j.Provider.Selected === true).length;
      let providerIds =
        _count > 1
          ? temp
              .filter((j) => (j.Provider.Selected ? j.Provider.ProviderCode : ''))
              .map((i) => i.Provider.ProviderCode)
          : [];
      props.getDetailsOfSelectedProviders(_count, providerIds);
    }
  };

  const getBatchEditDetails = () => {
    switch (batchEditType) {
      case 'Hospital Affiliations':
        return 'Hospitals';
      case 'Insurance':
        return 'InsuranceList';
      case 'Photos':
        return 'PhotoData';
      default:
        return 'Items';
    }
  };

  const getProviderPhoto = (val) => {
    let item = getBatchEditDetails();
    let photodetails = val[item];
    let providerDetails = val['Provider'];
    let tempReturn = !_.isEmpty(photodetails) ? (
      <>
        <div className='photo-container'>
          <div className='photo-display-container'>
            <ProviderImage
              providerName={providerDetails.Name}
              providerGender={getGenderCode(photodetails.Gender)}
              src={photodetails.ImageUrl}
              size='lg'
            />
          </div>
          <div className='photo-upload-remove-container'>
            <div className='upload-photo'>
              <img src={UploadSVG} alt='upload' className='upload-img' />
              <Button
                id={`btn-${val.value}`}
                className={`btn-photo-upload btn-photo`}
                text={'Upload Photo'}
                disabled={false}
                size='lg'
                style='ghost'
                onClick={() => {
                  //open pop-up
                }}
              />
            </div>
            <div className='remove-photo'>
              {photodetails?.HasImage && (
                <>
                  <img src={TrashSVG} alt='remove' className='remove-img' />
                  <Button
                    id={`btn-${val.value}`}
                    className={`btn-photo-remove btn-photo`}
                    text={'Remove Photo'}
                    disabled={false}
                    size='lg'
                    style='ghost'
                    onClick={() => {
                      //open pop-up
                    }}
                  />
                </>
              )}
            </div>
          </div>
        </div>
      </>
    ) : (
      <span>No {batchEditType}</span>
    );
    return tempReturn;
  };

  /* #region need in future */
  const onEditHandler = (val) => {
    setEditPopup(val);
    let data = getDataForCurrentProvider(val);
    setBatchData(data);
    setCurrentProvider(val.Provider, data);
  };
  /* #endregion */

  const getDataForCurrentProvider = (val) => {
    if (batchEditType.toLocaleLowerCase() == 'hospital affiliations') return val.Hospitals;
    else if (batchEditType.toLocaleLowerCase() == 'insurance') return val.InsuranceList;
    else if (
      batchEditType.toLocaleLowerCase() == 'conditions' ||
      batchEditType.toLocaleLowerCase() == 'procedures' ||
      batchEditType.toLocaleLowerCase() == 'specialty'
    )
      return val.Items;
  };

  const reloadList = (val) => {
    let tempBatchArr = [..._initProvidersArray];
    let index = tempBatchArr.findIndex(
      (i) => i.Provider.ProviderCode === openEditPopup.Provider.ProviderCode
    );
    let item = getBatchEditDetails();
    tempBatchArr[index][item] = val;
    setInitProvidersArray(tempBatchArr);
    setEditPopup(false);
  };

  const getModal = (val) => {
    props.setOpenModal(val);
    val ? props.addForSingle(true) : null;
  };

  const getInsuranceJSX = (val) => {
    let item = getBatchEditDetails();
    let arr = val[item];
    return <InsuranceListData insuranceData={arr} batchEditType={batchEditType} />;
  };

  const getCommonJSX = (val) => {
    let item = getBatchEditDetails();
    let arr = val[item];
    return <CommonBatchData batchData={arr} batchEditType={batchEditType} batchText={batchText} />;
  };
  /* #endregion */

  /* #region effects */
  useEffect(() => {
    !_.isEmpty(batchEditType) && setEditType(batchEditType);
    !_.isEmpty(batchText) && setBatchText(batchText);
    !_.isEmpty(currentBatchData) ? setInitProvidersArray([...currentBatchData]) : null;
  }, [batchEditType, batchText, currentBatchData]);

  useEffect(() => {
    !_.isEmpty(_initProvidersArray) && setBatchProvidersArray([..._initProvidersArray]);
  }, [_initProvidersArray]);

  useEffect(() => {
    props.hideButtonToAddBatchEditOption(selectedProvidersCount);
  }, [selectedProvidersCount]);

  useEffect(()=>{
    setSelectedProvidersCount(providersCount) 
    setSelectedProviders(currentBatchData)},[currentBatchData])

  useEffect(() => {
    if (!_.isEmpty(providerIds)) {
      let temp = providerIds.split(',');
      props.getDetailsOfSelectedProviders(temp.length, temp);
    }
  }, []);
  /* #endregion */

  /* #region JSX */
  const commonJsx = (
    <>
      {batchProvidersArray.map((val, index) => (
        <div
          className={index % 2 !== 0 ? 'provider-row alternate-background' : 'provider-row'}
          key={index}>
          <div className='checkbox'>
            <input
              id={val.Provider.ProviderCode}
              name={val.Provider.ProviderCode}
              value={val.Provider.Selected}
              type='checkbox'
              onChange={handleSelectChange}
              checked={val.Provider.Selected == true}></input>
            <label className='checkbox-single-provider' htmlFor={val.Provider.ProviderCode}></label>
          </div>

          <div className='providerInRoster-details-container'>
            <div
              id={val.Provider.ProviderCode}
              onMouseEnter={(e) => setHoveredID(e.currentTarget.id)}
              onMouseLeave={() => setHoveredID('')}
              className={
                index % 2 !== 0
                  ? 'providerInRoster-details alternate-background'
                  : 'providerInRoster-details'
              }>
              <div className='providerInRoster-name-container'>
                <span>{val.Provider.Name}</span>
                <div className={'providerInRoster-info roster-providers'}>
                  <span className='icon-text-container'>
                    <img src={genderIcon} alt='gender' />
                    {genderText(val.Provider.Gender)}
                  </span>
                  <span className='icon-text-container'>
                    <img src={specialtyIcon} alt='gender' />
                    {val.Provider.Specialty}
                  </span>
                </div>
              </div>

              <div className='providerInRoster-office'>
                {!_.isEmpty(val.Provider.Address) && (
                  <span className='icon-text-container'>
                    <img src={locationIcon} alt='location' />
                    {`${
                      !_.isEmpty(val.Provider.Address.PracticeName)
                        ? val.Provider.Address.PracticeName
                        : ''
                    }${!_.isEmpty(val.Provider.Address.PracticeName) ? ', ' : ''} 
                    ${val.Provider.Address.Street}${
                      !_.isEmpty(val.Provider.Address.Street) ? ', ' : ''
                    }`}
                    <br />
                    {`${val.Provider.Address.CityState}`}
                  </span>
                )}
              </div>
                {batchEditType.toLocaleLowerCase() == 'insurance' && <div className='mobile-batch-edittype'>
                  <hr/>
                  {batchEditType}
                  </div>}
              {batchEditType !== 'Photos' ? (
                batchEditType.toLocaleLowerCase() == 'insurance' ? (
                  getInsuranceJSX(val)
                ) : (
                  getCommonJSX(val)
                )
              ) : (
                <div className={'providerInRoster-batch-edit'}>{getProviderPhoto(val)}</div>
              )}
              {/* 
              Need this in future 
              <div
                className={'providerInRoster-batch-edit edit-onhover'}
                onClick={() => onEditHandler(val)}>
                <div className='btn-edit-onhover'>
                  <img
                    src={EditIcon}
                    alt='Edit'
                    id={val.Provider.ProviderCode}
                    className='img'
                    style={
                      !_.isEmpty(hoveredID) && hoveredID == val.Provider.ProviderCode
                        ? { display: 'block' }
                        : { display: 'none' }
                    }
                  />
                  {!_.isEmpty(hoveredID) && hoveredID == val.Provider.ProviderCode ? 'Edit' : ''}
                </div>
              </div> */}
            </div>
          </div>
        </div>
      ))}
    </>
  );
  /* #endregion */

  return (
    <div>
      <div className='provider-list-content'>
        {/* Header */}
        <div className='checkbox'>
          <input
            id='AllSelect'
            name='AllSelect'
            type='checkbox'
            checked={
              batchProvidersArray.length == 0
                ? false
                : batchProvidersArray.filter((val) => val.Provider.Selected !== true).length < 1
            }
            onChange={handleSelectAllChange}></input>
          <label className='checkbox-cp' htmlFor='AllSelect'></label>
        </div>
        <Header columns={headerColumnsForBatchEdit} isShow={true} providersCount={providersCount} />

        {/* List */}
        {!_.isEmpty(batchProvidersArray) && (
          <div className='provider-item-container'>{commonJsx}</div>
        )}
      </div>

      <EditModal
        type={type}
        batchText={_batchText}
        setEditPopup={setEditPopup}
        addBtnClickHander={getModal}
        currentProviderBatchData={batchData}
        currentBatchData={openEditPopup.Provider}
        reloadList={reloadList}
        openEditPopup={openEditPopup}
        setOpenAddPopup={setOpenModal}
        setOpenAddPopupFlag={setOpenAddPopupFlag}
        setRemoveConfirmation={setRemoveConfirmation}
        selectInsurance={selectInsurance}
        setSelectInsurance={setSelectInsurance}
      />
      {removeConfirmation && <RemoveConfirmationPopup />}
    </div>
  );
};

export default ProvidersList;
