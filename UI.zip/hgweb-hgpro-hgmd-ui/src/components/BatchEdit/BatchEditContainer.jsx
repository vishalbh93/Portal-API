import React, { useState, useEffect, Suspense, lazy } from 'react';
import './_batchEditContainer.less';
import _ from 'lodash';
import PropTypes from 'prop-types';
import Breadcrumbs from '@hg/joy/src/components/Breadcrumbs';
import BatchEditFilters from './BatchEditFilters';
import RightChervon from '../../assets/images/chevron_right.svg';
const ProvidersWithSelectedBatchEdit = lazy(() => import('./ProvidersWithSelectedBatchEdit'));

const BatchEditContainer = (props) => {
  const {
    currentBatchData,
    batchEditType,
    batchText,
    providersCount,
    selectedProvidersCount,
    providerIds,
    setSelectedProvidersCount
  } = props;

  const [batchData, setBacthData] = useState(currentBatchData);
  const [resetSelection, setResetSelection] = useState(false);
  const breadcrumbLink = [
    {
      href: `${document.referrer}`,
      name: 'Providers'
    },
    {
      name: batchEditType
    }
  ];

  const filterClickHandler = (val) => {
    props.filterSelectionHandler(val);
    setResetSelection(true);
  };

  const setResetSelectionForFilterChange = (val) => {
    setResetSelection(val);
  };

  useEffect(() => {
    !_.isEmpty(currentBatchData) && setBacthData(currentBatchData);
  }, [currentBatchData, batchEditType]);

  return (
    <main className={`batch-edit-main`}>
      <div className={`batch-edit-inner-main`}>
        <Breadcrumbs className='optional-class' links={breadcrumbLink} />

        <div className='navigation'>
          <a href={`${document.referrer}`}><span className='sp1'>Providers</span></a>
          <span>
            <img src={RightChervon} alt='chevron-img' />
          </span>
          <span className='sp2'>{batchEditType}</span>
        </div>
        <BatchEditFilters
          providersCount={providersCount}
          batchEditType={batchEditType}
          batchText={batchText}
          filterSelectionHandler={filterClickHandler}
        />
        <Suspense fallback=''>
          <ProvidersWithSelectedBatchEdit
            currentBatchData={batchData}
            batchEditType={batchEditType}
            batchText={batchText}
            providerIds={providerIds}
            providersCount={providersCount}
            resetSelection={resetSelection}
            setResetSelectionForFilterChange={setResetSelectionForFilterChange}
            selectedProvidersCount={selectedProvidersCount}
            setSelectedProvidersCount={setSelectedProvidersCount}
          />{' '}
        </Suspense>
      </div>
    </main>
  );
};

BatchEditContainer.propTypes = {
  batchEditType: PropTypes.string,
  batchText: PropTypes.string
};

BatchEditContainer.defaultProps = {
  batchEditType: 'hopitals',
  batchText: 'Hospital Affiliations'
};

export default BatchEditContainer;
