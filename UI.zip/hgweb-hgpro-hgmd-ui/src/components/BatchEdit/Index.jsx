/* #region imports and helper*/
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import './_index.less';
import Footer from '../Common/Footer/Footer';
import MenuComponent from '../Common/Menu/Menu';
import Banner from './Banner';
import BatchEditContainer from './BatchEditContainer';
import { HG3Tracker } from '../../utils/tracking';

import * as service from '../../utils/service';
import _ from 'lodash';
/* #endregion */

const Index = () => {
  /* #region selector */
  const { batchEdit, providerCode, currentUserId, providerIds, batchEditType } = useSelector(
    (state) => state.loadBatchEdit
  );
  /* #endregion */

  /* #region constants and states */
  const batchEditData = batchEdit;
  const [currentBatchData, setCurrentBatchData] = useState([]);
  const [providersCount, setProvidersCount] = useState();
  const [selectedProvidersCount, setSelectedProvidersCount] = useState();
  const [type, setType] = useState('');
  const [batchText, setBatchText] = useState('');
  /* #endregion */

  /* #region handlers */
  const providerDetails = () => {
    if (!_.isEmpty(batchEditData)) {
      let details = {
        DisplayFullName: batchEditData.NavigationModel.DisplayName,
        ImageUrl: batchEditData.NavigationModel.ImageUrl,
        PrimarySpecialty: '',
        Gender: '',
        Age: '',
        Pwid: batchEditData.NavigationModel.ProviderId
      };
      return details;
    }
    return [];
  };

  const getBreadcrumbText = (val) => {
    switch (val.toLowerCase()) {
      case 'hospitals':
        return 'Hospital Affiliations';
      case 'conditions':
        return 'Conditions';
      case 'insurance':
        return 'Insurance';
      case 'photos':
        return 'Photos';
      case 'procedures':
        return 'Procedures';
      case 'specialties':
        return 'Specialty';
      default:
        return 'Hospital Affiliations';
    }
  };

  const handleFilterClick = (value) => {
    if (!_.isEmpty(value) && !_.isEmpty(providerIds)) {
      let payload = providerIds.split(',');
      let currentType = getBreadcrumbText(value);
      setType(currentType);
      setBatchText(value);
      setProvidersCount(payload.length);
      setSelectedProvidersCount();
      service._post(`/api/roster/${value}`, payload, true).then((res) => {
        if (res.status == 200) {
          setCurrentBatchData(res.data);
          setSelectedProvidersCount(res.data.length);
        }
      });
      HG3Tracker.OmnitureTrackLink(`batch-filter|${value}`);
    } else {
      window.history.back();
    }
  };
  /* #endregion */

  /* #region useeffects */
  useEffect(() => {
    handleFilterClick(batchEditType);
    HG3Tracker.SetInitialPageVariables({
      contextData: {},
      pageName: `batch:${type}`,
      server: 'hgmd',
      channel: 'batch'
    });

    // Track page load
    HG3Tracker.TrackPage({ pageName: `batch:${type}` });
    HG3Tracker.OmnitureResetPageName(`batch:${type}`);
  }, []);

  useEffect(() => {
    !_.isEmpty(currentBatchData) && setCurrentBatchData(currentBatchData);
  }, [currentBatchData]);
  /* #endregion */

  /* #region jsx */
  return (
    <section id='section-batch-edit' className={''}>
      <MenuComponent
        showMenus={true}
        menuItems={batchEditData.Navigations}
        infoObject={batchEditData.NavigationModel}
        providerInfo={providerDetails()}
      />
      <Banner />

      <BatchEditContainer
        currentBatchData={currentBatchData}
        batchEditType={type}
        batchText={batchText}
        providersCount={providersCount}
        filterSelectionHandler={handleFilterClick}
        providerIds={providerIds}
        selectedProvidersCount={selectedProvidersCount}
        setSelectedProvidersCount={setSelectedProvidersCount}
      />

      <div className='footer-container'>
        <Footer />
      </div>
    </section>
  );
  /* #endregion */
};

export default Index;
