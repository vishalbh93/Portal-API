import React, { Fragment, useEffect, useState } from 'react';
import './_batchEditFilters.less';
import Button from '@hg/joy/src/components/Button/Button';
import * as constants from '../../utils/constant-data';
import _ from 'lodash';
import Spinner from '../Spinner/Spinner';
import expandRow from '/public/images/auditPage/chevron-down.svg';
import { useSelector } from 'react-redux';

const BatchEditFilters = (props) => {
  const { providersCount, batchEditType } = props;

  const { providerIds } = useSelector((state) => state.loadBatchEdit);
  const filterByBatchEditTypeArray = constants.filterByBatchEditTypeArray;
  const [type, setType] = useState(batchEditType);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [openDropDown, setOpenDropDown] = useState(false);

  useEffect(() => {
    !_.isEmpty(batchEditType) && setType(batchEditType);
  }, [batchEditType]);

  const isMoreThanOne = _.isEmpty(providerIds) ? providersCount : providerIds.split(',').length;
  
  return (
    <>
      <div className='batch-edit-heading'>
        <h1>{`Batch Edit`}</h1>
        <h2>{`(${isMoreThanOne} ${isMoreThanOne > 1 ? 'Providers' : 'Provider'})`}</h2>
      </div>

      <div className='batch-edit-options'>
        <h3>{`Batch Edit Options`}</h3>
        <div className='batch-edit-options-dropdown'>
          <div className='dropdown-container' onClick={() => setOpenDropDown(!openDropDown)}>
            {type}
          </div>
          <div className='drp-img' onClick={() => setOpenDropDown(!openDropDown)}>
            <img src={expandRow} alt='expand' className={openDropDown ? 'img-flip' : ''} />
          </div>
          {openDropDown && (
            <div className='dropdown-options'>
              {filterByBatchEditTypeArray.map((val) => (
                <li
                  className='drp-list-item'
                  onClick={() => {
                    setSpinnerVisibility(true);
                    setType(val.name);
                    props.filterSelectionHandler(val.value);
                    setSpinnerVisibility(false);
                    setOpenDropDown(false);
                  }}>
                  {val.name}
                </li>
              ))}
            </div>
          )}
        </div>
        <div className='btn-set-batch-edit-filter'>
          {filterByBatchEditTypeArray.map((val, index) => (
            <Fragment key={index}>
              <Button
                id={`btn-${val.value}`}
                className={`btn-batch-edit-filter ${
                  val.name == type ? 'selected-btn-batch-edit-filter' : ''
                }`}
                text={val.name}
                disabled={false}
                size='lg'
                style='ghost'
                onClick={() => {
                  setSpinnerVisibility(true);
                  setType(val.value);
                  props.filterSelectionHandler(val.value);
                  setSpinnerVisibility(false);
                }}
              />
            </Fragment>
          ))}
        </div>
      </div>

      {spinnerVisibility && <Spinner cta={true} />}
    </>
  );
};

export default BatchEditFilters;
