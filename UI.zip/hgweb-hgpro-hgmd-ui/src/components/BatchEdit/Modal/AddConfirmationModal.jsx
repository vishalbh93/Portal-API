import React, { useEffect, useState } from 'react';
import './_addConfirmationModal.less';
import Cta from '../../Common/Form/CTA/Cta';
import ReactModal from 'react-modal';
import crossicon from '/public/images/auditPage/cross.svg';
import Button from '@hg/joy/src/components/Button/Button';
import _ from 'lodash';
import { useSelector } from 'react-redux';

const AddConfirmationModal = (props) => {
  const {
    itemsToBeAdded,
    hideModal,
    addHospitalsHandler,
    selectedProvidersCount,
    updatedCountAfterConflict,
    allowedBatchDataArrAfterConflicts,
    allowedBatchDataArrAfterConflictCount,
    editType,
    pwidsArr,
    addBatchHandler,
    currentBatchData,
    selectedProviders
  } = props;
  const { providerIds } = useSelector((state) => state.loadBatchEdit);
  const [countBatch, setBatch] = useState([]);

  const getBatchEditDetails = () => {
    switch (editType) {
      case 'Hospital Affiliations':
        return 'Hospitals';
      default:
        return 'Items';
    }
  };

  const countTheSelectedProviders = (data) => {
    let type = getBatchEditDetails();
    let totalCount = 0;
    countBatch.forEach((provider) => {
      provider[type].forEach((hospiptal) => {
        if (hospiptal.Code == data.Id) {
          totalCount++;
        }
      });
    });
    return totalCount;
  };

  useEffect(() => {
    setBatch(selectedProviders.length > 0 ? [...selectedProviders] : [...currentBatchData]);
  }, []);

  const [displayString, setDisplayString] = useState('');
  // Need confirmation for list to be displayed then we can remove this
  const getItemsToBeAdded = () => {
    let list = itemsToBeAdded.map((i) => {
      //return index == itemsToBeAdded.length - 2 ? `<span>${i.trim()} &</span>` : `<span>${i.trim()}</span>`;
      return `<span>${i.trim()}</span>`;
    });
    return list; //list.toString();
  };

  let providersCount = _.isEmpty(providerIds) ? 0 : providerIds.split(',').length;
  // let providersCount = _.isEmpty(pwidsArr) ? 0 : pwidsArr.length;

  const finalCountOfProvidersUpdatedAfterBatch =
    updatedCountAfterConflict > 0
      ? `${providersCount - updatedCountAfterConflict}`
      : pwidsArr.length;

  const finalCountForAllowedBatchDataArrAfterConflicts =
    allowedBatchDataArrAfterConflictCount > 0
      ? `${providersCount - allowedBatchDataArrAfterConflictCount}`
      : pwidsArr.length;

  useEffect(() => {
    let val = props.getNameOfRepeatedItem();
    setDisplayString(val);
  }, [updatedCountAfterConflict, providersCount]);

  return (
    <ReactModal
      overlayClassName='roster-modal-overlay'
      className='modal-dialog batch-add-modal-dialog'
      isOpen={true}
      ariaHideApp={false}
      contentLabel='batch-add-modal'
      shouldCloseOnOverlayClick={false}>
      <div className='batch-add-modal-container'>
        <div className='batch-add-modal-popup'>
          <div onClick={() => hideModal(false)} className='close-icon'>
            <img src={crossicon} alt='' />
          </div>

          <div className='batch-add-modal-content'>
            <h2>{`Add ${editType}`}</h2>
            {selectedProvidersCount !== updatedCountAfterConflict ? (
              <div className='div-batch-add-modal-content'>
                Would you like to add the following {editType.toLowerCase()}
                <ul>
                  <div
                    className='list-hospitals'
                  //dangerouslySetInnerHTML={{ __html: getItemsToBeAdded() }}
                  >
                    {itemsToBeAdded.map((i) => (
                      <>
                        <li>
                          {i.trim()}
                          {/* to {}
                          {/* <span>{pwidsArr.length - countTheSelectedProviders(i)}</span> 
                          {finalCountOfProvidersUpdatedAfterBatch > 1 ? ' providers' : ' provider'} */}
                        </li>
                      </>
                    ))}
                  </div>
                </ul>
              </div>
            ) : (
              <>
                {_.isEmpty(allowedBatchDataArrAfterConflicts) ? (
                  <div className='div-batch-add-modal-content'>
                    <span>All selected providers already have this {editType.toLowerCase()}</span>
                    {displayString.length > 0 &&
                      displayString.map((i) => (
                        <>
                          <span>{` ${i.Name != null ? i.Name : i.Text} `}</span>
                        </>
                      ))}
                  </div>
                ) : (
                  <div className='div-batch-add-modal-content'>
                    <span>Selected providers already have this {editType.toLowerCase()}</span>
                    <div>
                      {displayString.length > 0 &&
                        displayString.map((i) => (
                          <li>
                            {i.Name != null ? i.Name : i.Text}

                            {/* is already affiliated with{' '}
                             {countTheSelectedProviders(i)} some of the selected providers */}
                            <br />
                          </li>
                        ))}
                    </div>
                    <br />
                    Would you still like to add the following {editType.toLowerCase()}
                    <div>
                      {allowedBatchDataArrAfterConflicts.map((i) => (
                        <li>
                          {i.Text}
                          {/* to {}{' '}
                         <span>{pwidsArr.length - countTheSelectedProviders(i)}</span> 
                          {}{' '}
                          {finalCountForAllowedBatchDataArrAfterConflicts > 1
                            ? 'providers'
                            : 'provider'} */}
                        </li>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {(selectedProvidersCount !== updatedCountAfterConflict ||
            !_.isEmpty(allowedBatchDataArrAfterConflicts)) && (
              <Cta
                ctaValid={'valid'}
                cancelText='Cancel'
                disabled={false}
                className={`${'btn-batch-add'}`}
                cancelClickHandler={() => hideModal(false)}
                confirmText='Confirm'
                confirmClickHandler={addBatchHandler}
                cancelValid={false}
              />
            )}

          {selectedProvidersCount === updatedCountAfterConflict &&
            _.isEmpty(allowedBatchDataArrAfterConflicts) && (
              <div className='action-section btn-batch-add'>
                <Button
                  id={`btn-batch-add-cancel`}
                  className={`btn-batch-edit-filter btn-cancel`}
                  text={'Cancel'}
                  disabled={false}
                  size='lg'
                  style='ghost'
                  onClick={() => hideModal(false)}
                />
              </div>
            )}
        </div>
      </div>
    </ReactModal>
  );
};

export default AddConfirmationModal;
