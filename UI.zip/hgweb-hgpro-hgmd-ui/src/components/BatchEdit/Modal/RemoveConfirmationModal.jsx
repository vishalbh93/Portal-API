import React from 'react';
import './_removeConfirmationModal.less';
import Cta from '../../Common/Form/CTA/Cta';
import ReactModal from 'react-modal';
import crossicon from '/public/images/auditPage/cross.svg';
import _ from 'lodash';

const RemoveConfirmationModal = (props) => {
  const { hospitals, providerName, hideModal, removeProvidersHandler } = props;

  const getHospitals = () => {
    let arr = hospitals.split('.');
    let list = arr.map((i, index) => {
      // need to check & adding , - can check in future
      //return index == arr.length - 2 ? `<li>${i.trim()} &</li>` : `<li>${i.trim()}</li>`;
      return ` <span>${i.trim()}</span>`;
    });
    return list.toString();
  };

  return (
    <ReactModal
      overlayClassName='roster-modal-overlay'
      className='modal-dialog batch-remove-modal-dialog'
      isOpen={true}
      ariaHideApp={false}
      contentLabel='batch-remove-modal'
      shouldCloseOnOverlayClick={false}>
      <div className='batch-remove-modal-container'>
        <div className='batch-remove-modal-popup'>
          <div onClick={() => hideModal(false)} className='close-icon'>
            <img src={crossicon} alt='' />
          </div>

          <div className='batch-remove-modal-content'>
            <h2>Remove Hospital Affiliations</h2>
            <div>
              Are you sure, you want to remove
              <ul>
                <div
                  className='list-hospitals'
                  dangerouslySetInnerHTML={{
                    __html: getHospitals()
                  }}></div>
              </ul>
              for <b>{providerName}</b>?
            </div>
          </div>
          <Cta
            ctaValid={'valid'}
            cancelText='Cancel'
            disabled={false}
            className={`${'btn-batch-remove'}`}
            cancelClickHandler={() => hideModal(false)}
            confirmText='Confirm'
            confirmClickHandler={removeProvidersHandler}
            cancelValid={false}
          />
        </div>
      </div>
    </ReactModal>
  );
};

export default RemoveConfirmationModal;
