import React, { Fragment, useState, useEffect } from 'react';
import './_editModal.less';
import * as service from '../../../utils/service';

import crossicon from '/public/images/auditPage/cross.svg';
import genderIcon from '../../../assets/images/icon-user.svg';
import ReactModal from 'react-modal';
import EditInsuranceListWithAutoSuggest from '../InsuranceBatchEdit/EditInsuranceListWithAutoSuggest';
import Button from '@hg/joy/src/components/Button/Button';
import _ from 'lodash';
import Cta from '../../Common/Form/CTA/Cta';
import Toast from '../../Common/Toast/Toast';
import RemoveConfirmationModal from './RemoveConfirmationModal';

function EditModal(props) {
  const {
    type,
    setEditPopup,
    addBtnClickHander,
    currentProviderBatchData,
    currentBatchData,
    batchText,
    openEditPopup,
    setOpenAddPopup,
    setOpenAddPopupFlag,
    setRemoveConfirmation,
    setSelectInsurance,
    selectInsurance
  } = props;

  const [cardsVisibilityLimit, setCardsVisibilityLimit] = useState(5);
  const [_currentProviderBatchData, setCurrentProviderBatchData] =
    useState(currentProviderBatchData);
  const [selectedProvidersForDelete, setSelectedProvidersForDelete] = useState(0);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showRemoveConfirmationHandler, setShowRemoveConfirmationHandler] = useState(false);
  const _ctaValid = selectedProvidersForDelete != 0 ? 'valid' : ''; // add conditions here
  const [hospitalsSelected, setHospitalsSelected] = useState('');
  const [hoveredID, setHoveredID] = useState('');


  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const openAddPopup = () => {
    setTimeout(() => {
      setEditPopup(false);
      addBtnClickHander(true);
      setOpenAddPopup(currentBatchData)
      setOpenAddPopupFlag(true)
    }, 2000);
  };

  const getText = () => {
    if (type.toLocaleLowerCase() == 'hospital affiliations')
      return `No Hospital Affiliations yet, Add hospitals to manage affiliations`;
    if (
      type.toLocaleLowerCase() == 'conditions' ||
      type.toLocaleLowerCase() == 'procedures' ||
      type.toLocaleLowerCase() == 'specialty'
    )
      return `No ${type} yet, Add ${type}`;
  };

  const getUrlForUpdate = () => {
    switch (type) {
      case 'Hospital Affiliations':
        return '/api/provider/update-hospitals';
      case 'Specialty':
        return '/api/provider/update-specialties';
      case 'Conditions':
        return '/api/provider/update-conditions';
      case 'Procedures':
        return '/api/provider/update-procedures';
      case 'Insurance':
        return '/api/provider/update-insurance';
    }
  };

  const handleSelectChange = (e) => {
    const { id, checked } = e.target;
    let temp = _currentProviderBatchData.map((data, index) => {
      if (data.Code === id)
        return { ...data, Selected: checked, UpdateType: checked ? 'Delete' : 'None' };
      else {
        return { ...data };
      }
    });
    setCurrentProviderBatchData([...temp]);
    let _length = !_.isEmpty(temp.filter((i) => i.UpdateType === 'Delete'))
      ? temp.filter((i) => i.UpdateType === 'Delete').length
      : 0;
    setSelectedProvidersForDelete(_length);
  };

  const removeProvidersHandler = () => {
    if (!_.isEmpty(currentBatchData) && !_.isEmpty(_currentProviderBatchData)) {
      let payload = {
        ProviderId: currentBatchData.ProviderCode,
        Items: _currentProviderBatchData.map((i) => ({
          Code: i.Code,
          ActualName: i.Name,
          NameExtension: i.CityState,
          UpdateType: i.UpdateType
        }))
      };
      let url = getUrlForUpdate();
      service._post(url, payload, true).then((res) => {
        if (res.status == 200) {
          if (res.data.Success) {
            toaster.Success(
              `Hospital Removed successfully for ${
                !_.isEmpty(currentBatchData.Name) ? currentBatchData.Name : 'provider'
              }`
            );
            let tempData = JSON.parse(res.data.ReturnData).Items;
            let _tempProviderList = _currentProviderBatchData.filter((provider1) =>
              tempData.some((provider2) => provider1.Code === provider2.Code)
            );
            setEditPopup(false);
            props.reloadList(_tempProviderList);
          } else {
            toaster.Error(res.data.ErrorMessage);
          }
        } else {
          toaster.Error(successMsg);
        }
      });
      hideModal(false);
    }
  };

  const hideModal = (val) => {
    setShowRemoveConfirmationHandler(val);
  };

  const getHospitals = () => {
    let hospitalsSelectedTemp = _currentProviderBatchData.reduce((acc, item) => {
      if (item.UpdateType == 'Delete') {
        if (acc != '') {
          acc += '. ';
        }
        acc += item.Name + item.CityState;
      }
      return acc;
    }, '');
    setHospitalsSelected(hospitalsSelectedTemp);
  };

  const makeCurrentSpeciltyAsPrimary = (code) => {
    let index = _currentProviderBatchData.findIndex((i) => i.Code === code);
    let tempArray = _currentProviderBatchData;
    if (index > -1) {
      let updatedArray = tempArray.map((i, idx) => {
        return {
          Code: i.Code,
          Name: i.Name,
          UpdateType: i.UpdateType,
          IsPrimary: index === idx,
          LegacyId: '0'
        };
      });
      let payload = {
        ProviderId: currentBatchData.ProviderCode,
        Specialties: updatedArray
      };
      let url = getUrlForUpdate();
      service._post(url, payload, true).then((res) => {
        if (res.status == 200) {
          if (res.data.Success) {
            toaster.Success(
              `Updated primary specility for ${
                !_.isEmpty(currentBatchData.Name) ? currentBatchData.Name : ' provider sucessfully!'
              }`
            );
            let tempData = JSON.parse(res.data.ReturnData).Specialties;
            props.reloadList(tempData);
          }
        }
      });
    }
  };

  useEffect(() => {
    setCurrentProviderBatchData(currentProviderBatchData);
  }, [currentProviderBatchData]);

  return (
    <>
      {openEditPopup && (
        <ReactModal
          overlayClassName='roster-modal-overlay'
          className='modal-dialog batch-edit-modal-dialog'
          isOpen={true}
          ariaHideApp={false}
          contentLabel='batch-edit-modal'
          shouldCloseOnOverlayClick={false}>
          <div className='batch-edit-modal-container'>
            <div className='batch-edit-modal-popup'>
              <div className='batch-edit-option'>
                <div className='edit-option-value'>
                  <div className='edit-ins-str'>{`Edit ${type}`}</div>
                  <div className='provider-name'>
                    <div className='user-icon'>
                      <img src={genderIcon} alt='gender' />
                    </div>
                    <div className='provider-title-name'>{currentBatchData.Name}.</div>
                  </div>
                </div>

                <div onClick={() => setEditPopup(false)} className='close-icon'>
                  <img src={crossicon} alt='' />
                </div>
              </div>
              {(type.toLocaleLowerCase() == 'hospital affiliations' ||
                type.toLocaleLowerCase() == 'conditions' ||
                type.toLocaleLowerCase() == 'procedures' ||
                type.toLocaleLowerCase() == 'specialty') && (
                <>
                  {_currentProviderBatchData != undefined &&
                  _currentProviderBatchData.length <= 0 ? (
                    <div className='no-data-available'>
                      {getText()}
                      <Button
                        id={`btn-add-${type}`}
                        className={`btn-add-batch-edit`}
                        text={`Add ${type}`}
                        disabled={false}
                        size='lg'
                        style='ghost'
                        onClick={() => {
                          addBtnClickHander(true);
                        }}
                      />
                    </div>
                  ) : (
                    <div className='batch-data-available'>
                      <div className='header-container-batch'>
                        <h3>{type}</h3>
                        <Button
                          id={`btn-text-${type}`}
                          className={`btn-text`}
                          text={`Add ${batchText}`}
                          disabled={
                            !_.isEmpty(
                              _currentProviderBatchData.filter((i) => {
                                return i.UpdateType === 'Delete';
                              })
                            )
                          }
                          size='lg'
                          style='ghost'
                          onClick={() => {
                            addBtnClickHander(true);
                          }}
                        />
                      </div>
                      {!_.isEmpty(_currentProviderBatchData) && (
                        <>
                          <div className='list-wrapper'>
                            <div className='scrollbar' id='scrollbar-styles'>
                              {_currentProviderBatchData.map((value, index) => {
                                return (
                                  <Fragment key={index}>
                                    <div className='checkbox'>
                                      <input
                                        id={value.Code}
                                        name={value.Name}
                                        value={value.Code}
                                        type='checkbox'
                                        onChange={handleSelectChange}
                                        checked={value.Selected == true}></input>
                                      <label
                                        className='checkbox-single-provider'
                                        htmlFor={value.Code}></label>
                                    </div>
                                    {type.toLocaleLowerCase() !== 'specialty' && (
                                      <span key={index} className='list-item'>
                                        {value.Name}
                                      </span>
                                    )}
                                    {type.toLocaleLowerCase() == 'specialty' && (
                                      <div
                                        className='div-list-item-specialty edit-onhover'
                                        onMouseEnter={(e) => setHoveredID(value.Code)}
                                        onMouseLeave={() => setHoveredID('')}>
                                        <span key={index} className='list-item'>
                                          {value.Name}
                                        </span>
                                        {value.IsPrimary && (
                                          <span className='speciality-primary'>Primary</span>
                                        )}

                                        {!value.IsPrimary && (
                                          <div
                                            className='btn-edit-onhover'
                                            onClick={() =>
                                              makeCurrentSpeciltyAsPrimary(value.Code)
                                            }>
                                            {!_.isEmpty(hoveredID) && hoveredID == value.Code
                                              ? 'Make Primary'
                                              : ''}
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </Fragment>
                                );
                              })}
                            </div>
                          </div>

                          <Cta
                            ctaValid={_ctaValid}
                            cancelText='Cancel'
                            disabled={_ctaValid != 'valid'}
                            className={`${'btn-add-batch-edit'}`}
                            cancelClickHandler={() => {
                              setEditPopup(false);
                              setCurrentProviderBatchData(currentProviderBatchData);
                            }}
                            confirmText={`Remove ${type} ${
                              selectedProvidersForDelete != 0
                                ? `(${selectedProvidersForDelete})`
                                : ''
                            }`}
                            confirmClickHandler={() => {
                              setShowRemoveConfirmationHandler(true);
                              getHospitals();
                            }}
                            cancelValid={false}
                          />
                        </>
                      )}
                    </div>
                  )}
                </>
              )}
              {type == 'Insurance' && (
                <>
                  <div className='insurance-accepted-str'>
                    <div className='insurance-accepted'>Insurance accepted</div>
                    <div className='add-insurance-link' onClick={openAddPopup}>{`Add ${type}`}</div>
                  </div>

              <div className='insurance-edit-list'>
                {openEditPopup.InsuranceList.map((insurance, index) => {
                  if (index < cardsVisibilityLimit) {
                    return (
                      <EditInsuranceListWithAutoSuggest
                        key={index}
                        insuranceData={insurance}
                        insurancePlans={insurance.InsurancePlans}
                        setSelectInsurance={setSelectInsurance}
                        selectInsurance={selectInsurance}
                      />
                    );
                  }
                })}
               { selectInsurance &&<div className='remove-ins-btns'>
                  <button className='cancel-btn'>Cancel</button>
                  <button className='remove-btn' onClick={()=>{{setRemoveConfirmation(true);setEditPopup(false)}}}>Remove Insurance</button>
                </div>}
              </div>
            </>
          )}
        </div>
      </div>
    </ReactModal>)}
    </>
  );
}

export default EditModal;
