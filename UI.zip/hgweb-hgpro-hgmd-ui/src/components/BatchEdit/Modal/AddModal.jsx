import { useState, useEffect } from 'react';
import './_addModal.less';
import PropTypes from 'prop-types';
import _ from 'lodash';

import crossicon from '/public/images/auditPage/cross.svg';
import genderIcon from '../../../assets/images/icon-user.svg';

import ReactModal from 'react-modal';
import AutoSuggest from '../AutoSuggest';
import * as service from '../../../utils/service';
import Cta from '../../Common/Form/CTA/Cta';
import AddConfirmationModal from './AddConfirmationModal';
import AddInsuranceAutoSuggest from '../InsuranceBatchEdit/AddInsuranceAutoSuggest';
import Toast from '../../Common/Toast/Toast';
import { HG3Tracker } from '../../../utils/tracking';

function AddModal(props) {
  const {
    editType,
    batchText,
    selectedProvidersCount,
    setOpenAddPopup,
    alreadySelectedItem,
    isFromEditModalForSingleProvider,
    currentBatchData,
    pwidsArr,
    reloadList,
    openAddPopup,
    openAddPopupFlag,
    setSelectInsurancePlans,
    setOpenInsurancePlans,
    setAlreadyExistInsurance,
    setAddInsuranceListProvider,
    selectedProviders,
    initialProvidersCount,
    resetSelection,
    setPwidsArr,
    showToasterForBulk,
    selectAllInsurances,
    setSelectAllInsurances,
    setOpenFianlStatus,
    addInsuranceValue,
    setAddInsuranceValue,
    setDisplayAddCheckbox,
    displayAddCheckbox
  } = props;

  const [providerItem, setProviderItem] = useState(alreadySelectedItem);
  const [addedSelectionFromSuggestArr, setAddedSelectionFromSuggestArr] = useState([]);
  const [searchText, setSearchText] = useState([]);
  const [autoSuggestData, setAutoSuggestData] = useState([]);
  const [selectedCount, setSelectedCount] = useState(0);
  const [buttonDisable, setButtonDisable] = useState([]);
  const _ctaValid =
    (!_.isEmpty(addedSelectionFromSuggestArr) &&
      addedSelectionFromSuggestArr.filter((i) => i.Checked) != 0 &&
      _.isEmpty(autoSuggestData)) ||
    buttonDisable.length > 0
      ? 'valid'
      : '';
  const [showAddConfirmationHandler, setShowAddConfirmationHandler] = useState(false);
  const [updatedCountAfterConflict, setUpdatedCountAfterConflict] = useState(0);
  const [arrayOfConflicts, setarrayOfConflicts] = useState([]);
  const [allowedBatchDataArrAfterConflicts, setallowedBatchDataArrAfterConflicts] = useState([]);
  const [allowedBatchDataArrAfterConflictCount, setallowedBatchDataArrAfterConflictCount] =
    useState(0);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [providersSelected, setProvidersSelected] = useState(selectedProvidersCount);
  const [selectedInsuranceItem, setSelectedInsuranceItem] = useState('');
  

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const autosuggestOptions = {
    topLabel: `Add ${editType}`,
    id: `id- ${editType}`,
    placeholder: `Add ${editType}`,
    initialValue: searchText != '' ? searchText : '',
    data: autoSuggestData,
    onInputChangeHandler: (event) => {
      event.currentTarget.value.trim().length > 0
        ? setSearchText(event.currentTarget.value)
        : setSearchText('');
    },
    onSuggestSelectHandler: (data) => {},
    setCurrentSelection: false,
    showValidationMsg: true,
    isSearch: true,
    onSaveClick: (suggestData) => {
      saveDataHandler(suggestData);
    },
    onCancelClick: () => {
      setAutoSuggestData([]);
      setSearchText('');
      HG3Tracker.OmnitureEditPageTrack(
        'batch',
        'cancel',
        `cancel-selected-${editType.toLowerCase()}`
      );
    },
    buttonNames: [`Add ${batchText}`, 'Cancel']
  };

  const hideAutosuggestList = () => {
    setOpenAddPopup(false);
    setAutoSuggestData([]);
    setSearchText('');
    HG3Tracker.OmnitureEditPageTrack('batch', 'cancel', `cancel-add-${editType.toLowerCase()}`);
  };

  const deleteProviderHandler = (data) => {
    if (data.UpdateType == 'None') {
      let _tempUpdatelist = providerItem.map((value) => {
        return value.ProviderId == data.ProviderId
          ? { ...value, Selected: false, Checked: false }
          : { ...value };
      });
      setProviderItem(_tempUpdatelist);
    } else {
      let providerindex = providerItem.findIndex((i) => data.ProviderId == i.ProviderId);
      providerItem.splice(providerindex, 1);
      let _tempnewUpdatelist = providerItem.map((value) => value);
      setProviderItem(_tempnewUpdatelist);
    }
  };

  const getUrl = () => {
    let url = '';
    if (editType == 'Hospital Affiliations')
      url = `api/provider/hospitals?latlon=44.90446,-93.41903&term=${searchText}`;
    else if (editType == 'Insurance') url = `/api/autosuggest/insurance?term=${searchText}`;
    else if (editType == 'Conditions') url = `/api/autosuggest?term=${searchText}&type=Condition`;
    else if (editType == 'Procedures') url = `/api/autosuggest?term=${searchText}&type=Procedure`;
    else if (editType == 'Specialty') url = `/api/autosuggest/specialties?term=${searchText}`;
    return url;
  };

  const saveDataHandler = (suggestData) => {
    let _tempProvidersData = suggestData.filter(
      (data) => data.Checked || data.UpdateType == 'None'
    );
    setProviderItem(_tempProvidersData);
    let uniqueArr = !_.isEmpty([...addedSelectionFromSuggestArr, ..._tempProvidersData])
      ? _.uniq([...addedSelectionFromSuggestArr, ..._tempProvidersData])
      : [];
    setAddedSelectionFromSuggestArr(_.uniqBy(uniqueArr, (v) => v.Id));
    setAutoSuggestData([]);
    HG3Tracker.OmnitureEditPageTrack('batch', 'save', `add-selected-${editType.toLowerCase()}`);
  };

  const getCountOfSelected = (count) => {
    setSelectedCount(count);
  };

  const getAutosuggestDataForCurrentBatch = (data) => {
    if (!_.isEmpty(data)) {
      let _getProviderSuggest = data.map((provider) => ({
        ...provider,
        Id: provider.Id,
        Text: provider.Text,
        Selected:
          addedSelectionFromSuggestArr != null
            ? addedSelectionFromSuggestArr.findIndex((Sprovider) => Sprovider.Id === provider.Id) >
              -1
            : true,
        UpdateType:
          addedSelectionFromSuggestArr.findIndex((Uprovider) => {
            return Uprovider.Id === provider.Id;
          }) > -1
            ? 'None'
            : 'New',
        Checked:
          addedSelectionFromSuggestArr != null
            ? addedSelectionFromSuggestArr.findIndex((Sprovider) => Sprovider.Id === provider.Id) >
              -1
            : true,
        Disabled: false
      }));
      setAutoSuggestData(_getProviderSuggest);
    }
  };

  const inputChangeHandler = (isChecked, item) => {
    let _tempSuggestData = [...addedSelectionFromSuggestArr];
    let tempProviderItem = _tempSuggestData.map((data) => {
      if (data.Id == item.Id) {
        return { ...data, Checked: isChecked };
      } else {
        return { ...data };
      }
    });
    setAddedSelectionFromSuggestArr(tempProviderItem);
    setButtonDisable(tempProviderItem.filter((item) => item.Checked));
  };

  const getUrlForAdd = () => {
    switch (editType) {
      case 'Hospital Affiliations':
        return '/api/roster/add-hospital';
      case 'Specialty':
        return '/api/roster/add-specialty';
      case 'Conditions':
        return '/api/roster/add-condition';
      case 'Procedures':
        return '/api/roster/add-procedure';
      case 'Insurance':
        return '/api/roster/add-insurance';
    }
  };

  const getPayload = () => {
    let item = [];
    if (editType == 'Hospital Affiliations')
      item = addedSelectionFromSuggestArr
        .filter((i) => i.Checked)
        .map((i) => ({
          Code: i.Id,
          Name: i.Name,
          CityState: i.NameExtension
        }));
    else if (editType == 'Specialty')
      item = addedSelectionFromSuggestArr
        .filter((i) => i.Checked)
        .map((i) => ({
          Code: i.Id,
          Name: i.Text,
          GroupCode: i.GroupCode
        }));
    else
      item = addedSelectionFromSuggestArr
        .filter((i) => i.Checked)
        .map((i) => ({
          Code: i.Id,
          Name: i.Text
        }));

    let payload = {
      ProviderIds: pwidsArr,
      Item: item
    };
    return payload;
  };

  const hideAddPopUp = () => {
    hideAutosuggestList();
    setShowAddConfirmationHandler(false);
  };

  const addBatchHandler = () => {
    if (!_.isEmpty(addedSelectionFromSuggestArr)) {
      let payload = getPayload();
      let url = getUrlForAdd();
      if (!_.isEmpty(payload) && !_.isEmpty(url)) {
        service._post(url, payload, true).then((res) => {
          if (res.status == 200) {
            if (!_.isEmpty(res.data) && !_.isNil(res.data.Success) && res.data.Success) {
              const finalCountOfProvidersUpdatedAfterBatch =
                updatedCountAfterConflict > 0
                  ? `${Math.abs(selectedProvidersCount - updatedCountAfterConflict)}`
                  : selectedProvidersCount;
              reloadList(
                addedSelectionFromSuggestArr.filter((i) => i.Checked),
                finalCountOfProvidersUpdatedAfterBatch
              );
              hideAddPopUp();
            } else if (!_.isEmpty(res.data)) {
              showToasterForBulk(res.data);
              hideAddPopUp();
            } else {
              toaster.Error(res.data.ErrorMessage);
            }
          } else {
            toaster.Error(successMsg);
          }
        });
      }
      HG3Tracker.OmnitureEditPageTrack('batch', 'save', `save-${editType}`);
    }
  };

  const hideModal = (val) => {
    setShowAddConfirmationHandler(val);
    setOpenAddPopup(!val);
    HG3Tracker.OmnitureEditPageTrack(
      'batch',
      'cancel',
      `cancel-confirmation-${editType.toLowerCase()}`
    );
  };

  const getBatchEditDetails = () => {
    switch (editType) {
      case 'Hospital Affiliations':
        return 'Hospitals';
      case 'Insurance':
        return 'InsuranceList';
      case 'Photos':
        return 'PhotoData';
      default:
        return 'Items';
    }
  };

  const confirmClickHandlerForAddButton = () => {
    let type = getBatchEditDetails();
    let associaltedCodeArr = currentBatchData.flatMap((batchData) =>
      batchData[type].map((item) => item.Code)
    );
    let filteredSectionArr = addedSelectionFromSuggestArr.filter((i) =>
      associaltedCodeArr.includes(i.Id)
    );
    if (!_.isEmpty(filteredSectionArr)) {
      let pwidsArray = [];
      pwidsArray = currentBatchData
        .filter((val) =>
          val[type].some((batch1) => filteredSectionArr.some((batch2) => batch2.Id === batch1.Code))
        )
        .map((s) => s.Provider.ProviderCode);
      let arr = currentBatchData.filter((i) => pwidsArray.includes(i.Provider.ProviderCode));
      setarrayOfConflicts(filteredSectionArr.filter((i) => i.Checked));
      setUpdatedCountAfterConflict(arr.length);
      if (addedSelectionFromSuggestArr.length >= filteredSectionArr.length) {
        let unommonArray = addedSelectionFromSuggestArr.filter(
          (i) => !filteredSectionArr.some((j) => j.Id === i.Id)
        );
        setallowedBatchDataArrAfterConflicts(unommonArray.filter((i) => i.Checked));
        let pwidsArrayLooped = currentBatchData
          .filter((val) =>
            val[type].some((batch1) => unommonArray.some((batch2) => batch2.Id === batch1.Code))
          )
          .map((s) => s.Provider.ProviderCode);
        let arrLooped = currentBatchData.filter((i) =>
          pwidsArrayLooped.includes(i.Provider.ProviderCode)
        );
        //setallowedBatchDataArrAfterConflicts(arrLooped.length);
      }
      //  else {
      //   setallowedBatchDataArrAfterConflictCount(0);
      //   setAddedSelectionFromSuggestArr([]);
      // }
    } else {
      setarrayOfConflicts([]);
      setUpdatedCountAfterConflict(0);
    }
    setShowAddConfirmationHandler(true);
    HG3Tracker.OmnitureEditPageTrack('batch', 'save', `add-${editType.toLowerCase()}`);
  };

  const getNameOfRepeatedItem = () => {
    if (!_.isEmpty(arrayOfConflicts) && updatedCountAfterConflict > 0) {
      return arrayOfConflicts;
    }
    return '';
  };

  useEffect(() => {
    if (searchText.length > 1) {
      let url = getUrl();
      if (!_.isEmpty(url)) {
        service
          ._get(url, false)
          .then((res) => {
            if (res.status == 200) {
              let data = res.data;
              if (!_.isEmpty(data)) {
                if (editType === 'Insurance') {
                  let _tempInsuranceData = data.map((insurance) => ({
                    Id: insurance.med_term_id,
                    Text: insurance.s_query,
                    Disabled: providerItem.findIndex((ins) => ins.Id == insurance.med_term_id) > -1,
                    Obj: insurance,
                    updateType: 'Add'
                  }));
                  setAutoSuggestData(_tempInsuranceData);
                } else getAutosuggestDataForCurrentBatch(data);
              }
            }
          })
          .catch((err) => {});
      } else {
        setAutoSuggestData([]);
      }
    }
  }, [searchText]);

  useEffect(() => {
    setProviderItem(providerItem);
  }, [setOpenAddPopup]);

  useEffect(() => {
    if (!_.isUndefined(initialProvidersCount)) {
      setProvidersSelected(selectedProvidersCount ? selectedProvidersCount : initialProvidersCount);
      props.setResetSelectionForFilterChange(false);
    }
  }, [selectedProvidersCount]);

  return (
    <ReactModal
      overlayClassName='roster-modal-overlay'
      className='modal-dialog batch-edit-modal-dialog'
      isOpen={true}
      ariaHideApp={false}
      contentLabel='batch-edit-add-modal'
      shouldCloseOnOverlayClick={false}>
      {!showAddConfirmationHandler && (
        <div className='batch-edit-search-container'>
          <div className='batch-edit-search-popup'>
            <div
              className='search-icon-close'
              onClick={() => {
                setOpenAddPopup(false);
                setSelectAllInsurances(false);
                setDisplayAddCheckbox(false);
                HG3Tracker.OmnitureEditPageTrack(
                  'batch',
                  'cancel',
                  `cancel-add-${editType.toLowerCase()}`
                );
              }}>
              <img src={crossicon} alt='' />
            </div>

            <div className='batch-edit-option'>{`Add ${editType}`}</div>

            {isFromEditModalForSingleProvider && (
              <div className='provider-name'>
                <div className='user-icon'>
                  <img src={genderIcon} alt='gender' />
                </div>
                <div className='provider-title-name'>{currentBatchData.Name}.</div>
              </div>
            )}
            {/* Need in future
              {openAddPopupFlag && <div className='provider-name'>
                 <div className={openAddPopupFlag ?'user-icon':'user-icon1'}>
                    <img src={genderIcon} alt='gender' />
                  </div>
                  <div className='provider-title-name'>{openAddPopup.Name}.</div>
            </div>} */}
            {!openAddPopupFlag && (
              <div className='search-msg-str'>
                Search and select the {editType} carrier you would like to add from the {providersSelected} selected {` ${providersSelected > 1 ? 'providers' : 'provider'} `}.
                 
              </div>
            )}
            <div className='batch-edit-search-input'>
              {editType != 'Insurance' && (
                <AutoSuggest
                  autosuggestOptions={autosuggestOptions}
                  onShowItemlist={providerItem}
                  onDeleteitem={deleteProviderHandler}
                  passCountOfSelected={getCountOfSelected}
                />
              )}
              {editType === 'Insurance' && (
                <AddInsuranceAutoSuggest
                  batchEditType={editType}
                  setSelectInsurancePlans={setSelectInsurancePlans}
                  setOpenInsurancePlans={setOpenInsurancePlans}
                  setOpenAddPopup={setOpenAddPopup}
                  currentBatchData={currentBatchData}
                  setAlreadyExistInsurance={setAlreadyExistInsurance}
                  setAddInsuranceListProvider={setAddInsuranceListProvider}
                  selectedProviders={selectedProviders}
                  setSelectedInsuranceItem={setSelectedInsuranceItem}
                  selectedInsuranceItem={selectedInsuranceItem}
                  setSelectAllInsurances={setSelectAllInsurances}
                  selectAllInsurances={selectAllInsurances}
                  setOpenFianlStatus={setOpenFianlStatus}
                  setAddInsuranceValue={setAddInsuranceValue}
                  addInsuranceValue={addInsuranceValue}
                  displayAddCheckbox={displayAddCheckbox}
                  setDisplayAddCheckbox={setDisplayAddCheckbox}
                />
              )}

              {!_.isEmpty(addedSelectionFromSuggestArr) && _.isEmpty(autoSuggestData) && (
                <div className='new-selected-hospitals'>
                  <div className='fac-title'>New Selected {editType}:</div>

                  {addedSelectionFromSuggestArr.map((d, index) => (
                    <div className='suggest-item' key={`key-dv-${d.Id}`}>
                      <input
                        key={`key-ip-chk-${d.Id}`}
                        id={`ip-chk-${d.Id}`}
                        type='checkbox'
                        className='item-checkbox'
                        checked={d.Checked}
                        onChange={(event) => {
                          inputChangeHandler(event.currentTarget.checked, d);
                          d.Checked = event.currentTarget.checked;
                        }}></input>
                      <label
                        htmlFor={`ip-chk-${d.Id}`}
                        className={''}
                        key={index}
                        value={d.Id}
                        disabled={false}>
                        <>
                          {d.Text}
                          {/* <span>{`(${d.Id})`}</span> */}
                        </>
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {editType != 'Insurance' && <hr className='button-top-horizontal-line'></hr>}
            {editType != 'Insurance' && (
              <div className='search-popup-buttons'>
                <Cta
                  ctaValid={_ctaValid}
                  cancelText='Cancel'
                  disabled={_ctaValid != 'valid'}
                  className={`${'btn-add-batch-edit'}`}
                  cancelClickHandler={hideAutosuggestList}
                  confirmText={`Add ${batchText} ${
                    !_.isEmpty(addedSelectionFromSuggestArr)
                      ? `(${addedSelectionFromSuggestArr.filter((i) => i.Checked).length})`
                      : ''
                  }`}
                  confirmClickHandler={() => {
                    confirmClickHandlerForAddButton();
                  }}
                  cancelValid={false}
                />
              </div>
            )}
          </div>
        </div>
      )}

      {showAddConfirmationHandler && (
        <AddConfirmationModal
          itemsToBeAdded={
            !_.isEmpty(addedSelectionFromSuggestArr)
              ? addedSelectionFromSuggestArr
                  .filter((j) => j.Checked)
                  .map((i) => (_.isEmpty(i.Name) ? i.Text : i.Name))
              : []
          }
          hideModal={hideModal}
          addBatchHandler={addBatchHandler}
          selectedProvidersCount={selectedProvidersCount}
          updatedCountAfterConflict={updatedCountAfterConflict}
          getNameOfRepeatedItem={getNameOfRepeatedItem}
          allowedBatchDataArrAfterConflicts={allowedBatchDataArrAfterConflicts}
          allowedBatchDataArrAfterConflictCount={allowedBatchDataArrAfterConflictCount}
          editType={editType}
          pwidsArr={pwidsArr}
          currentBatchData={currentBatchData}
          selectedProviders={selectedProviders}
        />
      )}
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </ReactModal>
  );
}

AddModal.propTypes = {
  isFromEditModalForSingleProvider: PropTypes.bool
};

AddModal.defaultProps = {
  isFromEditModalForSingleProvider: false
};

export default AddModal;
