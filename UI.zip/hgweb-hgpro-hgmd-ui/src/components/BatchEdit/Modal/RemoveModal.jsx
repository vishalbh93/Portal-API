import ReactModal from 'react-modal';
import crossicon from '/public/images/auditPage/cross.svg';
import AutoSuggest from '../AutoSuggest';
import { useEffect, useState } from 'react';
import RemoveInsuranceAutosuggest from '../InsuranceBatchEdit/RemoveInsuranceAutoSuggest';
import { HG3Tracker } from '../../../utils/tracking';
import Cta from '../../Common/Form/CTA/Cta';
const RemoveModal = (props) => {
  const {
    setOpenDeletePopup,
    editType,
    selectedProvidersCount,
    currentBatchData,
    selectedProviders,
    setOpenRemoveConfirmationPopup,
    setOpenInsurancePlans,
    setCloseInsurancePopup,
    closeInsurancePopup,
    setSelectedInsurancePlans,
    selectedInsurancePlans,
    selectedInsurance,
    setSelectedInsurance,
    setInsuranceDetails,
    openRemoveConfirmationPopup,
    selectAllInsurances,
    setSelectAllInsurances,
    openInsurancePopUp,
    setOpenInsurancePopup,
    setOpenInsurancePlanPopup,
    openInsurancePlanPopup,
    isInsuranceSelected,
    setIsInsuranceSelected,
    setCurrentInsuranceValue,
    currentInsuranceValue,
    displayCheckbox,
    setDisplayCheckBox,
    isInsuranceTyped,
    setIsInsuranceTyped,
    batchText
  } = props;

  // const [searchText, setSearchText] = useState([]);
  // const [autoSuggestData, setAutoSuggestData] = useState([]);
  // const [selectedCount, setSelectedCount] = useState(0);
  // const [data, setData] = useState([]);

  // const getCountOfSelected = (count) => {
  //   setSelectedCount(count);
  // };

  // useEffect(() => {
  //   if (searchText != null && searchText != '') {
  //     getDataForAutoSuggest();
  //   }
  // }, [searchText]);

  // const getDataForAutoSuggest = () => {
  //   switch (editType) {
  //     case 'Hospital Affiliations':
  //       const tempHospitalAffiliations = currentBatchData.flatMap((hospitals) => {
  //         return hospitals.Hospitals.filter((hospital) => hospital.Name.includes(searchText));
  //       });
  //       setAutoSuggestData(tempHospitalAffiliations);
  //     case 'Specialty':
  //       return '/api/roster/add-specialty';
  //     case 'Conditions':
  //       return '/api/roster/add-condition';
  //     case 'Procedures':
  //       return '/api/roster/add-procedure';
  //     case 'Insurance':
  //       return '/api/roster/add-insurance';
  //   }
  // };

  // const autosuggestOptions = {
  //   topLabel: `Remove ${editType}`,
  //   id: `id- ${editType}`,
  //   placeholder: `Remove ${editType}`,
  //   initialValue: searchText != '' ? searchText : '',
  //   data: autoSuggestData,
  //   onInputChangeHandler: (event) => {
  //     event.currentTarget.value.trim().length > 0
  //       ? setSearchText(event.currentTarget.value)
  //       : setSearchText('');
  //   },
  //   onSuggestSelectHandler: (data) => {},
  //   setCurrentSelection: false,
  //   showValidationMsg: true,
  //   isSearch: true,
  //   onSaveClick: (suggestData) => {},
  //   onCancelClick: () => {
  //     setAutoSuggestData([]);
  //     setSearchText('');
  //     HG3Tracker.OmnitureEditPageTrack(
  //       'batch',
  //       'cancel',
  //       `cancel-selected-${editType.toLowerCase()}`
  //     );
  //   },
  //   buttonNames: [`Remove ${batchText}`, 'Cancel']
  // };
  //handlers
  const handleCancelClick = () => {
    setIsInsuranceSelected(false);
    setOpenInsurancePlanPopup(false);
    setOpenInsurancePopup(true);
    setCloseInsurancePopup(false);
    HG3Tracker.OmnitureEditPageTrack('batch', 'cancel', `cancel-add-${editType.toLowerCase()}`);
  };

  const handleCancelInsurancePopup = () => {
    setOpenDeletePopup(false);
    setOpenInsurancePopup(false);
    setSelectAllInsurances(false);
    setCurrentInsuranceValue('');
    setDisplayCheckBox(false);
    setIsInsuranceTyped(false);
    HG3Tracker.OmnitureEditPageTrack('batch', 'cancel', `cancel-add-${editType.toLowerCase()}`);
  };

  return (
    <>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog batch-edit--modal-dialog'
        isOpen={true}
        ariaHideApp={false}
        contentLabel='batch-edit-add-modal'>
        <div className='batch-edit-search-container'>
          <div className='batch-edit-search-popup'>
            <div
              className='search-icon-close'
              onClick={openInsurancePopUp ? handleCancelInsurancePopup : handleCancelClick}>
              <img src={crossicon} alt='' />
            </div>
            <div className='batch-edit-option'>{`Remove ${editType}`}</div>
            <div className='search-msg-str'>
              {openInsurancePopUp
                ? `Search and select the ${editType} carrier you would like to remove from the ${' '}
                ${selectedProvidersCount} selected providers.`
                : `Search and select the Insurance plan(s) you would like to remove from the
                ${selectedProvidersCount} selected providers.`}
            </div>
            <div className='batch-edit-search-input'>
              {/* {editType !== 'Insurance' && (
                <AutoSuggest
                  autosuggestOptions={autosuggestOptions}
                  passCountOfSelected={getCountOfSelected}
                />
              )} */}
              {editType === 'Insurance' && (
                <RemoveInsuranceAutosuggest
                  batchEditType={editType}
                  setOpenDeletePopup={setOpenDeletePopup}
                  currentBatchData={currentBatchData}
                  selectedProviders={selectedProviders}
                  setCloseInsurancePopup={setCloseInsurancePopup}
                  closeInsurancePopup={closeInsurancePopup}
                  setOpenRemoveConfirmationPopup={setOpenRemoveConfirmationPopup}
                  setOpenInsurancePlans={setOpenInsurancePlans}
                  setSelectedInsurancePlans={setSelectedInsurancePlans}
                  selectedInsurancePlans={selectedInsurancePlans}
                  setSelectedInsurance={setSelectedInsurance}
                  selectedInsurance={selectedInsurance}
                  setInsuranceDetails={setInsuranceDetails}
                  openRemoveConfirmationPopup={openRemoveConfirmationPopup}
                  selectAllInsurances={selectAllInsurances}
                  setSelectAllInsurances={setSelectAllInsurances}
                  openInsurancePopUp={openInsurancePopUp}
                  setOpenInsurancePopup={setOpenInsurancePopup}
                  setOpenInsurancePlanPopup={setOpenInsurancePlanPopup}
                  openInsurancePlanPopup={openInsurancePlanPopup}
                  isInsuranceSelected={isInsuranceSelected}
                  setIsInsuranceSelected={setIsInsuranceSelected}
                  currentInsuranceValue={currentInsuranceValue}
                  setCurrentInsuranceValue={setCurrentInsuranceValue}
                  displayCheckbox={displayCheckbox}
                  setDisplayCheckBox={setDisplayCheckBox}
                  isInsuranceTyped={isInsuranceTyped}
                  setIsInsuranceTyped={setIsInsuranceTyped}
                />
              )}
              {/* {editType != 'Insurance' && <hr className='button-top-horizontal-line'></hr>}
              {editType != 'Insurance' && (
                <div className='search-popup-buttons'>
                  <Cta
                    cancelText='Cancel'
                    className={`${'btn-remove-batch-edit'}`}
                    cancelValid={false}
                    confirmText={`Remove ${batchText}`}
                  />
                </div>
              )} */}
            </div>
          </div>
        </div>
      </ReactModal>
    </>
  );
};
export default RemoveModal;
