import EditProviderIns from './InsuranceBatchEdit/EditProviderIns';
import './_batchEditPopup.less';
import crossicon from '/public/images/auditPage/cross.svg';
import React, { lazy, useState, Suspense } from 'react';

function BatchEditPopup(props) {
  const [cardsVisibilityLimit, setCardsVisibilityLimit] = useState(5);
  const openAddInsurancePopup = () => {
    setTimeout(() => {
      props.setEditPopup(false);
      props.setOpenSearchPopUP(true);
    }, 2000);
  };
  return (
    <>
      <div className='batch-edit-ins-container'>
        <div className='batch-edit-ins-popup'>
          <div className='batch-edit-option'>
            <div className='edit-option-value'>
              <div className='edit-ins-str'>{`Edit ${props.editType}`}</div>
              <div className='provider-name'>
                <div></div>
                <div className='provider-title-name'>{props.providerData.Name}.</div>
              </div>
            </div>

            <div onClick={() => props.setEditPopup(false)} className='close-icon'>
              <img src={crossicon} alt='' />
            </div>
          </div>
          <div className='insurance-accepted-str'>
            <div className='insurance-accepted'>Insurance accepted</div>
            <div
              className='add-insurance-link'
              onClick={openAddInsurancePopup}>{`Add ${props.editType}`}</div>
          </div>
          <div className='insurance-edit-list'>
            {props.openEditPopup.map((insurance, index) => {
              if (index < cardsVisibilityLimit) {
                return (
                  <EditProviderIns
                    key={index}
                    insuranceData={insurance}
                    insurancePlans={insurance.InsurancePlans}
                  />
                );
              }
            })}
          </div>
        </div>
      </div>
    </>
  );
}
export default BatchEditPopup;
