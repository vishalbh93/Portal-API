import React, { useRef } from 'react';
import './_autoSuggest.less';
import AutoSuggestWithCheckboxList from '../Common/Form/AutoSuggest/AutoSuggestWithCheckboxList';

const AutoSuggest = (props) => {
  const { autosuggestOptions, onShowItemlist, onDeleteitem, passCountOfSelected } = props;
  const _autosuggestList = useRef(null);

  const getCountOfSelected = (count) => {
    passCountOfSelected(count);
  };

  return (
    <div className='search-autosuggest-label' ref={_autosuggestList}>
      <div className='top-text'>{autosuggestOptions.topLabel}</div>
      <div className='search-provider-group'>
        <div className='input-auto-suggest'>
          <AutoSuggestWithCheckboxList
            id={`provider-autosuggest`}
            label=''
            name=''
            placeholder={autosuggestOptions.placeholder}
            initialValue={autosuggestOptions.initialValue}
            data={autosuggestOptions.data}
            onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
            onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
            setCurrentSelection={autosuggestOptions.setCurrentSelection}
            showValidationMsg={autosuggestOptions.showValidationMsg}
            isSearch={autosuggestOptions.isSearch}
            buttonNames={autosuggestOptions.buttonNames}
            onSaveClick={autosuggestOptions.onSaveClick}
            onCancelClick={autosuggestOptions.onCancelClick}
            showList='enable'
            isProviderListInPractice={true}
            isBatchEditPage={true}
            passCountOfSelected={getCountOfSelected}
          />
        </div>
      </div>
    </div>
  );
};

export default AutoSuggest;
