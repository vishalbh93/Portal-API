import { Suspense, lazy } from 'react';
import './_batchEditSearchPopup.less';
import crossicon from '/public/images/auditPage/cross.svg';

function BatchEditSearchPopup(props) {
  return (
    <>
      <div className='batch-edit-search-container'>
        <div className='batch-edit-search-popup'>
          <div className='search-icon-close' onClick={() => props.setOpenSearchPopUP(false)}>
            <img src={crossicon} alt='' />
          </div>

          <div className='batch-edit-option'>{`Add ${props.editType}`}</div>
          <div className='search-msg-str'>
            Search and add Insurance for the selected providers({props.providersCount})
          </div>
          <div className='edit-search-option'>{`Add ${props.editType}`}</div>
          <div className='batch-edit-search-input'>
            <input className='search-input' />
            <span className='search-icon'>
              <i className='icon'></i>
            </span>
          </div>
          <div className='search-popup-buttons'></div>
        </div>
      </div>
    </>
  );
}
export default BatchEditSearchPopup;
