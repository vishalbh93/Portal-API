import React, { useState } from 'react';
import { HG3Tracker } from '../../utils/tracking';

const CommonBatchData = ({ batchData, batchEditType, batchText }) => {
  const [cardsVisibilityLimit, setCardsVisibilityLimit] = useState(5);
  let commonImplemenattion =
    batchEditType.toLocaleLowerCase() == 'hospital affiliations' ||
    batchEditType.toLocaleLowerCase() == 'conditions' ||
    batchEditType.toLocaleLowerCase() == 'procedures';

  const _viewMoreLess = (arr) => {
    if (arr.length > 5) {
      if (cardsVisibilityLimit === 5)
        return (
          <a
            onClick={() => {
              setCardsVisibilityLimit(arr.length);
              HG3Tracker.OmnitureTrackLink(`batch|view-all|${batchEditType}`);
            }}
            id={batchEditType + Math.random()}
            className='view-all-insurance'>
            View all {batchText}
          </a>
        );
      else
        return (
          <a
            onClick={() => {
              setCardsVisibilityLimit(5);
              HG3Tracker.OmnitureTrackLink(`batch|show-less|${batchEditType}`);
            }}
            className='view-all-insurance'>
            Show Less {batchText}
          </a>
        );
    }
    return null;
  };

  return !_.isEmpty(batchData) ? (
    <div className={'providerInRoster-batch-edit'}>
      {window.innerWidth <= 768 && (
        <>
          <hr></hr>
          <span className='edit-type-mobile'>{batchEditType}</span>
        </>
      )}

      {batchData.map((value, index) => {
        if (commonImplemenattion && index < cardsVisibilityLimit) {
          return (
            <span key={index} className='list-item'>
              {value.Name}
            </span>
          );
        } else if (
          batchEditType.toLocaleLowerCase() == 'specialty' &&
          index < cardsVisibilityLimit
        ) {
          return (
            <div className='div-list-item-specialty'>
              <span key={index} className='list-item'>
                {value.Name}
              </span>
              {value.IsPrimary && <span className='speciality-primary'>Primary</span>}
            </div>
          );
        }
      })}

      {_viewMoreLess(batchData)}
    </div>
  ) : (
    <div className={'providerInRoster-batch-edit'}>
      <span>No {batchEditType}</span>
    </div>
  );
};

export default CommonBatchData;
