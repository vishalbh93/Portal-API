import React, { useEffect, useState } from 'react';
import './_providersWithSelectedBatchEdit.less';
import _ from 'lodash';
import Button from '@hg/joy/src/components/Button/Button';
import ProvidersList from './ProvidersList';
import AddModal from './Modal/AddModal';
import SelectInsurancePlans from './InsuranceBatchEdit/SelectInsurancePlans';
import FinalConfirmationToAdd from './InsuranceBatchEdit/FinalConfirmationToAdd';
import Toast from '../Common/Toast/Toast';
import * as service from '../../utils/service';
import Spinner from '../Spinner/Spinner';
import AlreadySelectedProvidersIns from './InsuranceBatchEdit/AlreadySelectedProvidersIns';
import { HG3Tracker } from '../../utils/tracking';
import RemoveModal from './Modal/RemoveModal';
import FinalConfirmationToRemove from './InsuranceBatchEdit/FinalConfirmationToRemove';

const ProvidersWithSelectedBatchEdit = (props) => {
  const {
    providersCount,
    batchEditType,
    batchText,
    currentBatchData,
    providerIds,
    resetSelection,
    selectedProvidersCount,
    setSelectedProvidersCount
  } = props;
  const [editType, setEditType] = useState(batchEditType);
  const [_batchText, setBatchText] = useState(batchText);
  const [batchData, setBacthData] = useState(currentBatchData);
  const [openAddPopup, setOpenAddPopup] = useState(false);
  const [openDeletePopup, setOpenDeletePopup] = useState(false);
  const [alreadySelectedItem, setAlreadySelectedItem] = useState([]);
  const [isAddModalForSingleProviders, setAddModalIsForSingleProviders] = useState(false);
  const [batchDataForCurrentProvider, setBatchDataForCurrentProvider] = useState([]);
  const [pwidsArr, setPwidsArr] = useState([]);
  const [selectInsurancePlans, setSelectInsurancePlans] = useState('');
  const [openInsurancePlans, setOpenInsurancePlans] = useState(false);
  const [openFinalStatus, setOpenFianlStatus] = useState(false);
  const [selectedInsPlans, setSelectedInsPlans] = useState([]);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [hideButton, sethideButton] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);
  const [alreadyExistInsurance, setAlreadyExistInsurance] = useState(false);
  const [addInsuranceListProvider, setAddInsuranceListProvider] = useState([]);
  const [selectedProviders, setSelectedProviders] = useState([]);
  const [openRemoveConfirmationPopup, setOpenRemoveConfirmationPopup] = useState(false);
  const [closeInsurancePopup, setCloseInsurancePopup] = useState(false);
  const [selectedInsurance, setSelectedInsurance] = useState();
  const [selectedInsurancePlans, setSelectedInsurancePlans] = useState([]);
  const [selectedInsuranceDetails, setInsuranceDetails] = useState([]);
  const [selectAllInsurances, setSelectAllInsurances] = useState(false);
  const [openInsurancePopUp, setOpenInsurancePopup] = useState(false);
  const [openInsurancePlanPopup,setOpenInsurancePlanPopup] = useState(false);
  const [isInsuranceSelected, setIsInsuranceSelected] = useState(false);
  const [addInsuranceValue,setAddInsuranceValue] = useState('');
  const [currentInsuranceValue, setCurrentInsuranceValue] = useState(selectedInsurance);
  const [displayCheckbox, setDisplayCheckBox] = useState(false);
  const [isInsuranceTyped, setIsInsuranceTyped] = useState(false);
  const[displayAddCheckbox, setDisplayAddCheckbox] = useState(false)
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //handlers
  const addForSingle = (val) => {
    setAddModalIsForSingleProviders(val);
  };

  const setCurrentProvider = (provider, batchData) => {
    setBatchDataForCurrentProvider(provider);
  };

  const getDetailsOfSelectedProviders = (cnt, arr) => {
    setSelectedProvidersCount(cnt);
    setPwidsArr(arr);
  };
  const [openAddPopupFlag, setOpenAddPopupFlag] = useState(false);

  const setUpdatedBatchData = (data) => {
    setBacthData(data);
  };

  const reloadList = (addedHospitalsArr, count) => {
    let payload = _.isEmpty(providerIds) ? [] : providerIds.split(',');
    service._post(`/api/roster/${batchText}`, payload, true).then((res) => {
      if (res.status == 200) {
        setUpdatedBatchData(res.data);
        toaster.Success(
          `Successfully added ${addedHospitalsArr.length} ${editType} to selected ${
            !_.isNil(count) && !_.isNaN(count)
              ? count > 1
                ? // ? `${count} providers`
                  // : `${count} provider.`
                  ` providers`
                : ` provider.`
              : ' provider.'
          }`
        );
      } else {
        toaster.Error('Some problem in loading details please refresh the page!');
      }
    });
  };

  const showToasterForBulk = (res) => {
    toaster.Success(res);
  };

  const reloadInsurenceList = (addedHospitalsArr) => {
    let payload = _.isEmpty(addedHospitalsArr) ? [] : addedHospitalsArr;
    service._post(`/api/roster/${batchText}`, payload, true).then((res) => {
      if (res.status == 200) {
        setUpdatedBatchData(res.data);
        // toaster.Success(
        //   `Hospital affiliated (${addedHospitalsArr.length}) to ${
        //     !_.isEmpty(pwidsArr)
        //       ? pwidsArr.length > 1
        //         ? `${pwidsArr.length} providers`
        //         : `${pwidsArr.length} provider`
        //       : 'provider'
        //   }`
        // );
      } else {
        // toaster.Error('Some problem in loading details please refresh the page!');
      }
    });
  };

  const hideButtonToAddBatchEditOption = (val) => {
    val == 0 ? sethideButton(true) : sethideButton(false);
  };

  const setResetSelectionForFilter = (val) => {
    props.setResetSelectionForFilterChange(val);
  };

  useEffect(() => {
    !_.isEmpty(batchEditType) && setEditType(batchEditType);
    !_.isEmpty(batchText) && setBatchText(batchText);
    !_.isEmpty(currentBatchData) && setBacthData(currentBatchData);
  }, [batchEditType, batchText, currentBatchData]);

  useEffect(() => {
    if (batchEditType === 'Hospital Affiliations') {
      let a = currentBatchData.map((i) => i.Hospitals);
      let _tempAlreadySelectedItem = a.reduce((acc, curr) => {
        return acc.filter((Code) => curr.some((i) => i.Code === Code.Code));
      }, a[0]);
      !_.isEmpty(_tempAlreadySelectedItem) && setAlreadySelectedItem(_tempAlreadySelectedItem);
    }
  }, [currentBatchData]);

  return (
    <>
      {!_.isEmpty(editType) && (
        <div className='batch-providers-list'>
          <div className='batch-providers-list-title'>
            <div className='mobile-edit-type'>{editType}</div>
            <div className='add-and-remove-button'>
            <div className='remove-button'>
              {!hideButton && editType === 'Insurance' && (
                <Button
                  id={`btn-add-${editType}`}
                  className={`btn-remove-batch-edit-filter`}
                  text={`Remove ${editType}`}
                  disabled={false}
                  size='lg'
                  style='ghost'
                  onClick={() => {
                    setOpenDeletePopup(true);
                    setOpenInsurancePopup(true);
                    HG3Tracker.OmnitureTrackLink(`batch|remove ${editType.toLowerCase()}`);
                  }}
                />
              )}
            </div>
            
            {!hideButton && (
              <div className='add-button'>
              <Button
                id={`btn-add-${editType}`}
                className={`btn-add-batch-edit-filter`}
                text={`Add ${editType}`}
                disabled={false}
                size='lg'
                style='ghost'
                onClick={() => {
                  setOpenAddPopup(true);
                  HG3Tracker.OmnitureTrackLink(`batch|add ${editType.toLowerCase()}`);
                }}
              />
              </div>
            )}
          </div>
          </div>

          <div className='provider-container'>
            <ProvidersList
              providersCount={providersCount}
              batchEditType={editType}
              batchText={_batchText}
              currentBatchData={batchData}
              setOpenModal={setOpenAddPopup}
              addForSingle={addForSingle}
              setCurrentProvider={setCurrentProvider}
              getDetailsOfSelectedProviders={getDetailsOfSelectedProviders}
              providerIds={providerIds}
              setOpenAddPopupFlag={setOpenAddPopupFlag}
              hideButtonToAddBatchEditOption={hideButtonToAddBatchEditOption}
              setSelectedProviders={setSelectedProviders}
              setOpenDeletePopup={setOpenDeletePopup}
            />
          </div>
        </div>
      )}

      {openAddPopup && !openDeletePopup && (
        <AddModal
          editType={editType}
          batchText={batchText}
          selectedProvidersCount={selectedProvidersCount != undefined ? selectedProvidersCount : 0}
          initialProvidersCount={providersCount}
          alreadySelectedItem={alreadySelectedItem}
          openAddPopup={openAddPopup}
          openAddPopupFlag={openAddPopupFlag}
          isFromEditModalForSingleProvider={isAddModalForSingleProviders}
          pwidsArr={pwidsArr}
          currentBatchData={batchData}
          setSelectInsurancePlans={setSelectInsurancePlans}
          setOpenInsurancePlans={setOpenInsurancePlans}
          providerIds={providerIds}
          reloadList={reloadList}
          setOpenAddPopup={setOpenAddPopup}
          setAlreadyExistInsurance={setAlreadyExistInsurance}
          setAddInsuranceListProvider={setAddInsuranceListProvider}
          selectedProviders={selectedProviders}
          resetSelection={resetSelection}
          setResetSelectionForFilterChange={setResetSelectionForFilter}
          showToasterForBulk={showToasterForBulk}
          selectAllInsurances={selectAllInsurances}
          setSelectAllInsurances={setSelectAllInsurances}
          setOpenFianlStatus={setOpenFianlStatus}
          addInsuranceValue={addInsuranceValue}
          setAddInsuranceValue={setAddInsuranceValue}
          displayAddCheckbox={displayAddCheckbox}
          setDisplayAddCheckbox={setDisplayAddCheckbox}
        />
      )}
      {openDeletePopup && (
        <RemoveModal
          selectedProvidersCount={selectedProvidersCount != undefined ? selectedProvidersCount : 0}
          selectedProviders={selectedProviders}
          editType={editType}
          setOpenDeletePopup={setOpenDeletePopup}
          currentBatchData={currentBatchData}
          setOpenRemoveConfirmationPopup={setOpenRemoveConfirmationPopup}
          setOpenInsurancePlans={setOpenInsurancePlans}
          closeInsurancePopup={closeInsurancePopup}
          setCloseInsurancePopup={setCloseInsurancePopup}
          setSelectedInsurancePlans={setSelectedInsurancePlans}
          selectedInsurancePlans={selectedInsurancePlans}
          setSelectedInsurance={setSelectedInsurance}
          selectedInsurance={selectedInsurance}
          setInsuranceDetails={setInsuranceDetails}
          openRemoveConfirmationPopup={openRemoveConfirmationPopup}
          selectAllInsurances={selectAllInsurances}
          setSelectAllInsurances={setSelectAllInsurances}
          openInsurancePopUp={openInsurancePopUp}
          setOpenInsurancePopup={setOpenInsurancePopup}
          openInsurancePlanPopup={openInsurancePlanPopup}
          setOpenInsurancePlanPopup={setOpenInsurancePlanPopup}
          isInsuranceSelected={isInsuranceSelected}
          setIsInsuranceSelected={setIsInsuranceSelected}
          currentInsuranceValue={currentInsuranceValue}
          setCurrentInsuranceValue={setCurrentInsuranceValue}
          displayCheckbox={displayCheckbox}
          setDisplayCheckBox={setDisplayCheckBox}
          isInsuranceTyped={isInsuranceTyped}
          setIsInsuranceTyped={setIsInsuranceTyped}
          batchText={batchText}
        />
      )}
      {openRemoveConfirmationPopup && (
        <FinalConfirmationToRemove
          setOpenRemoveConfirmationPopup={setOpenRemoveConfirmationPopup}
          selectedInsurancePlans={selectedInsurancePlans}
          selectedInsurance={selectedInsurance}
          setCloseInsurancePopup={setCloseInsurancePopup}
          openRemoveConfirmationPopup={openRemoveConfirmationPopup}
          selectedProviders={selectedProviders}
          selectedInsuranceDetails={selectedInsuranceDetails}
          setShowSpinner={setShowSpinner}
          selectAllInsurances={selectAllInsurances}
          openInsurancePlanPopup={openInsurancePlanPopup}
          setOpenInsurancePlanPopup={setOpenInsurancePlanPopup}
          setOpenInsurancePopup={setOpenInsurancePopup}
          openDeletePopup={openDeletePopup}
          setOpenDeletePopup={setOpenDeletePopup}
          displayCheckbox={displayCheckbox}
          setDisplayCheckBox={setDisplayCheckBox}
          isInsuranceTyped={isInsuranceTyped}
          setIsInsuranceTyped={setIsInsuranceTyped}
          setCurrentInsuranceValue={setCurrentInsuranceValue}
          setNotifyProperties={setNotifyProperties}
        />
      )}
      {openInsurancePlans && !alreadyExistInsurance && addInsuranceListProvider.length > 0 && (
        <SelectInsurancePlans
          selectInsurancePlans={selectInsurancePlans}
          currentBatchData={currentBatchData}
          setSelectInsurancePlans={setSelectInsurancePlans}
          setOpenInsurancePlans={setOpenInsurancePlans}
          setOpenFianlStatus={setOpenFianlStatus}
          setSelectedInsPlans={setSelectedInsPlans}
          setOpenAddPopup={setOpenAddPopup}
          selectAllInsurances={selectAllInsurances}
          selectedProvidersCount={selectedProvidersCount}
        />
      )}
      {openFinalStatus && (
        <FinalConfirmationToAdd
          selectInsurancePlans={selectInsurancePlans}
          insurancePlans={selectedInsPlans}
          currentBatchData={currentBatchData}
          setOpenFianlStatus={setOpenFianlStatus}
          setShowSpinner={setShowSpinner}
          addInsuranceListProvider={addInsuranceListProvider}
          setNotifyProperties={setNotifyProperties}
          reloadList={reloadInsurenceList}
          setOpenInsurancePlans={setOpenInsurancePlans}
          setOpenAddPopup={setOpenAddPopup}
          setSelectedInsPlans={setSelectedInsPlans}
          selectedProviders={selectedProviders}
          selectAllInsurances={selectAllInsurances}
          addInsuranceValue={addInsuranceValue}
          setAddInsuranceValue={setAddInsuranceValue}
          
        />
      )}
      {alreadyExistInsurance && (
        <AlreadySelectedProvidersIns
          setAlreadyExistInsurance={setAlreadyExistInsurance}
          selectInsurancePlans={selectInsurancePlans}
        />
      )}
      {showSpinner && <Spinner />}
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </>
  );
};

export default ProvidersWithSelectedBatchEdit;
