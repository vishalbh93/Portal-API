import ReactModal from 'react-modal';
import crossicon from '/public/images/auditPage/cross.svg';

function AlreadySelectedProvidersIns({ setAlreadyExistInsurance, selectInsurancePlans }) {
  return (
    <>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog batch-edit-modal-dialog'
        isOpen={true}
        ariaHideApp={false}
        contentLabel='batch-edit-add-modal'
        shouldCloseOnOverlayClick={false}>
        <div className='final-confirmation-add-container'>
          <div className='final-confirmation-popup'>
            <div className='search-icon-close' onClick={() => setAlreadyExistInsurance(false)}>
              <img src={crossicon} alt='close-modal' />
            </div>
            <div className='edit-type-option'>Add Insurance</div>
            <div className='add-this-ins'>All selected providers already have this insurance:</div>
            <div className='insurance-name'>{selectInsurancePlans.Obj.s_query}</div>
            <div className='remove-ins-btns'>
              <button
                className='cancel-btn'
                aria-label='Close'
                onClick={() => setAlreadyExistInsurance(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      </ReactModal>
    </>
  );
}
export default AlreadySelectedProvidersIns;
