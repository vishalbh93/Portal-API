import React, { useState, useEffect } from 'react';
import * as service from '../../../utils/service';
import AutoSuggestWithCheckbox from '../../Common/Layouts/AutoSuggestWithCheckbox';

function EditProviderIns({ insuranceData, insurancePlans }) {
  const [insuranceObj, setInsuranceObj] = useState({
    PayorId: insuranceData.PayorId,
    PayorCode: insuranceData.PayorCode,
    Payor: insuranceData.Payor,
    PayorPlanCount: insuranceData.PayorPlanCount,
    UpdateType: insuranceData.UpdateType
  });
  let _tempInsurancePlans = insurancePlans.map((ins) => {
    return {
      id: ins.PlanId,
      label: ins.Plan,
      checked: false,
      obj: ins
    };
  });
  const [currentInsurancePlans, setCurrentInsurancePlans] = useState(_tempInsurancePlans);
  const [insurancePlanAutoSuggestData, setInsurancePlanAutoSuggestData] = useState([]);
  const [insurancePlanSearchText, setInsurancePlanSearchText] = useState('');
  const [showRemovePlanModal, setShowRemovePlanModal] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const handleCheckboxClick = (option, checked) => {
    let _tempCurrentInsurancePlans = currentInsurancePlans.map((ins) => {
      return ins.id == option.id ? { ...ins, checked: checked } : { ...ins };
    });
    setCurrentInsurancePlans(_tempCurrentInsurancePlans);
  };

  const handleDeleteClick = () => {
    let _tempInsurance = insuranceInformation.Insurance;

    let payload = {
      Insurance: _tempInsurance.map((ins) => {
        if (ins.PayorId == insuranceObj.PayorId) return { ...ins, UpdateType: 'Delete' };
        else {
          return { ...ins };
        }
      }),
      ProviderId: insuranceInformation.ProviderId
    };
    updateInsurancePlans(payload);
  };
  const autosuggestOptions = {
    placeholder: 'Add Plan',
    initialValue: insurancePlanSearchText,
    data: insurancePlanAutoSuggestData,
    onInputChangeHandler: (event) => {
      if (event.currentTarget.value.trim().length > 0)
        setInsurancePlanSearchText(event.currentTarget.value);
    },
    onSuggestSelectHandler: () => {},
    setCurrentSelection: false,
    showValidationMsg: true,
    isSearch: true,
    onSaveClick: (suggestData) => {
      let _tempInsurance = insuranceInformation.Insurance;
      let currentInsuranceIndex = _tempInsurance.findIndex(
        (i) => insuranceObj.PayorId == i.PayorId
      );

      let checkedInsurancePlans = suggestData.filter((data) => data.Checked);
      _tempInsurance[currentInsuranceIndex] = {
        ..._tempInsurance[currentInsuranceIndex],
        InsurancePlans: checkedInsurancePlans.map((ins) => ({
          PlanId: ins.Id,
          Plan: ins.Name,
          UpdateType: 'Add'
        }))
      };

      let payload = {
        Insurance: _tempInsurance,
        ProviderId: insuranceInformation.ProviderId
      };
      updateInsurancePlans(payload);
      setInsurancePlanAutoSuggestData([]);
      setInsurancePlanSearchText('');
    },
    onCancelClick: () => {
      setInsurancePlanAutoSuggestData([]);
      setInsurancePlanSearchText('');
    },
    buttonNames: ['Save', 'Cancel']
  };
  const updateInsurancePlans = (payload) => {
    service._post('/api/provider/update-insurance', payload, true).then((res) => {
      if (res.status == 200) {
        let data = res.data;
        updateInsuranceInStore(data.ReturnData);
        toaster.Success('Success!');
      } else {
        let data = res.data;
        toaster.Error(data.ErrorMessage);
      }
    });
  };
  const updateInsuranceInStore = (insuranceJson) => {
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      InsuranceJson: insuranceJson
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
  };
  const ctaOptions = {
    isVisibile:
      currentInsurancePlans.length > 0 && currentInsurancePlans.some((ins) => ins.checked),
    ctaValid: currentInsurancePlans.some((ins) => ins.checked),
    cancelText: 'Cancel',
    cancelClickHandler: selectedPlanCancelClickHandler,
    confirmText: 'Remove Plan',
    confirmClickHandler: () => setShowRemovePlanModal(true)
  };
  const selectedPlanCancelClickHandler = () => {
    let _tempCurrentInsurancePlans = currentInsurancePlans.map((ins) => ({
      ...ins,
      checked: false
    }));
    setCurrentInsurancePlans(_tempCurrentInsurancePlans);
  };
  const fetchInsurancePlans = () => {
    let payload = {
      CurrentCodes: currentInsurancePlans.map((plan) => plan.PlanId),
      ItemCode: insuranceObj.PayorCode
    };
    return service._post(`/api/autosuggest/insuranceplans`, payload, false);
  };

  //effects
  useEffect(() => {
    if (insurancePlanSearchText.length > 0) {
      if (insurancePlanAutoSuggestData.length === 0) {
        fetchInsurancePlans().then((res) => {
          if (res.status == 200) {
            let insurancePlans = res.data;
            setInsurancePlanAutoSuggestData(
              insurancePlans.map((plan) => ({
                ...plan,
                Id: plan.Id,
                Text: plan.Name,
                Checked: currentInsurancePlans.findIndex((cplan) => cplan.id == plan.Id) > -1
              }))
            );
          }
        });
      }
    }
  }, [insurancePlanSearchText]);
  return (
    <>
      <AutoSuggestWithCheckbox
        title={`${insuranceObj.Payor}${
          currentInsurancePlans.length !== 0 ? ` (${currentInsurancePlans.length})` : ''
        }`}
        showAutoSuggestTextField={insuranceObj.PayorPlanCount !== 0}
        checkboxOptions={currentInsurancePlans}
        checkboxOptionsLimit={2}
        checkBoxInputClick={handleCheckboxClick}
        autosuggestOptions={autosuggestOptions}
        ctaOptions={ctaOptions}
        onCloseClick={handleDeleteClick}
        id={insuranceData.PayorId}
      />
    </>
  );
}
export default EditProviderIns;
