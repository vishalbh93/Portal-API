import { useEffect, useRef, useState } from 'react';
import './_addInsuranceAutoSuggest.less';
import { HG3Tracker } from '../../../utils/tracking';
import * as service from '../../../utils/service';
import { sectionsToExcludeForUnsavedData } from '../../../utils/constant-data';
const RemoveInsuranceAutosuggest = (props) => {
  const {
    setOpenDeletePopup,
    batchEditType,
    selectedProviders,
    setSelectedInsuranceItem,
    setOpenRemoveConfirmationPopup,
    setOpenInsurancePlans,
    setSelectedInsurancePlans,
    selectedInsurancePlans,
    selectedInsurance,
    setSelectedInsurance,
    setInsuranceDetails,
    selectAllInsurances,
    setSelectAllInsurances,
    openInsurancePopUp,
    setOpenInsurancePopup,
    setOpenInsurancePlanPopup,
    openInsurancePlanPopup,
    isInsuranceSelected,
    setIsInsuranceSelected,
    currentInsuranceValue,
    setCurrentInsuranceValue,
    displayCheckbox,
    setDisplayCheckBox,
    isInsuranceTyped,
    setIsInsuranceTyped
  } = props;

  //states
  const [batchEditData, setBatchEditData] = useState();
  const [insuranceSuggestData, setInsuranceSuggestData] = useState([]);
  const [currentInsurancePlanValue, setCurrentInsurancePlanValue] = useState('');
  const [insuranceList, setInsuranceList] = useState([]);
  const [selectedInsurancePayor, setSelectedInsurancePayor] = useState();
  const [insurancePlansDetails, setInsurancePlansDetails] = useState([]);
  const [insurancePlans, setInsurancePlans] = useState([]);
  const [selectedPlansCount, setSelectedPlansCount] = useState();
  //handlers
  const onCurrentInsuranceChangeHandler = (event) => {
    let { value } = event.target;
    setCurrentInsuranceValue(value);
    if (value === '') {
      setIsInsuranceTyped(false);
      setDisplayCheckBox(false);
    }
    getDatForAutoSuggest();
  };

  const onCurrentInsurancePlansChangeHandler = (event) => {
    let { value } = event.target;
    setCurrentInsurancePlanValue(value);
    getDatForAutoSuggestPlans(value);
  };

  const getDatForAutoSuggest = () => {
    if (batchEditData != undefined) {
      let InsuranceList = batchEditData.flatMap((data) => {
        return data.InsuranceList.flatMap((insurance) => {
          return insurance.Payor;
        });
      });
      let allPayors = InsuranceList.flat();
      let uniquePayorList = new Set(allPayors);
      let uniquePayors = Array.from(uniquePayorList);
      setInsuranceSuggestData(uniquePayors);
    }
  };

  const getDatForAutoSuggestPlans = (value) => {
    if (insurancePlansDetails != undefined && insurancePlansDetails.length > 0) {
      var insurancePlanNames = insurancePlansDetails.filter((ins) =>
        ins.Plan.toLowerCase().includes(value.toLowerCase())
      );
      const uniquePlans = new Set();
      const uniqueArray = insurancePlanNames.filter((data) => {
        if (!uniquePlans.has(data.Plan)) {
          uniquePlans.add(data.Plan);
          return true;
        }
        return false;
      });
      checkForSelectedPlans(uniqueArray);
    }
  };

  const checkForSelectedPlans = (uniqueArray) => {
    if (uniqueArray.length > 0 && selectedInsurancePlans.length > 0) {
      let addSelectedForPlans = uniqueArray.map((ins) => {
        const isPlanAlreadySelected = selectedInsurancePlans.find((plan) => plan.Plan === ins.Plan);
        if (isPlanAlreadySelected != undefined) {
          return { ...ins, selected: isPlanAlreadySelected.selected };
        }
        return ins;
      });
      setInsurancePlans(addSelectedForPlans);
    } else if (uniqueArray.length > 0) {
      setInsurancePlans(uniqueArray);
    } else {
      let addSelectedForPlans = uniqueArray.map((data) => ({ ...data, selected: false }));
      setInsurancePlans(addSelectedForPlans);
    }
  };

  const selectedInsurancePlansToremove = (uniqueArray) => {
    if (uniqueArray.length > 0) {
      let addSelectedForPlans = uniqueArray.map((ins) => {
        if (ins.selected) {
          return { ...ins, selected: true };
        } else {
          return { ...ins, selected: false };
        }
      });
      setInsurancePlans(addSelectedForPlans);
    }
  };

  const openInsurancePlansPopup = () => {
    let value = currentInsuranceValue || selectedInsurance;
    let selectedInsuranceData = selectedProviders.find((ins) => {
      return ins.InsuranceList.some((item) => {
        return item.Payor === value;
      });
    });
    let PayorCodeDetails = [];
    if (selectedInsuranceData != undefined) {
      PayorCodeDetails = selectedInsuranceData.InsuranceList.filter((data) => {
        return data.Payor === value;
      });
      setInsuranceDetails(PayorCodeDetails);
    }
    fetchInsurancePlans(value);
    if (!selectAllInsurances) {
      setOpenInsurancePlanPopup(true);
      setOpenInsurancePopup(false);
      setSelectedInsurancePayor(value);
      setSelectedInsurance(value);
      ClearValues();
      let payorCode = PayorCodeDetails.map((payor) => {
        return payor.PayorCode;
      });
    } else {
      setOpenInsurancePopup(false);
      setSelectedInsurancePayor(value);
      setSelectedInsurance(value);
      setOpenRemoveConfirmationPopup(true);
    }
  };

  const handleRemoveInsurance = () => {
    setOpenInsurancePlanPopup(false);
    setOpenRemoveConfirmationPopup(true);
  };

  const checkIfPlansExist = (value) => {
    let selectedInsuranceData = selectedProviders.flatMap((ins) => {
      return ins.InsuranceList.filter((item) => item.Payor === value);
    });
    let matchingArrayCount = 0;
    if (selectedInsuranceData != undefined) {
      let isInsurancePlanExist = selectedInsuranceData.map((data) => {
        if (data != []) {
          if (data.InsurancePlans.length > 0) {
            matchingArrayCount = matchingArrayCount + 1;
          }
        }
      });
      if (matchingArrayCount > 0) {
        setDisplayCheckBox(true);
      } else {
        setDisplayCheckBox(false);
        setSelectAllInsurances(true);
      }
    }
  };

  const fetchInsurancePlans = (currentInsuranceValue, payorCode) => {
    const insuranceDetails = selectedProviders.flatMap((data) => {
      return data.InsuranceList.filter((plans) => {
        return plans.Payor === currentInsuranceValue;
      });
    });
    if (insuranceDetails != undefined && insuranceDetails.length > 0) {
      const insurancePlanDetails = insuranceDetails.flatMap((plans) => {
        return plans.InsurancePlans;
      });
      let addSelectedForPlans = insurancePlanDetails.map((data) => ({ ...data, selected: false }));
      setInsurancePlansDetails(addSelectedForPlans);
      console.log(addSelectedForPlans);
      if (selectAllInsurances) {
        const uniquePlans = new Set();
        const uniqueArray = addSelectedForPlans.filter((data) => {
          if (!uniquePlans.has(data.Plan)) {
            uniquePlans.add(data.Plan);
            return true;
          }
          return false;
        });
        setSelectedInsurancePlans(uniqueArray);
      }
    }
  };

  const ClearValues = () => {
    setInsuranceList('');
    setSelectAllInsurances(false);
  };

  const ClearPlans = () => {
    setInsurancePlans([]);
    setInsurancePlansDetails([]);
  };

  const setInputValue = (data) => {
    if (data != '') {
      setCurrentInsuranceValue(data);
      setDisplayCheckBox(true);
      setIsInsuranceTyped(true);
      setInsuranceList([]);
      checkIfPlansExist(data);
    } else {
      setDisplayCheckBox(false);
      setIsInsuranceTyped(false);
    }
  };

  const handleSelectChange = (planId) => {
    setIsInsuranceSelected(true);
    let updatedInsPlans = [...insurancePlans];
    let updatePlanDetails = [...insurancePlansDetails];
    let selectedInsPlans = updatedInsPlans.map((ins) => {
      if (ins.Plan == planId && ins.selected != true) {
        ins.selected = true;
      } else if (ins.Plan == planId && ins.selected == true) {
        ins.selected = false;
      }
      return ins;
    });

    let selectedPlanDetails = updatePlanDetails.map((ins) => {
      if (ins.Plan == planId && ins.selected != true) {
        ins.selected = true;
      } else if (ins.Plan == planId && ins.selected == true) {
        ins.selected = false;
      }
      return ins;
    });

    const uniquePlans = new Set();
    const uniqueDetails = new Set();

    const uniqueArray = selectedInsPlans.filter((data) => {
      if (!uniquePlans.has(data.Plan)) {
        uniquePlans.add(data.Plan);
        return true;
      }
      return false;
    });

    const uniqueArrayDetails = selectedPlanDetails.filter((data) => {
      if (!uniqueDetails.has(data.Plan)) {
        uniqueDetails.add(data.Plan);
        return true;
      }
      return false;
    });

    selectedInsurancePlansToremove(uniqueArray);
    setInsurancePlansDetails(uniqueArrayDetails);

    var selectedInsurancePlansForConfirm = insurancePlansDetails.filter((plans) => plans.selected);
    let allPlans = selectedInsurancePlansForConfirm.flat();
    // let uniquePlansList = new Set(allPlans);
    // let plansToDisplay = Array.from(uniquePlansList);
    const uniquePlansArray = new Set();
    const uniqueArrayPlans = allPlans.filter((data) => {
      if (!uniquePlansArray.has(data.Plan)) {
        uniquePlansArray.add(data.Plan);
        return true;
      }
      return false;
    });
    setSelectedInsurancePlans(uniqueArrayPlans);
  };

  const handleSelectAllInsurances = () => {
    setSelectAllInsurances(!selectAllInsurances);
    setIsInsuranceTyped(currentInsuranceValue != '' ? true : false);
  };

  const handleCancelClick = () => {
    setOpenInsurancePlanPopup(false);
    setIsInsuranceSelected(false);
    setOpenInsurancePopup(true);
    ClearPlans();
    HG3Tracker.OmnitureTrackLink(`batch|cancel|remove-insurance`);
  };

  //useEffects
  useEffect(() => {
    setBatchEditData(selectedProviders);
  }, []);

  useEffect(() => {
    setInsuranceSuggestData(insuranceSuggestData);
  }, [insuranceSuggestData]);

  useEffect(() => {
    if (insurancePlansDetails.length > 0) {
      setSelectedPlansCount(insurancePlansDetails.filter((plan) => plan.selected).length);
    }
  }, [insurancePlansDetails]);

  useEffect(() => {
    if (
      insuranceSuggestData != undefined &&
      insuranceSuggestData != null &&
      insuranceSuggestData.length > 0 &&
      !isInsuranceTyped &&
      currentInsuranceValue != ''
    ) {
      var insuranceDataList = insuranceSuggestData.filter((data) =>
        data.toLowerCase().includes(currentInsuranceValue.toLowerCase())
      );
      setInsuranceList(insuranceDataList);
      console.log(insuranceDataList);
    } else if (currentInsuranceValue === '') {
      setInsuranceList([]);
    }
  }, [currentInsuranceValue]);

  useEffect(() => {
    if (
      insurancePlansDetails != undefined &&
      insurancePlansDetails.length > 0 &&
      !isInsuranceSelected
    ) {
      var insurancePlanNames = insurancePlansDetails.map((name) => {
        return {
          Plan: name.Plan,
          PlanId: name.PlanId
        };
      });
      const uniquePlans = new Set();
      const uniqueArray = insurancePlanNames.filter((data) => {
        if (!uniquePlans.has(data.Plan)) {
          uniquePlans.add(data.Plan);
          return true;
        }
        return false;
      });
      let addSelectedForPlans = uniqueArray.map((data) => ({ ...data, selected: false }));
      setInsurancePlans(addSelectedForPlans);
    }
  }, [insurancePlansDetails]);

  useEffect(() => {
    if (currentInsuranceValue === null && currentInsuranceValue === '') {
      setIsInsuranceTyped(false);
    }
  }, [currentInsuranceValue]);

  useEffect(() => {
    if (openInsurancePlanPopup) {
      setIsInsuranceSelected(false);
      openInsurancePlansPopup();
    }
  }, [setOpenInsurancePlanPopup]);

  return openInsurancePopUp ? (
    <div className='remove-insurance-autosuggest-container'>
      <div className='top-search-msg'>
        {`Select ${batchEditType} Carrier`}
        <div className='search-container'>
          <input
            type='text'
            className='search-input'
            placeholder='Search and select Insurance Carrier'
            value={currentInsuranceValue}
            onChange={(event) => onCurrentInsuranceChangeHandler(event)}
          />

          {insuranceList != undefined && insuranceList != null && insuranceList.length > 0 && (
            <div className='autosuggest-data-container'>
              {insuranceList.map((data, index) => (
                <ul className='insurance-list-items' onClick={() => setInputValue(data)}>
                  {insuranceList != undefined && insuranceList != null && <li>{data}</li>}
                </ul>
              ))}
            </div>
          )}

          {displayCheckbox && (
            <div className='checkbox'>
              <input
                id='select-plans'
                name='select-plan'
                aria-label='select-checkbox'
                type='checkbox'
                onChange={handleSelectAllInsurances}
                checked={selectAllInsurances}></input>
              <label className='checkbox-select-plans' htmlFor='select-plans' key='select-plans'>
                Remove carrier and all associated plans
              </label>
            </div>
          )}
          <div className='remove-ins-btns'>
            <hr className='horizontal-line-button' />
            <button
              className='cancel-btn'
              onClick={() => {
                setOpenDeletePopup(false);
                setOpenInsurancePopup(false);
                setSelectAllInsurances(false);
                setCurrentInsuranceValue('');
                setDisplayCheckBox(false);
                setIsInsuranceTyped(false);
                HG3Tracker.OmnitureTrackLink(`batch|cancel|remove-insurance`);
              }}>
              Cancel
            </button>
            <button
              className={isInsuranceTyped ? 'remove-button' : 'disable-button'}
              disabled={!isInsuranceTyped ? true : false}
              onClick={openInsurancePlansPopup}>
              {selectAllInsurances ? 'Remove Carrier' : 'Continue to Plans'}
            </button>
          </div>
        </div>
      </div>
    </div>
  ) : (
    openInsurancePlanPopup && (
      <>
        <div className='remove-insurance-autosuggest-container open-plans-pop-up'>
          <div className='payor-details'>{selectedInsurancePayor}</div>
          <div className='top-search-msg remove-top-content'>
            {`Remove ${batchEditType} plan(s)`}
            <div className='search-container'>
              <input
                type='text'
                className='search-input'
                placeholder='Remove Insurance Plan'
                value={currentInsurancePlanValue}
                onChange={(event) => onCurrentInsurancePlansChangeHandler(event)}
              />

              {insuranceList != undefined && insuranceList != null && insuranceList.length > 0 && (
                <div className='autosuggest-data-container'>
                  {insuranceList.map((data, index) => (
                    <ul className='insurance-list-items' onClick={() => setInputValue(data)}>
                      {insuranceList != undefined && insuranceList != null && <li>{data}</li>}
                    </ul>
                  ))}
                </div>
              )}
              {insurancePlans != undefined &&
                insurancePlans != null &&
                insurancePlans.length > 0 && (
                  <div className='insurance-plans'>
                    {insurancePlans.length > 0 &&
                      insurancePlans.map((ins) => (
                        <div className='checkbox'>
                          <input
                            id={ins.PlanId != '' ? ins.PlanId : ins.Plan}
                            name={ins.Plan}
                            aria-label='select-checkbox'
                            value={ins.Plan}
                            type='checkbox'
                            onChange={() => handleSelectChange(ins.Plan)}
                            checked={ins.selected}></input>
                          <label
                            className='checkbox-single-provider'
                            htmlFor={ins.PlanId != '' ? ins.PlanId : ins.Plan}
                            key={ins.PlanId}>
                            {ins.Plan}
                          </label>
                        </div>
                      ))}
                  </div>
                )}
            </div>
          </div>
        </div>
        <div className='remove-ins-btns'>
          <hr className='horizontal-line-button' />
          <button className='cancel-btn' onClick={handleCancelClick}>
            Cancel
          </button>
          <button
            className={selectedPlansCount > 0 ? 'remove-btn' : 'disable-button'}
            onClick={handleRemoveInsurance}
            disabled={selectedPlansCount > 0 ? false : true}>
            Remove {selectedPlansCount > 0 &&  + selectedPlansCount}{' '}
            {selectedPlansCount > 1 ? 'plans' : 'plan'}
          </button>
        </div>
      </>
    )
  );
};
export default RemoveInsuranceAutosuggest;
