import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import React, { useState, useEffect, useRef } from 'react';
import * as service from '../../../utils/service';
import './_addInsuranceAutoSuggest.less';
import { HG3Tracker } from '../../../utils/tracking';

function AddInsuranceAutoSuggest({
  batchEditType,
  setOpenAddPopup,
  setSelectInsurancePlans,
  setOpenInsurancePlans,
  currentBatchData,
  setAlreadyExistInsurance,
  setAddInsuranceListProvider,
  setSelectedProviders,
  selectedProviders,
  selectedInsuranceItem,
  setSelectedInsuranceItem,
  selectAllInsurances,
  setSelectAllInsurances,
  setOpenFianlStatus,
  addInsuranceValue,
  setAddInsuranceValue,
  setDisplayAddCheckbox,
  displayAddCheckbox
}) {
  const [currentInsuranceValue, setCurrentInsuranceValue] = useState('');
  const [selectedInsuranceArray, setSelectedInsuranceArray] = useState([]);
  const [insuranceSuggestData, setInsuranceSuggesData] = useState([]);
  const [hideAutoSuggestData, setHideAutoSuggestData] = useState(false);
  const [stopApiCall, setStopApiCall] = useState(false);
  const fetchInsuranceData = () => {
    service
      ._get(`/api/autosuggest/insurance?term=${currentInsuranceValue}`, false)
      .then((res) => {
        if (res.status == 200) {
          let data = res.data;
          let _tempInsuranceData = data.map((insurance) => ({
            Id: insurance.med_term_id,
            Text: insurance.s_query,
            Disabled:
              // currentInsurances.findIndex((ins) => ins.PayorId == insurance.med_term_id) > -1 ||
              selectedInsuranceArray.findIndex((ins) => ins.Id == insurance.med_term_id) > -1,
            Obj: insurance,
            updateType: 'Add'
          }));
          setInsuranceSuggesData(_tempInsuranceData);
        }
      })
      .catch((err) => {});
  };
  const onCurrentInsuranceChangeHandler = (event) => {
    let { value } = event.target;
    if (value === '') {
      setDisplayAddCheckbox(false);
    }
    setCurrentInsuranceValue(value);
    setStopApiCall(false);
    setSelectedInsuranceItem(false);
    setHideAutoSuggestData(false);
  };
  const onInsuranceSelectHandler = (insurance) => {
    setCurrentInsuranceValue('');
    if (selectedInsuranceArray.findIndex((ins) => ins.Id == insurance.Id) == -1) {
      let tempArr = [...selectedInsuranceArray, insurance];
      setSelectedInsuranceArray(
        tempArr.reduce((filtered, item) => {
          if (
            !filtered.some((filteredItem) => JSON.stringify(filteredItem) == JSON.stringify(item))
          )
            filtered.push(item);
          return filtered;
        }, [])
      );
    }
  };
  const handleSelectAllInsurances = () => {
    setSelectAllInsurances(!selectAllInsurances);
  };
  const selectInsurancePlans = () => {
    if (!selectAllInsurances) {
      let checkSelectedInsurance =
        selectedProviders.length > 0 ? [...selectedProviders] : [...currentBatchData];
      let insurenceIsExistsPids = new Set();
      let insurenceTobeAddedPids = new Set();
      checkSelectedInsurance.forEach((providerData) => {
        let found = false;
        providerData.InsuranceList.forEach((insuranePlan) => {
          if (
            insuranePlan.PayorId == selectedInsuranceItem.Id &&
            insuranePlan.InsurancePlans.length == selectedInsuranceItem?.Obj?.payor_plan_count
          ) {
            insurenceIsExistsPids.add(providerData);
            found = true;
          }
        });
        if (!found) {
          insurenceTobeAddedPids.add(providerData);
        }
      });

      if (insurenceTobeAddedPids.size == 0) {
        setAlreadyExistInsurance(true);
      }
      // set state
      setAddInsuranceListProvider(Array.from(insurenceTobeAddedPids));
      setSelectInsurancePlans(selectedInsuranceItem);
      setOpenAddPopup(false);
      setOpenInsurancePlans(true);
    } else {
      setOpenFianlStatus(true);
      setOpenInsurancePlans(false);
      setOpenAddPopup(false);
      HG3Tracker.OmnitureTrackLink(`batch|continue|insurancePlan`);
    }
    HG3Tracker.OmnitureTrackLink(`batch|save|add-insurance-to-provider`);
  };
  const setInputValue = (data) => {
    if (data != '') {
    setSelectedInsuranceItem(data);
    setStopApiCall(true);
    setCurrentInsuranceValue(data.Obj.s_query);
    setAddInsuranceValue(data.Obj.s_query);
    setHideAutoSuggestData(true);
    setDisplayAddCheckbox(true);
    }
    else
    {
      setDisplayAddCheckbox(false);
    }
  };
  const getActiveClass = (data) => {
    return selectedInsuranceItem.Id === data.Id
      ? 'insurance-list-items isActive'
      : 'insurance-list-items';
  };
  useEffect(() => {
    if (currentInsuranceValue.length > 0 && !stopApiCall) fetchInsuranceData();
  }, [currentInsuranceValue]);
  const refSearchInput = useRef();

  const handleClickOutside = (event) => {
    if (refSearchInput.current && !refSearchInput.current.contains(event.target)) {
      setHideAutoSuggestData(true);
    }
  };
  if (insuranceSuggestData.length > 0) {
    document.addEventListener('mousedown', handleClickOutside);
  }
  return (
    <>
      <div className='add-insurance-autosuggest-container'>
        <div className='top-search-msg'>{`Select ${batchEditType} Carrier`}</div>
        <div className='search-container'>
          <input
            type='text'
            className='search-input'
            value={currentInsuranceValue}
            placeholder='Search and select Insurance Carrier'
            onChange={(event) => onCurrentInsuranceChangeHandler(event)}
          />

          {insuranceSuggestData.length > 0 && !hideAutoSuggestData && (
            <div className='autosuggest-data-container' ref={refSearchInput}>
              {insuranceSuggestData.length > 0 &&
                insuranceSuggestData.map((data, index) => (
                  <ul className={getActiveClass(data)} onClick={() => setInputValue(data)}>
                    <li>{data.Obj.s_query}</li>
                  </ul>
                ))}
            </div>
          )}
          {displayAddCheckbox && (
            <div className='checkbox'>
              <input
                id='select-plans'
                name='select-plan'
                aria-label='select-checkbox'
                type='checkbox'
                onChange={handleSelectAllInsurances}
                checked={selectAllInsurances}></input>
              <label className='checkbox-select-plans' htmlFor='select-plans' key='select-plans'>
                Add carrier without selecting plans
              </label>
            </div>
          )}
          <div className='remove-ins-btns'>
            <hr className='horizontal-line-button' />
            <button
              className='cancel-btn'
              onClick={() => {
                setOpenAddPopup(false);
                setSelectAllInsurances(false);
                setDisplayAddCheckbox(false);
                HG3Tracker.OmnitureTrackLink(`batch|cancel|add-insurance`);
              }}>
              Cancel
            </button>
            <button
              className={selectedInsuranceItem ? 'remove-btn' : 'disable-button'}
              onClick={selectInsurancePlans}
              disabled={!selectedInsuranceItem ? true : false}>
              {selectAllInsurances ? 'Add Carrier' : 'Continue to Plans'}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
export default AddInsuranceAutoSuggest;
