import { useEffect, useState } from 'react';
import './_finalConfirmationToAdd.less';
import crossicon from '/public/images/auditPage/cross.svg';
import ReactModal from 'react-modal';
import * as service from '../../../utils/service';
import { HG3Tracker } from '../../../utils/tracking';

const FinalConfirmationToRemove = (props) => {
  const {
    selectedInsurancePlans,
    selectedInsurance,
    setOpenRemoveConfirmationPopup,
    setCloseInsurancePopup,
    selectedProviders,
    openRemoveConfirmationPopup,
    selectedInsuranceDetails,
    setShowSpinner,
    selectAllInsurances,
    openInsurancePlanPopup,
    setOpenInsurancePlanPopup,
    setOpenInsurancePopup,
    setOpenDeletePopup,
    displayCheckbox,
    setDisplayCheckBox,
    isInsuranceTyped,
    setIsInsuranceTyped,
    setCurrentInsuranceValue,
    setNotifyProperties
  } = props;
  const [providerIds, setProviderIds] = useState([]);
  const [selectedInsuranceData, setSelectedInsuranceData] = useState(selectedInsuranceDetails);
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };
  const postData = () => {
    setOpenDeletePopup(false);
    setOpenInsurancePopup(false);
    setCurrentInsuranceValue('');
    setDisplayCheckBox(false);
    setIsInsuranceTyped(false);
    setShowSpinner(true);
    let payload = {
      ProviderIds: providerIds,
      Insurance: {
        Payor: selectedInsuranceData[0].Payor,
        PayorCode: selectedInsuranceData[0].PayorCode,
        PayorId: selectedInsuranceData[0].PayorId,
        PayorPlanCount: selectedInsuranceData[0].PayorPlanCount,
        InsurancePlans: selectedInsurancePlans,
        UpdateType: 'Delete'
      }
    };
    service
      .post(`/api/roster/add-insurance`, payload)
      .then((res) => {
        if (res.Success) {
          setShowSpinner(false);
          setOpenDeletePopup(false);
          setOpenRemoveConfirmationPopup(false);
          selectAllInsurances
            ? toaster.Success(
                `Successfully removed ${selectedInsurance}
             insurance  to selected and all associated plans from the ${
               !_.isEmpty(selectedProviders)
                 ? selectedProviders.length > 1
                   ? `${selectedProviders.length} providers`
                   : `${selectedProviders.length} provider`
                 : 'provider'
             }`
              )
            : toaster.Success(
                `Successfully removed ${
                  selectedInsurancePlans.length > 0 ? '(' + selectedInsurancePlans.length + ')' : ''
                } insurance ${selectedInsurancePlans.length > 1 ? 'plans' : 'plan'} to selected ${
                  !_.isEmpty(selectedProviders)
                    ? selectedProviders.length > 1
                      ? `${selectedProviders.length} providers`
                      : `${selectedProviders.length} provider`
                    : 'provider'
                }`
              );
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        } else if (res.IsError) {
          setShowSpinner(false);
          setOpenDeletePopup(false);
          setOpenRemoveConfirmationPopup(false);
          toaster.Error('Some problem in loading details please refresh the page!');
        }
      })
      .catch((err) => {
        toaster.Success(
          `Your bulk update request has been submitted, it will be processed in few minutes.`
        );
        setShowSpinner(false);
        setOpenFianlStatus(false);
      });
    HG3Tracker.OmnitureTrackLink(`batch|save|add-insurance-with-plan`);
  };
  useEffect(() => {
    let pwids = selectedProviders.map((provider) => {
      return provider.Provider.ProviderCode;
    });
    setProviderIds(pwids);
  }, [selectedProviders]);

  useEffect(() => {
    let InsuranceDetails = selectedInsuranceDetails.map((data) => {
      return {
        Payor: data.Payor,
        PayorId: data.PayorId,
        PayorCode: data.PayorCode,
        PayorPlanCount: data.PayorPlanCount
      };
    });
    setSelectedInsuranceData(InsuranceDetails);
  }, [selectedInsuranceDetails]);

  return (
    <>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog batch-edit-modal-dialog'
        isOpen={openRemoveConfirmationPopup}
        ariaHideApp={false}
        contentLabel='batch-edit-add-modal'
        shouldCloseOnOverlayClick={false}>
        {
          <div className='final-confirmation-remove-container'>
            <div className='final-confirmation-popup'>
              <div
                className='search-icon-close'
                onClick={() => {
                  setOpenRemoveConfirmationPopup(false);
                  setIsInsuranceTyped(true);
                  selectAllInsurances
                    ? setOpenInsurancePlanPopup(false)
                    : setOpenInsurancePlanPopup(true);
                  selectAllInsurances && setOpenInsurancePopup(true);
                  HG3Tracker.OmnitureTrackLink(`batch|cancel|remove-insurance`);
                }}>
                <img src={crossicon} alt='close-modal' />
              </div>
              <div className='edit-type-option'>Remove Insurance</div>
              <div className='add-this-ins'>
                {selectAllInsurances ? (
                  <div>
                    Are you sure you want to remove <b>{selectedInsurance}</b>{' '}
                    {selectedInsurancePlans.length > 0 && 'and all associated plans'} from the{' '}
                    {selectedProviders.length} selected providers?
                  </div>
                ) : (
                  <div>
                    Are you sure you want to remove the following {selectedInsurancePlans.length}{' '}
                    insurance plans from {selectedProviders.length} providers?
                  </div>
                )}
              </div>
              <div className='insurance-with-plans-list'>
                {selectedInsurance != undefined &&
                  selectedInsurance != null &&
                  !selectAllInsurances && (
                    <div className='selected-insurance-item'>{selectedInsurance}</div>
                  )}
                {!selectAllInsurances && (
                  <div className='div-ins-plans'>
                    {selectedInsurancePlans.length > 0 &&
                      selectedInsurancePlans.map((ins) => (
                        <li className='list-item'>{ins.Plan}</li>
                      ))}
                  </div>
                )}
              </div>
              <div className='remove-ins-btns'>
                <button
                  className='cancel-btn'
                  aria-label='Cancel'
                  onClick={() => {
                    setOpenRemoveConfirmationPopup(false);
                    selectAllInsurances
                      ? setOpenInsurancePlanPopup(false)
                      : setOpenInsurancePlanPopup(true);
                    selectAllInsurances && setOpenInsurancePopup(true);
                    selectAllInsurances && setIsInsuranceTyped(false);
                    setIsInsuranceTyped(true);
                    HG3Tracker.OmnitureTrackLink(`batch|cancel|remove-insurance`);
                  }}>
                  Cancel
                </button>
                <button className='remove-button' aria-label='Yes' onClick={postData}>
                  Confirm
                </button>
              </div>
            </div>
          </div>
        }
      </ReactModal>
    </>
  );
};
export default FinalConfirmationToRemove;
