import ReactModal from 'react-modal';
import './_removeConfirmationPopup.less'
import crossicon from '/public/images/auditPage/cross.svg';

function RemoveConfirmationPopup(){
    return(
        <>
    <ReactModal
      overlayClassName='roster-modal-overlay'
      className='modal-dialog batch-edit-modal-dialog'
      isOpen={true}
      ariaHideApp={false}
      contentLabel='batch-edit-add-modal'
      shouldCloseOnOverlayClick={false}>
      <div className='remove-confirmation-container'>
      <div className='search-icon-close'>
            <img src={crossicon} alt='' />
          </div>
        <div className='remove-confirmation'>Remove Insurance</div>
        <div className='remove-status'>Are you sure, you want to remove</div>
        <div className='remove-buttons'>
            <button className='cancel-btn'>Cancel</button>
            <button className='remove-btn'>Confirm</button>
        </div>
      </div>
    </ReactModal>
        </>
    )
}
export default RemoveConfirmationPopup;