import ReactModal from 'react-modal';
import crossicon from '/public/images/auditPage/cross.svg';
import { useEffect, useState } from 'react';
import './_finalConfirmationToAdd.less';
import * as service from '../../../utils/service';
import { HG3Tracker } from '../../../utils/tracking';

function FinalConfirmation({
  selectInsurancePlans,
  insurancePlans,
  currentBatchData,
  setOpenFianlStatus,
  setShowSpinner,
  addInsuranceListProvider,
  setNotifyProperties,
  reloadList,
  setOpenInsurancePlans,
  setOpenAddPopup,
  setSelectedInsPlans,
  selectAllInsurances,
  selectedProviders,
  addInsuranceValue
}) {
  const [finalSelectedInsuracePlans, setFinalSelectedInsuracnePlans] = useState([]);
  const [selectedInsurance, setSelectedInsurance] = useState('');
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  useEffect(() => {
    let selectedInsurancePlans = [...insurancePlans];
    let finalInsurancePlans = selectedInsurancePlans.filter((plan) => plan.Selected == true);
    setFinalSelectedInsuracnePlans(finalInsurancePlans);
  }, [insurancePlans]);

  const postData = () => {
    setShowSpinner(true);
    let ProviderIds = addInsuranceListProvider.map((provider) => provider.Provider.ProviderCode);
    let selectedInsurances = [];
    finalSelectedInsuracePlans.forEach((plan) => {
      const { Id: PlanId, Name: Plan } = plan;
      selectedInsurances.push({ PlanId, Plan });
    });
    let payload = {
      ProviderIds: ProviderIds,
      Insurance: {
        Payor: selectInsurancePlans.Obj.s_query,
        PayorCode: selectInsurancePlans.Obj.payor_code,
        PayorId: selectInsurancePlans.Obj.med_term_id,
        PayorPlanCount: selectInsurancePlans.Obj.payor_plan_count,
        InsurancePlans: selectedInsurances
      }
    };
    service
      .post(`/api/roster/add-insurance`, payload)
      .then((res) => {
        if (res.Success) {
          toaster.Success(
            `Successfully added ${
              selectedInsurances.length > 0 ? '(' + selectedInsurances.length + ')' : ''
            } insurance ${selectedInsurances.length > 1 ? 'plans' : 'plan'} to selected ${
              !_.isEmpty(ProviderIds)
                ? ProviderIds.length > 1
                  ? `${ProviderIds.length} providers`
                  : `${ProviderIds.length} provider`
                : 'provider'
            }`
          );
          setShowSpinner(false);
          reloadList(ProviderIds);
          setOpenFianlStatus(false);
        } else if (res.IsError) {
          setShowSpinner(false);
          setOpenFianlStatus(false);
          toaster.Error('Some problem in loading details please refresh the page!');
        }
      })
      .catch((err) => {
        toaster.Success(
          `Your bulk update request has been submitted, it will be processed in few minutes.`
        );
        setShowSpinner(false);
        setOpenFianlStatus(false);
      });
    HG3Tracker.OmnitureTrackLink(`batch|save|add-insurance-with-plan`);
  };
  const modalPopUpOpen = () => {
    if (!selectAllInsurances) {
      if (finalSelectedInsuracePlans.length == 0) {
        setOpenFianlStatus(false);
        setOpenAddPopup(true);
      } else {
        setFinalSelectedInsuracnePlans([]);
        setSelectedInsPlans([]);
        setOpenFianlStatus(false);
        setOpenInsurancePlans(true);
      }
    } else {
      setOpenFianlStatus(false);
      setOpenInsurancePlans(false);
      setOpenAddPopup(true);
    }
    HG3Tracker.OmnitureTrackLink(`batch|cancel|add-insurance-with-plan`);
  };
  return (
    <>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog batch-edit-modal-dialog'
        isOpen={true}
        ariaHideApp={false}
        contentLabel='batch-edit-add-modal'
        shouldCloseOnOverlayClick={false}>
        <div className='final-confirmation-add-container'>
          <div className='final-confirmation-popup'>
            <div
              className='search-icon-close'
              onClick={() => {
                setOpenFianlStatus(false);
                selectAllInsurances ? setOpenAddPopup(true) : setOpenInsurancePlans(true);
              }}>
              <img src={crossicon} alt='close-modal' />
            </div>
            <div className='edit-type-option'>Add Insurance</div>
            <div className='add-this-ins'>
              {!selectAllInsurances ? (
                <div>
                  Do you want to add this insurance
                  {insurancePlans.length == 0 ? <b>{selectInsurancePlans.Obj.s_query}</b> : ''} to all
                  selected {addInsuranceListProvider.length == 1 ? 'provider?' : 'providers?'}
                </div>
              ) : (
                <div>
                  Are you sure you want to add <b>{addInsuranceValue}</b> to the {selectedProviders.length} selected providers?
                </div>
              )}
            </div>
            {insurancePlans.length > 0 && (
              <div className='selected-insurance-item'>
                {selectInsurancePlans ? selectInsurancePlans.Obj.s_query : ''}
              </div>
            )}

            <div className='div-ins-plans'>
              {finalSelectedInsuracePlans.length > 0 &&
                finalSelectedInsuracePlans.map((ins) => <li className='list-item'>{ins.Name}</li>)}
            </div>

            <div className='remove-ins-btns'>
              <button className='cancel-btn' aria-label='Cancel' onClick={modalPopUpOpen}>
                Cancel
              </button>
              <button className='remove-btn' aria-label='Yes' onClick={postData}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      </ReactModal>
    </>
  );
}
export default FinalConfirmation;
