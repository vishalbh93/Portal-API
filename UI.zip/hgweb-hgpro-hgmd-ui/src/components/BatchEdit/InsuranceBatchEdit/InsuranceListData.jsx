import React, { useState } from 'react';
import { HG3Tracker } from '../../../utils/tracking';

const InsuranceListData = ({ insuranceData, batchEditType }) => {
  const [cardsVisibilityLimit, setCardsVisibilityLimit] = useState(3);

  const _viewMoreLess = (arr) => {
    if (arr.length > 3) {
      if (cardsVisibilityLimit === 3)
        return (
          <a
            onClick={() => {
              setCardsVisibilityLimit(arr.length);
              HG3Tracker.OmnitureTrackLink(`batch|view-all|${batchEditType}`);
            }}
            className='view-all-insurance'>
            View all {batchEditType}
          </a>
        );
      else
        return (
          <a
            onClick={() => {
              setCardsVisibilityLimit(3);
              HG3Tracker.OmnitureTrackLink(`batch|show-less|${batchEditType}`);
            }}
            className='view-all-insurance'>
            Show Less {batchEditType}
          </a>
        );
    }
    return null;
  };

  return !_.isEmpty(insuranceData) ? (
    <div className={'providerInRoster-batch-edit'}>
      {insuranceData.map((value, index) => {
        if (batchEditType.toLocaleLowerCase() == 'insurance' && index < cardsVisibilityLimit) {
          return (
            <span key={index} className='insurance-list-item'>
              <strong>{value.Payor}</strong>
              {value.InsurancePlans.map((j, index) => (
                <ul key={`insurance-plan-${index}`} className='ul-list-item'>
                  <li>{j.Plan}</li>
                </ul>
              ))}
            </span>
          );
        }
      })}

      {batchEditType.toLocaleLowerCase() == 'insurance' && _viewMoreLess(insuranceData)}
    </div>
  ) : (
    <div className={'providerInRoster-batch-edit'}>
      <span>No {batchEditType}</span>
    </div>
  );
};

export default InsuranceListData;
