import { useState } from 'react';
import './_removeInsuranceList.less'
function RemoveInsuranceList({insuranceData , insurancePlans , setSelectInsurance , selectInsurance}){
    const handleSelectChange = (id) =>{
        if(!selectInsurance){
            setSelectInsurance(id)
        }
        else{
            setSelectInsurance(false)
        }
    }
    const selectRemovedInsuranceList = (id)=>{
        let selectItem;
        if(selectInsurance.length>0){
         selectItem = selectInsurance.filter((item)=>item==id);
         if(selectItem){
             return true;
         }
         return false
        }
    }
    return(
        <>
            <div className="remove-insurance-list-container">
            <div className='checkbox'>
            <input
              id={insuranceData.Payor}
              name={insuranceData.Payor}
              value={selectInsurance}
              type='checkbox'
              onChange={()=>handleSelectChange(insuranceData.PayorId)}
              checked={()=>selectRemovedInsuranceList(insuranceData.PayorId)}
              ></input>
            <label className='checkbox-single-provider' htmlFor={insuranceData.Payor}>{insuranceData.Payor}({insuranceData.InsurancePlans.length})</label>
          </div>
                <div className='autosuggest-insuranceplans'>
                    <input type="text" className='insurance-plans-search'/>
                    {insuranceData && insuranceData.InsurancePlans.map((ins)=>
                     <div className='checkbox'>
                     <input
                       id={insuranceData.Payor}
                       name={insuranceData.Payor}
                    //    value={selectInsurance}
                       type='checkbox'
                       onChange={handleSelectChange}
                    //    checked={selectInsurance}
                       ></input>
                     <label className='checkbox-single-provider' htmlFor={insuranceData.Payor}>{ins.Plan}</label>
                   </div>
                    )}
                </div>
                {/* {insuranceData && insuranceData.} */}
            </div>
        </>
    )
}
export default RemoveInsuranceList;