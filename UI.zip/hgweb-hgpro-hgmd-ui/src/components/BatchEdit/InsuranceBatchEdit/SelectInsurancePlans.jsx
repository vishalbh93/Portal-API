import { useEffect, useState } from 'react';
import ReactModal from 'react-modal';
import * as service from '../../../utils/service';
import crossicon from '/public/images/auditPage/cross.svg';
import './_selectInsurancePlans.less';
import Spinner from '../../Spinner/Spinner';
import { HG3Tracker } from '../../../utils/tracking';

function SelectInsurancePlans({
  selectInsurancePlans,
  currentBatchData,
  setSelectInsurancePlans,
  setOpenInsurancePlans,
  setOpenFianlStatus,
  setSelectedInsPlans,
  setOpenAddPopup,
  selectedProvidersCount
}) {
  const [insurancePlans, setInsurancePlans] = useState([]);
  const [filteredInsurancePlans, setfilteredInsurancePlans] = useState([]);
  const [showSpinner, setShowSpinner] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const fetchInsurancePlans = () => {
    setShowSpinner(true);
    let payload = { ItemCode: selectInsurancePlans.Obj.payor_code, CurrentCodes: [] };
    service
      .post(`/api/autosuggest/insuranceplans`, payload)
      .then((res) => {
        if (res.length > 0) {
          let data = res;
          setInsurancePlans(data);
          setfilteredInsurancePlans(data);
          setShowSpinner(false);
        } else if (res.length == 0) {
          setInsurancePlans([]);
          setShowSpinner(false);
          setOpenInsurancePlans(false);
          setOpenFianlStatus(true);
        }
      })
      .catch((err) => {
        setShowSpinner(false);
      });
  };
  const handleSelectChange = (data) => {
    let updatedInsPlans = [...insurancePlans];
    let selectedInsPlans = updatedInsPlans.map((ins) => {
      if (ins.Id == data.Id && ins.Selected != true) {
        ins.Selected = true;
      } else if (ins.Id == data.Id && ins.Selected == true) {
        ins.Selected = false;
      }
      return ins;
    });
    setInsurancePlans(selectedInsPlans);
  };
  const openFinalConfirmation = () => {
    setOpenFianlStatus(true);
    setOpenInsurancePlans(false);
    setSelectedInsPlans(insurancePlans);
    HG3Tracker.OmnitureTrackLink(`batch|continue|insurancePlan`);
  };
  const onCurrentInsuranceChangeHandler = (e) => {
    setSearchValue(e.target.value);
    let filteredData = insurancePlans.filter((plan) =>
      plan.Name.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setfilteredInsurancePlans(filteredData);
  };

  useEffect(() => {
    fetchInsurancePlans();
  }, []);

  return (
    <>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog batch-edit-modal-dialog'
        isOpen={true}
        ariaHideApp={false}
        contentLabel='batch-edit-add-modal'
        shouldCloseOnOverlayClick={false}>
        <div className='batch-edit-search-container'>
          <div className='batch-edit-search-popup'>
            <div
              className='search-icon-close'
              onClick={() => {
                setOpenInsurancePlans(false);
                setOpenAddPopup(true);
              }}>
              <img src={crossicon} alt='' />
            </div>
            <div className='add-ins-header'>Add Insurance</div>
            <div className='sub-header'>
              Search and select the Insurance plan(s) you would like to add from the{' '}
              {selectedProvidersCount} selected providers.
            </div>
            <div className='add-plans-content'>
              <div className='selected-insurance-item'>
                {selectInsurancePlans ? selectInsurancePlans.Obj.s_query : ''}
              </div>
              <span className='input-label'>Add Insurance Plan(s)</span>
              <input
                type='text'
                className='search-input'
                value={searchValue}
                placeholder='Search plan'
                onChange={(event) => onCurrentInsuranceChangeHandler(event)}
              />
              <div className='insurance-plans'>
                {filteredInsurancePlans.length > 0 &&
                  filteredInsurancePlans.map((ins) => (
                    <div className='checkbox'>
                      <input
                        id={ins.Id}
                        name={ins.Name}
                        value={ins.Name}
                        type='checkbox'
                        onChange={() => handleSelectChange(ins)}
                        checked={ins.Selected}></input>
                      <label className='checkbox-single-provider' htmlFor={ins.Id}>
                        {ins.Name}
                      </label>
                    </div>
                  ))}
              </div>
            </div>
            <div className='remove-ins-btns'>
              <button
                className='cancel-btn'
                onClick={() => {
                  setOpenInsurancePlans(false);
                  setOpenAddPopup(true);
                  HG3Tracker.OmnitureTrackLink(`batch|cancel|insurancePlan`);
                }}>
                Cancel
              </button>
              <button className='remove-btn' onClick={openFinalConfirmation}>
                Add{' '}
                {`${
                  insurancePlans.filter((i) => i.Selected).length > 0
                    ?insurancePlans.filter((i) => i.Selected).length 
                    : ''
                }`}{' '}
                {`${insurancePlans.filter((i) => i.Selected).length > 1 ? 'Plans' : 'Plan'}`}
              </button>
            </div>
            {showSpinner && <Spinner />}
          </div>
        </div>
      </ReactModal>
    </>
  );
}

export default SelectInsurancePlans;
