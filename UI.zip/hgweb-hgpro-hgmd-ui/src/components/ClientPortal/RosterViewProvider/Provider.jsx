import React, { Fragment, useState, useEffect } from 'react';
import './_provider.less';
import PropTypes from 'prop-types';
import Gauge from '../../Gauge/Gauge';
import moment from 'moment';
import Remove from '../../../assets/images/delete_icon.svg';
import Spinner from '../../Spinner/Spinner';
import { useDispatch } from 'react-redux';
import ReactModal from 'react-modal';
import Alert from '../../Alert/Alert';
import { rosterPage } from '../../../components/Practice/Utils/Helpers';
import { ROSTER_PAGE } from '../../../components/Practice/Utils/Constants';
import { providerCodeArray } from '../../../utils/constant-data';
import icon_sponsored from '../../../../assets/images/icon_sponsored.svg';

const CP_Provider = (props) => {
  const {
    ProviderName,
    ProviderId,
    Npi,
    Office,
    PercentComplete,
    SpecialtyName,
    ProfileViews,
    listId,
    SponsorType,
    LastAccessedBy,
    LastModified,
    selectedCount,
    accountInfo,
    IsSponsored,
    ProductCode
  } = props;

  const [style, setStyle] = useState({ display: 'none' });
  const [showSpinner, setShowSpinner] = useState(false);
  const [showModal, toggleModal] = useState(false);
  const [popupMessage, setPopupMessage] = useState('');
  const getClassNameForSponsorStype = (type) => {
    switch (type) {
      case 'AFFILIATED':
        return 'tags_a';
      case 'EMPLOYED':
        return 'tags_e';
      case 'STANDARD':
        return 'tags_s';
      case 'PREMIUM':
        return 'tags_a';
      case 'ENHANCED':
        return 'tags_e';
      default:
        break;
    }
  };

  const onDeleteHandler = () => {
    toggleModal(true);
    setPopupMessage(`Are you sure want to remove this ${ProviderName}`);
  };

  const closeAlertModel = () => {
    toggleModal(false);
  };

  const confirmToDelete = (userId, pwid, clientCode) => {
    setShowSpinner(true);
    let providerList = [pwid];
    props.removeProvider(userId, providerList, clientCode);
    closeAlertModel();
    setShowSpinner(false);
  };

  const sponsorshipVisibility =
    IsSponsored &&
    !providerCodeArray?.map((code) => code?.id)?.includes(ProductCode?.toUpperCase());
  const isMobileView = window.innerWidth <= 768;

  return (
    <Fragment>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog'
        ariaHideApp={true}
        isOpen={showModal}
        contentLabel=''
        onRequestClose={closeAlertModel}>
        <Alert
          action={closeAlertModel}
          heading=''
          message={popupMessage}
          confirmUpdate={() =>
            confirmToDelete(accountInfo.userId, ProviderId, accountInfo.clientCode)
          }></Alert>
      </ReactModal>

      <div className='providerInRoster-details-container'>
        <div
          onMouseEnter={(e) => {
            setStyle({ display: 'block' });
          }}
          onMouseLeave={(e) => {
            setStyle({ display: 'none' });
          }}
          className={
            listId % 2 !== 0
              ? 'providerInRoster-details alternate-background'
              : 'providerInRoster-details'
          }>
          <div className='providerInRoster-name-container'>
            {/* <img className='provider-profile-picture' src={providerImage} alt='profileImage' /> */}
            <div
              className={
                rosterPage == ROSTER_PAGE
                  ? 'providerInRoster-info roster-providers'
                  : `providerInRoster-info`
              }>
              <a href={`/provider/profile/${ProviderId}`} alt={ProviderName}>
                {ProviderName}
              </a>
              {rosterPage != ROSTER_PAGE && <span>{SpecialtyName}</span>}

              {SponsorType != null &&
                selectedCount !== 0 &&
                rosterPage != ROSTER_PAGE &&
                window.innerWidth > 768 && (
                  <span className={getClassNameForSponsorStype(SponsorType)}>{SponsorType}</span>
                )}
            </div>
            {rosterPage == ROSTER_PAGE && IsSponsored && sponsorshipVisibility && (
              <img className='sponsor' src={icon_sponsored} alt='IsSponsored' />
            )}
          </div>
          {selectedCount == 0 && isMobileView && (
            <div
              className={rosterPage != ROSTER_PAGE ? 'remove-onhover' : 'remove-roster-hover'}
              onClick={() => onDeleteHandler()}>
              <img
                src={Remove}
                id={`${ProviderId}-remove-provider`}
                className='img'
                style={style}
                title='Remove Provider'
                alt='Remove Provider'></img>
            </div>
          )}
          <>
            {rosterPage != ROSTER_PAGE ? (
              <div className='providerInRoster-typeID'>
                {isMobileView ? <b className='Type-Id-mobile'>Type/Id </b> : ''}
                {SponsorType != null && (
                  <>
                    <span className={getClassNameForSponsorStype(SponsorType)}>{SponsorType}</span>
                  </>
                )}
                <span className='npi-pwid'>
                  NPI: {Npi}, <br />
                  PWID: {ProviderId}
                </span>
              </div>
            ) : (
              <div className='providerInRoster-specialty'>
                <span>{SpecialtyName}</span>
              </div>
            )}

            <div className='practice-container'>
              {Office ? (
                <Fragment>
                  <span>{Office.Name}</span>
                  <p>{Office.AddressLine}</p>
                  <p>{Office.CityState}</p>
                </Fragment>
              ) : null}
            </div>
          </>

          <div
            className={
              rosterPage != ROSTER_PAGE ? 'profile-completeness' : 'roster-profile-completeness'
            }>
            {isMobileView ? <b className='profile-complete-mobile'>Profile Completeness </b> : ''}
            <Gauge
              radius={30}
              percent={Number(PercentComplete)}
              backgroundColor={'#E3E3E3'}
              fillColor={'#74D9E2'}
              font={'15px'}
            />
          </div>
          <div className={rosterPage != ROSTER_PAGE ? 'profile-views' : 'roster-profile-views'}>
            {isMobileView ? <b className='profile-views-mobile'>Profile Views : </b> : ''}
            {ProfileViews}
          </div>
          {rosterPage != ROSTER_PAGE && (
            <div className='lastAccessedBy-info'>
              {LastAccessedBy != null && (
                <>
                  {isMobileView ? <b className='Last-Accessed-By'>Last Accessed By </b> : ''}
                  <p>{LastAccessedBy}</p>
                  <span>{moment(LastModified).format('LL')}</span>
                </>
              )}
            </div>
          )}

          {selectedCount == 0 && !isMobileView && (
            <div
              className={rosterPage != ROSTER_PAGE ? 'remove-onhover' : 'remove-roster-hover'}
              onClick={() => onDeleteHandler()}>
              <img
                src={Remove}
                id={`${ProviderId}-remove-provider`}
                className='img'
                style={style}
                title='Remove Provider'
                alt='Remove Provider'></img>
            </div>
          )}
        </div>
      </div>
      {showSpinner && <Spinner cta={true} />}
    </Fragment>
  );
};

CP_Provider.propTypes = {
  ProviderName: PropTypes.string,
  ProviderId: PropTypes.string,
  Npi: PropTypes.string,
  SpecialtyCode: PropTypes.string,
  SpecialtyName: PropTypes.string,
  Office: PropTypes.object,
  PercentComplete: PropTypes.number,
  ProfileViews: PropTypes.number,
  LastAccessedBy: PropTypes.string,
  LastModified: PropTypes.string,
  SponsorType: PropTypes.string,
  listId: PropTypes.number,
  removeProvider: PropTypes.func,
  accountInfo: PropTypes.object
};

export default CP_Provider;
