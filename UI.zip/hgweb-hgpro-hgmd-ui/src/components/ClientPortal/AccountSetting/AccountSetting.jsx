import React, { Fragment, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
import Modal from 'react-modal';
import './_accountSetting.less';
import showPassword from '../../../assets/images/show_password.svg';
import hidePassword from '../../../assets/images/icon_hidepassword.svg';
import * as constants from '../../../utils/constant-data';
import close from '../../../assets/images/ProviderProfile/svg-cross.svg';
import AutoComplete from '../../FormComponents/AutoComplete/AutoComplete';
import ValidationErrorMessage from '../../FormComponents/ValidationErrorMessage';
import TextValidation from '../../../utils/validation/isTextValid';
import isEmpty from '../../../utils/validation/isEmpty';
import * as actions from '../../../store/actions';
import Spinner from '../../Spinner/Spinner';
import EmailInput from '@hg/joy/src/components/formElements/EmailInput';
import { rosterPage } from '../../../components/Practice/Utils/Helpers';
import { CLIENTPORTAL_PAGE, ROSTER_PAGE } from '../../../components/Practice/Utils/Constants';
import * as _pService from '../../../utils/serviceCalls/clientPortal';
import * as service from './../../../utils/service';
import _ from 'lodash';

const AccountSettingModal = (props) => {
  const {
    showModalAcc,
    toggleModalAcc,
    closeModalAcc,
    clientDataCode,
    handleAccountInfo,
    isUserAdmin = false
  } = props;

  // Load details
  const profileData = props.profileInfo;
  const [password, togglePassword] = useState(false);
  const [cnfpassword, toggleCnfPassword] = useState(false);
  const [isShowPasswordGroup, setIsShowPasswordGroup] = useState(false);
  const isEmptyField = { isValid: false, error: 'This field is required' };
  const dispatch = useDispatch();
  const [displaySpinner, setDisplaySpinner] = useState(false);
  const [userDetails, setUserDetails] = useState();

  //To get Client Code
  const [suggestData, setSuggestData] = useState(Object);
  const [suggestValue, setSuggestValue] = useState('');
  const [selectedClientData, setSelectedClientData] = useState({
    clientCode: '',
    clientName: ''
  });

  const [account, setAccount] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    cnfpassword: '',
    adminRole: profileData.currentRole,
    clientCode: profileData.clientCode,
    clientName: '',
    clientCodes: profileData.clientCodes,
    userId: profileData.userId,
    pMinimum: 0,
    pMaximum: 0,
    isAllowMultipleFacility: profileData.isAllowMultipleFacility
  });

  const getSuggestValue = () => {
    if (account != null && account != undefined) {
      if (account.clientCode != '') {
        let cc = account.clientCodes.map((i) => {
          if (i.ClientToProductCode === account.clientCode) {
            setSuggestData({
              clientCode: i.ClientCode,
              clientName: i.ClientName,
              clientToProductCode: i.ClientToProductCode
            });
            setSuggestValue(i.ClientName + ' : ' + i.ClientToProductCode);
          } else {
            return;
          }
        });
      }
    }
  };

  const closeHandler = () => {
    setAccount({
      ...account,
      adminRole: profileData.currentRole,
      clientCode: profileData.clientCode
    });
    getSuggestValue();
    updateValidationSetToTrue();
    closeModalAcc();
    updateDataChange(dataChange + 1);
    if (account.pMinimum != 0 && account.pMaximum != 0) {
      setIsThresholdValid({ isValid: false, error: null });
    }
    setIsMinimumCountValid({
      isValid: false,
      error: null
    });
    setIsMaximumCountValid({
      isValid: false,
      error: null
    });
    setCheckboxValidation({
      isValid: false,
      error: null
    });
  };

  //Update Account Settings
  const { success, errorMsg } = useSelector((state) => state.updateAccountSettingsReducer);

  // Update password
  const { updatePasswordsuccess, updatePassworderrorMsg } = useSelector(
    (state) => state.updatePasswordReducer
  );

  const [isFirstnameValid, setFirstnameValidation] = useState({
    isValid: profileData.firstName != '' && profileData.firstName != undefined ? true : false,
    error: ''
  });
  const [isLastnameValid, setLastnameValidation] = useState({
    isValid: profileData.lastName != '' && profileData.lastName != undefined ? true : false,
    error: ''
  });
  const [isEmailValid, setEmailValidation] = useState({
    isValid: profileData.email != '' && profileData.email != undefined ? true : false,
    error: ''
  });
  const [isPasswordValid, setPasswordValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isCnfPasswordValid, setCnfPasswordValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isAdminRoleValid, setAdminRoleValidation] = useState({
    isValid: profileData.currentRole != '' && profileData.currentRole != undefined ? true : false,
    error: ''
  });
  const [isClientCodeValid, setClientCodeValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isChecked, setCheckboxValidation] = useState({
    isValid: false,
    error: null
  });
  const [isThresholdValid, setIsThresholdValid] = useState({
    isValid: false,
    error: null
  });
  const [isMinimumCountValid, setIsMinimumCountValid] = useState({
    isValid: false,
    error: null
  });
  const [isMaximumCountValid, setIsMaximumCountValid] = useState({
    isValid: false,
    error: null
  });

  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  const validateInput = () => {
    if (isEmpty(account.firstName)) {
      setFirstnameValidation(isEmptyField);
    } else {
      setFirstnameValidation(TextValidation(account.firstName, 'name'));
    }

    if (isEmpty(account.lastName)) {
      setLastnameValidation(isEmptyField);
    } else {
      setLastnameValidation(TextValidation(account.lastName, 'name'));
    }

    if (isEmpty(account.email)) {
      setEmailValidation(isEmptyField);
    } else {
      setEmailValidation(TextValidation(account.email, 'emailaddress'));
    }

    if (isEmpty(account.password) && isShowPasswordGroup) {
      setPasswordValidation(isEmptyField);
    } else {
      setPasswordValidation(TextValidation(account.password, 'password'));
    }

    if (isEmpty(account.cnfpassword) && isShowPasswordGroup) {
      setCnfPasswordValidation({
        isValid: false,
        error: 'Please re-enter your password to confirm'
      });
    } else {
      setCnfPasswordValidation('Please re-enter your password to confirm');
    }

    if (
      isEmpty(account.adminRole) ||
      account.adminRole == 'Select Role' ||
      account.adminRole == '-'
    ) {
      setAdminRoleValidation(isEmptyField);
    } else {
      setAdminRoleValidation({ isValid: true, error: '' });
    }

    if (account.adminRole === 'Client_Admin') {
      if (isEmpty(account.clientCode)) {
        setClientCodeValidation(isEmptyField);
      } else {
        setClientCodeValidation({ isValid: true, error: '' });
      }
      if (_.isNumber(account.pMinimum) && _.isNumber(account.pMaximum)) {
        if (account.pMinimum == 0 || account.pMinimum == '') {
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider should not be 0'
          });
        }
        if (account.pMaximum == 0 || account.pMaximum == '') {
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider should not be 0'
          });
        } else if (Number(account.pMaximum) <= Number(account.pMinimum)) {
          setIsThresholdValid({
            isValid: true,
            error: 'Maximum provider should be greater than Minimum provider'
          });

          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
        }
      }
      if (_.isNaN(_.toNumber(account.pMinimum))) {
        setIsMinimumCountValid({
          isValid: true,
          error: 'Minimum provider count is invalid'
        });
      }
      if (_.isNaN(_.toNumber(account.pMaximum))) {
        setIsMaximumCountValid({
          isValid: true,
          error: 'Maximum provider count is invalid'
        });
      }
    } else {
      setClientCodeValidation({
        isValid: true,
        error: ''
      });
    }

    if (!isChecked.isValid) {
      setCheckboxValidation({
        isValid: false,
        error: 'Please verify the identity of this user'
      });
    }
  };

  const isRosterInValid = () => {
    let validateStatus =
      isEmpty(account.firstName) ||
      isEmpty(account.lastName) ||
      isEmpty(account.email) ||
      isEmpty(account.adminRole) ||
      !isChecked.isValid ||
      (account.adminRole === 'Client_Admin' && isEmpty(account.clientCode)) ||
      (account.adminRole === 'Client_Admin' && account.pMinimum >= account.pMaximum) ||
      (account.adminRole === 'Client_Admin' && account.pMaximum == '') ||
      (account.adminRole === 'Client_Admin' && account.pMinimum == '') ||
      (account.adminRole === 'Client_Admin' && account.pMinimum == 0) ||
      (account.adminRole === 'Client_Admin' && account.pMaximum == 0) ||
      _.isNaN(_.toNumber(account.pMinimum)) ||
      _.isNaN(_.toNumber(account.pMaximum)) ||
      (isShowPasswordGroup
        ? isEmpty(account.password) || account.password != account.cnfpassword
        : false)
        ? true
        : false;

    return validateStatus;
  };

  const [dataChange, updateDataChange] = useState(0);
  useEffect(() => {
    if (dataChange > 0) {
      if (
        account.firstName != '' &&
        account.lastName != '' &&
        account.email != '' &&
        account.password == account.cnfpassword &&
        account.adminRole != '' &&
        account.adminRole != '-' &&
        account.clientCode != '' &&
        account.clientCode != 'Client Code'
      ) {
        updateValidationSetToTrue();
      }
    }
  }, [dataChange]);

  const updateValidationSetToTrue = () => {
    setFirstnameValidation({ isValid: true, error: null });
    setLastnameValidation({ isValid: true, error: null });
    setEmailValidation({ isValid: true, error: null });
    setPasswordValidation({ isValid: true, error: null });
    setCnfPasswordValidation({ isValid: true, error: null });
    setAdminRoleValidation({ isValid: true, error: null });
    setClientCodeValidation({ isValid: true, error: null });
  };

  const updateValidationSetToFalse = () => {
    setFirstnameValidation({ isValid: false, error: '' });
    setLastnameValidation({ isValid: false, error: '' });
    setEmailValidation({ isValid: false, error: '' });
    setPasswordValidation({ isValid: false, error: '' });
    setCnfPasswordValidation({ isValid: false, error: '' });
    setAdminRoleValidation({ isValid: false, error: '' });
    setClientCodeValidation({ isValid: false, error: '' });
    setIsThresholdValid({ isValid: false, error: '' });
  };

  const changeHandler = (e) => {
    updateDataChange(dataChange + 1);

    switch (e.target.id) {
      case 'firstname':
        setAccount({ ...account, firstName: e.target.value });
        if (isEmpty(e.target.value)) {
          setFirstnameValidation(isEmptyField);
        } else {
          setFirstnameValidation(TextValidation(account.firstName, 'name'));
        }
        break;

      case 'lastname':
        setAccount({ ...account, lastName: e.target.value });
        if (isEmpty(e.target.value)) {
          setLastnameValidation(isEmptyField);
        } else {
          setLastnameValidation(TextValidation(account.firstName, 'name'));
        }
        break;

      case 'password':
        setAccount({ ...account, password: e.target.value });
        setPasswordValidation(TextValidation(e.target.value, 'password'));
        break;

      case 'cnfpassword':
        setAccount({ ...account, cnfpassword: e.target.value });
        setCnfPasswordValidation({
          isValid: e.target.value != account.password ? false : true,
          error: 'Please re-enter your password to confirm'
        });
        break;

      case 'adminRole':
        setAccount({ ...account, adminRole: e.target.value });
        setAdminRoleValidation({
          isValid: e.target.value != '-' || e.target.value != undefined ? true : false,
          error: 'Please Select Any Role'
        });
        if (account.adminRole !== 'Client_Admin') {
          if (_.isEmpty(account.clientCode)) {
            setSuggestValue('');
          }
          let clientDataElement = document.getElementById('clientData');
          if (clientDataElement) {
            document.getElementById('clientData').value = '';
          }
        }
        break;

      case 'clientCode':
        setAccount({ ...account, clientCode: e.target.value });
        var clientData = clientDataCode.filter((x) => x.clientCode == e.target.value);
        if (clientData.length > 0) {
          setAccount({
            ...account,
            pMinimum:
              clientData[0].minProviderCount != undefined && clientData[0].minProviderCount != null
                ? clientData[0].minProviderCount
                : 0,
            pMaximum:
              clientData[0].maxProviderCount != undefined && clientData[0].maxProviderCount != null
                ? clientData[0].maxProviderCount
                : 0
          });
        } else {
          setAccount({
            ...account,
            pMinimum: 0,
            pMaximum: 0
          });
        }
        setClientCodeValidation({
          isValid: e.target.value != '-' || e.target.value != undefined ? true : false,
          error: 'Please Select Any of client Codes'
        });
        break;

      case 'minimum':
        if (e.target.value < 0) {
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider count is invalid'
          });
          setIsButtonDisabled(true);
        } else {
          setAccount({ ...account, pMinimum: e.target.value });
          if (_.isNaN(_.toNumber(e.target.value))) {
            setIsMinimumCountValid({
              isValid: true,
              error: 'Minimum provider count is invalid'
            });
            setIsButtonDisabled(true);
          } else if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMinimumCountValid({
              isValid: true,
              error: 'Minimum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(true);
          } else if (Number(e.target.value) >= account.pMaximum) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(true);
          } else {
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(false);
          }
        }
        break;

      case 'maximum':
        if (e.target.value < 0) {
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider count is invalid'
          });
          setIsButtonDisabled(true);
        } else {
          setAccount({ ...account, pMaximum: e.target.value });
          if (_.isNaN(_.toNumber(e.target.value))) {
            setIsMaximumCountValid({
              isValid: true,
              error: 'Maximum provider count is invalid'
            });
            setIsButtonDisabled(true);
          } else if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMaximumCountValid({
              isValid: true,
              error: 'Maximum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(true);
          } else if (account.pMinimum >= Number(e.target.value)) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(true);
          } else {
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setIsButtonDisabled(false);
          }
        }
        break;

      case 'verifycheckBox':
        if (e.currentTarget.checked == false) {
          setCheckboxValidation({
            isValid: false,
            error: 'Please verify the identity of this user'
          });
        } else {
          setCheckboxValidation({
            isValid: true,
            error: ''
          });
        }
        break;
    }
  };

  const onUpdateHandler = (e) => {
    e.preventDefault();
    validateInput();
    if (!isRosterInValid()) {
      if (account.adminRole !== 'Client_Admin') {
        setAccount({ ...account, clientCode: '' });
        setAccount({ ...account, clientName: '' });
      }
      setDisplaySpinner(true);
      if (isShowPasswordGroup) {
        dispatch(
          actions.updatePassword(
            account.password,
            account.cnfpassword,
            account.userId,
            setDisplaySpinner
          )
        );
      }
      let currPage = rosterPage != ROSTER_PAGE ? CLIENTPORTAL_PAGE : ROSTER_PAGE;
      dispatch(actions.updateAccountSettings(account, setDisplaySpinner, closeModalAcc, currPage));
      initValidation();
      handleAccountInfo(account.clientCode, account.adminRole);
      updateValidationSetToFalse();
      setIsMinimumCountValid({
        isValid: false,
        error: null
      });
      setIsMaximumCountValid({
        isValid: false,
        error: null
      });
    }
    fetchUserDetails();
    window.location.reload();
  };
  const clientsTextBoxData = {
    id: 'clientData',
    name: 'clientData',
    placeholder: 'Client Code'
  };
  const searchClientCodeChange = (e) => {
    setSuggestValue(e.target.value);
    if (e.currentTarget.value.length <= 1) {
      setAccount({ ...account, clientCode: '' });
      setClientCodeValidation(isEmptyField);
      return;
    }
    let filteredClients = account.clientCodes.filter(function (v) {
      if (
        v.ClientName.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1 ||
        v.ClientCode.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1
      ) {
        return v;
      }
    });
    let clientsData = filteredClients.slice(0, 5);
    setSuggestData(clientsData);
    return clientsData;
  };

  const onSelectedItem = (data) => {
    if (!_.isEmpty(data)) {
      setSelectedClientData({
        ...selectedClientData,
        clientCode: data[0].values,
        clientName: data[0].text
      });
      var clientData = clientDataCode.filter((x) => x.clientCode == data[0].values);
      if (clientData.length > 0) {
        let tempAccountObj = {
          ...account,
          pMinimum: !_.isEmpty(clientData[0]) ? clientData[0].minProviderCount : 0,
          pMaximum: !_.isEmpty(clientData[0]) ? clientData[0].maxProviderCount : 0,
          clientCode: data[0].values
        };
        if (clientData[0].minProviderCount == 0 || clientData[0].minProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider should not be 0'
          });
        }
        if (clientData[0].maxProviderCount == 0 || clientData[0].maxProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider should not be 0'
          });
        } else {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
        }
        setAccount({ ...tempAccountObj });
      } else {
        setAccount({
          ...account,
          pMinimum: 0,
          pMaximum: 0
        });
      }
      setSuggestValue(data[0].text);
      if (isEmpty(data[0].values)) {
        setClientCodeValidation(isEmptyField);
      } else {
        setClientCodeValidation({ isValid: true, error: '' });
      }
    }
  };

  useEffect(() => {
    setAccount({ ...account });
    setClientCodeValidation({
      isValid: true,
      error: ''
    });
  }, [account.adminRole]);

  const togglePasswordGroup = () => {
    setIsShowPasswordGroup(!isShowPasswordGroup);
  };

  const clearAccountSettings = () => {
    setAccount({
      ...account,
      password: '',
      cnfpassword: ''
    });
    updateValidationSetToFalse();
    toggleModalAcc(false);
    setDisplaySpinner(false);
  };

  const initValidation = () => {
    setCheckboxValidation({ isValid: false, error: null });
  };

  useEffect(() => {
    toggleModalAcc(false);
  }, []);

  useEffect(() => {
    let init = {
      firstName: profileData.firstName,
      lastName: profileData.lastName,
      email: profileData.email,
      password: '',
      cnfpassword: '',
      adminRole: profileData.currentRole,
      clientCode: profileData.clientCode,
      clientName: '',
      clientCodes: profileData.clientCodes,
      userId: profileData.userId,
      pMinimum: 0,
      pMaximum: 0,
      isAllowMultipleFacility: profileData.isAllowMultipleFacility
    };
    //setAccount(init);
    getSuggestValue();
  }, [showModalAcc]);

  useEffect(() => {
    let msg = updatePasswordsuccess ? updatePasswordsuccess && success : success;
    if (msg) {
      clearAccountSettings();
    } else if (errorMsg != '') {
    }
  }, [success, errorMsg, updatePasswordsuccess, updatePassworderrorMsg]);

  useEffect(() => {
    Modal.setAppElement('body');
  });

  const emailChangeHandler = (value) => {
    account.email = value;
    setAccount({ ...account, email: value });
    setEmailValidation(TextValidation(value, 'emailaddress'));
  };
  useEffect(() => {
    if (clientDataCode != undefined && clientDataCode != null) {
      var clientData = clientDataCode.filter((x) => x.clientCode == account.clientCode);
      if (clientData.length > 0) {
        setAccount({
          ...account,
          pMinimum:
            clientData[0].minProviderCount != undefined && clientData[0].minProviderCount != null
              ? clientData[0].minProviderCount
              : 0,
          pMaximum:
            clientData[0].maxProviderCount != undefined && clientData[0].maxProviderCount != null
              ? clientData[0].maxProviderCount
              : 0,
          clientCode: profileData.clientCode,
          isAllowMultipleFacility: clientData[0].isAllowMultipleFacility
        });
        if (account.pMaximum > 0 && account.pMaximum > account.pMinimum && account.pMinimum != 0) {
          setIsThresholdValid({
            isValid: false,
            error: ''
          });
        }
      } else {
        setAccount({
          ...account,
          pMinimum: 0,
          pMaximum: 0,
          clientCode: profileData.clientCode
        });
      }
    }
  }, [clientDataCode]);

  useEffect(() => {
    getSuggestValue();
  }, [profileData, dataChange]);

  useEffect(() => {
    if (selectedClientData != null && selectedClientData != undefined) {
      if (selectedClientData.clientCode != '' && selectedClientData.clientName != '') {
        let cliName = selectedClientData.clientName.split(':');
        setAccount({
          ...account,
          clientCode: selectedClientData.clientCode,
          clientName: cliName[0]
        });
      }
    }
  }, [selectedClientData]);

  const fetchUserDetails = () => {
    const userId = profileData.userId;
    if (
      (profileData.isImpersonate !== undefined && profileData.isImpersonate === true) ||
      isUserAdmin
    ) {
      service.get(`/api/admin/user-details?userId=${userId}`).then((res) => {
        if (res != undefined) {
          //const { data } = res;
          setUserDetails(res);
        }
      });
    }
  };
  useEffect(() => {
    fetchUserDetails();
    setIsButtonDisabled(true);
  }, [showModalAcc]);

  useEffect(() => {
    if (userDetails !== undefined) {
      setAccount({
        ...account,
        firstName: userDetails.FirstName,
        lastName: userDetails.LastName,
        email: userDetails.Email
      });
    }
  }, [userDetails]);

  useEffect(() => {
    if (
      isFirstnameValid.isValid &&
      isEmailValid.isValid &&
      isLastnameValid.isValid &&
      isAdminRoleValid.isValid &&
      isPasswordValid.isValid &&
      !isMinimumCountValid.isValid &&
      !isMaximumCountValid.isValid &&
      !isThresholdValid.isValid &&
      isChecked.isValid 
    ) {
      setIsButtonDisabled(false);
    } else {
      setIsButtonDisabled(true);
    }
  }, [
    isClientCodeValid,
    isMinimumCountValid,
    isMaximumCountValid,
    isThresholdValid,
    isFirstnameValid,
    isLastnameValid,
    isAdminRoleValid,
    isPasswordValid,
    isChecked
  ]);

  return (
    <Fragment>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog'
        ariaHideApp={true}
        isOpen={showModalAcc}
        contentLabel='Account Setting'
        onRequestClose={closeHandler}
        shouldCloseOnEsc={false}
        shouldCloseOnOverlayClick={false}>
        <div className={'manage-account'}>
          <div className='roster-modal'>
            <div className='close-modal'>
              <img className='close-icon' src={close} alt='close' onClick={closeHandler} />
            </div>
            <form id='rosterForm' autoComplete='off'>
              <div className='roster-modal-container'>
                <div className='error-response'>
                  {!success && (
                    <ValidationErrorMessage
                      className='error-response'
                      message={errorMsg}></ValidationErrorMessage>
                  )}
                </div>
                <div className='roster-modal-header'>
                  <>
                    <h1> Account Settings</h1>
                    <p>General Information</p>
                  </>
                </div>

                <div className='roster-modal-content'>
                  <div className='input-inline'>
                    <div className='firstname'>
                      <div className='height-fix'>
                        <input
                          className='input'
                          id='firstname'
                          type='text'
                          value={account.firstName}
                          onChange={changeHandler}
                        />
                        <label htmlFor='firstname' className='floating-label'>
                          First Name*
                        </label>
                      </div>
                      {!isFirstnameValid.isValid && (
                        <ValidationErrorMessage message={isFirstnameValid.error} />
                      )}
                    </div>

                    <div className='lastname'>
                      <div className='height-fix'>
                        <input
                          className='input'
                          id='lastname'
                          type='text'
                          value={account.lastName}
                          onChange={changeHandler}
                        />
                        <label htmlFor='lastname' className='floating-label'>
                          Last Name*
                        </label>
                      </div>{' '}
                      {!isLastnameValid.isValid && (
                        <ValidationErrorMessage message={isLastnameValid.error} />
                      )}
                    </div>
                  </div>
                  <div className='input-block'>
                    <>
                      <div className='email'>
                        <div className='height-fix'>
                          <EmailInput
                            label='Enter Email*'
                            name='email'
                            id='email'
                            value={account.email}
                            type='text'
                            onChange={(name, value) => emailChangeHandler(value)}
                          />
                        </div>
                        {!isEmailValid.isValid && (
                          <ValidationErrorMessage message={isEmailValid.error} />
                        )}
                      </div>
                      <div className='password-grp'>
                        <label className='password-grp-title'> Password</label>
                        <label className='password-grp-toggle' onClick={togglePasswordGroup}>
                          {isShowPasswordGroup ? 'Hide' : 'Show'}
                        </label>
                        {isShowPasswordGroup && (
                          <Fragment>
                            <div className='password'>
                              <div className='height-fix'>
                                <input
                                  id='password'
                                  type={password ? 'password' : 'text'}
                                  className='block-password'
                                  onChange={changeHandler}
                                  placeholder={'New Password'}
                                />
                              </div>
                              <div className='pswd-toggle'>
                                <div className='toggle-password' id='togglePassword'>
                                  <label htmlFor='togglePassword'>
                                    <div>
                                      {password ? (
                                        <img
                                          src={showPassword}
                                          alt='showpassword'
                                          onClick={() => togglePassword(!password)}
                                        />
                                      ) : (
                                        <img
                                          src={hidePassword}
                                          alt='hidepassword'
                                          onClick={() => togglePassword(!password)}
                                        />
                                      )}
                                    </div>
                                  </label>
                                </div>
                              </div>
                            </div>
                            <div className='password'>
                              <div className='height-fix'>
                                <input
                                  id='cnfpassword'
                                  type={cnfpassword ? 'password' : 'text'}
                                  className='block-password'
                                  onChange={changeHandler}
                                  placeholder={'Confirm password'}
                                />
                              </div>
                              <div className='pswd-toggle'>
                                <div className='toggle-password' id='toggleCnfPassword'>
                                  <label htmlFor='toggleCnfPassword'>
                                    <div>
                                      {cnfpassword ? (
                                        <img
                                          src={showPassword}
                                          alt='showpassword'
                                          onClick={() => toggleCnfPassword(!cnfpassword)}
                                        />
                                      ) : (
                                        <img
                                          src={hidePassword}
                                          alt='hidepassword'
                                          onClick={() => toggleCnfPassword(!cnfpassword)}
                                        />
                                      )}
                                    </div>
                                  </label>
                                </div>
                              </div>
                            </div>
                            {(!isPasswordValid.isValid ||
                              account.password != account.cnfpassword) && (
                              <ValidationErrorMessage message={isCnfPasswordValid.error} />
                            )}
                          </Fragment>
                        )}
                      </div>
                      <div className='admin-role'>
                        <p>
                          <label>Select Role</label>
                          <select
                            name='adminRole'
                            id='adminRole'
                            onChange={changeHandler}
                            value={account.adminRole}>
                            {constants.createUserRoles.map((data, index) => (
                              <option key={index} value={data.value}>
                                {data.label}
                              </option>
                            ))}
                          </select>
                          {!isAdminRoleValid.isValid && (
                            <ValidationErrorMessage message={isAdminRoleValid.error} />
                          )}
                        </p>
                      </div>
                    </>
                    <>
                      {account.adminRole === 'Client_Admin' && (
                        <div className='client-code'>
                          <p>
                            <label>Client Code</label>
                            <AutoComplete
                              textBoxData={clientsTextBoxData}
                              suggestData={suggestData}
                              searchValue={suggestValue}
                              onChangeHandler={searchClientCodeChange}
                              searchType='clientData'
                              onSelectedItem={onSelectedItem}
                            />
                            {!isClientCodeValid.isValid && (
                              <ValidationErrorMessage message={isClientCodeValid.error} />
                            )}
                          </p>
                        </div>
                      )}
                      {account.adminRole === 'Client_Admin' && !isEmpty(suggestValue) && (
                        <>
                          <div className='provider-threshold'>
                            <div className='min-max-provider'>
                              <label className='text-provider-mincount'>Minimum Provider</label>
                              <input
                                className='input'
                                id='minimum'
                                type='number'
                                min={0}
                                value={account.pMinimum}
                                onChange={changeHandler}
                              />
                              {isMinimumCountValid.isValid && (
                                <div className='min-max-provider-validation'>
                                  <ValidationErrorMessage message={isMinimumCountValid.error} />
                                </div>
                              )}
                            </div>
                            <div className='min-max-provider'>
                              <label className='text-provider-maxcount'>Maximum Provider</label>
                              <input
                                className='input'
                                id='maximum'
                                type='number'
                                min={0}
                                value={account.pMaximum}
                                onChange={changeHandler}
                              />
                              {isMaximumCountValid.isValid && (
                                <div className='min-max-provider-validation'>
                                  <ValidationErrorMessage message={isMaximumCountValid.error} />
                                </div>
                              )}
                            </div>
                          </div>
                          {isThresholdValid.isValid && (
                            <div className='validation-message'>
                              <ValidationErrorMessage message={isThresholdValid.error} />
                            </div>
                          )}
                        </>
                      )}
                    </>
                  </div>

                  <div className='user-verification'>
                    <div className='checkbox'>
                      <input id='verifycheckBox' type='checkbox' onClick={changeHandler}></input>
                      <label htmlFor='verifycheckBox'></label>
                    </div>
                    <div className='text'>
                      {isChecked.error == null ? (
                        <label htmlFor='verifycheckBox' className='verified'>
                          User Verification
                        </label>
                      ) : (
                        <label
                          htmlFor='verifycheckBox'
                          className={isChecked.isValid ? 'verified' : 'not-verified'}>
                          User Verification
                        </label>
                      )}
                      <br />{' '}
                      {account.adminRole === 'HG_Audit_Admin' ? (
                        <span>
                          I confirm that the identity of this user has been verified and that they
                          are authorized to manage profiles on behalf of providers.
                        </span>
                      ) : (
                        <span>
                          I have confirmed that a signed DLA is on file and they are authorized to
                          manage profiles on behalf of providers.
                        </span>
                      )}
                      <div className='error-wrapper'>
                        {!isChecked.isValid && <ValidationErrorMessage message={isChecked.error} />}
                      </div>
                    </div>
                  </div>
                </div>
                <div className='footer-seperator'></div>
                <div
                  className={
                    rosterPage != ROSTER_PAGE
                      ? 'roster-modal-footer client-portal'
                      : 'roster-modal-footer'
                  }>
                  <button onClick={closeHandler} className='cancel-btn'>
                    Cancel
                  </button>
                  <button onClick={onUpdateHandler}  disabled={isButtonDisabled} className={isButtonDisabled ?'button-disabled account-settings' : 'add-btn'}>
                    Save
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </ReactModal>
      {displaySpinner && <Spinner cta={true} />}
    </Fragment>
  );
};
AccountSettingModal.propTypes = {
  showModalAcc: PropTypes.bool,
  closeModalAcc: PropTypes.func,
  profileInfo: PropTypes.object,
  toggleModalAcc: PropTypes.func,
  showSpinnerModel: PropTypes.func,
  handleAccountInfo: PropTypes.func,
  isUserAdmin: PropTypes.bool
};
AccountSettingModal.defaultProps = {
  handleAccountInfo: () => {},
  isUserAdmin: false
};
export default AccountSettingModal;
