import React, { Fragment, useState } from 'react';

// import media
import Total from '../../../assets/images/total-providers.svg';
import Premium from '../../../assets/images/premium.svg';
import Enhanced from '../../../assets/images/enhanced.svg';
import Standard from '../../../assets/images/standard.svg';

// import style
import './_banner.less';
import PropTypes from 'prop-types';

const Header = (props) => {
  const [empFilter, setEmpFilter] = useState(false);
  const [affFilter, setAffFilter] = useState(false);
  const [preFilter, setPreFilter] = useState(false);
  const [enhFilter, setEnhFilter] = useState(false);
  const [stdFilter, setStdFilter] = useState(false);
  const isMobileView = window.innerWidth <= 768;

  const {
    sponsoredProvidersCount,
    sponsorTypeChangeHandler,
    sponsorInformation,
    scrolled,
    numOfChildElements
  } = props;

  return (
    <Fragment>
      <div
        className={
          !isMobileView
            ? `cols ${sponsoredProvidersCount.total === 0 && 'disabled-cols'}`
            : numOfChildElements > 3 && numOfChildElements != undefined
            ? `cols ${sponsoredProvidersCount.total === 0 && 'disabled-cols'}`
            : `cols cols-mobile ${sponsoredProvidersCount.total === 0 && 'disabled-cols'}`
        }
        onClick={(e) => {
          sponsoredProvidersCount.total > 0 && sponsorTypeChangeHandler('ALL');
          setEmpFilter(false);
          setAffFilter(false);
          setPreFilter(false);
          setEnhFilter(false);
          setStdFilter(false);
        }}>
        <img src={Total} alt='profile' className='icons' />
        <span className='count right-border'>{sponsoredProvidersCount.total}</span>
        <p className='heading'>Total Providers</p>
      </div>
      {sponsorInformation.isFacility &&
      (sponsorInformation.sponsorType == 'PDCHSP' || sponsorInformation.sponsorType == 'MAP') ? (
        <>
          <div
            className={`cols ${sponsoredProvidersCount.employed === 0 && 'disabled-cols'}`}
            onClick={(e) => {
              sponsoredProvidersCount.employed > 0 && sponsorTypeChangeHandler('Employed');
              setEmpFilter(true);
              setAffFilter(false);
              setStdFilter(false);
            }}>
            <img src={Premium} alt='rating' className='icons' />
            <span
              className={
                !isMobileView
                  ? `count right-border ${empFilter ? 'column-active-employed' : ''}`
                  : 'count'
              }>
              {sponsoredProvidersCount.employed}
            </span>
            <p className={`heading ${empFilter ? 'column-active-employed' : ''}`}>Employed</p>
          </div>
          <div
            className={`cols ${sponsoredProvidersCount.affiliated === 0 && 'disabled-cols'}`}
            onClick={(e) => {
              sponsoredProvidersCount.affiliated > 0 && sponsorTypeChangeHandler('Affiliated');
              setAffFilter(true);
              setEmpFilter(false);
              setStdFilter(false);
            }}>
            <img src={Enhanced} alt='Award' className='icons' />
            <span className={`count right-border ${affFilter ? 'column-active-affiliated' : ''}`}>
              {sponsoredProvidersCount.affiliated}
            </span>
            <p className={`heading ${affFilter ? 'column-active-affiliated' : ''}`}>Affiliated</p>
          </div>
        </>
      ) : (
        <>
          {(sponsorInformation.sponsorType == 'PDCPRAC' ||
            sponsorInformation.sponsorType == 'MAP') && (
            <div
              className={`cols ${sponsoredProvidersCount.premium === 0 && 'disabled-cols'}`}
              onClick={(e) => {
                sponsoredProvidersCount.premium > 0 && sponsorTypeChangeHandler('Premium');
                setPreFilter(true);
                setEnhFilter(false);
                setStdFilter(false);
              }}>
              <img src={Premium} alt='rating' className='icons' />
              <span className={`count right-border ${preFilter ? 'column-active-premium' : ''}`}>
                {sponsoredProvidersCount.premium}
              </span>
              <p className={`heading ${preFilter ? 'column-active-premium' : ''}`}>Premium</p>
            </div>
          )}
          {sponsorInformation.sponsorType == 'PDCPRACT2' && (
            <div
              className={`cols ${sponsoredProvidersCount.enhanced === 0 && 'disabled-cols'}`}
              onClick={(e) => {
                sponsoredProvidersCount.enhanced > 0 && sponsorTypeChangeHandler('Enhanced');
                setEnhFilter(true);
                setPreFilter(false);
                setStdFilter(false);
              }}>
              <img src={Enhanced} alt='Award' className='icons' />
              <span className={`count right-border ${enhFilter ? 'column-active-enhanced' : ''}`}>
                {sponsoredProvidersCount.enhanced}
              </span>
              <p className={`heading ${enhFilter ? 'column-active-enhanced' : ''}`}>Enhanced</p>
            </div>
          )}
        </>
      )}
      <div
        className={`cols standard-last ${
          sponsoredProvidersCount.standard === 0 && 'disabled-cols'
        }`}
        onClick={(e) => {
          sponsoredProvidersCount.standard > 0 && sponsorTypeChangeHandler('Standard');
          setStdFilter(true);
          setEmpFilter(false);
          setAffFilter(false);
          setPreFilter(false);
          setEnhFilter(false);
        }}>
        <img src={Standard} alt='rating' className='icons' />
        <span className={`count ${stdFilter ? 'column-active-standard' : ''}`}>
          {sponsoredProvidersCount.standard}
        </span>
        <p className={`heading ${stdFilter ? 'column-active-standard' : ''}`}>Standard</p>
      </div>
    </Fragment>
  );
};

Header.propTypes = {
  sponsoredProvidersCount: PropTypes.object,
  sponsorTypeChangeHandler: PropTypes.func,
  sponsorInformation: PropTypes.object,
  scrolled: PropTypes.bool,
  numOfChildElements: PropTypes.number
};

export default Header;
