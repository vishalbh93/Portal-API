import React, { Fragment, useState, useEffect } from 'react';
import './_banner.less';
import PropTypes from 'prop-types';
import Medal from '../../../assets/images/medal-icon.svg';
import * as actions from '../../../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import Header from './Header';
import { rosterPage } from '../../../components/Practice/Utils/Helpers';
import { ROSTER_PAGE } from '../../../components/Practice/Utils/Constants';
import Total from '../../../assets/images/total-providers.svg';
import icon_manager from '../../../assets/images/RosterPage/icon_manager.svg';

const Banner = (props) => {
  const {
    providerDisplayName,
    clientCode,
    sponsorTypeHandler,
    sponsorInformationHandler,
    isReloadBanner,
    batchEdit,
    sponsorProvidersHandler,     
  } = props;
  const [scrolled, setScrolled] = useState(false);

  const [refreshBanner, setRefreshBanner] = useState(false);

  const dispatch = useDispatch();
  const { sponsorInformation, sponsoredProvidersCount } = useSelector(
    (state) => state.getClientPortalBannerDataReducer
  );

  //ManageTab Section
  const [manageTab, setManageTab] = useState(false);
  const [userId, setUserId] = useState(props.userId);

  const manageTabahandler = () => {
    setManageTab(!manageTab);
  };

  let highlightSecClasses = ['highlight-section-inner'];
  if (scrolled) {
    highlightSecClasses.push('bottom-border-radius');
  }

  const handleScroll = () => {
    setTimeout(() => {
      let offset = window.scrollY;
      if (offset > 196) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    }, 5);
  };
  const isMobileView = window.innerWidth <= 768;
  useEffect(() => {
    window.scrollTo(0, 0);
    var payload = {
      userId: userId,
      clientCode: clientCode
    };
    loadBannerData(payload);
  }, [userId, clientCode]);

  const loadBannerData = (payload) => {
    dispatch(actions.getClientPortalBannerData(payload));
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
  });

  const sponsorTypeChangeHandler = (sponsorType) => {
    sponsorTypeHandler(sponsorType);
    window.scrollTo(0, 370);
  };

  useEffect(() => {
    sponsorInformationHandler(sponsorInformation);
  }, [sponsorInformation]);

  const [isReadMore, setIsReadMore] = useState(false);
  const toggleReadMore = () => {
    setIsReadMore(!isReadMore);
  };

  useEffect(() => {
    setRefreshBanner(isReloadBanner);
  }, [isReloadBanner]);

  useEffect(() => {
    setRefreshBanner(false);
    sponsorProvidersHandler(sponsoredProvidersCount);
  }, [sponsoredProvidersCount]);

  useEffect(() => {
    if (refreshBanner) {
      var payload = {
        userId: userId,
        clientCode: clientCode
      };
      loadBannerData(payload);
    }
  }, [refreshBanner]);

  const openModalAccTab = () => {
    props.openModal_Acc(true);
  };
  const onDeleteModalTab = () => {
    props.onDeleteModal_Acc(true);
  };

  const onClientSettingsTab = () => {
    props.onClientSettings_Tab(true);
  };
  const onDuplicateAssignModalTab = () => {
    props.onDuplicateAssign_Modal(true);
  };

  const generateHeaderSectionForEmptyProviders = () => {
    const headerSection = scrolled ? (
      <div className='scrolled-header'>
        <div className={`highlight-section ${isReadMore && 'read-more'}`}>
          <div className='highlight-section-inner bottom-border-radius'>
            <div className={`cols`} style={{ width: '100%', background: 'unset' }}>
              <img src={Total} alt='profile' className='icons' />
              <span className='count'>0</span>
              <p className='heading'>Total Provider</p>
            </div>
          </div>
        </div>
      </div>
    ) : (
      <div className='fixed-header'>
        <div className={`highlight-section ${isReadMore && 'read-more'}`}>
          <div className='highlight-section-inner'>
            <div className={`cols`} style={{ width: '100%', background: 'unset' }}>
              <img src={Total} alt='profile' className='icons' />
              <span className='count'>0</span>
              <p className='heading'>Total Provider</p>
            </div>
          </div>
        </div>
      </div>
    );
    return <>{headerSection}</>;
  };
  const numOfChildElements = document.querySelectorAll('.cols').length;

  const manageTabComponent = () => {
    return (
      <>
        <span id='icon-image_1'>
          <icon>
            <img
              src={icon_manager}
              className='icon-image'
              onClick={manageTabahandler}
              alt='manager-icon'
            />
          </icon>
        </span>
        {manageTab && (
          <div id='manage-tab' className='manage-roster-items'>
            <ul
              className='dropdown-item'
              onMouseEnter={() => {
                setManageTab(true);
              }}
              onMouseLeave={() => {
                setManageTab(false);
              }}>
              {props.currentRole === 'Client_Admin' && (
                <li className='disabled-list-item'>
                  <span onClick={onClientSettingsTab}>Client Settings</span>
                </li>
              )}
              <li>
                <span onClick={openModalAccTab}>Account Settings</span>
              </li>
              <li className='disabled-list-item'>
                <span onClick={onDeleteModalTab}>Delete Account</span>
              </li>
              {/* <li className='disabled-list-item'>
                          <span onClick={onDuplicateAssignModalTab}>Duplicate and Assign</span>
                       </li>                      */}
            </ul>
          </div>
        )}
      </>
    );
  };

  return (
    <Fragment>
      <div className='rosterviewbanner-container'>
        <div
          className={
            rosterPage == ROSTER_PAGE
              ? !scrolled
                ? 'rosterviewbanner-inner-container'
                : 'rosterviewbanner-inner-container scroll-height'
              : 'rosterviewbanner-inner-container'
          }>
          <div className='banner-section'>
            <div className='top-sec'>
              {isMobileView && (
                <div className='body-title-impersonate'>
                  <a href='/admin/index' alt='Search Results'>
                    Search Results
                  </a>
                  <span> {'>'} </span> {providerDisplayName}
                </div>
              )}
              <div className='head-container'>
              <h1 className='heading'>{providerDisplayName}</h1>
              {props.isUserAdmin && manageTabComponent()}
              </div>
              {sponsorInformation.sponsorLogo != undefined &&
                sponsorInformation.sponsorLogo != '' && (
                  <div className='header-logo'>
                    <img
                      className='right-align-logo'
                      src={sponsorInformation.sponsorLogo}
                      alt='Logo'
                    />
                </div>
                )}
            </div>
            <div className='sub-sec'>
              <div className='subheading-profile-type'>
                <span>
                  <img src={Medal} alt='rating' className='premium-medal' />
                  Healthgrades Partner Program
                </span>
              </div>
              {!isMobileView ? (
                <p className={`para`}>
                  Healthgrades is a digital extension of the affiliated
                  {sponsorInformation.isFacility ? ' hospital' : ' practice'}'s physician and
                  provider referral program. It makes the practice more discoverable and accessible
                  to potential new patients, and includes
                  <i>
                    {' '}
                    Featured Placement, Competitive Intercept, and a Distinctive Profile{' '}
                  </i> on{' '}
                  {isReadMore ? (
                    <span>
                      <u>
                        <a
                          href='https://www.healthgrades.com/'
                          alt='healthgrades.com'
                          target='_blank'
                          rel='noopener noreferrer'>
                          Healthgrades
                        </a>
                      </u>
                      .
                      <br />
                      <p></p>
                      The phone number showing on this{' '}
                      <u>
                        <a
                          href='https://www.healthgrades.com/'
                          alt='healthgrades.com'
                          target='_blank'
                          rel='noopener noreferrer'>
                          Healthgrades
                        </a>
                      </u>{' '}
                      profile is part of the Healthgrades partner program and is used for tracking
                      purposes. The calls will continue to go to the saved number for this profile.{' '}
                    </span>
                  ) : null}
                  <span onClick={toggleReadMore} className='read-or-hide'>
                    <i>
                      <u>{`${isReadMore ? 'Show less' : '...Read more'}`}</u>
                    </i>
                  </span>
                </p>
              ) : (
                <p className={`para`}>
                  Healthgrades is a digital extension of the affiliated
                  {sponsorInformation.isFacility ? ' hospital' : ' practice'}'s physician and
                  provider referral program. It makes the
                  {isReadMore ? (
                    <span>
                      practice more discoverable and accessible to potential new patients, and
                      includes
                      <i>
                        {' '}
                        Featured Placement, Competitive Intercept, and a Distinctive Profile{' '}
                      </i>{' '}
                      on{' '}
                      <u>
                        <a
                          href='https://www.healthgrades.com/'
                          alt='healthgrades.com'
                          target='_blank'
                          rel='noopener noreferrer'>
                          Healthgrades
                        </a>
                      </u>
                      .
                      <br />
                      <p></p>
                      The phone number showing on this{' '}
                      <u>
                        <a
                          href='https://www.healthgrades.com/'
                          alt='healthgrades.com'
                          target='_blank'
                          rel='noopener noreferrer'>
                          Healthgrades
                        </a>
                      </u>{' '}
                      profile is part of the Healthgrades partner program and is used for tracking
                      purposes. The calls will continue to go to the saved number for this profile.{' '}
                    </span>
                  ) : null}
                  <span onClick={toggleReadMore} className='read-or-hide'>
                    <i>
                      <u>{`${isReadMore ? 'Show less' : '...Read more'}`}</u>
                    </i>
                  </span>
                </p>
              )}
            </div>
          </div>

          {!batchEdit && sponsoredProvidersCount.total > 0 ? (
            scrolled ? (
              <div className='scrolled-header'>
                <div className={`highlight-section ${isReadMore && 'read-more'}`}>
                  <div className='highlight-section-inner bottom-border-radius'>
                    <Header
                      sponsoredProvidersCount={sponsoredProvidersCount}
                      sponsorTypeChangeHandler={sponsorTypeChangeHandler}
                      sponsorTypeHandler={sponsorTypeHandler}
                      sponsorInformation={sponsorInformation}
                      numOfChildElements={numOfChildElements}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className='fixed-header'>
                <div className={`highlight-section ${isReadMore && 'read-more'}`}>
                  <div className='highlight-section-inner'>
                    <Header
                      sponsoredProvidersCount={sponsoredProvidersCount}
                      sponsorTypeChangeHandler={sponsorTypeChangeHandler}
                      sponsorTypeHandler={sponsorTypeHandler}
                      sponsorInformation={sponsorInformation}
                      numOfChildElements={numOfChildElements}
                    />
                  </div>
                </div>
              </div>
            )
          ) : (
            !batchEdit && generateHeaderSectionForEmptyProviders()
          )}
          <svg
            className={`rosterviewbanner-background-svg ${
              batchEdit && isReadMore ? 'add-margin' : ' '
            }`}
            data-qa-target='rosterviewbanner-background-svg'
            preserveAspectRatio='none'
            viewBox='0 0 1442 149'>
            <path
              d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
              fill='white'></path>
          </svg>

          <svg
            className='rosterviewbanner-background-svg-mobile'
            data-qa-target='rosterviewbanner-background-svg-mobile'
            preserveAspectRatio='none'
            viewBox='0 0 375 120'>
            <path
              d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
              fill='#FFFFFF'></path>
          </svg>
        </div>
      </div>
    </Fragment>
  );
};

Banner.propTypes = {
  providerDisplayName: PropTypes.string,
  profileOverviewPeriod: PropTypes.string,
  sponsorTypeHandler: PropTypes.func,
  sponsorInformationHandler: PropTypes.func,
  isReloadBanner: PropTypes.bool,
  batchEdit: PropTypes.bool,
  sponsorProvidersHandler: PropTypes.func,
  openModal_Acc: PropTypes.func,
  onDeleteModalTab: PropTypes.func,
  onDuplicateAssignModalTab: PropTypes.func,
  isUserAdmin: PropTypes.bool,
  currentRole: PropTypes.string
};
Banner.defaultProps = {
  currentAccountDetails: {},
  isUserAdmin: false
};

export default Banner;
