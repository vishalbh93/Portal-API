import React, { Fragment, useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
import Modal from 'react-modal';
import './_clientSetting.less';
import close from '../../../assets/images/ProviderProfile/svg-cross.svg';
import AutoComplete from '../../FormComponents/AutoComplete/AutoComplete';
import ValidationErrorMessage from '../../FormComponents/ValidationErrorMessage';
import isEmpty from '../../../utils/validation/isEmpty';
import * as actions from '../../../store/actions';
import Spinner from '../../Spinner/Spinner';
import { rosterPage } from '../../../components/Practice/Utils/Helpers';
import { CLIENTPORTAL_PAGE, ROSTER_PAGE } from '../../../components/Practice/Utils/Constants';
import * as _pService from '../../../utils/serviceCalls/clientPortal';
import _ from 'lodash';

const ClientSettingModal = (props) => {
  const {
    showModalClint,
    closeModalAcc,
    clientDataCode,
    profileData,
    handleAccountInfo,
    sponsorInformation
  } = props;
  /* #region declarations */
  const isEmptyField = { isValid: false, error: 'This field is required' };
  const dispatch = useDispatch();
  const [displaySpinner, setDisplaySpinner] = useState(false);
  const [dataChange, updateDataChange] = useState(0);
  const clientsTextBoxData = {
    id: 'clientData',
    name: 'clientData',
    placeholder: 'Client Code'
  };
  const [suggestData, setSuggestData] = useState(Object);
  const [suggestValue, setSuggestValue] = useState('');
  const [selectedClientData, setSelectedClientData] = useState({
    clientCode: '',
    clientName: ''
  });
  const [isClientCodeValid, setClientCodeValidation] = useState({
    isValid: true,
    error: null
  });
  const [isThresholdValid, setIsThresholdValid] = useState({
    isValid: false,
    error: null
  });
  const [isMinimumCountValid, setIsMinimumCountValid] = useState({
    isValid: false,
    error: null
  });
  const [isMaximumCountValid, setIsMaximumCountValid] = useState({
    isValid: false,
    error: null
  });
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);
  const [account, setAccount] = useState({
    firstName: profileData.firstName,
    lastName: profileData.lastName,
    email: profileData.email,
    password: '',
    cnfpassword: '',
    adminRole: profileData.currentRole,
    clientCode: profileData.clientCode,
    clientName: '',
    clientCodes: profileData.clientCodes,
    userId: profileData.userId,
    pMinimum: 0,
    pMaximum: 0,
    isAllowMultipleFacility: profileData.isAllowMultipleFacility
  });
  const [multifacilityFlag, setMultiFacilityFlag] = useState(account.isAllowMultipleFacility);
  const showCheckbox = _.isEmpty(sponsorInformation)
    ? false
    : sponsorInformation.isFacility &&
      (sponsorInformation.sponsorType == 'PDCHSP' || sponsorInformation.sponsorType == 'MAP');
  /* #endregion */

  const getSuggestValue = () => {
    if (account != null && account != undefined) {
      if (account.clientCode != '') {
        let cc = account.clientCodes.map((i) => {
          if (i.ClientToProductCode === account.clientCode) {
            setSuggestData({
              clientCode: i.ClientCode,
              clientName: i.ClientName,
              clientToProductCode: i.ClientToProductCode
            });
            setSuggestValue(i.ClientName + ' : ' + i.ClientToProductCode);
          } else {
            return;
          }
        });
      } else {
        setSuggestData('');
      }
    }
  };

  const validateInput = () => {
    if (isEmpty(account.clientCode)) {
      setClientCodeValidation(isEmptyField);
    } else {
      setClientCodeValidation({
        isValid: true,
        error: ''
      });
    }
    if (_.isNumber(account.pMinimum) && _.isNumber(account.pMaximum)) {
      if (account.pMinimum == 0 || account.pMinimum == '') {
        setIsMinimumCountValid({
          isValid: true,
          error: 'Minimum provider should not be 0'
        });
      }
      if (account.pMaximum == 0 || account.pMinimum == '') {
        setIsMaximumCountValid({
          isValid: true,
          error: 'Maximum provider should not be 0'
        });
      } else if (Number(account.pMaximum) <= Number(account.pMinimum)) {
        setIsThresholdValid({
          isValid: true,
          error: 'Maximum provider should be greater than Minimum provider'
        });

        setIsMaximumCountValid({
          isValid: false,
          error: null
        });
      }
    } else {
      if (_.isNaN(_.toNumber(account.pMinimum))) {
        setIsMinimumCountValid({
          isValid: true,
          error: 'Minimum provider count is invalid'
        });
      }
      if (_.isNaN(_.toNumber(account.pMaximum))) {
        setIsMaximumCountValid({
          isValid: true,
          error: 'Maximum provider count is invalid'
        });
      }
    }
  };

  const updateValidationSetToTrue = () => {
    setClientCodeValidation({ isValid: true, error: null });
  };

  const changeHandler = (e) => {
    updateDataChange(dataChange + 1);
    switch (e.target.id) {
      case 'clientCode':
        var clientData = clientDataCode.filter((x) => x.clientCode == e.target.value);
        if (clientData.length > 0) {
          setAccount({
            ...account,
            pMinimum:
              clientData[0].minProviderCount != undefined && clientData[0].minProviderCount != null
                ? clientData[0].minProviderCount
                : 0,
            pMaximum:
              clientData[0].maxProviderCount != undefined && clientData[0].maxProviderCount != null
                ? clientData[0].maxProviderCount
                : 0,
            clientCode: e.target.value
          });
          setIsThresholdValid({
            isValid: false,
            error: null
          });
        } else {
          setAccount({
            ...account,
            pMinimum: 0,
            pMaximum: 0,
            clientCode: e.target.value
          });
          setIsThresholdValid({
            isValid: true,
            error: 'Maximum provider should be greater than Minimum provider'
          });
        }
        setClientCodeValidation({
          isValid: e.target.value != '-' || e.target.value != undefined ? true : false,
          error: 'Please Select Any of client Codes'
        });
        break;

      case 'minimum':
        if (e.target.value < 0) {
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider count is invalid'
          });
        } else {
          setAccount({ ...account, pMinimum: e.target.value });
          if (_.isNaN(_.toNumber(e.target.value))) {
            setIsMinimumCountValid({
              isValid: true,
              error: 'Minimum provider count is invalid'
            });
          } else if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMinimumCountValid({
              isValid: true,
              error: 'Minimum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          } else if (Number(e.target.value) >= account.pMaximum) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
          } else {
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          }
        }
        break;

      case 'maximum':
        if (e.target.value < 0) {
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider count is invalid'
          });
        } else {
          setAccount({ ...account, pMaximum: e.target.value });
          if (_.isNaN(_.toNumber(e.target.value))) {
            setIsMaximumCountValid({
              isValid: true,
              error: 'Maximum provider count is invalid'
            });
          } else if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMaximumCountValid({
              isValid: true,
              error: 'Maximum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          } else if (account.pMinimum >= Number(e.target.value)) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
          } else {
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          }
        }
        break;
    }
  };

  const onUpdateHandler = (e) => {
    e.preventDefault();
    validateInput();
    if (!isRosterInValid()) {
      if (account.adminRole !== 'Client_Admin') {
        setAccount({ ...account, clientCode: '', clientName: '' });
      }
      setDisplaySpinner(true);
      let currPage = rosterPage != ROSTER_PAGE ? CLIENTPORTAL_PAGE : ROSTER_PAGE;
      dispatch(actions.updateAccountSettings(account, setDisplaySpinner, closeModalAcc, currPage));
      handleAccountInfo(
        account.clientCode,
        profileData.currentRole,
        account.isAllowMultipleFacility
      );
      updateValidationSetToFalse();
      setIsMinimumCountValid({
        isValid: false,
        error: null
      });
      setIsMaximumCountValid({
        isValid: false,
        error: null
      });
    } else {
    }
  };

  const searchClientCodeChange = (e) => {
    setSuggestValue(e.target.value);
    if (e.currentTarget.value.length <= 1) {
      setAccount({ ...account, clientCode: '' });
      setClientCodeValidation(isEmptyField);
      return;
    }
    let filteredClients = account.clientCodes.filter(function (v) {
      if (
        v.ClientName.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1 ||
        v.ClientCode.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1
      ) {
        return v;
      }
    });
    let clientsData = filteredClients.slice(0, 5);
    setSuggestData(clientsData);
    return clientsData;
  };

  const onSelectedItem = (data) => {
    if (!_.isEmpty(data)) {
      setSelectedClientData({
        ...selectedClientData,
        clientCode: data[0].values,
        clientName: data[0].text
      });
      var clientData = clientDataCode.filter((x) => x.clientCode == data[0].values);
      if (clientData.length > 0) {
        let tempAccountObj = {
          ...account,
          pMinimum: !_.isEmpty(clientData[0]) ? clientData[0].minProviderCount : 0,
          pMaximum: !_.isEmpty(clientData[0]) ? clientData[0].maxProviderCount : 0,
          clientCode: data[0].values
        };
        if (clientData[0].minProviderCount == 0 || clientData[0].minProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider should not be 0'
          });
        }
        if (clientData[0].maxProviderCount == 0 || clientData[0].maxProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider should not be 0'
          });
        } else {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
        }
        setAccount({ ...tempAccountObj });
      } else {
        setAccount({
          ...account,
          pMinimum: 0,
          pMaximum: 0
        });
      }
      setSuggestValue(data[0].text);
      if (isEmpty(data[0].values)) {
        setClientCodeValidation(isEmptyField);
      } else {
        setClientCodeValidation({
          isValid: true,
          error: ''
        });
      }
    }
  };

  const closeHandler = () => {
    setAccount({
      ...account,
      adminRole: profileData.currentRole,
      clientCode: profileData.clientCode
    });
    getSuggestValue();
    updateValidationSetToFalse();
    updateDataChange(dataChange + 1);
    if (account.pMinimum != 0 && account.pMaximum != 0) {
      setIsThresholdValid({ isValid: false, error: null });
    }
    setIsMinimumCountValid({
      isValid: false,
      error: null
    });
    setIsMaximumCountValid({
      isValid: false,
      error: null
    });
    closeModalAcc();
    setMultiFacilityFlag(profileData.isAllowMultipleFacility);
  };

  const isRosterInValid = () => {
    let validateStatus =
      (profileData.adminRole === 'Client_Admin' && isEmpty(account.clientCode)) ||
      (profileData.adminRole === 'Client_Admin' && account.pMinimum >= account.pMaximum) ||
      _.isNaN(_.toNumber(account.pMinimum)) ||
      _.isNaN(_.toNumber(account.pMaximum)) ||
      account.pMaximum == '' ||
      account.pMinimum == '' ||
      account.pMinimum == 0 ||
      account.pMaximum == 0
        ? true
        : false;
    return validateStatus;
  };

  const updateValidationSetToFalse = () => {
    setClientCodeValidation({ isValid: false, error: '' });
    setIsThresholdValid({ isValid: false, error: '' });
  };

  useEffect(() => {
    setAccount({ ...account });
    setClientCodeValidation({
      isValid: true,
      error: ''
    });
  }, [account.adminRole]);

  useEffect(() => {
    Modal.setAppElement('body');
  });

  useEffect(() => {
    if (!_.isEmpty(clientDataCode)) {
      var clientData = clientDataCode.filter((x) => x.clientCode == account.clientCode);
      if (clientData.length > 0) {
        setAccount({
          ...account,
          pMinimum:
            clientData[0].minProviderCount != undefined && clientData[0].minProviderCount != null
              ? clientData[0].minProviderCount
              : 0,
          pMaximum:
            clientData[0].maxProviderCount != undefined && clientData[0].maxProviderCount != null
              ? clientData[0].maxProviderCount
              : 0,
          clientCode: profileData.clientCode,
          isAllowMultipleFacility: clientData[0].isAllowMultipleFacility
        });
      } else {
        setAccount({
          ...account,
          pMinimum: 0,
          pMaximum: 0,
          clientCode: profileData.clientCode
        });
        if (account.pMaximum == 0 || account.pMinimum == 0) {
          setIsThresholdValid({
            isValid: true,
            error: 'Maximum provider should be greater than Minimum provider'
          });
        }
      }
    }
  }, [clientDataCode]);

  useEffect(() => {
    getSuggestValue();
  }, [profileData, dataChange]);

  useEffect(() => {
    if (selectedClientData != null && selectedClientData != undefined) {
      if (selectedClientData.clientCode != '' && selectedClientData.clientName != '') {
        let cliName = selectedClientData.clientName.split(':');
        setAccount({
          ...account,
          clientCode: selectedClientData.clientCode,
          clientName: cliName[0]
        });
      }
    }
  }, [selectedClientData]);

  useEffect(() => {
    getSuggestValue();
  }, [showModalClint]);

  useEffect(() => {
    if (dataChange > 0) {
      if (account.clientCode != '' && account.clientCode != 'Client Code') {
        updateValidationSetToTrue();
      }
    }
  }, [dataChange]);

  useEffect(() => {
    setMultiFacilityFlag(account.isAllowMultipleFacility);
  }, [account.isAllowMultipleFacility]);

  useEffect(() => {
    if (
      !isMinimumCountValid.isValid &&
      !isMaximumCountValid.isValid &&
      !isThresholdValid.isValid 
    ) {
      setIsButtonDisabled(false);
    } else {
      setIsButtonDisabled(true);
    }
  }, [
    isClientCodeValid,
    isMinimumCountValid,
    isMaximumCountValid,
    isThresholdValid
  ]);

  useEffect(()=>
  {
    setIsButtonDisabled(true);
  },[showModalClint])
  return (
    <Fragment>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog'
        ariaHideApp={true}
        isOpen={showModalClint}
        contentLabel='Account Setting'
        onRequestClose={closeHandler}
        shouldCloseOnEsc={false}
        shouldCloseOnOverlayClick={false}>
        <div className={'manage-account'}>
          <div className='roster-modal'>
            <div className='close-modal'>
              <img className='close-icon' src={close} alt='close' onClick={closeHandler} />
            </div>
            <form id='rosterForm' autoComplete='off'>
              <div className='roster-modal-container'>
                <div className='client-modal-header'>
                  <h1>Client Settings</h1>
                </div>

                <div className='roster-modal-content'>
                  <div className='input-block'>
                    <div className='client-code'>
                      <p>
                        <label>Client Code</label>
                        <AutoComplete
                          textBoxData={clientsTextBoxData}
                          suggestData={suggestData}
                          searchValue={suggestValue}
                          onChangeHandler={searchClientCodeChange}
                          searchType='clientData'
                          onSelectedItem={onSelectedItem}
                        />
                        {!isClientCodeValid.isValid && (
                          <ValidationErrorMessage message={isClientCodeValid.error} />
                        )}
                      </p>
                    </div>
                    {account.clientCode !== '' && !isEmpty(suggestValue) && (
                      <div className='provider-threshold'>
                        <div className='min-max-provider'>
                          <label className='text-provider-mincount'>Minimum Provider</label>
                          <input
                            className='input'
                            id='minimum'
                            type='number'
                            min={0}
                            value={account.pMinimum}
                            onChange={changeHandler}
                          />
                          {isMinimumCountValid.isValid && (
                            <div className='min-max-provider-validation'>
                              <ValidationErrorMessage message={isMinimumCountValid.error} />
                            </div>
                          )}
                        </div>
                        <div className='min-max-provider'>
                          <label className='text-provider-maxcount'>Maximum Provider</label>
                          <input
                            className='input'
                            id='maximum'
                            type='number'
                            min={0}
                            value={account.pMaximum}
                            onChange={changeHandler}
                          />
                          {isMaximumCountValid.isValid && (
                            <div className='min-max-provider-validation'>
                              <ValidationErrorMessage message={isMaximumCountValid.error} />
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    {isThresholdValid.isValid && (
                      <div className='validation-message'>
                        <ValidationErrorMessage message={isThresholdValid.error} />
                      </div>
                    )}

                    {!_.isEmpty(account.adminRole) &&
                      account.adminRole.toLowerCase() === 'client_admin' &&
                      showCheckbox && (
                        <div className='user-verification multi-facility-checkbox'>
                          <div
                            className={`checkbox ${
                              profileData.isAllowMultipleFacility ? 'disable-checkbox' : ''
                            }`}>
                            <input
                              id='allowMultiFacilityChk'
                              type='checkbox'
                              onClick={(e) => {
                                setAccount({
                                  ...account,
                                  isAllowMultipleFacility: e.currentTarget.checked
                                });
                              }}
                              onKeyDown={(e) => handleKeyPress(e)}
                              checked={multifacilityFlag}
                              disabled={profileData.isAllowMultipleFacility}></input>
                            <label htmlFor='allowMultiFacilityChk'></label>
                          </div>
                          <div className='text' id='allowMultiFacilityChk'>
                            <span className='multifacility-text'>
                              Allow approved clients the ability to designate a provider to more
                              than one facility, making them an HGPro approved member.
                            </span>
                          </div>
                        </div>
                      )}
                  </div>
                </div>

                <div className='footer-seperator'></div>
                <div className='client-modal-footer'>
                  <button onClick={closeHandler} className='cancel-btn'>
                    Cancel
                  </button>
                  <button onClick={onUpdateHandler} disabled={isButtonDisabled} className={isButtonDisabled ?'button-disabled client-settings' : 'add-btn'}>
                    Update
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </ReactModal>
      {displaySpinner && <Spinner cta={true} />}
    </Fragment>
  );
};
ClientSettingModal.propTypes = {
  showModalAcc: PropTypes.bool,
  closeModalAcc: PropTypes.func,
  profileInfo: PropTypes.object,
  toggleModalAcc: PropTypes.func,
  showSpinnerModel: PropTypes.func,
  handleAccountInfo: PropTypes.func
};
ClientSettingModal.defaultProps = {
  handleAccountInfo: () => {}
};
export default ClientSettingModal;
