import React, { Fragment, useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import './_clientPortalDashboard.less';
import '@hg/joy/src/globalstyles';
import PropTypes from 'prop-types';
import Banner from '../Banner/Banner';
import Providers from '../RosterViewProviderList/Providers'; 
import MenuComponent from '../../Common/Menu/Menu';
import Footer from '../../Common/Footer/Footer';
import DesignationManagement from '../BatchEdit/DesignationManagement/DesignationManagement';
import * as service from '../../../utils/service'

//helper
import _ from 'lodash';

const ClientPortalDashboard = (props) => {
  const [currentSponsorType, setCurrentSponsorType] = useState('ALL');
  const [sponsorInformation, setSponsorInformation] = useState({});
  const { accountInfo } = useSelector((state) => state.getAccountDetailsReducer);

  const [batchEdit, setbatchEdit] = useState(false);
  const [batchEditOption, setBatchEditOption] = useState('');
  const [selectedArray, setSelectedArray] = useState([]);
  const [providerDisplayName, setProviderDisplayName]= useState(`${accountInfo.firstName}  ${accountInfo.lastName}`);
  const [providers, setProviders] = useState({});
  const [reload, setReload] = useState(false);
  const [sProviderCount, setSProviderCount] = useState({});

  const [manageAccSettingTab, setManageAccSettingTab] = useState (false);
  const [manageDeleteAccTab, setManageDeleteAccTab] = useState (false);
  const [manageDuplicateRosterProTab, setManageDuplicateRosterProTab] = useState (false);
  const [manageClientSettingsTab, setManageClientSettingsTab] = useState (false);

  const isUserAdmin = accountInfo ? accountInfo.navigationModel.UserIsAdmin : false;
  const currentRole = accountInfo? accountInfo.currentRole : '';
  const [userDetails, setUserDetails] = useState(); 

  const sponsorTypeHandler = (sponsorType) => {
    setCurrentSponsorType(sponsorType);
  };

  const sponsorInformationHandler = (sponsorInformation) => {
    setSponsorInformation(sponsorInformation);
  };

  const sponsorProvidersHandler = (sponsorProviders) => {
    setSProviderCount(sponsorProviders);
  };

  const providersHandler = (providers) => {
    setProviders(providers);
  };
  const [reloadBanner, setReloadBanner] = useState(false);

  const loadBanner = (e) => {
    if (e == true) setReloadBanner(true);
    else setReloadBanner(false);
    setTimeout(() => {
      setReloadBanner(false);
    }, 1000);
  };

  const batchEditOptionHandler = (type, selectedProviders) => {
    if ((type != null || type != undefined) && type == 'designation') {
      setSelectedArray(selectedProviders);
      setBatchEditOption(type);
      setbatchEdit(true);
    } else {
      let pwids = Object.keys(selectedProviders).join(',');
      let form = document.createElement('form');
      form.setAttribute('method', 'post');
      form.setAttribute('action', '/batch');

      let hiddenFieldEditType = document.createElement('input');
      hiddenFieldEditType.setAttribute('type', 'hidden');
      hiddenFieldEditType.setAttribute('name', 'BatchEditType');
      hiddenFieldEditType.setAttribute('value', type.toLocaleLowerCase());
      form.appendChild(hiddenFieldEditType);

      let hiddenFieldPwids = document.createElement('input');
      hiddenFieldPwids.setAttribute('type', 'hidden');
      hiddenFieldPwids.setAttribute('name', 'Pwids');
      hiddenFieldPwids.setAttribute('value', pwids);
      form.appendChild(hiddenFieldPwids);

      let hiddenFieldUserId = document.createElement('input');
      hiddenFieldUserId.setAttribute('type', 'hidden');
      hiddenFieldUserId.setAttribute('name', 'UserId');
      hiddenFieldUserId.setAttribute('value', accountInfo.userId);
      form.appendChild(hiddenFieldUserId);

      document.body.appendChild(form);
      form.submit();
    }
  };

  const reloadList = (reloaded) => {
    setReload(reloaded);
  };

  const providerCount = (val) => {
    setSProviderCount(val);
  };

  useEffect(() => {
    // batchEditOptionHandler('designation',Object.keys(selectedArray));
    setReload(reload);
  }, [reload]);

  const menuClick = (section) => {
    setCurrentTab(section);
  };

  const openModal_Acc=(value)=>{
    setManageAccSettingTab(value); 
  }
  const onDeleteModalTab=(value)=>{
    setManageDeleteAccTab(value); 
  }
  
  const onDuplicateAssignModalTab=(value)=>{
    setManageDuplicateRosterProTab(value);
  }

  const onClientSettingsTab=(value)=>{
    setManageClientSettingsTab(value); 
  }

  const manageTab =()=>{
    setManageAccSettingTab(false); 
    setManageDeleteAccTab(false);
    setManageDuplicateRosterProTab(false);
    setManageClientSettingsTab(false);
  }
  let menuItems = accountInfo.navigations;
  let navigationModelObject = accountInfo.navigationModel;

  const fetchUserDetails = () => {
    const userId = accountInfo.userId;
    if(accountInfo.isImpersonate!==undefined && accountInfo.isImpersonate){
    service.get(`/api/admin/user-details?userId=${userId}`).then((res) => {
      if (res != undefined) {
        setUserDetails(res);             
      }
    });
   }
  };
  useEffect(() => {
    if(!_.isEmpty(accountInfo.isImpersonate) && accountInfo.isImpersonate){   
    fetchUserDetails();
    }
  }, []);

  useEffect(()=>{
    if(!_.isEmpty(userDetails)){
      setProviderDisplayName(`${userDetails.FirstName} ${userDetails.LastName}`);   
    }
  },[userDetails])
  return (
    <Fragment>
      <MenuComponent
        menuClick={menuClick}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        showMenus={true}
      />
      <Banner
        providerDisplayName={providerDisplayName}
        clientCode={accountInfo.clientCode}
        userId={accountInfo.userId}
        sponsorTypeHandler={sponsorTypeHandler}
        sponsorInformationHandler={sponsorInformationHandler}
        isReloadBanner={reloadBanner}
        batchEdit={batchEdit}
        sponsorProvidersHandler={sponsorProvidersHandler}
        openModal_Acc ={openModal_Acc}
        onDeleteModal_Acc ={onDeleteModalTab}
        onDuplicateAssign_Modal = {onDuplicateAssignModalTab}
        onClientSettings_Tab = {onClientSettingsTab}
        isUserAdmin ={isUserAdmin}
        currentRole ={currentRole}      
      />
      {!batchEdit ? (
        <Providers
          accountInfo={accountInfo}
          currentSponsorType={currentSponsorType}
          sponsorInformation={sponsorInformation}
          reloadBanner={(e) => loadBanner(e)}
          batchEditOptionHandler={batchEditOptionHandler}
          selectedArrayHandler={setSelectedArray}
          providersHandler={providersHandler}
          sProviderCount={sProviderCount}
          currentAccountDetails={{ userId: accountInfo.userId, clientCode: accountInfo.clientCode }}
          manageTab={manageTab}
          manageAccSettingTab ={manageAccSettingTab}
          manageDeleteAccTab ={manageDeleteAccTab}
          manageDuplicateRosterProTab = {manageDuplicateRosterProTab} 
          manageClientSettingsTab={manageClientSettingsTab}
        />
      ) : (
        batchEditOption === 'designation' && (
          <>
            {/* Old implemetation (Phase I)- Can be removed once implemetation is done for testing */}
            {/* <Designation
              providerDisplayName={providerDisplayName}
              selectedProviders={selectedArray}
              providersFound={Object.keys(selectedArray).length}
              accountInfo={accountInfo}
              providersInfo={providers}
              reloadList={reloadList}
              sponsorInformation={sponsorInformation}
              currentPage={!accountInfo.isImpersonate ? true : false}
            /> */}

            {/* New implemetation (Phase II)*/}
            <DesignationManagement
              providerDisplayName={providerDisplayName}
              selectedProviders={selectedArray}
              providersFound={Object.keys(selectedArray).length}
              accountInfo={accountInfo}
              providersInfo={providers}
              reloadList={reloadList}
              sponsorInformation={sponsorInformation}
              currentPage={!accountInfo.isImpersonate ? true : false}
            />
          </>
        )
      )}
      <Footer />
    </Fragment>
  );
};

ClientPortalDashboard.propTypes = {
  providerDisplayName: PropTypes.string,
  profileOverviewPeriod: PropTypes.string,
  providers: PropTypes.arrayOf(PropTypes.object),
  providersFound: PropTypes.number,
  profileInfo: PropTypes.object
};

export default ClientPortalDashboard;
