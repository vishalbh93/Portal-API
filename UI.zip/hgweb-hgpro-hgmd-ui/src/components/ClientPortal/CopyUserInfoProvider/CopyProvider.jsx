import React, { Fragment, useState, useEffect, useRef } from 'react';
import ReactModal from 'react-modal';
import PropTypes from 'prop-types';
import Toast from '../../Common/Toast/Toast';
import cross from '../../../../public/images/cross.png';
import * as service from '../../../utils/service';
import './_copyProvider.less';
import Spinner from '../../Spinner/Spinner';
import { TextBox } from '../../FormComponents/TextBox';

const CopyProvider = (props) => {
  const {
    showModalCopyProvider,
    closeModalCopyRosterPro,
    _accountInfo,
    isClientPageFlag,
    clientDataCode
  } = props;
  const [selectedRosterManagerArray, setSelectedRosterManagerArray] = useState([]);
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const [card, setCard] = useState(false);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [userToken, setUserToken] = useState('');
  const [validationMessage, setValidationMessage] = useState('');
  const [destinationUserType, setDestinationUserType] = useState('');
  const [destinationClientCode, setdestinationClientCode] = useState('');
  const [inputValue, setinputValue] = useState('');
  const textBoxClasses = 'search_input_box input-field width-100';
  const [isError, setIsError] = useState(false);
  const [isClearData, setIsClearData] = useState(false);
  const [userDetails, setUserDetails] = useState();
  const [isButtonClicked, setIsButtonClicked] = useState(false);

  const baseurl = `/api/admin`;

  const sourceUserId = props.isClientPageFlag
    ? _accountInfo.accountInfo.userId
    : _accountInfo.accountData.userId;
  const sourceEmail = props.isClientPageFlag
    ? _accountInfo.accountInfo.email
    : _accountInfo.accountData.email;
  const rosterName = props.isClientPageFlag
    ? _accountInfo.accountInfo.firstName + ' ' + _accountInfo.accountInfo.lastName
    : _accountInfo.accountData.firstName + ' ' + _accountInfo.accountData.lastName;
  const numberofProviders = props.isClientPageFlag
    ? _accountInfo.accountInfo.navigationModel.ProviderCount
    : JSON.parse(_accountInfo.rosterInfo.ProviderListJson)['NumberOfProviders'];

  const checkValidation = (value) => {
    let regex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
    if (sourceEmail == value) {
      setIsError(true);
      setValidationMessage('The providers can not assign to same user');
    } else if (!_.isEmpty(value) && value.match(regex)) return true;
    else {
      setIsError(true);
      setValidationMessage('Enter valid email address !');
      return false;
    }
  };

  const setSearchValue = (e) => {
    setValidationMessage('');
    setCard(false);
    setButtonDisabled(true);
    let val = e.target.value.replace(/\s/g, '');
    setIsError(false);
    if (val != inputValue) {
      setIsClearData(false);
    }
    setinputValue(e.target.value.replace(/\s/g, ''));
  };

  const onKeyPressed = (e) => {
    let code = e.keyCode || e.which;
    if (code === 13) {
      fetchRosterManagerData(inputValue);
    }
  };

  const clearText = (e) => {
    e.preventDefault();
    setinputValue('');
    setIsClearData(false);
    setIsError(false);
    setValidationMessage('');
  };

  const onRosterSelectHandler = (rosterValue) => {
    let tempArr = [rosterValue, ...selectedRosterManagerArray];
    setSelectedRosterManagerArray(tempArr);
    setCard(true);
    setUserToken(rosterValue.UserInfoToken);
    setButtonDisabled(false);
    if (rosterValue.UserRole.includes('Client')) {
      setButtonDisabled(true);
    }
  };

  const selectRosterManager = (rosterData) => {
    let rosterUser = rosterData.filter((roster) => roster.Email == inputValue);
    if (rosterUser && rosterUser.length > 0) {
      setDestinationUserType(rosterUser[0].UserRole);
      setdestinationClientCode(rosterUser[0].ClientCode);
      onRosterSelectHandler(rosterUser[0]);
    } else {
      setIsError(true);
      setValidationMessage('Email address not found');
    }
  };

  const closeModalHandler = (item) => {
    closeModalCopyRosterPro();
    setValidationMessage('');
    setSelectedRosterManagerArray(
      selectedRosterManagerArray.filter((a) => {
        return false;
      })
    );
    setCard(false);
    setButtonDisabled(true);
    setinputValue('');
  };

  const fetchRosterManagerData = (searchInfo) => {
    let searchInfoValue = searchInfo.replace(/\s/g, '');
    if (checkValidation(searchInfoValue)) {
      let searchModel = {
        searchType: 'email',
        searchValue: searchInfoValue,
        page: 1,
        sortOrder: 'asc',
        sortBy: 'name'
      };
      var url = `${baseurl}/searchrosteruser?searchType=email&searchValue=${searchInfoValue}&page=1&sortOrder=asc&sortBy=name`;
      setSpinnerVisibility(true);
      service
        .get(url, searchModel)
        .then((res) => {
          if (!_.isEmpty(res) && !_.isEmpty(res.Results) && res.Results.length > 0) {
            let data = res.Results.filter(
              (roster) => roster.UserRole.includes('Client') || roster.UserRole.includes('Roster')
            );
            if (data && data.length > 0) {
              let _tempRosterManagerData = data.map((rosterManager) => ({
                Id: rosterManager.Id,
                UserInfoToken: rosterManager.UserInfoToken,
                ClientCode: rosterManager.ClientCode,
                FullName: rosterManager.FullName,
                IsActive: rosterManager.IsActive,
                IsAuthorized: rosterManager.IsAuthorized,
                Text: `${rosterManager.FirstName} ${rosterManager.LastName}<br/>${rosterManager.Email}`,
                Email: rosterManager.Email,
                Disabled: false,
                UserRole: rosterManager.UserRole,
                ProviderCount: rosterManager.ProviderCount,
                IsThirdParty: rosterManager.IsThirdParty
              }));
              selectRosterManager(_tempRosterManagerData);
              setSpinnerVisibility(false);
              setUserDetails(_tempRosterManagerData);
            } else {
              setIsError(true);
              setValidationMessage('Please enter email address of Roster Manager');
            }
          } else {
            setIsError(true);
            setValidationMessage('Email address not found');
          }
          setSpinnerVisibility(false);
        })
        .catch((err) => {
          setSpinnerVisibility(false);
          toaster.Error(err.error);
        });
    }
  };

  const assignRosterProviders = (value) => {
    let isActive =
      userDetails != undefined &&
      userDetails.every((roster) => roster.IsActive && !roster.IsThirdParty);
    if (isActive != undefined && isActive) {
      let destionationUserId = selectedRosterManagerArray[0].Id;
      let assignModel = {
        destionationUserId: destionationUserId,
        sourceUserId: sourceUserId,
        destinationUserType: destinationUserType,
        destinationClientCode: destinationClientCode
      };
      let url = `${baseurl}/copyrosterproviders?destionationUserId=${destionationUserId}&sourceUserId=${sourceUserId}&destinationUserType=${destinationUserType}&destinationClientCode=${destinationClientCode}`;
      setSpinnerVisibility(true);
      service
        .post(url, assignModel)
        .then((res) => {
          if (res) {
            setCard(false);
            setButtonDisabled(false);
            setValidationMessage('');
            toaster.Success(res.ErrorMessage);
            setSpinnerVisibility(false);
            setIsButtonClicked(true);
          }
          window.location.href = isClientPageFlag
            ? `/clientportal/RosterProfile?userToken=${userToken}`
            : `/roster/RosterProfile?userToken=${userToken}`;
        })
        .catch((err) => {
          setSpinnerVisibility(false);
          setCard(false);
          setButtonDisabled(false);
          toaster.Error(err.error);
        });
    } else {
      setIsError(true);
      setValidationMessage(
        'Sorry! Cannot duplicate and assign the roster. The selected roster is either inactive or third-party.'
      );
      setButtonDisabled(true);
    }
  };

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  useEffect(() => {
    props.handlePopUp();
  }, [isButtonClicked]);

  return (
    <Fragment>
      {showModalCopyProvider && (
        <ReactModal
          overlayClassName='roster-modal-overlay'
          className='modal-dialog-add-copy-provider'
          ariaHideApp={true}
          isOpen={showModalCopyProvider}
          contentLabel='Create Roster User'
          onRequestClose={() => closeModalHandler(false)}
          shouldCloseOnEsc={false}
          shouldCloseOnOverlayClick={false}>
          <Fragment>
            <div className='close'>
              <img
                className='close-icon'
                src={cross}
                alt='close'
                onClick={() => closeModalHandler(false)}
              />
            </div>
            <div className='copy-providers-container'>
              <div className='heading-1'>
                <div className='duplicate-assign-text'>Duplicate and Assign</div>
              </div>
              <div className='horizontal-line'>
                <span className='line-icon'></span>
              </div>
              <div className='description-text'>
                <span>Use the Search to Find the Roaster Manager to copy all </span>
                <span className='description-text-bold'>
                  {`${numberofProviders} ${rosterName} Providers.`}{' '}
                </span>
              </div>
              <div className='search-roster-container'>
                <div className='search-heading'>Search Roster Managers</div>
                <div className='search-bar'>
                  <TextBox
                    placeholder='e.g.janedoe@gmail.com'
                    textValue={inputValue}
                    onChangeHandler={setSearchValue}
                    onKeyPressed={onKeyPressed}
                    classes={textBoxClasses}
                  />
                  {
                    <span className='search-icon-npi-model'>
                      <i
                        className={`${isClearData ? 'icon-close' : 'icon-model'}`}
                        onClick={(e) =>
                          isClearData ? clearText(e) : fetchRosterManagerData(inputValue)
                        }></i>
                    </span>
                  }
                </div>
                {isError && (
                  <div className='div-error-msg'>
                    <span className='alrt-msg'>{validationMessage}</span>
                  </div>
                )}
              </div>
            </div>
            {card && selectedRosterManagerArray && (
              <div className='copy-providers-card'>
                <div className='copy-providers-instruction'>
                  Assign {numberofProviders} providers to :
                </div>
                <div className='copy-providers-card-inner'>
                  <div className='roster-name'> {selectedRosterManagerArray[0].FullName} </div>
                  <div className='horizontal-line'>
                    {' '}
                    <span className='line-icon'></span>
                  </div>
                  <div className='card-description'>
                    <div>
                      <span className='descrip-title'>Email :</span>
                      <span className='descrip-text'>{selectedRosterManagerArray[0].Email}</span>
                    </div>
                    <div>
                      <span className='descrip-title'>User Type :</span>
                      <span className='descrip-text'>{selectedRosterManagerArray[0].UserRole}</span>
                    </div>
                    <div>
                      <span className='descrip-title'>Providers on Roster :</span>
                      <span className='descrip-text'>
                        {selectedRosterManagerArray[0].ProviderCount}
                      </span>
                    </div>
                    <div>
                      <span className='descrip-title'>Autorization Status :</span>
                      <span className='descrip-text'>
                        {selectedRosterManagerArray[0].IsAuthorized ? `Authorized` : 'UnAuthorized'}
                      </span>
                      {selectedRosterManagerArray[0].IsActive ? (
                        <span className='active-txt'>ACTIVE</span>
                      ) : (
                        <span className='inactive-txt'>INACTIVE</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
            {card &&
              selectedRosterManagerArray &&
              selectedRosterManagerArray[0].UserRole.includes('Client') && (
                <div className='validation-message'>
                  Sorry, we do not allow this action for the Client Admins.
                </div>
              )}

            <div className='horizontal-line'>
              <span className='line-icon'></span>
            </div>
            <div className='assign-button-container'>
              <div className='button-row'>
                <div className='btn-grp'>
                  <button className='btn-submit-cancel' onClick={() => closeModalHandler(false)}>
                    Cancel
                  </button>
                  <button
                    disabled={buttonDisabled}
                    className={`${buttonDisabled ? 'disabledButton' : 'btn-submit-add'}`}
                    onClick={assignRosterProviders}>
                    Assign
                  </button>
                </div>
              </div>
            </div>
          </Fragment>
        </ReactModal>
      )}
      {spinnerVisibility && <Spinner cta={true} />}
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </Fragment>
  );
};

CopyProvider.propTypes = {
  showModalCopyProvider: PropTypes.bool,
  closeModalCopyRosterPro: PropTypes.func
};
export default CopyProvider;
