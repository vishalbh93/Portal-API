import React, { Fragment, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '../../../store/actions';
import PropTypes from 'prop-types';
import _ from 'lodash';

import './_providerList.less';

import * as headerColumn from '../../../utils/constant-data';

import Header from '../../Header/Header';
import Provider from '../RosterViewProvider/Provider';
import Spinner from '../../Spinner/Spinner';
import SearchIcon from '../../SearchIcon/SearchIcon';
import SelectedProvider from '../SelectedProvider/SelectedProvider';
import PaginationUI from '../../Pagination/Pagination';
import Body from '../Body/Body';
import ProviderTypeTags from './ProviderTypeTags';
import ReactModal from 'react-modal';
import { rosterPage, clientAdminPage } from '../../../components/Practice/Utils/Helpers';
import { ROSTER_PAGE, CLIENT_ADMIN_PAGE } from '../../../components/Practice/Utils/Constants';
import icon_sponsored from '../../../../assets/images/icon_sponsored.svg';
import Fab from '../../../assets/images/FabIcon.svg';
import * as _pService from '../../../utils/serviceCalls/clientPortal';
import Notification from '../../Common/NotificationModel/NotificationModel';
import { objectToCamel } from '../../../utils/utils';
import * as service from '../../../utils/service';
import Toast from '../../Common/Toast/Toast';

// Global State
let _selectedProviders = {};

const Providers = (props) => {
  const {
    accountInfo,
    currentSponsorType,
    sponsorInformation,
    selectedArrayHandler,
    providersHandler,
    rosterInfo,
    providerData,
    providerMain,
    rosterAccount,
    currentAccountDetails,
    userDetails
  } = props;
  const isClientPage = rosterPage != ROSTER_PAGE;
  let rosterFilterList = isClientPage
    ? [
        {
          filterType: 'search',
          value: '',
          displayName: '',
          isUnaffiliated: false
        },
        {
          filterType: 'sponsorType',
          value: 'ALL',
          displayName: '',
          isUnaffiliated: false
        }
      ]
    : [
        {
          filterType: 'search',
          value: '',
          displayName: '',
          isUnaffiliated: false
        }
      ];
  const [filters, setFilters] = useState(rosterFilterList);
  const [searchText, setSearchText] = useState('');
  const [filterArray, setFilterArray] = useState([]);
  const [showSpinner, setShowSpinner] = useState(false);
  const [page, setPage] = useState(isClientPage ? accountInfo.page : rosterAccount.page);
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [sortOrder, setSortOrder] = useState(
    isClientPage ? accountInfo.sortOrder : rosterAccount.sortOrder
  );
  const [sortBy, setSortBy] = useState(isClientPage ? accountInfo.sortBy : rosterAccount.sortBy);
  const [selectedCount, setSelectedCount] = useState(0);

  const isImpersonatedUser = isClientPage ? accountInfo.isImpersonate : rosterAccount.isImpersonate;

  const headerColumns = headerColumn.headerColumnsClientPortal;
  const rosterheaderColumns = headerColumn.headerColumnsRoster;

  const dispatch = useDispatch();
  const { providers, totalRecords, rosterFilters, displayMessage, clientCode } = isClientPage
    ? useSelector((state) => state.getClientPortalProvidersReducer)
    : useSelector((state) => state.loadRoster);
  const [totalProvidersRecords, setTotalProvidersRecords] = useState(totalRecords);
  const [providersArray, setProvidersArray] = useState(providers);
  const [toggleAddProvider, setToggleAddProvider] = useState(false);

  const { response, isDeleteClick, providerCount } = isClientPage
    ? useSelector((state) => state.removeProvidersReducer)
    : useSelector((state) => state.removeProviderFromRoster);

  const [getStatus, setStatus] = useState({});
  const [showNotifyModel, setShowNotifyModel] = useState(false);

  const [scrolled, setScrolled] = useState(false);

  const isMobileView = window.innerWidth <= 768;
  const [showSelectorModal, toggleSelectorModal] = useState(false);
  const [showFab, setShowFab] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);

  /* #region handlers */
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const fetchProviders = () => {
    if (isClientPage) {
      if (accountInfo.userId != undefined && accountInfo.userId != '') {
        setShowSpinner(true);
        dispatch(
          actions.getClientPortalProviders({
            filters: filters,
            page: page,
            recordsPerPage: recordsPerPage,
            sortBy: sortBy,
            sortOrder: sortOrder,
            userId: accountInfo.userId,
            isImpersonate: accountInfo.isImpersonate
          })
        );
      }
    } else {
      let rosterFilterInfo = filters && filters.some((x) => x.filterType != '');
      let payload = {
        page: page,
        providersPerPage: recordsPerPage,
        sortBy: sortBy,
        sortOrder: sortOrder,
        userId: rosterInfo.UserId,
        filters: rosterFilterInfo ? filters : [],
        isImpersonate: rosterInfo.IsImpersonate
      };
      setShowSpinner(true);
      dispatch(actions.loadProviderUpdate(payload, payload.filters, setShowSpinner));
    }
  };

  const onPageChange = (pageNumber) => {
    setPage(pageNumber);
    setProvidersArray(providers);
    setSelectedCount(0);
    _selectedProviders = {};
  };

  const onPageFilterChange = (perPage) => {
    perPage != null ? window.scrollTo(0, 300) : null;
    setPage(1);
    setRecordsPerPage(perPage);
    {
      isClientPage
        ? (accountInfo.recordsPerPage = perPage)
        : (rosterAccount.recordsPerPage = perPage);
    }
  };

  const onSort = (sortOption, sortBy) => {
    setSortBy(sortBy);
    setSortOrder(sortOption);
  };

  const handleSelectAllChange = (e) => {
    const { name, checked } = e.target;
    if (name == 'AllSelect') {
      providers.forEach((provider) => {
        checked
          ? (_selectedProviders[provider.ProviderId] = provider)
          : delete _selectedProviders[provider.ProviderId];
      });
      setProvidersArray([...providersArray]);
    }
  };
  const fabClickHandler = (event, message) => { 
    toggleSelectorModal(!showSelectorModal);
  };

  const handleSelectChange = (e) => {
    const { id, checked } = e.target;
    let prov = {};
    checked
      ? ((prov = providersArray.find((prov) => prov.ProviderId == id)),
        (_selectedProviders[id] = prov))
      : delete _selectedProviders[id];
    setProvidersArray([...providersArray]);
    isMobileView && setShowFab(true);
  };

  const onClosehandler = (e) => {
    setSelectedCount(0);
    _selectedProviders = {};
    toggleSelectorModal(false);
  };

  const reloadList = (data) => {
    if (data == true) {
      fetchProviders();
      if (isClientPage) {
        props.reloadBanner(data);
      }
    }
  };

  const removeProvider = async (userId, pwid, clientCode) => {
    let isRemoveProvidersIsClicked = true;
    if (!isImpersonatedUser && rosterPage != ROSTER_PAGE) {
      let _promises = [];
      _promises.push(service._get(`/api/clientportal/clientportaldata`, false));
      const _result = await Promise.allSettled(_promises);
      if (_result.every((res) => res.status === 'fulfilled')) {
        var clientDataInfo = objectToCamel(_result.map((res) => res.value.data) || []);
        var clientDataCode =
          objectToCamel(JSON.parse(clientDataInfo.map((x) => x.returnData))) || [];
        validationServiceCall(
          false,
          clientCode,
          pwid,
          userId,
          clientDataCode,
          isRemoveProvidersIsClicked
        );
      }
    } else {
      if (rosterPage != ROSTER_PAGE) {
        setShowSpinner(true);
        dispatch(
          actions.removeProvidersFromUser(
            userId,
            pwid,
            clientCode,
            setShowSpinner,
            isRemoveProvidersIsClicked
          )
        );
      } else {
        setShowSpinner(true);
        dispatch(
          actions.removeProviderFromRoster(
            rosterInfo != undefined ? rosterInfo.UserId : userId,
            pwid,
            setShowSpinner,
            isImpersonatedUser
          )
        );
      }
    }
  };

  const addProviderHandler = (val) => {
    setToggleAddProvider(val);
  };

  const batchEditOptionHandler = (e, type) => {
    if (type != null) {
      let pwids = Object.keys(_selectedProviders);
      props.batchEditOptionHandler(type, _selectedProviders);
    }
  };

  const handleScroll = () => {
    setTimeout(() => {
      setScrolled(true);
    }, 5);
  };

  const removeProvidersDispatch = (
    userId,
    pwid,
    clientCode,
    setShowSpinner,
    isRemoveProvidersIsClicked
  ) => {
    setShowSpinner(true);
    dispatch(
      actions.removeProvidersFromUser(
        userId,
        pwid,
        clientCode,
        setShowSpinner,
        isRemoveProvidersIsClicked
      )
    );
  };
  const validationServiceCall = (
    status,
    clientCode,
    pwid,
    userId,
    clientDataCode,
    isRemoveProvidersIsClicked
  ) => {
    var clientDataIn =
      clientDataCode.length > 0 ? clientDataCode.filter((x) => x.clientCode == clientCode) : [];
    var pMinimum = clientDataIn.length > 0 ? clientDataIn[0].minProviderCount : 0;
    var designationStatus = false;
    var desingationData = [];
    var providerList = props.sProviderCount != undefined && props.sProviderCount;
    let pwidList = pwid != undefined && pwid != null ? pwid : [];

    var getProviderList = providers.filter((e1) => {
      return pwidList.find((e2) => {
        return e1.ProviderId == e2;
      });
    });

    var getNonDesignationProviders = getProviderList.filter(
      (h) => h.SponsorType == 'STANDARD'
    ).length;

    var getDesignationProviders = getProviderList.filter((h) => h.SponsorType != 'STANDARD').length;

    //bulk providers remove calculation
    var designateProviders = Number(providerList.total - providerList.standard) - pMinimum;
    var totalDesignateProviders =
      getDesignationProviders > designateProviders
        ? getDesignationProviders - designateProviders
        : designateProviders - getDesignationProviders;
    designationStatus = designateProviders > 0 ? true : false;
    var payload = {
      ClientCode: accountInfo.clientCode,
      TotalProviders: Number(providerList.total - providerList.standard) - getDesignationProviders,
      IsProviderAdd: status
    };
    if (getDesignationProviders > 0) {
      return _pService
        .getValidateStatus(payload)
        .then((res) => {
          if (res.status == 200) {
            let pData = objectToCamel(res.data || []);
            if (pData.isError) {
              if (!designationStatus) {
                setStatus(pData.errorMessage);
              }
              if (designateProviders == 0 && getDesignationProviders > 0) {
                setShowNotifyModel(true);
              } else {
                desingationData =
                  getNonDesignationProviders > 0
                    ? getProviderList
                        .map((x) => x.SponsorType == 'STANDARD' && x.ProviderId)
                        .filter((x) => x != false)
                    : [];

                if (designationStatus) {
                  getDisplayMessage(designateProviders, Number(getDesignationProviders));
                  var updateDesignationData = getProviderList
                    .slice(0, Number(totalDesignateProviders))
                    .map((x) => x.SponsorType != 'STANDARD' && x.ProviderId)
                    .filter((x) => x != false);
                  if (updateDesignationData.length > 0) {
                    desingationData.push(...updateDesignationData);
                  } else {
                    setShowNotifyModel(true);
                  }
                }
                if (designationStatus) {
                  setShowNotifyModel(true);
                } else {
                  if (
                    (getNonDesignationProviders > 0 || designationStatus) &&
                    desingationData.length > 0
                  ) {
                    removeProvidersDispatch(
                      userId,
                      pwid,
                      clientCode,
                      setShowSpinner,
                      isRemoveProvidersIsClicked
                    );
                  } else {
                    setShowNotifyModel(true);
                  }
                }
              }
            } else {
              removeProvidersDispatch(
                userId,
                pwid,
                clientCode,
                setShowSpinner,
                isRemoveProvidersIsClicked
              );
            }
          }
        })
        .catch((err) => {
          console.error(err);
        });
    } else {
      removeProvidersDispatch(userId, pwid, clientCode, setShowSpinner, isRemoveProvidersIsClicked);
    }
  };

  const closeNotifyHandler = () => {
    setShowNotifyModel(false);
  };

  const onSearchFilterChange = (searchData) => {
    setSearchText(searchData);
  };

  const onApplyQuickFilter = (filterData) => {
    setFilterArray(filterData);
    setFilters(filterData)
  };

  const getDisplayMessage = (removedCount, totalSelectedCount) => {
    let clientValidMessage = `<p>Please note that we are allowing to remove only ${removedCount} designated ${
      removedCount == 1 ? 'provider' : 'providers'
    } out of ${totalSelectedCount} selected providers. <a href='/contactus'>Contact support</a> if you need assistance.</p>`;
    setStatus(clientValidMessage);
  };

  useEffect(() => {
    if (isClientPage) {
      fetchProviders();
    }
  }, []);

  useEffect(() => {
    if (isClientPage) {
      providersHandler(providers);
    }
  }, [providers]);

  useEffect(() => {
    if (totalRecords > 0) {
      setProvidersArray(providers);
      setTotalProvidersRecords(totalRecords);
    }
    setShowSpinner(false);
  }, [totalRecords, providers]);

  useEffect(() => {
    setSelectedCount(Object.keys(_selectedProviders).length);
  }, [providersArray, handleSelectChange, fabClickHandler]);

  useEffect(() => {
    fetchProviders();
  }, [filters, page, recordsPerPage, sortBy, sortOrder]);

  useEffect(() => {
    setPage(1);
    setFilters(
      filters.map((filter) =>
        filter.filterType == 'search' ? { ...filter, value: searchText.toLowerCase() } : filter
      )
    );
  }, [searchText]);

  useEffect(() => {
    setFilters(
      filters.map((filter) =>
        filter.filterType == 'sponsorType' ? { ...filter, value: currentSponsorType } : filter
      )
    );
  }, [currentSponsorType]);

  useEffect(() => {
    if (filterArray != undefined && filterArray != null && filterArray.length > 0) {
      let quickFilterArrary = filters;

      filterArray.map((item) => {
        if (item.filterType === 'missing') {
          quickFilterArrary = quickFilterArrary.filter((obj) => obj.filterType !== 'missing');
        } else if (item.filterType === 'specialty') {
          quickFilterArrary = quickFilterArrary.filter((obj) => obj.filterType !== 'specialty');
        }
        quickFilterArrary.push(item);
      });
      let quickFilterUniqueArrary = Array.from(
        quickFilterArrary.reduce((map, obj) => map.set(obj.value, obj), new Map()).values()
      );
      setPage(1);

      setFilters(quickFilterUniqueArrary);
    } else {
      setFilters(rosterFilterList);
    }
  }, [filterArray]);

  useEffect(() => {
    let totalPages = Math.ceil(totalProvidersRecords / recordsPerPage);
    //if it is last page delete operation set to 1st page always
    if (totalPages == page) {
      setPage(1);
    }     

    if (response.Message != undefined && response.Message != '') {
      if (response.IsError != undefined && response.IsError)
        toaster.Error(
          response.ErrorMessage != undefined && response.ErrorMessage != ''
            ? response.ErrorMessage
            : 'Some error occurred, please try again!'
        );
      else if(Number(providerCount)<30){
        toaster.Success(response.Message);
      }
    }
    if(Number(providerCount)>30){
      toaster.Success('Your bulk update request has been submitted. It will be processed in few minutes.');
    }

    if (isClientPage) {
      if (isDeleteClick) {
        reloadList(true);
      }
    } else {
      if (response != null) {
        reloadList(true);
      }
    }
  }, [response, isDeleteClick]);

  useEffect(() => {
    if (isClientPage) {
      selectedArrayHandler(() => providersArray.filter((i) => i?.ProvidersChecked == true));
    }
  }, [providersArray]);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
  });
  useEffect(() => {
    if (rosterPage == ROSTER_PAGE) {
      setProvidersArray(providers);
      setTotalProvidersRecords(providerData.NumberOfProviders);
    }
  }, [rosterInfo]);

  useEffect(() => {
    if (rosterPage == ROSTER_PAGE) {
      if (providers.length > 0) {
        let providerSearch = providers
          .map((el1) => {
            return providers.some((el2) => el2.ProviderId == el1.ProviderId) ? { ...el1 } : null;
          })
          .filter((item) => item != null);
        if (providerSearch.length > 0) {
          setProvidersArray(providerSearch);
        } else {
          setProvidersArray(providers);
        }
      } else {
        setProvidersArray(providers);
      }
    }
  }, [providers]);

  useEffect(() => {
    if (selectedCount > 0) {
      rosterheaderColumns.isShow == true;
    }
  }, [selectedCount]);

  useEffect(() => {
    if (totalRecords <= 0) {
      setTotalProvidersRecords(totalRecords);
    }
  }, [totalRecords]);

  return (
    <Fragment>
      {!showSpinner && showNotifyModel && (
        <Notification
          textMessage={getStatus}
          showModel={showNotifyModel}
          closeModal={closeNotifyHandler}
        />
      )}
      {isMobileView && selectedCount > 0 && (
        <ReactModal
          overlayClassName='roster-modal-selected-provider'
          className='modal-dialog'
          ariaHideApp={true}
          isOpen={showSelectorModal}
          contentLabel=''
          onRequestClose={onClosehandler}
          shouldCloseOnEsc={false}
          shouldCloseOnOverlayClick={false}>
          <div className='model-window'>
            <div className='model-container'>
              <Fragment>
                <SelectedProvider
                  providers={_selectedProviders}
                  accountInfo={rosterPage != ROSTER_PAGE ? accountInfo : rosterAccount}
                  onClosehandler={onClosehandler}
                  removeProvider={handleSelectChange}
                  batchEditOptionHandler={batchEditOptionHandler}
                  batchDelete={removeProvider}
                />
              </Fragment>
            </div>
          </div>
        </ReactModal>
      )}
      <Body
        providers={providers.map((i) => i.DisplayName)}
        rosterFilters={rosterFilters}
        profileInfo={
          isClientPage ? accountInfo : { providers: providerMain, userId: rosterInfo.UserId }
        }
        searchFilterChange={(data) => {
          onSearchFilterChange(data);
        }}
        applyQuickFilter={(filterData) => {
          onApplyQuickFilter(filterData);
        }}
        reloadList={reloadList}
        rosterData={rosterInfo}
        addProvider={addProviderHandler}
        toggleAddProvider={toggleAddProvider}
        totalProviders={totalRecords}
        isImpersonateFlag={isImpersonatedUser}
        isClientPageFlag={isClientPage}
        currentAccountDetails={currentAccountDetails}
        manageTab={props.manageTab}
        manageAccSettingTab ={props.manageAccSettingTab}
      manageDeleteAccTab ={props.manageDeleteAccTab}
      manageDuplicateRosterProTab = {props.manageDuplicateRosterProTab}
      manageClientSettingsTab={props.manageClientSettingsTab}
      userDetails={userDetails}
      />
      <div className='provider-container'>
        {totalRecords > 0 ? (
          <Fragment>
            <div className='provider-list-container'>
              <div className='provider-list'>
                <div className='provider-list-content'>
                  <div
                    className={
                      selectedCount > 0 && !isMobileView
                        ? 'short-header-inner-content'
                        : 'header-inner-content'
                    }>
                    {!isMobileView ? (
                      <div className='checkbox'>
                        <input
                          id='AllSelect'
                          name='AllSelect'
                          type='checkbox'
                          aria-label='allselect-checkbox'
                          checked={providers.every((prov) =>
                            Object.keys(_selectedProviders).includes(prov.ProviderId)
                          )}
                          onChange={handleSelectAllChange}></input>
                        <label
                          className={isClientPage ? 'checkbox-cp' : 'checkbox-rp'}
                          htmlFor='AllSelect'></label>
                      </div>
                    ) : (
                      selectedCount > 0 && (
                        <div className='fab-icon'>
                          <img
                            id={providersArray.map((provider, index) => provider.ProviderId)}
                            name='AllSelect'
                            src={Fab}
                            alt='fab'
                            onClick={(event) => fabClickHandler(event, 'AllSelect')}
                            className='fab-img'
                          />
                          {selectedCount > 0 && (
                            <span
                              className={
                                rosterPage != ROSTER_PAGE
                                  ? 'provider-length client'
                                  : 'provider-length'
                              }>
                              {selectedCount}
                            </span>
                          )}
                        </div>
                      )
                    )}

                    <div
                      className={
                        isClientPage
                          ? selectedCount > 0 && !isMobileView
                            ? 'provider-list-shortheader'
                            : 'provider-list-header'
                          : selectedCount > 0 && !isMobileView
                          ? 'roster-list-shortheader'
                          : 'roster-list-header'
                      }>
                      <Header
                        columns={isClientPage ? headerColumns : rosterheaderColumns}
                        onSort={onSort}
                        isShow={selectedCount > 0}
                      />
                    </div>
                  </div>
                  <div
                    className={
                      !isMobileView
                        ? isClientPage
                          ? selectedCount > 0
                            ? 'main-provider-area'
                            : null
                          : selectedCount > 0
                          ? 'main-roster-area'
                          : null
                        : null
                    }>
                    <div className='provider-item-container'>
                      <div className='vertical-line'></div>
                      {providersArray.map((provider, index) => (
                        <div
                          className={
                            index % 2 !== 0 ? 'provider-row alternate-background' : 'provider-row'
                          }
                          key={index}>
                          <div className='checkbox'>
                            <input
                              id={provider.ProviderId}
                              name={`${provider.ProviderId}-input-provider-checkbox`}
                              value={_selectedProviders.hasOwnProperty(provider.ProviderId)}
                              type='checkbox'
                              aria-label={`${provider.ProviderId}-provider-checkbox`}
                              onChange={handleSelectChange}
                              checked={_selectedProviders.hasOwnProperty(
                                provider.ProviderId
                              )}></input>
                            <label
                              className={isClientPage ? 'checkbox-cp' : 'checkbox-rp'}
                              htmlFor={provider.ProviderId}></label>
                          </div>
                          <Provider
                            {...provider}
                            accountInfo={isClientPage ? accountInfo : rosterAccount}
                            listId={index}
                            key={index}
                            reloadList={reloadList}
                            removeProvider={removeProvider}
                            selectedCount={selectedCount}
                          />
                        </div>
                      ))}
                    </div>

                    {selectedCount > 0 && !isMobileView && (
                      <SelectedProvider
                        providers={_selectedProviders}
                        accountInfo={isClientPage ? accountInfo : rosterAccount}
                        onClosehandler={onClosehandler}
                        removeProvider={handleSelectChange}
                        batchEditOptionHandler={batchEditOptionHandler}
                        batchDelete={removeProvider}
                      />
                    )}
                  </div>
                </div>
              </div>
              <div className='provider-list-pagination'>
                {isClientPage ? (
                  <ProviderTypeTags sponsorInformation={sponsorInformation} />
                ) : providerData.HasSponsored != undefined && providerData.HasSponsored ? (
                  <>
                    <span className='roster-sponsor-info'>
                      <img className='sponsor' src={icon_sponsored} alt='IsSponsored' />
                      <p>Sponsored Provider in Healthgrades Premium Services</p>
                    </span>
                  </>
                ) : (
                  ''
                )}
                <div>
                  <div className='joy-pagination'>
                    {totalProvidersRecords > 10 && (
                      <PaginationUI
                        recordsFound={totalProvidersRecords}
                        onPageChange={onPageChange}
                        showPerPage={true}
                        recordsPerPage={recordsPerPage}
                        onPageFilterChange={onPageFilterChange}
                        showJoyPagination={true}
                        isBulkProviders={totalProvidersRecords>500}
                        isClientPage={isClientPage}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </Fragment>
        ) : (
          <SearchIcon />
        )}
      </div>
      {showSpinner && <Spinner cta={true} />}
      <div className={`${providerCount>30? 'resize-toast-msg':''}`}>
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={10000}
      />
      </div>
    </Fragment>
  );
};

Providers.defaultProps = {
  currentAccountDetails: {}
};

Providers.propTypes = {
  accountInfo: PropTypes.object,
  reloadBanner: PropTypes.func,
  batchEditOptionHandler: PropTypes.func,
  selectedArrayHandler: PropTypes.func,
  providersHandler: PropTypes.func,
  currentAccountDetails: PropTypes.object
};

export default Providers;
