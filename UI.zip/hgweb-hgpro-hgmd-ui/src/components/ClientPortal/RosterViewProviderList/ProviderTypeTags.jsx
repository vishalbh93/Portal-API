import React, { Fragment } from 'react';
import PropTypes from 'prop-types';

const ProviderTypeTags = (props) => {
  const Enhanced = 'Enhanced';
  const Premium = 'Premium';
  const Employed = 'Employed';
  const Affiliated = 'Affiliated';
  const Standard = 'Standard';

  const { sponsorInformation } = props;
  const isMobileView = window.innerWidth <= 768;

  return (
    <Fragment>
      <div className='info-tags'>
        {sponsorInformation.isFacility ? (
          <>
            <div className='tags-column'>
              <span className='tags tags_e'>{Employed.toUpperCase()}</span>
              {!isMobileView ?
              <span className='tags_details'>
                Designated Profile on Healthgrades for an {Employed} Provider in your program
              </span>
              :
              <span className='tags_details'>
                {Employed} providers in Healthgrades
              </span>
              }
            </div>
            <div className='tags-column'>
              <span className='tags tags_a'>{Affiliated.toUpperCase()}</span>
              {!isMobileView ?
              <span className='tags_details'>
                Designated Profile on Healthgrades for an {Affiliated} Provider in your program
              </span>
              :
              <span className='tags_details'>
                {Affiliated} providers in Healthgrades
              </span>
              }
             
            </div>
          </>
        ) : (
          <>
            {(sponsorInformation.sponsorType == 'PDCPRAC' ||
              sponsorInformation.sponsorType == 'MAP') && (
              <>
                <div className='tags-column'>
                  <span className='tags tags_a'>{Premium.toUpperCase()}</span>
                  {!isMobileView ?
                  <span className='tags_details'>
                   Designated Profile on Healthgrades for an {Premium} Provider in your program
                  </span>
                  :
                  <span className='tags_details'>
                   {Premium} providers in Healthgrades
              </span>
              }
                </div>
              </>
            )}
            {sponsorInformation.sponsorType == 'PDCPRACT2' && (
              <>
                <div className='tags-column'>
                  <span className='tags tags_e'>{Enhanced.toUpperCase()}</span>
                  {!isMobileView ?
                  <span className='tags_details'>
                    Designated Profile on Healthgrades for an {Enhanced} Provider in your program
                  </span>
                  :
                  <span className='tags_details'>
                  {Enhanced} providers in Healthgrades
              </span>
              }
                 
                </div>
              </>
            )}
          </>
        )}
        <div className='tags-column'>
          <span className='tags tags_s'>{Standard.toUpperCase()}</span>
          {!isMobileView ?
                  <span className='tags_details'>
                  {Standard} Profile on Healthgrades for all providers not designated in your program
                </span>
                  :
                  <span className='tags_details'>
                  {Standard}  providers in Healthgrades
              </span>
              }
          
        </div>
      </div>
    </Fragment>
  );
};

ProviderTypeTags.propTypes = {
  sponsorInformation: PropTypes.object
};

export default ProviderTypeTags;
