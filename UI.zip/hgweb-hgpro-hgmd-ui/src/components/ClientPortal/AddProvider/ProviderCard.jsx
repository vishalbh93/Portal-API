import React, { Fragment, useState, useEffect, useRef } from 'react';

// icon imports
import TrashIcon from '../../../assets/images/trash.svg';
import TrashHoverIcon from '../../../assets/images/trash-hover.svg';
import DownArrow from '../../../assets/images/down-arrow.svg';
import UpArrow from '../../../assets/images/up-arrow.svg';
import PropTypes from 'prop-types';

const ProviderCard = (props) => {
  const {
    provider,
    facilities,
    employmentTypes,
    removeProviderHandler,
    updateProviderHandler,
    indexValue,
    totalProviders,
    isRosterPage
  } = props;
  //state variables
  const [trashIconSrc, setTrashIconSrc] = useState(TrashIcon);
  const [showEmploymentTypeSection, setShowEmploymentTypeSection] = useState(false);
  const [showFacilitySection, setShowFacilitySection] = useState(false);
  const [showEmploymentTypeDropDown, setShowEmploymentTypeDropDown] = useState(false);
  const [showFacilityDropDown, setShowFacilityDropDown] = useState(false);
  const [requestObject, setRequestObject] = useState(provider);
  const [selectedEmpType, setSelectedEmpType] = useState(provider.employmentType); // 'Standard');
  const [selectedFacilityType, setSelectedFacilityType] = useState('Select Facility');
  const [showEmploymentList, setShowEmploymentList] = useState('disable');
  const [showFacilityList, setShowFacilityList] = useState('disable');

  const containerEl = useRef(null);

  // Workaround for useEffect
  const initialRender = useRef(true);

  const isMobileView = window.innerWidth <= 768;

  // Flag for facility section

  const isFacilityEmpty =
    JSON.stringify(requestObject.facility) ===
    JSON.stringify({ FacilityCode: '', FacilityName: '' });

  //Event / Change => Handlers
  const employmentSelectHandler = (employmentType) => {
    setRequestObject((prevState) => ({
      ...prevState,
      employmentType: employmentType,
      validation: {
        isFacilityValid: employmentType.toLowerCase() === 'standard' || facilities.length == 0,
        isEmploymentValid: true
      }
    }));
    setSelectedEmpType(employmentType);
    if (employmentType == 'Standard') setSelectedFacilityType('Select Facility');
    else setSelectedFacilityType(selectedFacilityType);
  };

  const facilitySelectHandler = (facility) => {
    setRequestObject((prevState) => ({
      ...prevState,
      facility: facility,
      validation: {
        ...prevState.validation,
        isFacilityValid: facility.FacilityCode !== '' && facility.FacilityName !== ''
      }
    }));
    setShowFacilityDropDown(false);
    setSelectedFacilityType(facility.FacilityName);
  };

  //useEffects
  useEffect(() => {
    if (!isRosterPage) {
      if (requestObject.isSponsored == true) {
        setShowEmploymentTypeSection(false);
        setShowFacilitySection(false);
      } else {
        setShowEmploymentTypeSection(true);
      }
      if (initialRender.current) initialRender.current = false;
      else {
        if (requestObject.employmentType == '') {
          setShowFacilitySection(false);
        } else {
          setShowEmploymentTypeDropDown(false);
          if (requestObject.employmentType.toLowerCase() == 'standard') {
            setShowFacilitySection(false);
          } else {
            setShowFacilitySection(true);
          }
        }
        updateProviderHandler(requestObject);
      }
    } else {
      if (requestObject.IsSponsored == false) {
        setShowFacilitySection(false);
        setShowEmploymentTypeSection(false);
      }
    }
  }, [requestObject]);

  useEffect(() => {
    setRequestObject(provider);
    setSelectedEmpType(provider.employmentType);
    setSelectedFacilityType(provider.facility.FacilityName);
  }, [provider]);

  useEffect(() => {
    let listEl = containerEl.current.querySelector("[role='list']");
    if (listEl != null) listEl.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [showEmploymentTypeDropDown]);

  useEffect(() => {
    let listEl = containerEl.current.querySelector("[role='list']");
    if (listEl != null) listEl.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [showFacilityDropDown]);

  // CSS Handlers

  const _providerCardClass = `${
    requestObject.validation.isEmploymentValid && requestObject.validation.isFacilityValid
      ? 'provider-search-card'
      : 'provider-search-card error'
  }`;
  const _facilityClass = `${
    requestObject.validation.isEmploymentValid && requestObject.validation.isFacilityValid
      ? ''
      : 'error'
  }`;

  //element reference
  const refEmploymentType = useRef();
  const refFacility = useRef();

  const handleClickOutside = (event) => {
    if (
      refEmploymentType.current &&
      !refEmploymentType.current.contains(event.target) &&
      refEmploymentType.current.id == requestObject.pwid
    ) {
      setShowEmploymentList('disable');
      setShowEmploymentTypeDropDown(false);
    } else if (refEmploymentType.current != undefined || refEmploymentType.current != null) {
      setShowEmploymentList('enable');
    }
    if (
      refFacility.current &&
      !refFacility.current.contains(event.target) &&
      refFacility.current.id == requestObject.pwid
    ) {
      setShowFacilityList('disable');
      setShowFacilityDropDown(false);
    } else if (refFacility.current != undefined || refFacility.current != null) {
      setShowFacilityList('enable');
    }
  };

  //Bind the event listener
  document.addEventListener('mousedown', handleClickOutside);

  return (
    <Fragment key={indexValue}>
      <div className={_providerCardClass} key={requestObject.pwid} ref={containerEl}>
        <span className='card-name'>{requestObject.displayName}</span>
        <br />
        <span className='card-location'>Location: {requestObject.location} | </span>
        <span className='card-npi'>NPI: {requestObject.npi} | </span>
        <span className='card-pwid'>PWID: {requestObject.pwid}</span>
        <span
          className='delete-icon'
          onClick={() => {
            setTrashIconSrc(TrashIcon);
            removeProviderHandler(requestObject.pwid);
          }}>
          <img
            src={trashIconSrc}
            onMouseOver={() => {
              setTrashIconSrc(TrashHoverIcon);
            }}
            onMouseOut={(e) => {
              setTrashIconSrc(TrashIcon);
            }}
            alt='delete-logo'></img>
        </span>
        {showEmploymentTypeSection && (
          <span className='provider-type'>
            <span className='employment-type'>Profile Type</span>
            {facilities != null && facilities.length > 0 && showFacilitySection && (
              <span className='facility-type'>Select Facility*</span>
            )}
          </span>
        )}

        {showEmploymentTypeSection && (
          <span>
            <div className='select-option'>
              <div
                className='dropdown dd-section-employment-type'
                ref={refEmploymentType}
                id={requestObject.pwid}>
                <button
                  type='button'
                  className='dropdown-header'
                  onClick={() => setShowEmploymentTypeDropDown(!showEmploymentTypeDropDown)}
                  onFocus={(e) => setShowEmploymentList('enable')}>
                  <span>{selectedEmpType}</span>
                  <img
                    className='icon'
                    src={showEmploymentTypeDropDown ? UpArrow : DownArrow} alt='arrow-icon'></img>
                </button>
                {showEmploymentTypeDropDown && showEmploymentList == 'enable' && (
                  <div role={'list'} className={`dropdown-body dd-employment-type`}>
                    {employmentTypes.map((employmentType, index) => (
                      <button
                        type='button'
                        className='dropdown-item'
                        key={index}
                        onClick={() => {
                          employmentSelectHandler(employmentType);
                        }}>
                        <strong >{employmentType}</strong>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* facility dropdown */}
              {facilities!= null && facilities.length > 0 && showFacilitySection && (
                <div
                  className='dropdown dd-section-facility'
                  ref={refFacility}
                  id={requestObject.pwid}>
                  <button
                    type='button'
                    className={`dropdown-header ${_facilityClass}`}
                    onClick={() => setShowFacilityDropDown(!showFacilityDropDown)}>
                    <span className='facility-name'>{`${
                      selectedFacilityType != 0 ? selectedFacilityType : 'Select Facility'
                    }`}</span>
                    <img className='icon' src={showFacilityDropDown ? UpArrow : DownArrow} alt='arrow-icon'></img>
                  </button>
                  {showFacilityDropDown && showFacilityList == 'enable' && (
                    <div role={'list'} className='dropdown-body dd-facility'>
                      <div className='scrollbar' id='scrollbar-dropdown-style'>
                        {facilities.map((facility, index) => (
                          <Fragment>
                            <button
                              key={index}
                              type='button'
                              className='dropdown-item facility-item'
                              title={facility.FacilityName}
                              onClick={() => {
                                facilitySelectHandler(facility);
                              }}>
                              <strong className={isMobileView && 'fac-name'}>{facility.FacilityName}</strong>
                              <span>{facility.FacilityCode} </span>
                            </button>
                          </Fragment>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </span>
        )}
      </div>
    </Fragment>
  );
};


export default ProviderCard;
