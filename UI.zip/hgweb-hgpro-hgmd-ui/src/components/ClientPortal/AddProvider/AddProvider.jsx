import React, { Fragment, useState, useEffect, useRef } from 'react';
import './_addProvider.less';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
import cross from '../../../../public/images/cross.png';
import { RadioGroup } from '../../FormComponents/RadioGroup';
import Modal from 'react-modal';
import * as constants from '../../../utils/constant-data';
import '@hg/joy/src/globalstyles';
import * as actions from '../../../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../Spinner/Spinner';
import ProviderCard from './ProviderCard';
import Toast from '../../Common/Toast/Toast';
import { rosterPage } from '../../../components/Practice/Utils/Helpers';
import { ROSTER_PAGE } from '../../../components/Practice/Utils/Constants';
import * as _pService from '../../../utils/serviceCalls/clientPortal';
import { objectToCamel } from '../../../utils/utils';
import { clientAdminPage } from '../../../components/Practice/Utils/Helpers';
import { CLIENT_ADMIN_PAGE } from '../../../components/Practice/Utils/Constants';
import isEmpty from '../../../utils/validation/isEmpty';
import _ from 'lodash';

const AddProviderModal = (props) => {
  const dispatch = useDispatch();
  const searchField = useRef(null);
  const {
    profileInfo,
    showModal,
    closeModal,
    totalProviders,
    isImpersonateFlag,
    isClientPageFlag,
    clientDataCode,
    currentRole
  } = props;
  const [searchRequest, setSearchRequest] = useState({
    userId: profileInfo.userId,
    clientCode: profileInfo.clientCode,
    searchType: 'npi',
    searchValue: '',
    page: 1,
    sortBy: 'name',
    pageSize: 1
  });

  const { sponsoredProvidersCount } =
    isClientPageFlag && useSelector((state) => state.getClientPortalBannerDataReducer);

  const {
    providerSearchResult,
    facilities,
    employmentTypes,
    totalRecords,
    validationResult,
    errorMsg
  } = isClientPageFlag
    ? useSelector((state) => state.searchClientPortalProvidersReducer)
    : useSelector((state) => state.searchRosterProvidersReducer);
  const { result } = isClientPageFlag
    ? useSelector((state) => state.addClientPortalProvidersToRosterReducer)
    : useSelector((state) => state.addProvidersToRosterReducer);

  const [resultObject, setResultObject] = useState({});
  const [warningFlag, setWarningFlag] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);
  const radioOptions = constants.radioOptionsforAdding;
  const [providersList, setprovidersList] = useState([]);
  const [constantProvidersList, setConstantProvidersList] = useState([]);
  const [employmentTypeList, setEmploymentTypeList] = useState([]);
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const [disable, setDisable] = useState(true);
  const [isSearchError, setIsSearchError] = useState(false);
  const [errorMsgSearch, setErrorMsgSearch] = useState('');
  const [isErrorAfterSearch, setIsErrorAfterSearch] = useState(false);
  const [providerCardError, setProviderCardError] = useState('');
  const [showPlaceholder, setShowPlaceholder] = useState(true);
  const [getStatus, setStatus] = useState({});
  const [statusValue, setStatusValue] = useState(false);
  const [showNotifyModel, setShowNotifyModel] = useState(false);
  const [currentValue, setCurrentValue] = useState('');
  const [defaultInputValue, setDefaultdefaultInputValue] = useState(null);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [searchClicked, setSearchClicked] = useState(false);

  // Handlers
  const closeModalHandler = (item, name) => {
    if (isClientPageFlag) {
      dispatch(actions.clearSearchClientPortalProviders());
      closeModal(item, name);
    } else {
      dispatch(actions.clearSearchRosterProviders());
      closeModal(true, name);
    }
    setDefaultdefaultInputValue(null);
  };

  const closeNotifyModal = () => {
    setShowNotifyModel(false);
  };

  const searchClientPortalProviders = () => {
    if (searchRequest.searchType != '' && searchRequest.searchValue != '') {
      setShowSpinner(true);
      if (searchFieldValidation()) {
        if (isClientPageFlag) {
          dispatch(actions.searchClientPortalProviders(searchRequest, setShowSpinner));
        } else {
          let payload = {
            Page: 1,
            PageSize: 1,
            searchType: searchRequest.searchType,
            searchValue: searchRequest.searchValue,
            setSession: false,
            SortBy: 'name',
            UserId: profileInfo.userId
          };
          dispatch(actions.searchRosterProviders(payload, setShowSpinner));
        }
        setShowPlaceholder(false);
      } else {
        setShowSpinner(false);
        setShowPlaceholder(true);
      }
    }
  };

  const filterArray = (arr1, arr2) => {
    let value1 = arr1.map((item) => item.trim());
    let value2 = arr2.map((item) => item.trim());
    const filtered = value1.filter((el) => {
      return value2.indexOf(el) === -1;
    });
    return filtered;
  };

  const searchedProvidersValidation = () => {
    let searchedList =
      searchField.current != undefined && searchField.current != null
        ? searchField.current.value
            .trim()
            .toUpperCase()
            .split(/\s*[\s,]\s*/)
        : [];
    let missingProviders = [];

    if (searchedList.length > constantProvidersList.length) {
      let providerSearchResults =
        searchRequest.searchType == 'pwid'
          ? constantProvidersList.map((provider) => provider.pwid)
          : constantProvidersList.map((provider) => provider.npi);
      missingProviders = searchedList.filter((val) => !providerSearchResults.includes(val));
      setIsErrorAfterSearch(true);
      let moreErrors = [];
      if (validationResult != null) {
        let _missingProviders = [];
        if (
          validationResult.DuplicateProviders != undefined &&
          validationResult.DuplicateProviders != ''
        ) {
          let _duplicateProviders = validationResult.DuplicateProviders.split(',');
          _missingProviders = missingProviders =
            missingProviders.length > 0 && filterArray(missingProviders, _duplicateProviders);

          moreErrors.push(
            validationResult.DuplicateErrorMessage + ' : ' + validationResult.DuplicateProviders
          );
        }
        if (
          validationResult.ClientConflictProviders != undefined &&
          validationResult.ClientConflictProviders != ''
        ) {
          let _otherClientsProviders = validationResult.ClientConflictProviders.split(',');
          _missingProviders = missingProviders =
            missingProviders.length > 0 && filterArray(missingProviders, _otherClientsProviders);
          moreErrors.push(
            validationResult.ClientConflictErrorMessage +
              ' : ' +
              validationResult.ClientConflictProviders
          );
        }
        if (!_.isEmpty(validationResult.InvalidProviders)) {
          let _otherClientsProviders = validationResult.InvalidProviders.split(',');
          _missingProviders = missingProviders =
            missingProviders.length > 0 && filterArray(missingProviders, _otherClientsProviders);
          moreErrors.push(
            validationResult.InvalidErrorMessage + ' : ' + validationResult.InvalidProviders
          );
        }

        _missingProviders.length > 0
          ? moreErrors.push(
              `We found no matches for ${
                _missingProviders.length
              } code(s): ${_missingProviders.join(', ')}`
            )
          : _missingProviders.length == 0 && missingProviders.length > 0
          ? moreErrors.push(
              `We found no matches for ${missingProviders.length} code(s): ${missingProviders.join(
                ', '
              )}`
            )
          : '';
      }
      generateErrorResponse(moreErrors);
    } else {
      clearErrorsForSearch();
      setErrorMsgSearch('');
    }
  };

  const generateErrorResponse = (errors) => {
    let result = '';
    errors.map((item, index) => {
      result = result.concat(item + '</br>');
    });
    setErrorMsgSearch(result);
  };

  const searchFieldValidation = () => {
    let requestArray =
      searchField.current != null
        ? searchField.current.value
            .trim()
            .toUpperCase()
            .split(/\s*[\s,]\s*/)
        : [];
    let pwidRegex = /^[a-zA-Z0-9s]+([,\r\n][sa-zA-Z0-9]+)*$/;
    let npiRegex = /^[0-9]{10}$/;

    let isSearchFieldValid = true;
    setShowPlaceholder(true);
    if (
      searchRequest.searchType == 'pwid' &&
      searchField.current != null &&
      searchField.current.value.length > 1
    ) {
      isSearchFieldValid = requestArray.every((val) => pwidRegex.test(val));
      isSearchFieldValid
        ? (setIsSearchError(false), setErrorMsgSearch(''), setShowPlaceholder(true))
        : (setIsSearchError(true), setErrorMsgSearch('PWID must contain only alphanumeric'));
    } else if (searchField.current != null && searchField.current.value.length > 1) {
      isSearchFieldValid = requestArray.every((val) => npiRegex.test(val));
      isSearchFieldValid
        ? (setIsSearchError(false), setErrorMsgSearch(''), setShowPlaceholder(true))
        : (setIsSearchError(true), setErrorMsgSearch('NPI must contain 10 digit numbers'));
    } else {
      setIsSearchError(false);
      setErrorMsgSearch('');
      setIsErrorAfterSearch(false);
      setShowPlaceholder(true);
    }
    return isSearchFieldValid;
  };

  const searchTypeChangeHandler = (e) => {
    e.persist();
    setSearchRequest((prevState) => ({
      ...prevState,
      searchType: e.target.value,
      searchValue: ''
    }));
  };

  const searchValueChangeHandler = (e) => {
    setSearchClicked(true);
    clearErrorsForSearch();
    setConstantProvidersList([]);
    let formattedValues = searchField.current.value.trim().split(/\s*[\s,]\s*/);
    if (!_.isEmpty(currentRole) && currentRole.toLowerCase() == 'provider') {
      if (Number(totalProviders) > 0) {
        setIsSearchError(true);
        setErrorMsgSearch('Provider already exist. You can only add one provider.');
      } else if (formattedValues.length > 1) {
        setIsSearchError(true);
        setErrorMsgSearch('You can only add one provider.');
      } else {
        setIsSearchError(false);
        setSearchRequest((prevState) => ({
          ...prevState,
          searchValue: formattedValues.join(','),
          pageSize: formattedValues.length
        }));
      }
    } else {
      setSearchRequest((prevState) => ({
        ...prevState,
        searchValue: formattedValues.join(','),
        pageSize: formattedValues.length
      }));
    }
  };

  const clearErrorsForSearch = () => {
    setShowPlaceholder(true);
    setIsSearchError(false);
    setIsErrorAfterSearch(false);
  };

  const getClientValidateData = async (val, providerList) => {
    var updatedDesignateProvider = providerList.filter(
      (x) => x.employmentType != 'Standard'
    ).length;
    let sProvidersCount =
      sponsoredProvidersCount != undefined ? sponsoredProvidersCount.standard : 0;
    let totalDesignateProviders = Number(totalProviders - sProvidersCount);
    var payload = {
      ClientCode: profileInfo.clientCode,
      TotalProviders: totalDesignateProviders + Number(updatedDesignateProvider),
      IsProviderAdd: val
    };
    return await _pService
      .getValidateStatus(payload)
      .then((res) => {
        if (res.status == 200) {
          let pData = objectToCamel(res.data || []);
          if (pData.isError && Number(updatedDesignateProvider) > 0) {
            setStatus(pData.errorMessage);
            return true;
          } else {
            return false;
          }
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const addProviderClickHandler = (validateResult) => {
    var clientData = clientDataCode.filter((x) => x.clientCode == profileInfo.clientCode);
    var pMaximum = clientData.length > 0 ? clientData[0].maxProviderCount : 0;
    var designationStatus = false;
    var desingationData = [];
    if (isClientPageFlag) {
      if (!profileInfo.isImpersonate) {
        var StandardProviderCount = providersList.filter(
          (x) => x.employmentType == 'Standard'
        ).length;
        if (validateResult) {
          desingationData =
            (validateResult &&
              StandardProviderCount > 0 &&
              providersList
                .map(
                  (x) =>
                    x.employmentType == 'Standard' && {
                      pwid: x.pwid,
                      facilityCode: x.facility.FacilityCode,
                      facilityName: x.facility.FacilityName,
                      employmentType: x.employmentType
                    }
                )
                .filter((x) => x != false)) ||
            [];
          var providerDesignationCount = providersList.filter(
            (x) => x.employmentType != 'Standard'
          ).length;
          let sProvidersCount =
            sponsoredProvidersCount != undefined ? sponsoredProvidersCount.standard : 0;
          let totalDesignateProviders = pMaximum - Number(totalProviders - sProvidersCount);
          var designation =
            Number(Number(totalProviders - sProvidersCount) + providerDesignationCount) - pMaximum;
          designationStatus = totalDesignateProviders >= 0 ? true : false;
          if (designationStatus) {
            var updateDesignationData = providersList
              .slice(0, Number(providerDesignationCount - designation))
              .map(
                (x) =>
                  x.employmentType != 'Standard' && {
                    pwid: x.pwid,
                    facilityCode: x.facility.FacilityCode,
                    facilityName: x.facility.FacilityName,
                    employmentType: x.employmentType
                  }
              )
              .filter((x) => x != false);
            if (updateDesignationData.length > 0) {
              desingationData.push(...updateDesignationData);
              getDisplayMessage(Number(totalDesignateProviders), Number(providerDesignationCount));
            } else {
              designationStatus = true;
            }
          } else if (pMaximum < Number(totalProviders - sProvidersCount)) {
            designationStatus = true;
          }
        } else if (!validateResult) {
          desingationData =
            providersList.map((prov) => ({
              pwid: prov.pwid,
              facilityCode: prov.facility.FacilityCode,
              facilityName: prov.facility.FacilityName,
              employmentType: prov.employmentType
            })) || [];
        }
      } else {
        designationStatus = false;
        desingationData =
          providersList.map((prov) => ({
            pwid: prov.pwid,
            facilityCode: prov.facility.FacilityCode,
            facilityName: prov.facility.FacilityName,
            employmentType: prov.employmentType
          })) || [];
      }
      let errorElements = document.getElementsByClassName('provider-search-card error');
      errorElements.length > 0
        ? errorElements[0].scrollIntoView({ behavior: 'smooth', block: 'end' })
        : profileInfo.isImpersonate
        ? dispatch(
            actions.addClientPortalProvidersToRoster(
              {
                userId: profileInfo.userId,
                clientCode: profileInfo.clientCode,
                designationInfo: desingationData.map((prov) => ({
                  pwid: prov.pwid,
                  facilityCode: prov.facilityCode,
                  facilityName: prov.facilityName,
                  employmentType: prov.employmentType
                }))
              },
              setShowSpinner
            )
          )
        : addingProvidersServiceCall(
            desingationData,
            validateResult,
            StandardProviderCount,
            designationStatus
          );
    } else {
      let payload = providersList.map((prov) => ({
        pwid: prov.pwid
      }));
      let stringpwid = payload.reduce((result, item) => {
        return `${result}${item.pwid},`;
      }, '');
      dispatch(actions.rosterAddProviders(stringpwid, searchRequest.userId, setShowSpinner));
    }
  };

  const getDisplayMessage = (totalAdded, totalDesignate) => {
    let displayMessage = `<p>Please note that we are allowing to add ${totalAdded} designated ${
      totalAdded == 1 ? 'provider' : 'providers'
    } out of ${totalDesignate} selected providers. <a href='/contactus'>Contact support</a> if you need assistance.</p>`;
    setStatus(displayMessage);
  };

  const addingProvidersServiceCall = (
    desingationData,
    validateResult,
    StandardProviderCount,
    designationStatus
  ) => {
    if (designationStatus) {
      setCurrentValue(searchField.current.value);
      setShowSpinner(false);
      setShowNotifyModel(true);
    } else {
      setCurrentValue('');
      if (!validateResult || StandardProviderCount > 0 || designationStatus) {
        dispatch(
          actions.addClientPortalProvidersToRoster(
            {
              userId: profileInfo.userId,
              clientCode: profileInfo.clientCode,
              designationInfo: desingationData.map((prov) => ({
                pwid: prov.pwid,
                facilityCode: prov.facilityCode,
                facilityName: prov.facilityName,
                employmentType: prov.employmentType
              }))
            },
            setShowSpinner
          )
        );
      } else {
        setShowSpinner(false);
        setShowNotifyModel(true);
      }
    }
  };

  const updateProvider = (provider) => {
    let providerIndex = providersList.findIndex((prov) => {
      return prov.pwid == provider.pwid;
    });
    let newProviderList = [...providersList];
    newProviderList[providerIndex] = provider;
    setprovidersList(newProviderList);
    getClientValidateData(true, newProviderList).then((res) => {
      setStatusValue(res);
    });
  };

  const removeProviderHandler = (pwid) => {
    let newProviderList = [...providersList];
    let newProvList = newProviderList.filter((prov) => {
      return prov.pwid != pwid;
    });
    setprovidersList([...newProvList]);
    getClientValidateData(true, [...newProvList]).then((res) => {
      setStatusValue(res);
    });
  };

  const confirmToAdd = () => {
    addProviderClickHandler(statusValue);
  };

  const searchOnChangeHandler = (e) => {
    let isFieldValid = searchFieldValidation();
    setDisable(!isFieldValid);
  };

  const searchProviders = () => {
    if (clientAdminPage == CLIENT_ADMIN_PAGE) {
      if (searchField.current == null && currentValue != undefined && currentValue != '') {
        let defaultValue = {
          value: currentValue
        };
        searchField.current = defaultValue;
        setDefaultdefaultInputValue(currentValue);
      }
    }
  };

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const errorMessageJsx = (
    <div
      className='error-msg'
      dangerouslySetInnerHTML={{
        __html: errorMsgSearch
      }}></div>
  );

  // UseEffects
  useEffect(() => {
    if (result != undefined && result != null) {
      if (Object.keys(result).length > 0) {
        let obj = {
          isError: result.isError,
          errorResponse: result.errorResponse
        };
        setResultObject(obj);
        closeModalHandler(true, '');
      }
    } else {
      setprovidersList([]);
      setWarningFlag(true);
      setIsSearchError(true);
      setErrorMsgSearch('We found no matches');
      setTimeout(() => {
        setWarningFlag(false);
      }, 3000);
    }
  }, [result]);

  useEffect(() => {
    if (totalRecords > 0 && !_.isEmpty(providerSearchResult)) {
      if (providerSearchResult.length == 0) {
        setWarningFlag(true);
        setTimeout(() => {
          setWarningFlag(false);
        }, 5000);
      } else setWarningFlag(false);
    }
  }, [providerSearchResult, totalRecords, validationResult]);

  useEffect(() => {
    let tempProviderList = [];
    let isProviderData =
      providerSearchResult != undefined && providerSearchResult.length > 0
        ? providerSearchResult.map((i) => i.ProviderCode != undefined).some((x) => x != false)
        : false;
    if (isProviderData) {
      providerSearchResult.forEach((provider) => {
        tempProviderList.push({
          pwid: provider.ProviderCode,
          displayName: provider.DisplayName,
          npi: provider.NPI,
          location: provider.Location,
          facility: { FacilityCode: '', FacilityName: '' },
          employmentType: provider.ProfileType,
          isSponsored: provider.IsSponsored,
          validation: { isEmploymentValid: true, isFacilityValid: true }
        });
      });
      setprovidersList(tempProviderList);
      setConstantProvidersList(tempProviderList);
      getClientValidateData(true, tempProviderList).then((res) => {
        setStatusValue(res);
      });
    } else {
      setprovidersList([]);
    }
  }, [providerSearchResult]);

  useEffect(() => {
    if (!_.isEmpty(employmentTypes)) {
      let isEmployedAffiliated =
        employmentTypes.findIndex((type) => {
          return (
            type.toLowerCase().includes('employed') || type.toLowerCase().includes('affiliated')
          );
        }) > -1;
      if (isEmployedAffiliated && !_.isEmpty(facilities) && facilities.length == 0)
        setEmploymentTypeList(['Standard']);
      else setEmploymentTypeList([...employmentTypes]);
    }
  }, [employmentTypes, facilities]);

  useEffect(() => {
    searchOnChangeHandler();
    searchClientPortalProviders(searchRequest);
  }, [searchRequest]);

  useEffect(() => {
    searchedProvidersValidation();
    providersList.every(
      (prov) => prov.validation.isEmploymentValid && prov.validation.isFacilityValid
    )
      ? setProviderCardError('')
      : setProviderCardError('Please provide Valid Input for providers.');
    // END

    let count = 0;
    if (providersList.length > 0) {
      setResultObject({
        isError: false,
        errorResponse: []
      });
      providersList.filter((i) => {
        i.validation.isEmploymentValid == false || i.validation.isFacilityValid == false
          ? (count = count + 1)
          : count;
      });
      if (count > 0) setButtonDisabled(true);
      else setButtonDisabled(false);
    } else if (providersList.length < 1) {
      setButtonDisabled(true);
    }
  }, [providersList]);

  useEffect(() => {
    setIsSearchError(isSearchError);
    setErrorMsgSearch(errorMsgSearch);
  }, [isSearchError, searchField]);

  useEffect(() => {
    setErrorMsgSearch(errorMsgSearch);
  }, [isErrorAfterSearch]);

  useEffect(() => {
    Modal.setAppElement('body');
  });

  useEffect(() => {
    if (clientAdminPage == CLIENT_ADMIN_PAGE) {
      setDefaultdefaultInputValue(null);
    }
  }, [showModal]);

  useEffect(() => {
    if (!_.isEmpty(validationResult) && !_.isEmpty(validationResult.InvalidProviders)) {
      searchedProvidersValidation();
    }
  }, [validationResult]);

  useEffect(() => {
    if (errorMsg !== undefined && errorMsg !== '') {
      setIsSearchError(true);
      setErrorMsgSearch(
        `Search could not be completed at this time.  Please wait a moment and then try your search again.  If you continue seeing this message, please contact <a href="/contactus">Customer Support</a>.`
      );
    } else {
      setIsSearchError(false);
      setErrorMsgSearch('');
    }
  }, [errorMsg]);

  useEffect(() => {
    setSearchClicked(false);
  }, [errorMsg, searchClicked]);

  return (
    <Fragment>
      {!showNotifyModel && (
        <ReactModal
          overlayClassName='roster-modal-overlay'
          className='modal-dialog-add'
          ariaHideApp={true}
          isOpen={showModal}
          contentLabel='Create Roster User'
          onRequestClose={() => closeModalHandler(false, '')}
          shouldCloseOnEsc={false}
          shouldCloseOnOverlayClick={false}>
          <div className='model-window'>
            <div className='model-container'>
              <Fragment>
                <div className='close'>
                  <img
                    className='close-icon'
                    src={cross}
                    alt='close'
                    onClick={() => closeModalHandler(false, 'close-icon')}
                  />
                </div>
                <div className='add-provider-modal-row'>
                  <div className='search-container'>
                    <h3 className='search-container-title'>Add Providers to Roster</h3>
                    <div className='text-note inform-note'>
                      Note : Please note it may take 24-48 business hours to designate the
                      providers.
                    </div>
                    <div className='filter-container'>
                      <div className='radiobtn-container'>
                        <RadioGroup
                          radioGroup={radioOptions}
                          selectedOption={searchRequest.searchType}
                          onChangeHandler={searchTypeChangeHandler}
                        />
                      </div>
                    </div>
                    <div className='search-grp'>
                      <div className='text-box' onBlur={searchProviders()}>
                        <textarea
                          rows='10'
                          ref={searchField}
                          defaultValue={
                            clientAdminPage == CLIENT_ADMIN_PAGE ? defaultInputValue : ''
                          }
                          onChange={(e) => searchOnChangeHandler(e)}
                          className='search-textbox'></textarea>
                      </div>
                      <div className='filter-btn-section'>
                        <button
                          onClick={searchValueChangeHandler}
                          disabled={disable}
                          className={`btn ${!disable && 'enable-btn'}`}>
                          Search
                        </button>
                      </div>
                    </div>

                    {showPlaceholder && !isSearchError && !isErrorAfterSearch && (
                      <div className='helper-text'>
                        {` ${
                          searchRequest.searchType == 'npi'
                            ? 'E.g. 901298017 (separate multiple codes using commas or line breaks)'
                            : 'E.g. 33L3G (separate multiple codes using commas or line breaks) '
                        }`}
                      </div>
                    )}
                    {(isSearchError || (!isSearchError && isErrorAfterSearch)) && errorMessageJsx}
                  </div>
                  {providersList.length > 0 && !isSearchError && (
                    <Fragment>
                      <div className='provider-section'>
                        <div className='provider-card'>
                          <div className='selected-providers'>
                            Selected Providers ({providersList.length})
                            {isErrorAfterSearch && (
                              <div className='error-msg'>{providerCardError}</div>
                            )}
                          </div>

                          <div className='scrollbar' id='scrollbar-styles'>
                            <div className='provider-container'>
                              {providersList.map((provider, index) => (
                                <Fragment key={index}>
                                  <ProviderCard
                                    provider={provider}
                                    facilities={facilities}
                                    employmentTypes={employmentTypeList}
                                    removeProviderHandler={removeProviderHandler}
                                    updateProviderHandler={updateProvider}
                                    key={index}
                                    indexValue={index}
                                    totalProviders={providersList.length}
                                    isRosterPage={rosterPage == ROSTER_PAGE ? true : false}
                                  />
                                </Fragment>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      {isClientPageFlag && (
                        <div className='text-note confirm-note'>
                          Note : Please verify that your designation types are correct before
                          proceeding.
                        </div>
                      )}
                      <div className='btn-grp'>
                        <button
                          className='btn-submit-cancel'
                          onClick={(event) => closeModalHandler(false, 'close-icon')}>
                          Cancel
                        </button>
                        <button
                          disabled={buttonDisabled}
                          className='btn-submit-add'
                          onClick={confirmToAdd}>
                          Add
                        </button>
                      </div>
                    </Fragment>
                  )}
                </div>
              </Fragment>
            </div>
          </div>
        </ReactModal>
      )}
      {showNotifyModel && (
        <ReactModal
          overlayClassName='roster-modal-overlay notification-modal-popup'
          className='notify-dialog'
          ariaHideApp={false}
          isOpen={showNotifyModel}
          contentLabel='notify-model'
          onRequestClose={closeNotifyModal}
          shouldCloseOnOverlayClick={false}>
          <div className='model-window-section'>
            <div className='model-container'>
              <div className='close'>
                <img className='close-icon' src={cross} alt='close' onClick={closeNotifyModal} />
              </div>
              <div className='modal-client-row'>
                <div className='title-sec'>{'Alert!'}</div>
                <div className='notification-text'>
                  {!isEmpty(getStatus) && (
                    <div
                      dangerouslySetInnerHTML={{
                        __html: `${getStatus}`
                      }}></div>
                  )}
                </div>
                <div>
                  <button onClick={closeNotifyModal} className='cancel-btn'>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ReactModal>
      )}
      {showSpinner && <Spinner cta={true} />}
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </Fragment>
  );
};

AddProviderModal.propTypes = {
  showModal: PropTypes.bool,
  closeModal: PropTypes.func,
  toggleModal: PropTypes.func,
  currentRole: PropTypes.string
};

AddProviderModal.defaultProps = {
  currentRole: ''
};
export default AddProviderModal;
