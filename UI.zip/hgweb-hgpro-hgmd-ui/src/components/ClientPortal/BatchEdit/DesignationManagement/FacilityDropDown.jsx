import React, { useState } from 'react';
import _ from 'lodash';

import DownArrow from '../../../../assets/images/down-arrow.svg';
import AutoSuggestCheckboxAlreadySelection from '../../../Common/Form/AutoSuggest/AutoSuggestCheckboxAlreadySelection';

const FacilityDropDown = (props) => {
  const {
    selectedItem,
    clientFacility,
    isOpen,
    showFacilityDropDown,
    showMultiFacilities,
    currentFacArr
  } = props;

  const [_clientFacility, setClientFacility] = useState(
    !_.isEmpty(currentFacArr)
      ? _.forEach(clientFacility, (i) => {
          if (_.some(currentFacArr, { code: i.FacilityCode })) {
            i.Checked = true; //i.Disabled = true;
          } else {
            i.Checked = false;
          }
        })
      : []
  );
  const [searchText, setSearchText] = useState('');
  const [_clientFacArr, setClientFacArr] = useState(
    clientFacility.map((con) => ({
      ...con,
      Id: con.FacilityCode,
      Text: con.FacilityName,
      Checked: con.Checked,
      Disabled: con.Checked
    }))
  );
  const autosuggestOptions = {
    placeholder: 'Select facility to designate',
    initialValue: searchText,
    data: _clientFacArr,
    onInputChangeHandler: (event) => {
      setSearchText(event.currentTarget.value);
      props.showDropdown(!_.isEmpty(event.currentTarget.value));
    },
    onSuggestSelectHandler: () => {},
    setCurrentSelection: false,
    showValidationMsg: true,
    isSearch: true
  };

  const onCloseHandler = () => {
    props.toggleDropdown();
  };

  const onSaveClickHandler = (suggestData) => {
    let filterSelection = _.filter(suggestData, (j) => j.Checked === true);
    if (!_.isEmpty(filterSelection)) {
      props.toggleDropdown();
      props.updateClientFac(filterSelection);
    }
  };

  return (
    <div className='select-option'>
      <div>Select Facility</div>
      {!showMultiFacilities && (
        <div className='dropdown'>
          <div
            className={`dropdown-header ${selectedItem ? 'temp' : ''}`}
            onClick={() => props.toggleDropdown()}>
            {selectedItem && !_.isEmpty(clientFacility)
              ? clientFacility.find((item) => item.FacilityCode == selectedItem).FacilityName
              : 'Select facility'}
            <img
              className={`${selectedItem} ? icon ${isOpen && ''} : icon ${isOpen && 'open'} `}
              src={DownArrow}></img>
          </div>

          {showFacilityDropDown && !_.isEmpty(_clientFacArr) && (
            <div className={`dropdown-body open`}>
              {_clientFacArr.map((item, index) => (
                <div
                  className='dropdown-item'
                  onClick={(e) => props.handleItemClick(e, item.FacilityCode, item.FacilityName)}
                  id={item.FacilityCode}
                  key={item.FacilityCode}>
                  <span
                    className={`dropdown-item-dot ${
                      item.FacilityCode == selectedItem ? 'selected' : ''
                    }`}></span>
                  <b> {item.FacilityName}</b>
                  <br />
                  {item.FacilityCode}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showMultiFacilities && (
        <div className='title'>
          <AutoSuggestCheckboxAlreadySelection
            id='autosuggest-checkbox'
            label=''
            name=''
            placeholder={autosuggestOptions.placeholder}
            initialValue={autosuggestOptions.initialValue}
            data={autosuggestOptions.data}
            setCurrentSelection={autosuggestOptions.setCurrentSelection}
            showValidationMsg={autosuggestOptions.showValidationMsg}
            isSearch={autosuggestOptions.isSearch}
            buttonNames={[`Add to list`, 'Cancel']}
            isFocusOut={false}
            showList='enable'
            isOpen={isOpen}
            showCount={true}
            onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
            onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
            onSaveClick={onSaveClickHandler}
            onCancelClick={onCloseHandler}
            currentFacArr={currentFacArr}
          />
        </div>
      )}
    </div>
  );
};

export default FacilityDropDown;
