import React, { Fragment, useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { RadioGroup } from '../../../FormComponents/RadioGroup';
import FacilityDropDown from './FacilityDropDown';
import * as _pService from '../../../../utils/serviceCalls/clientPortal';
import _ from 'lodash';

import './_assignDesigationModalContent.less';

const AssignDesigationModalContent = (props) => {
  const {
    name,
    radioSelect,
    setSelectedOption,
    clientFacility,
    employmentType,
    selectedItemHandler,
    desinagtionRadioSelect,
    setSelectedDesignationOption,
    currentFacArr,
    showMultiFacilities,
    selectedMultiFacilitiesHandler,
    disableOtherProviderType,
    initRadioSelect
  } = props;

  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedFacilityName, setSelectedFacilityName] = useState(null);
  const [isOpen, setOpen] = useState(false);
  const [showFacilityDropDown, setShowFacilityDropDown] = useState(false);
  const [selectedMultiFacArr, setSelectedMultiFacArr] = useState([]);
  const [_clientFacilityToBeDeDesignate, setClientFacilityToBeDeDesignate] = useState(
    !_.isEmpty(currentFacArr)
      ? _.forEach(currentFacArr, (i) => {
          {
            i.Checked = false;
          }
        })
      : []
  );

  let radioOptions = [];

  employmentType.map((item, index) => {
    if (item !== 'Standard') {
      radioOptions.push({
        Name: item,
        Value: item,
        Show: true
      });
    }
  });

  const assignTypeRadioOption = [
    {
      Name: 'Designate',
      Value: 'Designate',
      Show: true,
      disabled: showMultiFacilities ? false : desinagtionRadioSelect !== 'Designate'
    },
    {
      Name: 'De-designate',
      Value: 'De-designate',
      Show: true,
      disabled: showMultiFacilities
        ? initRadioSelect == 'Standard' ||
          (_clientFacilityToBeDeDesignate.filter((i) => _.isEmpty(i.code)).length ==
            _clientFacilityToBeDeDesignate.length &&
            initRadioSelect != 'Standard')
        : _.isEmpty(desinagtionRadioSelect)
        ? false
        : desinagtionRadioSelect !== 'De-designate'
    }
  ];

  const showFacDropdown = showMultiFacilities
    ? !_.isEmpty(radioSelect) && radioSelect != 'Standard' && !_.isEmpty(desinagtionRadioSelect)
    : !_.isEmpty(radioSelect) &&
      !_.isEmpty(desinagtionRadioSelect) &&
      desinagtionRadioSelect !== 'De-designate' &&
      !(Array.isArray(clientFacility) && !clientFacility.length);

  const showValDedesignating = desinagtionRadioSelect === 'De-designate' && !showMultiFacilities;

  const showFacilitiesForDedesignate =
    showMultiFacilities && desinagtionRadioSelect === 'De-designate';

  const handleItemClick = (e, code, fname) => {
    selectedItem == code ? setSelectedItem(null) : setSelectedItem(code);
    selectedFacilityName == fname ? setSelectedFacilityName(null) : setSelectedFacilityName(fname);
    setShowFacilityDropDown(false);
  };

  const toggleDropdown = () => {
    setOpen(!isOpen);
    setShowFacilityDropDown(!showFacilityDropDown);
  };

  const updateClientFac = (arr) => {
    setSelectedMultiFacArr(arr);
  };

  const inputChangeHandler = (isChecked, item) => {
    let _tempSuggestData = [...selectedMultiFacArr];
    let tempMultiSelectionArr = _tempSuggestData.map((data) => {
      if (data.Id == item.Id) {
        return { ...data, Checked: isChecked };
      } else {
        return { ...data };
      }
    });
    setSelectedMultiFacArr(_.filter(tempMultiSelectionArr, (j) => j.Checked === true));
  };

  const inputChangeHandlerForDedesignate = (isChecked, item) => {
    let _tempSuggestData = [..._clientFacilityToBeDeDesignate];
    let tempMultiSelectionArr = _tempSuggestData.map((data) => {
      if (data.code == item.code) {
        return { ...data, Checked: isChecked };
      } else {
        return { ...data };
      }
    });
    let arr = _.filter(tempMultiSelectionArr, (j) => j.Checked === true).map((i) => {
      return {
        FacilityCode: i.code,
        FacilityName: i.name
      };
    });
    setSelectedMultiFacArr(arr);
    setClientFacilityToBeDeDesignate(tempMultiSelectionArr);
  };

  const radioOnchangeHandler = (e) => {
    setSelectedMultiFacArr([]);
    setSelectedDesignationOption(e);
  };

  const showDropdown =(val)=>{
    setOpen(val);
    setShowFacilityDropDown(val);
  }

  useEffect(() => {
    setSelectedItem(selectedItem);
    selectedItemHandler(selectedItem, selectedFacilityName);
  }, [handleItemClick]);

  useEffect(() => {
    selectedMultiFacilitiesHandler(selectedMultiFacArr);
  }, [selectedMultiFacArr]);

  return (
    <Fragment>
      <div className={`designation-modal-row`}>
        <div className='designation-container'>
          <h3 className='designation-title'>{name} - Assign Designation</h3>

          {/* --Assign Type -- Desigatation/ de- desigantion  */}
          <div className='radioselect-provider-type'>
            <div>Assign Type</div>
            {assignTypeRadioOption != [] && (
              <div className='radioselect'>
                <RadioGroup
                  radioGroup={assignTypeRadioOption}
                  selectedOption={desinagtionRadioSelect}
                  onChangeHandler={radioOnchangeHandler}
                  disabled={false}
                />
              </div>
            )}
          </div>

          {/* --Provider Type -- Employed/Affiliated/Premium   */}
          {!_.isEmpty(desinagtionRadioSelect) && !_.isEmpty(initRadioSelect) && (
            <div className='radioselect-provider-type'>
              <div>Profile Type</div>
              {radioOptions != [] && (
                <div
                  id='designation-radio-select'
                  className={`radioselect ${
                    desinagtionRadioSelect == 'De-designate'
                      ? 'designation-radio-select-disabled'
                      : ''
                  }`}
                  disabled={desinagtionRadioSelect == 'De-designate'}>
                  <RadioGroup
                    radioGroup={radioOptions}
                    selectedOption={radioSelect}
                    onChangeHandler={setSelectedOption}
                    disabled={
                      showMultiFacilities
                        ? initRadioSelect != 'Standard'
                        : desinagtionRadioSelect == 'De-designate'
                    }
                  />
                </div>
              )}
            </div>
          )}

          {/* --Facility Type - dropdown */}
          {showFacDropdown && !showFacilitiesForDedesignate && (
            <FacilityDropDown
              selectedItem={selectedItem}
              clientFacility={clientFacility.map((j) => {
                return {
                  FacilityCode: j.FacilityCode,
                  FacilityName: j.FacilityName,
                  Checked: false,
                  Disabled: false
                };
              })}
              isOpen={isOpen}
              showFacilityDropDown={showFacilityDropDown}
              showMultiFacilities={showMultiFacilities}
              currentFacArr={currentFacArr}
              toggleDropdown={toggleDropdown}
              handleItemClick={handleItemClick}
              updateClientFac={updateClientFac}
              showDropdown={showDropdown}
            />
          )}

          {/* --Facility Type */}
          {!_.isEmpty(selectedMultiFacArr) && !isOpen && !showFacilitiesForDedesignate && (
            <div className='new-selected-fac'>
              <div className='fac-title'>
                New Selected facility {`(${selectedMultiFacArr.length})`}:
              </div>

              {selectedMultiFacArr.map((d, index) => (
                <div className='suggest-item' key={`key-dv-${d.Id}`}>
                  <input
                    key={`key-ip-chk-${d.Id}`}
                    id={`ip-chk-${d.Id}`}
                    type='checkbox'
                    className='item-checkbox'
                    checked={d.Checked}
                    onChange={(event) => {
                      inputChangeHandler(event.currentTarget.checked, d);
                      d.Checked = event.currentTarget.checked;
                    }}></input>
                  <label
                    htmlFor={`ip-chk-${d.Id}`}
                    className={''}
                    key={index}
                    value={d.Id}
                    disabled={false}>
                    <>
                      {d.Text}
                      <span>{`(${d.Id})`}</span>
                    </>
                  </label>
                </div>
              ))}
            </div>
          )}

          {/* --De-designate - for approved */}
          {showFacilitiesForDedesignate &&
            !_.isEmpty(currentFacArr) &&
            !_.isEmpty(_clientFacilityToBeDeDesignate) && (
              <div className='radioselect-provider-type'>
                <div className='fac-title'>
                  Designated facility
                  {` (${currentFacArr.filter((p) => !_.isEmpty(p.code)).length})`}:
                </div>
                <div>Assign type</div>
                <div className='new-selected-fac div-de-designation'>
                  {_clientFacilityToBeDeDesignate.map(
                    (d, index) =>
                      !_.isEmpty(d.code) && (
                        <div className='suggest-item' key={`key-dv-${d.code}`}>
                          <input
                            key={`key-ip-chk-${d.code}`}
                            id={`ip-chk-${d.code}`}
                            type='checkbox'
                            className='item-checkbox'
                            checked={d.Checked}
                            onChange={(event) => {
                              inputChangeHandlerForDedesignate(event.currentTarget.checked, d);
                              d.Checked = event.currentTarget.checked;
                            }}></input>
                          <label
                            htmlFor={`ip-chk-${d.code}`}
                            className={''}
                            key={index}
                            value={d.code}
                            disabled={false}>
                            <>
                              {d.name}
                              <span className='fac-text'> ({d.code})</span>
                            </>
                          </label>
                        </div>
                      )
                  )}
                </div>
              </div>
            )}

          {/* --De-desigantion div- for Not approved  */}
          {showValDedesignating &&
            !_.isEmpty(currentFacArr) &&
            !_.isEmpty(currentFacArr.map((j) => j.name)) &&
            !(Array.isArray(clientFacility) && !clientFacility.length) && (
              <div className='radioselect-provider-type'>
                <div className='fac-title'>
                  Designated facility
                  {` (${currentFacArr.filter((p) => !_.isEmpty(p.code)).length})`}:
                </div>
                <div>Assign type</div>
                <div>
                  {currentFacArr.map(
                    (j) =>
                      !_.isEmpty(j.code) && (
                        <>
                          {j.name}
                          <span className='fac-text'> ({j.code})</span>
                        </>
                      )
                  )}
                </div>
              </div>
            )}
        </div>
      </div>
    </Fragment>
  );
};

AssignDesigationModalContent.propTypes = {
  name: PropTypes.string,
  radioSelect: PropTypes.string,
  setSelectedOption: PropTypes.func,
  clientFacility: PropTypes.arrayOf(PropTypes.object),
  employmentType: PropTypes.array,
  selectedItemHandler: PropTypes.func,
  showMultiFacilities: PropTypes.bool
};

AssignDesigationModalContent.defaultProps = {
  showMultiFacilities: false
};

export default AssignDesigationModalContent;
