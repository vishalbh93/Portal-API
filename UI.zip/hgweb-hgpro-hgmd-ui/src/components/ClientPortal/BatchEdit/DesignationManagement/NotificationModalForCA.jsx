import React, { useState } from 'react';
import ReactModal from 'react-modal';
import cross from '../../../../assets/images/exit-icon.svg';
import _ from 'lodash';

const NotificationModalForCA = (props) => {
  const { getStatus, showNotifyModal, closeNotifyModal } = props;
  return (
    <ReactModal
      overlayClassName='roster-modal-overlay notification-modal-popup'
      className='notify-dialog'
      ariaHideApp={false}
      isOpen={showNotifyModal}
      contentLabel='notify-model'
      onRequestClose={closeNotifyModal}
      shouldCloseOnOverlayClick={false}>
      <div className='model-window-section'>
        <div className='model-container'>
          <div className='close'>
            <img className='close-icon' src={cross} alt='close' onClick={closeNotifyModal} />
          </div>
          <div className='modal-client-row'>
            <div className='title-sec'>{'Alert!'}</div>
            <div className='notification-text'>
              {!_.isEmpty(getStatus) && (
                <div
                  dangerouslySetInnerHTML={{
                    __html: `${getStatus}`
                  }}></div>
              )}
            </div>
            <div>
              <button onClick={closeNotifyModal} className='cancel-btn'>
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </ReactModal>
  );
};

export default NotificationModalForCA;
