/* #region imports */
import React, { Fragment, useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
//import style
import './_designationManagement.less';
//import media files
import cross from '../../../../assets/images/exit-icon.svg';
import backIcon from '../../../../assets/images/chevron-left.svg';
import info from '../../../../assets/images/info-circle.svg';
//import components
import Header from '../../../Header/Header';
import PaginationUI from '../../../Pagination/Pagination';
import AssignDesigationModalContent from './AssignDesigationModalContent';
import SearchIcon from '../../../SearchIcon/SearchIcon';
import ProviderTypeTags from '../../RosterViewProviderList/ProviderTypeTags';
import Button from '@hg/joy/src/components/Button';
//service
import * as _pService from '../../../../utils/serviceCalls/clientPortal';
import * as service from '../../../../utils/service';
import * as actions from '../../../../store/actions';
//helper
import { objectToCamel } from '../../../../utils/utils';
import { queryParam } from '../../../../utils/utils';
import * as headerColumn from '../../../../utils/constant-data';
import _ from 'lodash';
import NotificationModalForCA from './NotificationModalForCA';
import Toast from '../../../Common/Toast/Toast';
import { TooltipContent } from '../../../Common/ToolTip/Index';
/* #endregion */

const DesignationManagement = (props) => {
  const {
    providerDisplayName,
    selectedProviders,
    providersFound,
    accountInfo,
    reloadList,
    sponsorInformation,
    currentPage
  } = props;

  const dispatch = useDispatch();
  const { providerList, clientFacilities, employmentTypes } = useSelector(
    (state) => state.getClientPortalDesignationReducer
  );
  const [providersArray, setProvidersArray] = useState(Object.values(selectedProviders));
  const [providersArrayInList, setProvidersArrayInList] = useState([]);
  const [providers, setProviders] = useState(providerList);
  const [clientFacility, setClientFacility] = useState(clientFacilities);
  const [employmentType, setEmploymentType] = useState(employmentTypes);
  const [radioSelect, setRadioSelect] = useState('');
  const [desinagtionRadioSelect, setDesinagtionRadioSelect] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [showDesignationManagementModal, toggleDesignationManagementModal] = useState(false);
  const tempheaderColumns = headerColumn.headerColumnsCPDesignation;
  const showCheckbox = _.isEmpty(sponsorInformation)
    ? false
    : sponsorInformation.isFacility &&
      (sponsorInformation.sponsorType == 'PDCHSP' || sponsorInformation.sponsorType == 'MAP');
  const headerColumns = tempheaderColumns.map((i) => {
    if (i.ColumnName === 'Facility') {
      return { ...i, isShow: showCheckbox };
    }
    return { ...i };
  });
  const [activePage, setActivePage] = useState(1); //(accountInfo.page)
  const [name, setname] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedFacilityName, setSelectedFacilityName] = useState(null);
  const [currentPwid, setCurrentPwid] = useState(null);
  const warningMsg = `Something went wrong, you can contact Healthgrades customer service for assistance.`;
  const [warningFlag, setWarningFlag] = useState(null);
  const { isError, errorResponse, message } = useSelector(
    (state) => state.addRemoveDesignationReducer
  );
  const [currentType, setCurrentType] = useState('');
  const [recordsPerPage, setRecordsPerPage] = useState(accountInfo.recordsPerPage);
  const pageStart = recordsPerPage * (activePage - 1) + 1;
  const pageEnd =
    recordsPerPage * activePage > Number(providersFound)
      ? Number(providersFound)
      : recordsPerPage * activePage;
  const searchInputRef = useRef();
  const [sortOrderAsc, setSortOrderAsc] = useState(false);
  const [disabledBtn, setDisabledBtn] = useState(true);
  const [showPagination, setShowPagination] = useState(true);
  const [clientDataCode, setClientDataCode] = useState([]);
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [getStatus, setStatus] = useState({});
  const [currentFacArr, setCurrentFacArr] = useState({});
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showMultiFacilities, setShowMultiFacilities] = useState(false);
  const _accountInfo = useSelector((state) => state.getAccountDetailsReducer);
  const isMobileView = window.innerWidth <= 768;
  const [designateCount, setDesignateCount] = useState(0);
  const [initRadioSelect, setInitRadioSelect] = useState('');
  const [selectedFacilityArr, setSelectedFacilityArr] = useState(null);
  const [showTooltip, toggleTooltip] = useState({ pwid: '', show: false });
  const _delMenu = useRef(null);

  //Functions
  const handleSearchProvider = () => {
    let searchedProvider = [];
    if (searchInputRef.current.value != null && searchInputRef.current.value != '') {
      searchedProvider = providersArray.filter(function (i) {
        return i.ProviderName.toLowerCase().includes(searchInputRef.current.value.toLowerCase());
      });
      setProvidersArrayInList(searchedProvider);
      setShowPagination(false);
    } else {
      setProvidersArrayInList(providersArray);
      setShowPagination(true);
    }
  };

  const onShowModal = (e, pwid, name, type, val) => {
    onClientSettings();
    setCurrentPwid(pwid);
    toggleDesignationManagementModal(true);
    setname(name);
    //showMultiFacilities ? setDesinagtionRadioSelect('') : setDesinagtionRadioSelect(type);
    setDesinagtionRadioSelect(type);
    let sponsorType = val.SponsorType[0].toUpperCase() + val.SponsorType.substring(1).toLowerCase();
    setRadioSelect(sponsorType);
    setInitRadioSelect(sponsorType);
  };

  const closeModal = () => {
    toggleDesignationManagementModal(false);
    setSelectedItem(null);
    setRadioSelect(null);
    setDesinagtionRadioSelect(null);
  };

  const closeNotifyModal = () => {
    setShowNotifyModal(false);
  };

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const setSelectedOption = (e) => {
    setRadioSelect(e.target.value);
  };

  const setSelectedDesignationOption = (e) => {
    setDesinagtionRadioSelect(e.target.value);
  };

  const designateHandler = async (e, type) => {
    e.persist();
    toggleDesignationManagementModal(false);

    var payload = {
      userId: accountInfo.userId,
      clientCode: accountInfo.clientCode
    };
    let _promises = [];
    let params = queryParam(payload);
    _promises.push(service._get(`/api/clientportal/banner?${params}`, true));
    const _result = await Promise.allSettled(_promises);

    if (_result.every((res) => res.status === 'fulfilled')) {
      var clientDataInfo = objectToCamel(_result.map((res) => res.value.data) || []);
      var designateProviderList = clientDataInfo[0].sponsoredProvidersCount;
      var getValidateStatus = ValidateProviders(type, designateProviderList);
      var isExistingSponsored =
        showMultiFacilities &&
        radioSelect != 'Standard' &&
        currentFacArr.length > 0 &&
        !_.isEmpty(initRadioSelect) &&
        initRadioSelect != 'Standard';
      if (getValidateStatus || isExistingSponsored) {
        let request = {};
        setCurrentType(type);
        if (type == 'Designate') {
          request = {
            userId: accountInfo.userId,
            clientCode: accountInfo.clientCode,
            designationInfo: !showMultiFacilities
              ? [
                  {
                    pwid: currentPwid,
                    facilityCode: selectedItem,
                    facilityName: selectedFacilityName,
                    employmentType: radioSelect
                  }
                ]
              : selectedFacilityArr.map((i) => {
                  return {
                    pwid: currentPwid,
                    facilityCode: i.FacilityCode,
                    facilityName: i.FacilityName,
                    employmentType: radioSelect,
                    allowedMultiple: true
                  };
                })
          };
        } else {
          let providerDesignationData = providers.find((x) => x.Pwid === currentPwid)
            .Designations[0];
          request = {
            userId: accountInfo.userId,
            clientCode: accountInfo.clientCode,
            designationInfo: !showMultiFacilities
              ? [
                  {
                    pwid: currentPwid,
                    facilityCode:
                      providerDesignationData != undefined &&
                      (providerDesignationData.FacilityCode != undefined ||
                        providerDesignationData.FacilityCode != null)
                        ? providerDesignationData.FacilityCode
                        : '',
                    facilityName: '',
                    employmentType: ''
                  }
                ]
              : selectedFacilityArr.map((i) => {
                  return {
                    pwid: currentPwid,
                    facilityCode: i.FacilityCode,
                    facilityName: i.FacilityName,
                    employmentType: radioSelect,
                    allowedMultiple: true
                  };
                })
          };
        }
        dispatch(actions.addRemoveDesignation(request, type));
      } else {
        setShowNotifyModal(true);
      }
    }
  };

  const displayMessage = (min, max) => {
    var displayMessage = `<p>Please note that a minimum of ${min} and a maximum of ${max} people are allowed to be added. <a href='/contactus'>Contact support</a> if you need assistance.</p>`;
    setStatus(displayMessage);
  };

  const ValidateProviders = (type, designateProviderList) => {
    if (currentPage) {
      var clientData =
        clientDataCode != undefined
          ? clientDataCode.filter((x) => x.clientCode == accountInfo.clientCode)
          : [];
      var pMinimum =
        clientData != undefined && clientData.length > 0 ? clientData[0].minProviderCount : 0;
      var pMaximum =
        clientData != undefined && clientData.length > 0 ? clientData[0].maxProviderCount : 0;

      var designateCurrentProviders = Number(
        designateProviderList.total - designateProviderList.standard
      );

      var selectedProviders = providerList.filter((x) => x.Pwid == currentPwid).length;
      if (pMinimum == 0 && pMaximum == 0) {
        return true;
      } else {
        if (type == 'Designate') {
          let totalMaxCount = Number(designateCurrentProviders + selectedProviders);
          if (totalMaxCount > Number(pMaximum)) {
            displayMessage(pMinimum, pMaximum);
            return false;
          }
          return true;
        } else {
          let totalMinCount = Number(designateCurrentProviders - selectedProviders);
          if (totalMinCount < Number(pMinimum)) {
            displayMessage(pMinimum, pMaximum);
            return false;
          }
          return true;
        }
      }
    } else {
      return true;
    }
  };

  const showMessageHandler = (val, check) => {
    let tempFac = [];
    let designationLength = 0;
    if (showMultiFacilities) {
      tempFac = selectedFacilityArr.filter((i) => i.Checked === true);
      designationLength = !_.isEmpty(tempFac) && tempFac.length > 0 ? tempFac.length : 0;
    }

    let successMsg =
      val == 'Designate'
        ? `${
            designationLength > 0
              ? `${designationLength} new facilities designated Successfully assigned to`
              : 'Facility designated Successfully assigned to'
          } ${name}!`
        : `${
            designationLength > 0
              ? `${designationLength} new facilities de-designated Successfully assigned to`
              : 'Facility de-designated Successfully assigned to'
          } ${name}!`;

    check == 'pass'
      ? toaster.Success(successMsg)
      : val == 'Designate'
      ? toaster.Error('Designation failed!')
      : toaster.Error('De-designation failed!');
    setIsSuccess(true);
    let updatedList = Object.values(providersArray).map((item) => {
      if (item.ProviderId == currentPwid && check === 'pass') {
        return {
          ...item,
          SponsorType: currentType == 'Designate' ? radioSelect.toUpperCase() : 'STANDARD'
        };
      }
      return item;
    });

    setTimeout(() => {
      setIsSuccess(false);
      setProvidersArray(updatedList);
      setProvidersArrayInList(updatedList);
      dispatch(actions.addRemoveDesignationClear());
      if (check == 'pass') reloadList(true);
    }, 3000);
  };

  const onSort = () => {
    setSortOrderAsc(!sortOrderAsc);
    sortProviders();
  };

  const sortProviders = () => {
    if (sortOrderAsc) {
      setProvidersArrayInList(
        providersArray
          .sort((a, b) =>
            a.ProviderName.toLowerCase() < b.ProviderName.toLowerCase()
              ? -1
              : b.ProviderName.toLowerCase() > a.ProviderName.toLowerCase()
              ? 1
              : 0
          )
          .slice(0, recordsPerPage)
      );
    } else {
      setProvidersArrayInList(
        providersArray
          .sort((a, b) =>
            a.ProviderName.toLowerCase() > b.ProviderName.toLowerCase()
              ? -1
              : b.ProviderName.toLowerCase() < a.ProviderName.toLowerCase()
              ? 1
              : 0
          )
          .slice(0, recordsPerPage)
      );
    }
  };

  const getClassNameForSponsorstype = (type) => {
    switch (type) {
      case 'AFFILIATED':
        return 'tags_a';
      case 'EMPLOYED':
        return 'tags_e';
      case 'STANDARD':
        return 'tags_s';
      case 'ENHANCED':
        return 'tags_e';
      case 'PREMIUM':
        return 'tags_a';
      default:
        break;
    }
  };

  const onPageChange = (pageNumber) => {
    pageNumber != null ? window.scrollTo(0, 300) : null;

    setActivePage(pageNumber);
  };

  const onPageFilterChange = (perPage) => {
    perPage != null ? window.scrollTo(0, 300) : null;

    setActivePage(1);
    setRecordsPerPage(perPage);
  };

  const selectedItemHandler = (selectedItem, facName) => {
    setSelectedItem(selectedItem);
    setSelectedFacilityName(facName);
  };

  const selectedMultiFacilitiesHandler = (arr) => {
    if (showMultiFacilities)
      _.isEmpty(arr)
        ? setDisabledBtn(true)
        : (setDisabledBtn(false), setDesignateCount(arr.length));
    setSelectedFacilityArr(arr);
  };

  const onClientSettings = () => {
    _pService
      .clientDetails()
      .then((res) => {
        if (res.status == 200) {
          let clientData = objectToCamel(res.data || []);
          setClientDataCode(objectToCamel(JSON.parse(clientData.returnData)));
        }
      })
      .catch((error) => console.error(error));
  };

  const getMultiFacFlag = (clientDataObj) => {
    let data =
      !_.isEmpty(_accountInfo) &&
      !_.isEmpty(_accountInfo.accountInfo.clientCode) &&
      clientDataObj.find((x) => x.clientCode == _accountInfo.accountInfo.clientCode);
    return data;
  };

  const assignHandler = (e, val) => {
    let type = val.SponsorType.toUpperCase() == 'STANDARD' ? 'Designate' : 'De-designate';
    onShowModal(e, val.ProviderId, val.ProviderName, type, val);
    let selectedProviederArr = providerList.filter((i) => i.Pwid === val.ProviderId);
    let obj =
      !_.isEmpty(providerList) &&
      !_.isEmpty(selectedProviederArr) &&
      !_.isEmpty(selectedProviederArr[0].Designations) &&
      selectedProviederArr[0].Designations.map((j) => {
        return { name: j.FacilityName, code: j.FacilityCode };
      });
    val.SponsorType.toUpperCase() !== 'STANDARD'
      ? setCurrentFacArr([...obj])
      : setCurrentFacArr({});
  };

  const viewMore = (currentProviderid) => {
    toggleTooltip(
      _.isEmpty(currentProviderid) ? null : { pwid: currentProviderid, show: !showTooltip.show }
    );
  };

  const showToolTipHandler = (arr) => {
    return (
      !_.isEmpty(arr) && (
        <span className='tooltip-container'>
          <TooltipContent placement={`${isMobileView ? 'bottom' : 'right'}`}>
            {!_.isEmpty(arr) &&
              arr.splice(1).map((i, idx) => {
                return (
                  !_.isEmpty(i.FacilityCode) && (
                    <p key={idx}>
                      <b>{i.FacilityName}</b>
                      {` (${i.FacilityCode})`}
                    </p>
                  )
                );
              })}
          </TooltipContent>
        </span>
      )
    );
  };

  const updateProvidersArray = (providersArray) => {
    !_.isEmpty(providersArrayInList.find((i) => i.ProviderId === currentPwid))
      ? (providersArrayInList.find((i) => i.ProviderId === currentPwid).SponsorType = providerList
          .filter((i) => i.Pwid === currentPwid)[0]
          .Designations[0].DesignationType.toUpperCase())
      : null;
  };

  const btnJSX = (arr, val) => (
    <span>
      <div className='results-grid__view-more-results'>
        <div className='view-more-results' ref={_delMenu}>
          <Button
            id={`grid-view-more-btn-${val.ProviderId}`}
            text={`${arr.length - 1} More`}
            disabled={false}
            className={`view-more-Facilities`}
            size='lg'
            style='ghost'
            onClick={(e) => {
              let designationsArr = [...arr];
              let idMatch = e.target.className.match(/btn-(\w+)/);
              let currentProviderid = _.isEmpty(idMatch) ? '' : idMatch[0].split('-')[1];
              !_.isEmpty(designationsArr) && currentProviderid === val.ProviderId
                ? viewMore(currentProviderid)
                : '';
            }}
          />
          {!_.isEmpty(showTooltip) &&
            showTooltip.pwid === val.ProviderId &&
            showTooltip.show &&
            showToolTipHandler(arr)}
        </div>
      </div>
    </span>
  );

  const getFacilityType = (clientDataCode) => {
    let isMultiFacility = _.isEmpty(props.sponsorInformation)
      ? false
      : props.sponsorInformation.isFacility &&
        (props.sponsorInformation.sponsorType == 'PDCHSP' ||
          props.sponsorInformation.sponsorType == 'MAP');
    if (!_.isEmpty(clientDataCode)) {
      let data = getMultiFacFlag(clientDataCode);
      let tempShowMultiFacilities = !_.isEmpty(data)
        ? data.isAllowMultipleFacility && isMultiFacility
        : null;
      setShowMultiFacilities(tempShowMultiFacilities);
    } else setShowMultiFacilities(false);
  };

  const getFacName = (code) => {
    let facName =
      !_.isEmpty(clientFacility) &&
      !_.isEmpty(clientFacility.filter((i) => i.FacilityCode === code)[0]) &&
      clientFacility.filter((i) => i.FacilityCode === code)[0].FacilityName;
    return facName;
  };

  const handleClickOutside = (event) => {
    if (_delMenu.current && !_delMenu.current.contains(event.target)) {
      toggleTooltip({ pwid: '', show: false });
    }
  };

  //UseEffects
  useEffect(() => {
    let params = Object.keys(selectedProviders).toString();
    dispatch(actions.getClientPortalDesignation(params, accountInfo.clientCode));
  }, [providersArray]);

  useEffect(() => {
    if (providerList.length > 0) {
      setProviders(providerList);
      _.isEmpty(currentPwid) ? null : updateProvidersArray(providerList);
    }
  }, [providerList]);

  useEffect(() => {
    if (clientFacilities != []) {
      setClientFacility(clientFacilities);
    }
  }, [clientFacilities]);

  useEffect(() => {
    if (employmentTypes != null) setEmploymentType(employmentTypes);
  }, [employmentTypes]);

  useEffect(() => {
    if (isError != null && isError) {
      setWarningFlag(true);
      showMessageHandler(currentType, 'fail');
    } else if (isError == false) {
      showMessageHandler(currentType, 'pass');
      setWarningFlag(false);
      setTimeout(function () {
        setWarningFlag(true);
      }, 3000);
    }
  }, [isError]);

  useEffect(() => {
    setRadioSelect(radioSelect);
  }, [radioSelect]);

  useEffect(() => {
    setDesinagtionRadioSelect(desinagtionRadioSelect);
  }, [desinagtionRadioSelect]);

  useEffect(() => {
    closeModal;
  }, [selectedItem, radioSelect]);

  useEffect(() => {
    setCurrentPwid(currentPwid);
  }, [currentPwid]);

  useEffect(() => {
    let slicedArray = providersArray.slice(pageStart - 1, pageEnd);
    setProvidersArrayInList(slicedArray);
  }, [pageStart, pageEnd]);

  useEffect(() => {
    ReactModal.setAppElement('body');
  });

  useEffect(() => {
    let btnDisable = true;
    if (showDesignationManagementModal && !_.isEmpty(desinagtionRadioSelect)) {
      if (desinagtionRadioSelect == 'Designate') {
        let isfacility = !_.isEmpty(clientFacility);
        if (!_.isEmpty(radioSelect) && radioSelect != 'Standard') {
          if (isfacility) {
            btnDisable = selectedItem != null || !_.isEmpty(selectedFacilityArr) ? false : true;
            setDisabledBtn(btnDisable);
          } else if (!isfacility) {
            btnDisable = false;
            setDisabledBtn(btnDisable);
          } else setDisabledBtn(btnDisable);
        }
      } else {
        let showBtn =
          radioSelect !== 'Employed' || radioSelect !== 'Affiliated'
            ? radioSelect != 'Standard' || radioSelect == 'Premium'
            : false;
        setDisabledBtn(_.isEmpty(selectedFacilityArr) && !showBtn);
      }
    } else setDisabledBtn(btnDisable);
  }, [radioSelect, desinagtionRadioSelect, selectedItem, selectedFacilityArr]);

  useEffect(() => {
    onClientSettings();
    getFacilityType(clientDataCode);
  }, []);

  useEffect(() => {
    getFacilityType(clientDataCode);
  }, [clientDataCode, showDesignationManagementModal]);

  useEffect(() => {
    showTooltip.show && document.addEventListener('click', handleClickOutside, true);
  }, [showTooltip]);

  return (
    <Fragment>
      {/* Designation-container  */}
      <>
        <div className='desigantion-management'>
          <div className='designation-container'>
            <div className='para'>
              {accountInfo.isImpersonate && (
                <a href='/admin/index' alt='Search Results' className='para-content1'>
                  SearchResults
                </a>
              )}
              <a
                href={window.location.href}
                className={` ${
                  !accountInfo.isImpersonate ? 'hide-search-result' : 'para-content2'
                }`}>
                {providerDisplayName}
              </a>
              <span className='para-content3'>Designation management</span>
            </div>
            <div className='heading-designation'>Designation management</div>
            <div className='deisgignation-info'>
              <img className='info-icon' src={info}></img>
              Please note it may take up to 24-48 business hours to Designate/ De-designate the
              providers.
            </div>

            <div className='search-grp'>
              {!isMobileView && (
                <div className='back-to-roster'>
                  <a className='back-link' href={window.location.href}>
                    <img className='back-to-roster-icon' src={backIcon}></img>
                    <div>Back to Roster</div>
                  </a>
                </div>
              )}
              <div className='search-input'>
                <input
                  className='input'
                  id='searchProvider'
                  type='text'
                  maxLength='50'
                  placeholder='Search Provider By Name'
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSearchProvider();
                  }}
                  ref={searchInputRef}
                />
                <span className='search-icon'>
                  <i className='icon' onClick={handleSearchProvider}></i>
                </span>
              </div>
            </div>
          </div>

          <div
            className={`provider-designation-list ${
              !showCheckbox ? 'provider-designation-list-removed-fac-col' : ''
            }`}>
            {providersFound > 0 || !isError ? (
              <Fragment>
                {providersArrayInList.length > 0 ? (
                  <Fragment>
                    <Header columns={headerColumns} onSort={onSort} isShow={true} />
                    {providersArrayInList.map((val, index) => {
                      return (
                        <div key={index} className='providerInRoster-details-container'>
                          <div
                            key={index}
                            className={
                              index % 2 !== 0
                                ? 'providerInRoster-details alternate-background'
                                : 'providerInRoster-details'
                            }>
                            <div className='providerInRoster-info'>
                              <span className='providerInRoster-name'>
                                <a
                                  key={index}
                                  href={`/provider/profile/${val.ProviderId}`}
                                  alt={val.ProviderName}>
                                  {val.ProviderName}
                                </a>
                                <span className='providerInRoster-name-specialty'>
                                  {val.SpecialtyName}
                                </span>
                              </span>

                              <span className='providerInRoster-employement-types'>
                                {isMobileView && <p className='practice-office-name'>Type/ ID</p>}
                                <div
                                  className={
                                    !isMobileView
                                      ? 'providerInRoster-typeID'
                                      : 'providerInRoster-typeID info-tags-mobile'
                                  }>
                                  {val.SponsorType != null && (
                                    <>
                                      <span
                                        className={getClassNameForSponsorstype(
                                          val.SponsorType.toUpperCase()
                                        )}>
                                        {val.SponsorType}
                                      </span>
                                    </>
                                  )}
                                  <span className='npi-pwid'>
                                    NPI: {val.Npi}, <br />
                                    PWID: {val.ProviderId}
                                  </span>
                                </div>
                              </span>

                              <span className='providerInRoster-practice-office'>
                                {val.Office != null && (
                                  <Fragment>
                                    <p className='practice-office-name'>{val.Office.Name}</p>
                                    <p>{val.Office.AddressLine}</p>
                                    <p>{val.Office.CityState}</p>
                                  </Fragment>
                                )}
                              </span>

                              {headerColumns[3].isShow && (
                                <span id={val.ProviderId}>
                                  {val.ProviderId != null &&
                                  !_.isEmpty(providerList) &&
                                  !_.isEmpty(
                                    providerList.filter((i) => i.Pwid === val.ProviderId)
                                  ) &&
                                  !_.isEmpty(
                                    providerList
                                      .filter((i) => i.Pwid === val.ProviderId)[0]
                                      .Designations.filter((i) => !_.isEmpty(i.FacilityCode))
                                  )
                                    ? providerList
                                        .filter((i) => i.Pwid === val.ProviderId)[0]
                                        .Designations.filter((i) => !_.isEmpty(i.FacilityCode))
                                        .map((j, index) => {
                                          return (
                                            index == 0 && (
                                              <span
                                                key={index}
                                                className='providerInRoster-practice-office providerInRoster-facility-col'>
                                                {!_.isEmpty(j.FacilityCode) &&
                                                val.SponsorType.toLowerCase() != 'standard' ? (
                                                  <Fragment>
                                                    {!_.isEmpty(j.FacilityName) ? (
                                                      <p className='practice-office-name'>
                                                        {j.FacilityName}
                                                      </p>
                                                    ) : (
                                                      getFacName(j.FacilityCode)
                                                    )}
                                                    <p>{j.FacilityCode}</p>
                                                  </Fragment>
                                                ) : (
                                                  !isMobileView && <p className='no-data'>--</p>
                                                )}
                                              </span>
                                            )
                                          );
                                        })
                                    : !isMobileView && <p className='no-data'>--</p>}

                                  {!_.isEmpty(
                                    providerList.filter((i) => i.Pwid === val.ProviderId)
                                  ) &&
                                    providerList
                                      .filter((i) => i.Pwid === val.ProviderId)[0]
                                      .Designations.filter((i) => !_.isEmpty(i.FacilityCode))
                                      .length > 1 &&
                                    val.SponsorType.toLowerCase() != 'standard' &&
                                    btnJSX(
                                      providerList
                                        .filter((i) => i.Pwid === val.ProviderId)[0]
                                        .Designations.filter((i) => !_.isEmpty(i.FacilityCode)),
                                      val
                                    )}
                                </span>
                              )}

                              <span className='assign-btn'>
                                <button
                                  disabled={currentPage && isSuccess ? true : false}
                                  className={`${
                                    val.SponsorType.toUpperCase() == 'STANDARD'
                                      ? 'btn designate'
                                      : 'btn de-designate'
                                  }`}
                                  onClick={(e) => {
                                    assignHandler(e, val);
                                  }}
                                  value={val.ProviderId}>
                                  Assign
                                </button>
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    <div className={`${showPagination ? '' : 'add-bottom-padding'}`}>
                      <ProviderTypeTags sponsorInformation={sponsorInformation} />
                    </div>
                    {showPagination && providersFound > 10 && (
                      <div>
                        <PaginationUI
                          showJoyPagination={true}
                          recordsFound={Number(providersFound)}
                          onPageChange={onPageChange}
                          showPerPage={true}
                          recordsPerPage={Number(recordsPerPage)}
                          onPageFilterChange={onPageFilterChange}
                        />
                      </div>
                    )}
                  </Fragment>
                ) : (
                  <SearchIcon />
                )}
              </Fragment>
            ) : (
              (warningFlag || isError) && <div className='warning-msg'>{warningMsg}</div>
            )}
          </div>
        </div>
      </>

      {/* Modals  */}
      <>
        <ReactModal
          overlayClassName='roster-modal-overlay'
          className='modal-dialog'
          ariaHideApp={true}
          isOpen={showDesignationManagementModal}
          contentLabel='designate'
          onRequestClose={closeModal}
          shouldCloseOnOverlayClick={false}>
          <div
            className={`designation-model-window ${
              !(Array.isArray(clientFacility) && !clientFacility.length)
                ? 'with-facility'
                : 'no-facility'
            }`}>
            <div className='model-container'>
              <div className='close'>
                <img className='close-icon' src={cross} alt='close' onClick={closeModal} />
              </div>
              {showDesignationManagementModal && (
                <AssignDesigationModalContent
                  name={name}
                  radioSelect={radioSelect}
                  selectedFacilityName={selectedFacilityName}
                  setSelectedOption={setSelectedOption}
                  clientFacility={clientFacility}
                  employmentType={employmentType}
                  selectedItemHandler={selectedItemHandler}
                  desinagtionRadioSelect={desinagtionRadioSelect}
                  setSelectedDesignationOption={setSelectedDesignationOption}
                  currentFacArr={currentFacArr}
                  disableOtherProviderType={showMultiFacilities && radioSelect != 'Standard'}
                  showMultiFacilities={_.isNull(showMultiFacilities) ? false : showMultiFacilities}
                  selectedMultiFacilitiesHandler={selectedMultiFacilitiesHandler}
                  initRadioSelect={initRadioSelect}
                />
              )}

              <div className='action-section'>
                <Button
                  id='suggest-btn-cancel'
                  text={'Cancel'}
                  disabled={false}
                  className={`provider-designation-cancel valid `}
                  size='lg'
                  style='ghost'
                  onClick={closeModal}
                />
                <Button
                  id='suggest-btn-save'
                  text={`${desinagtionRadioSelect} ${
                    designateCount > 0 ? `(${designateCount})` : ''
                  }`}
                  disabled={disabledBtn}
                  className={`provider-designation-save ${disabledBtn ? '' : 'valid'}`}
                  size='lg'
                  style='ghost'
                  onClick={(e) => designateHandler(e, `${desinagtionRadioSelect}`)}
                />
              </div>
            </div>
          </div>
        </ReactModal>

        <NotificationModalForCA
          closeNotifyModal={closeNotifyModal}
          showNotifyModal={showNotifyModal}
          getStatus={getStatus}
        />
      </>

      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </Fragment>
  );
};

DesignationManagement.propTypes = {
  providerDisplayName: PropTypes.string,
  selectedProviders: PropTypes.object,
  providersFound: PropTypes.number,
  accountInfo: PropTypes.object,
  providersInfo: PropTypes.arrayOf(PropTypes.object),
  reloadList: PropTypes.func
};

export default DesignationManagement;
