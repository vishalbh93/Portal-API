import React, { Fragment, useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import './_body.less';

import AddProviderModal from '../AddProvider/AddProvider';
import AccountSettingModal from '../AccountSetting/AccountSetting';
import ClientSettingModal from '../ClientSetting/ClientSetting';
import CopyProvider from '../CopyUserInfoProvider/CopyProvider';
import QuickFilters from '../QuickFilters/QuickFilters';
import * as actions from '../../../store/actions';
import Alert from '../../Alert/Alert';
import ReactModal from 'react-modal';

import * as _pService from '../../../utils/serviceCalls/clientPortal';
import { objectToCamel } from '../../../utils/utils';

import downArrow from '../../../assets/images/down-arrow.svg';
import upArrow from '../../../assets/images/up-arrow.svg';
import Search from '../../../assets/images/Search-medium.svg';
import Tag from '../../../assets/images/RosterPage/tag-approved.svg';
import _ from 'lodash';

const Body = (props) => {
  /* #region declarations and states */
  const searchInputRef = useRef();
  const dispatch = useDispatch();

  const [filterType, setFilterType] = useState('');
  const [openDropwDown, setOpenDropwDown] = useState(false);
  const [showModalAcc, toggleModalAcc] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);
  const [active, setActive] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [pcount, setPCount] = useState(0);
  const [scount, setSCount] = useState(0);
  const [mcount, setMCount] = useState(0);
  const [showClearAllFilters, setShowClearAllFilters] = useState(false);
  const [isClientSetting, setIsClientSetting] = useState(false);
  const [showDeleteAccModal, toggleDeleteAccModal] = useState(false);
  const [clientDataCode, setClientDataCode] = useState([]);
  const [userId, setUserId] = useState('');
  const [actionType, setActionType] = useState('delete');
  const [popupMessage, setPopupMessage] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  const [showMultiFacilities, setShowMultiFacilities] = useState(false);
  const [showModalCopyProvider, setshowModalCopyProvider] = useState(false);

  const accountInfo = props.isClientPageFlag
    ? useSelector((state) => state.getAccountDetailsReducer)
    : useSelector((state) => state.loadRoster);
  const [_accountInfo, setAccountInfo] = useState(accountInfo);
  const accountSettingInfo =
    _accountInfo != undefined && _accountInfo != null
      ? props.isClientPageFlag
        ? _accountInfo.accountInfo
        : _accountInfo.accountData
      : [];
  const showSearchResults = props.isClientPageFlag
    ? _accountInfo.accountInfo.isImpersonate
    : _accountInfo.accountData.isImpersonate;

  const rosterName = props.isClientPageFlag
    ? _accountInfo.accountInfo.firstName + ' ' + _accountInfo.accountInfo.lastName
    : _accountInfo.accountData.firstName + ' ' + _accountInfo.accountData.lastName;

  const sponsorInformation = props.isClientPageFlag
    ? useSelector((state) => state.getClientPortalBannerDataReducer)
    : null;
  const [_sponsorInformation, setSponsorInformation] = useState(sponsorInformation);

  const { isDeleteClick } = useSelector((state) => state.deleteRosterReducer);
  const isMobileView = window.innerWidth <= 768;
  const isUserAdmin = props.isClientPageFlag
    ? _accountInfo.accountInfo.navigationModel.UserIsAdmin
    : _accountInfo.accountData
    ? JSON.parse(accountInfo.rosterInfo.NavigationJson)['UserIsAdmin']
    : false;

  /* #endregion */

  /* #region handlers */

  const manageHandler = () => {
    setOpenDropwDown(!openDropwDown);
  };

  const handleSearchProvider = () => {
    props.searchFilterChange(searchInputRef.current.value);
  };

  const getClientProviderLimit = () => {
    _pService
      .clientDetails()
      .then((res) => {
        if (res.status == 200) {
          let clientData = objectToCamel(res.data || []);
          setClientDataCode(objectToCamel(JSON.parse(clientData.returnData)));
        }
      })
      .catch((error) => console.error(error));
    props.addProvider(true);
  };

  const showSpinnerOnModalClose = (showSpinner) => {
    setShowSpinner(showSpinner);
  };

  const closeModal = (data, name) => {
    props.addProvider(false);
    if (name != 'close-icon') {
      props.reloadList(data);
    }
    props.manageTab();
  };

  const openModalAcc = () => {
    toggleModalAcc(true);
    onClientSettings(false);
  };

  const closeModalAcc = () => {
    toggleModalAcc(false);
    setIsClientSetting(false);
    onClientSettings(false);
    props.manageTab();
  };

  const closeAccountDeleteModel = () => {
    toggleDeleteAccModal(false);
    props.manageTab();
  };

  const manageFilterHandler = (e) => {
    let nameOfFilter = e.target.innerHTML;
    nameOfFilter = nameOfFilter.split('<');
    if (nameOfFilter[0] != null || nameOfFilter[0] != undefined) {
      setActive(true);
      switch (nameOfFilter[0]) {
        case 'Practices':
          setSelectedItem('practice');
          setFilterType('practice');
          setPCount(pcount);
          break;
        case 'Speciality':
          setSelectedItem('specialty');
          setFilterType('specialty');
          setSCount(scount);
          break;
        case 'Missing Fields':
          setSelectedItem('missing');
          setFilterType('missing');
          setMCount(mcount);
          break;
      }
    } else {
      setSelectedItem('');
      setFilterType('');
      setActive(false);
      setPCount(0);
      setSCount(0);
      setMCount(0);
    }
  };

  const closeFilterHandler = (e) => {
    setSelectedItem('');
    setActive(false);
    props.manageTab();
  };

  const clearFilterHandler = (e) => {
    e.preventDefault();
    setSelectedItem('');
    setActive(false);
  };

  const applyQuickFilter = (filterItem) => {
    setPCount(filterItem.filter((i) => i.filterType === 'practice').length);
    setSCount(filterItem.filter((i) => i.filterType === 'specialty').length);
    setMCount(filterItem.filter((i) => i.filterType === 'missing').length);
    props.applyQuickFilter(filterItem);
    setShowClearAllFilters(true);
  };

  const clearAllFilterHandler = (e) => {
    e.preventDefault();
    props.applyQuickFilter();
    setActive(false);
    setPCount(0);
    setSCount(0);
    setMCount(0);
    setShowClearAllFilters(false);
  };

  const onDelete = (userId) => {
    setShowSpinner(true);
    dispatch(actions.deleteRoster(userId, setShowSpinner));
    if (isDeleteClick) {
      window.location.href = `${window.location.origin}/Admin/Index`;
    }
  };

  const onDeleteModal = (userId) => {
    setUserId(
      props.isClientPageFlag ? _accountInfo.accountInfo.userId : _accountInfo.accountData.userId
    );
    setPopupMessage(`Are you sure? Do you want to delete ${rosterName}?`);
    setShowAlert(true);
    toggleDeleteAccModal(true);
  };

  const onClientSettings = (val) => {
    _pService
      .clientDetails()
      .then((res) => {
        if (res.status == 200) {
          let clientData = objectToCamel(res.data || []);
          setClientDataCode(objectToCamel(JSON.parse(clientData.returnData)));
        }
      })
      .catch((error) => console.error(error));
    if (val) setIsClientSetting(true);
  };

  const confirmUpdate = () => {
    props.addProvider(false);
    if (userId != '' && actionType != '') {
      if (actionType == 'delete') {
        onDelete(userId);
      }
    }
    setUserId('');
    setActionType('');
    setMessageOnActionType('');
    props.addProvider(false);
    setShowAlert(false);
  };

  const setMessageOnActionType = () => {
    setPopupMessage(`Are you sure? Do you want to delete ${rosterName}?`);
  };

  const handleAccountInfo = (clientCode, adminRole, flag = false) => {
    if (props.isClientPageFlag) {
      let accountInfoObj = {
        ...accountInfo.accountInfo,
        clientCode: clientCode,
        currentRole: adminRole,
        isAllowMultipleFacility: flag
      };
      setAccountInfo({ ...accountInfo, accountInfo: accountInfoObj });
      setShowMultiFacilities(flag);
    } else {
      let accountInfoObj = {
        ...accountInfo.accountData,
        clientCode: clientCode,
        currentRole: adminRole
      };
      setAccountInfo({ ...accountInfo, accountData: accountInfoObj });
    }
  };

  const getMultiFacFlag = (clientDataObj) => {
    let data =
      !_.isEmpty(accountSettingInfo) &&
      clientDataObj.find((x) => x.clientCode == accountSettingInfo.clientCode);
    return data;
  };

  const getSponsorInfo = () => {
    var payload = props.currentAccountDetails;
    !_.isEmpty(payload) && _.isObject(payload)
      ? dispatch(actions.getClientPortalBannerData(payload))
      : null;
  };

  const closeModalCopyRosterPro = () => {
    setshowModalCopyProvider(false);
    };
    const onDuplicateAssignModal = (val) => {
      setshowModalCopyProvider(true);    
    };
    
    const handlePopUp = () => 
    {
      setshowModalCopyProvider(false);
    }

  /* #endregion */

  /* #region effects */
  useEffect(() => {
    if (isDeleteClick) {
      window.location.href = `${window.location.origin}/Admin/Index`;
    }
  }, [isDeleteClick]);

  useEffect(() => {
    if (!_.isEmpty(clientDataCode)) {
      let data = getMultiFacFlag(clientDataCode);
      let isShow =
        !_.isEmpty(_sponsorInformation) &&
        _.isObject(_sponsorInformation) &&
        _sponsorInformation.hasOwnProperty('sponsorInformation')
          ? _sponsorInformation.sponsorInformation.isFacility &&
            (_sponsorInformation.sponsorInformation.sponsorType == 'PDCHSP' ||
              _sponsorInformation.sponsorInformation.sponsorType == 'MAP')
          : !_.isEmpty(_sponsorInformation) &&
            _sponsorInformation.isFacility &&
            (_sponsorInformation.sponsorType == 'PDCHSP' ||
              _sponsorInformation.sponsorType == 'MAP');
      let showCheckbox = _.isEmpty(_sponsorInformation) ? false : isShow;
      let showMultiFacilities = !_.isEmpty(data)
        ? data.isAllowMultipleFacility &&
          !_.isEmpty(_accountInfo.accountInfo) &&
          _accountInfo.accountInfo.currentRole === 'Client_Admin' &&
          showCheckbox
        : null;
      setShowMultiFacilities(showMultiFacilities);
    }
  }, [showMultiFacilities, clientDataCode, sponsorInformation]);

  useEffect(() => {
    setActive(false);
    setSelectedItem('');

    if(
      (props.isClientPageFlag && (_accountInfo.accountInfo!== undefined &&  (_accountInfo.accountInfo.navigationModel.UserIsAdmin 
        || _accountInfo.accountInfo.navigationModel.UserIsClientAdmin))))        
    {
    _pService
      .clientDetailsWithoutSpinner()
      .then((res) => {
        if (res.Success) {
          let clientData = objectToCamel(res || {});
          let tempReturnData = objectToCamel(JSON.parse(clientData.returnData));
          setClientDataCode(tempReturnData);
          getMultiFacFlag(tempReturnData);
          getSponsorInfo();
        }
      })
      .catch((error) => console.error(error));
    }
  }, []);

  useEffect(() => {
    setSponsorInformation(sponsorInformation);
  }, [sponsorInformation]);

  useEffect(() => {
    if (props.manageAccSettingTab) {
      openModalAcc();
    }
  }, [props.manageAccSettingTab]);

  useEffect(() => {
    if (props.manageDeleteAccTab) {
      onDeleteModal(userId);
    }
  }, [props.manageDeleteAccTab]);

  useEffect(() => {
    if (props.manageDuplicateRosterProTab) {
      onDuplicateAssignModal(userId);
    }
  }, [props.manageDuplicateRosterProTab]);

  useEffect(() => {
    if (props.manageClientSettingsTab) {
      onClientSettings(true);
    }
  }, [props.manageClientSettingsTab]);

  useEffect(() => {
    props.manageTab();
  });

  /* #endregion */

  return (
    <Fragment>
      <AddProviderModal
        profileInfo={props.isClientPageFlag ? _accountInfo.accountInfo : props.profileInfo}
        showModal={props.toggleAddProvider}
        closeModal={closeModal}
        rosterData={props.rosterData}
        totalProviders={props.totalProviders}
        isImpersonateFlag={props.isImpersonateFlag}
        isClientPageFlag={props.isClientPageFlag}
        clientDataCode={clientDataCode}
        currentRole={
          accountInfo.accountData != undefined && accountInfo.accountData.currentRole != undefined
            ? accountInfo.accountData.currentRole
            : ''
        }
      />
      <div className='account-setting-popup'>
        <AccountSettingModal
          showModalAcc={showModalAcc}
          closeModalAcc={closeModalAcc}
          toggleModalAcc={toggleModalAcc}
          profileInfo={{ ...accountSettingInfo, isAllowMultipleFacility: showMultiFacilities }}
          showSpinnerModel={showSpinnerOnModalClose}
          clientDataCode={clientDataCode}
          clientPageFlag={props.isClientPageFlag}
          handleAccountInfo={handleAccountInfo}
          isUserAdmin={isUserAdmin}
        />
      </div>
      <div className='client-setting-popup'>
        <ClientSettingModal
          showModalClint={isClientSetting}
          closeModalAcc={closeModalAcc}
          profileData={{ ...accountSettingInfo, isAllowMultipleFacility: showMultiFacilities }}
          showSpinnerModel={showSpinnerOnModalClose}
          clientDataCode={clientDataCode}
          handleAccountInfo={handleAccountInfo}
          sponsorInformation={
            !_.isEmpty(_sponsorInformation) &&
            _sponsorInformation.hasOwnProperty('sponsorInformation')
              ? _sponsorInformation.sponsorInformation
              : _sponsorInformation
          }
        />
      </div>
      <div>
      <CopyProvider
      showModalCopyProvider={showModalCopyProvider}   
      closeModalCopyRosterPro ={closeModalCopyRosterPro}
      _accountInfo={accountInfo}
      isClientPageFlag= {props.isClientPageFlag}
      clientDataCode={clientDataCode}
      handlePopUp = {handlePopUp}
      />
    </div>
      <div className='alert-popup'>
        {showAlert && (
          <>
            <ReactModal
              overlayClassName='roster-modal-overlay'
              className='modal-dialog'
              ariaHideApp={true}
              isOpen={showDeleteAccModal}
              contentLabel=''
              onRequestClose={closeAccountDeleteModel}>
              <Alert
                action={closeAccountDeleteModel}
                heading=''
                message={popupMessage}
                confirmUpdate={confirmUpdate}></Alert>
            </ReactModal>
          </>
        )}
      </div>
      <div
        className={
          props.isClientPageFlag
            ? 'rosterviewbody-container'
            : 'rosterviewbody-container roster-page'
        }>
        <div className='rosterviewbody-tablecontainer'>
          {showSearchResults && !isMobileView && (
            <div className='body-title-impersonate'>
              <a href='/admin/index' alt='Search Results'>
                Search Results
              </a>
              <span> {'>'} </span> {rosterName}
            </div>
          )}
          {isMobileView && (
            <div className='roster-mobile-header'>
              <h1>
                My Roster
                {!_.isNull(showMultiFacilities) && showMultiFacilities && (
                  <img src={Tag} alt='tag-approved' />
                )}
              </h1>
            </div>
          )}
          <div className='body-title'>
            {!isMobileView && (
              <h1>
                My Roster
                {!_.isNull(showMultiFacilities) && showMultiFacilities && (
                  <img src={Tag} alt='tag-approved' />
                )}
              </h1>
            )}

            <div className='btn-group'>
              {props.isClientPageFlag ? (
                <button
                  className={
                    _accountInfo.accountInfo.isImpersonate
                      ? 'btn btn-add'
                      : 'btn btn-add cp-impersonate'
                  }
                  onClick={getClientProviderLimit}>
                  Add Providers
                </button>
              ) : (
                (_accountInfo.accountData.isImpersonate ||
                  (_accountInfo.rosterInfo.NavigationModel.UserIsAdmin !== undefined &&
                    _accountInfo.rosterInfo.NavigationModel.UserIsAdmin === true)) && (
                  <button
                    className='btn btn-add only-add-provider'
                    onClick={getClientProviderLimit}>
                    Add Providers
                  </button>
                )
              )}
              {!isUserAdmin && props.isClientPageFlag
                ? _accountInfo.accountInfo.isImpersonate && (
                    <button className='btn btn-manage' onClick={manageHandler}>
                      Manage <img src={openDropwDown ? upArrow : downArrow} />
                    </button>
                  )
                : !isUserAdmin &&
                  _accountInfo.accountData.isImpersonate && (
                    <button className='btn btn-manage' onClick={manageHandler}>
                      Manage <img src={openDropwDown ? upArrow : downArrow} />
                    </button>
                  )}
              {!isUserAdmin && openDropwDown && (
                <div
                  id='manage-tab'
                  className={props.isClientPageFlag ? 'manage-items' : 'manage-roster-items'}>
                  <ul
                    className='dropdown-item'
                    onMouseEnter={() => {
                      setOpenDropwDown(true);
                    }}
                    onMouseLeave={() => {
                      setOpenDropwDown(false);
                    }}>
                    {accountSettingInfo.currentRole === 'Client_Admin' && (
                      <li className='disabled-list-item'>
                        <span onClick={(e) => onClientSettings(true)}>Client Settings</span>
                      </li>
                    )}
                    <li>
                      <span onClick={openModalAcc}>Account Settings</span>
                    </li>
                    <li className='disabled-list-item'>
                      <span onClick={() => onDeleteModal(userId)}>Delete Account</span>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
          <div className='filter-search-grp'>
            <div className='filter-grp' tabIndex='0'>
              <div>
                <span className='search-options'>Quick Filters : </span>

                <span className={`selected-filter ${selectedItem}`}>
                  {active && !isMobileView && (
                    <QuickFilters
                      practices={props.rosterFilters.Practices}
                      specialties={props.rosterFilters.Specialties}
                      missingFields={props.rosterFilters.MissingFields}
                      filterType={filterType.toLowerCase()}
                      action={closeFilterHandler}
                      clear={clearFilterHandler}
                      applyQuickFilter={applyQuickFilter}
                      showFilters={setActive}
                      clearAllFilters={setShowClearAllFilters}
                      pcount={pcount}
                      scount={scount}
                      mcount={mcount}
                    />
                  )}
                </span>
              </div>

              <div
                className={`search-content ${selectedItem} ${
                  selectedItem == 'Practices' && 'selected'
                } ${pcount != null && pcount > 0 ? 'counter' : ''}
                }`}
                onClick={manageFilterHandler}>
                Practices
                {pcount != null && pcount > 0 && (
                  <span className='filters-count'>
                    <span className='filters-count-text'>{('0' + pcount).slice(-2)}</span>
                  </span>
                )}
              </div>

              <div
                className={`search-content ${selectedItem} ${
                  selectedItem == 'Speciality' && 'selected'
                }${scount != null && scount > 0 ? ' counter' : ''}
                `}
                onClick={manageFilterHandler}>
                Speciality
                {scount != null && scount > 0 && (
                  <span className='filters-count'>
                    <span className='filters-count-text'>{('0' + scount).slice(-2)}</span>
                  </span>
                )}
              </div>

              <div
                className={`search-content ${selectedItem} ${
                  selectedItem == 'Missing Fields' && 'selected'
                }${mcount != null && mcount > 0 ? ' counter' : ''}`}
                onClick={manageFilterHandler}>
                Missing Fields
                {mcount != null && mcount > 0 && (
                  <span className='filters-count'>
                    <span className='filters-count-text'>{('0' + mcount).slice(-2)}</span>
                  </span>
                )}
              </div>
              {showClearAllFilters && (
                <div className='clear-all-filters'>
                  <button onClick={clearAllFilterHandler} className='cancel-btn'>
                    Clear all filters
                  </button>
                </div>
              )}
            </div>
            <span className={`selected-filter ${selectedItem}`}>
              {active && isMobileView && (
                <QuickFilters
                  practices={props.rosterFilters.Practices}
                  specialties={props.rosterFilters.Specialties}
                  missingFields={props.rosterFilters.MissingFields}
                  filterType={filterType.toLowerCase()}
                  action={closeFilterHandler}
                  clear={clearFilterHandler}
                  applyQuickFilter={applyQuickFilter}
                  showFilters={setActive}
                  clearAllFilters={setShowClearAllFilters}
                  pcount={pcount}
                  scount={scount}
                  mcount={mcount}
                />
              )}
            </span>

            <div className='search-grp'>
              <input
                className='input'
                id='searchProvider'
                type='text'
                maxLength='50'
                placeholder='Search for Provider By Name'
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSearchProvider();
                }}
                ref={searchInputRef}
              />
              <span className='search-icon'>
                {!isMobileView ? (
                  <i className='icon' onClick={handleSearchProvider}></i>
                ) : (
                  <img src={Search} alt='search' />
                )}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

Body.propTypes = {
  action: PropTypes.func,
  showSpinnerModel: PropTypes.func,
  currentUserId: PropTypes.string,
  getClientProviderLimit: PropTypes.func,
  profileInfo: PropTypes.object,
  rosterFilters: PropTypes.objectOf(PropTypes.array),
  openModal: PropTypes.func,
  reloadList: PropTypes.func,
  currentAccountDetails: PropTypes.object
};

Body.defaultProps = {
  currentAccountDetails: {}
};

export default Body;
