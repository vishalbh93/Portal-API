import React from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../../Common/Layouts/LayoutA';
import ReactModal from 'react-modal';

//Stylesheet impor
import './_notificationModel.less';

//helper
import isEmpty from '../../../utils/validation/isEmpty';

//Media imports
import cross from '../../../assets/images/ProviderProfile/Vector.svg';

const NotificationModel = (props) => {
  const { textMessage, showModel } = props;

  const onCloseHandler = () => {
    props.closeModal();
  };

  return (
    <LayoutA>
      <ReactModal
        overlayClassName='roster-modal-overlay notification-modal-popup'
        className='notify-dialog'
        ariaHideApp={false}
        isOpen={showModel}
        contentLabel='notify-model'
        onRequestClose={onCloseHandler}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-section'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
            </div>
            <div className='modal-client-row'>
              <div className='title-sec'>{'Alert!'}</div>
              <div className='notification-text'>
                {!isEmpty(textMessage) && (
                  <div
                    dangerouslySetInnerHTML={{
                      __html: `${textMessage}`
                    }}></div>
                )}
              </div>
              <div>
                <button onClick={onCloseHandler} className='cancel-btn'>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </ReactModal>
    </LayoutA>
  );
};

NotificationModel.defaultProps = {
  textMessage: '<p></p>',
  showModel: false
};

NotificationModel.propTypes = {
  textMessage: PropTypes.string,
  showModel: PropTypes.bool
};

export default NotificationModel;
