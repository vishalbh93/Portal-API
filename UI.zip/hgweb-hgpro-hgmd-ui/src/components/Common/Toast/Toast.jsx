import React, { useState, useEffect } from 'react';
import './_toast.less';
import '@hg/joy/src/globalstyles';
import PropTypes from 'prop-types';

import successIcon from '../../../assets/images/success.svg';
import errorIcon from '../../../assets/images/error.svg';
import infoIcon from '../../../assets/images/info.svg';
import warningIcon from '../../../assets/images/warning.svg';

const Toast = (props) => {
  const { toastList, position, autoDelete, autoDeleteTime } = props;
  const [list, setList] = useState(toastList);

  useEffect(() => {
    setList([...toastList]);
  }, [toastList]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (autoDelete && toastList.length && list.length) {
        deleteToast(toastList[0].id);
      }
    }, autoDeleteTime);

    return () => {
      clearInterval(interval);
    };
  }, [toastList, autoDelete, autoDeleteTime, list]);

  const deleteToast = (id) => {
    const listItemIndex = list.findIndex((e) => e.id === id);
    const toastListItem = toastList.findIndex((e) => e.id === id);
    list.splice(listItemIndex, 1);
    toastList.splice(toastListItem, 1);
    setList([...list]);
  };

  const iconImages = {
    successIcon,
    errorIcon,
    infoIcon,
    warningIcon
  };

  const getCurrentIcon = (title) => {
    return iconImages[title + 'Icon'];
  };

  const getBackgroundColor = (title) => {
    switch (title.toLowerCase()) {
      case 'success':
        return '#E3F7F9';
      case 'error':
        return '#FFD6D6';
      case 'info':
        return '#5BC0DE';
      case 'warning':
        return '#F0AD4E';
    }
  };

  const getColor = (title) => {
    switch (title.toLowerCase()) {
      case 'success':
        return '#156984';
      case 'error':
        return '#D83D40';
      case 'warning':
      case 'info':
        return '#FFF';
    }
  };

  return (
    <>
      <div className={`notification-container ${position}`}>
        {list.map((toast, i) => (
          <div
            key={i}
            className={`notification toast ${position}`}
            style={{
              backgroundColor: getBackgroundColor(toast.title),
              color: getColor(toast.title)
            }}>
            {/* <button onClick={() => deleteToast(toast.id)}>X</button>  getCurrentIcon(toast.title)*/}
            <div className='notification-image'>
              <img src={getCurrentIcon(toast.title.toLowerCase())} alt={toast.title} />
            </div>
            <div className='notification-info'>
              {/* <p className='notification-title'>{toast.title}</p> */}
              {
                !!toast.isHtml ? <p className='notification-message' dangerouslySetInnerHTML={{ __html: toast.description }} /> :
                  <p className='notification-message'>{toast.description}</p>
              }
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

Toast.propTypes = {
  toastList: PropTypes.array.isRequired,
  position: PropTypes.string.isRequired,
  autoDelete: PropTypes.bool,
  autoDeleteTime: PropTypes.number
};

export default Toast;
