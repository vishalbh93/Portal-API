import React from 'react';
import { storiesOf } from '@storybook/react';

import Toast from '../Toast';

const TOAST_PROPERTIES = [
  {
    id: Math.floor(Math.random() * 101 + 1),
    title: 'Success',
    description: 'Success message goes here'
  },
  {
    id: Math.floor(Math.random() * 101 + 1),
    title: 'Error',
    description: 'Failure message goes here'
  },
  {
    id: Math.floor(Math.random() * 101 + 1),
    title: 'Success',
    description:
      'Insurance information updated successfully!. Updated values will reflect within 24-48 hours'
  },
  {
    id: Math.floor(Math.random() * 101 + 1),
    title: 'Info',
    description: 'This is an info toast component'
  },
  {
    id: Math.floor(Math.random() * 101 + 1),
    title: 'Warning',
    description: 'This is a warning toast component'
  }
];

storiesOf('Common|Toast', module).add('Toast', () => (
  <Toast
    toastList={TOAST_PROPERTIES}
    position='top-left'
    autoDelete={false}
    autoDeleteTime={5000}
  />
));
