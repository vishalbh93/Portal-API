import React from 'react';
import './_smartReferralNotification.less';

import Cookies from 'js-cookie';

import LogoImg from '/public/images/PostLoginPopup.png';
import SmartReferralLogo from '/public/images/SR-popup-logo.png';
import SRframe1 from '/public/images/SR-frame1.png';
import SRframe2 from '/public/images/SR-frame2.png';
import SRframe3 from '/public/images/SR-frame3.png';
import CrossImg from '/public/images/cross.png';

const SmartReferralNotification = ({handleCloseSmartReferralPopup,handleMakeReferralPopup}) => {
    
  return (
    <div className='post-login-container'>
      <div className='post-login-outer'>
        <img className='sr-logo' src={LogoImg} alt='Logo-Img' />
        <img className='close-icon' src={CrossImg} alt='close-icon' onClick={handleCloseSmartReferralPopup} />
        <div className='sr-inner-container'>
          <div className='top-content'>
            Want to refer your patient to a specialist beyond their location?
          </div>
          <div className='header-content'>Introducing Smart Referral!</div>
          <div className='smartReferral-popup'>
            <img alt='Sr-popup' src={SmartReferralLogo} />
          </div>
          <div className='description'>
            Smart Referral leverages insightful data for referrals, so you can easily find and refer
            your patients to expertly qualified specialists.
          </div>
          <div className='cards-content'>
            <div className='card-content-1'>
              <img alt='Sr-frame1' src={SRframe1} />
              <div className='content'>Physician Treatment Frequency</div>
            </div>
            <div className='card-content-2'>
              <img alt='Sr-frame2' src={SRframe2} />
              <div className='content'>Facility Outcomes</div>
            </div>
            <div className='card-content-3'>
              <img alt='Sr-frame3' src={SRframe3} />
              <div className='content'>Patient Reviews</div>
            </div>
          </div>
          <div className='make-referral-button'>
            <button className='btn-make-referral' onClick={handleMakeReferralPopup}>Make a Referral Now</button>
            <u>
              <div className='not-now-button' onClick={handleCloseSmartReferralPopup}>Not now</div>
            </u>
          </div>
        </div>
      </div>
    </div>
    //<h1>Popup Information</h1>
  );
};
export default SmartReferralNotification;
