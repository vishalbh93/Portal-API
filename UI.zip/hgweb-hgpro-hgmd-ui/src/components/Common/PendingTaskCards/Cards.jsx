import React, { useState, Fragment, useEffect } from 'react';
import PropTypes from 'prop-types';
import { missingFields } from '../../../utils/constant-data';

//import components
import { Carousel } from 'react-responsive-carousel';
import { HG3Tracker } from '../../../utils/tracking';

const Cards = (props) => {
  const { providerId, missingProviderFields, pendingCount, isProfileEdit, onClickHandler } = props;
  let minMissingFields = 1;

  // Functions
  const redirectToSection = (sectionName, url) => {
    if (isProfileEdit) {
      HG3Tracker.OmnitureTrackLink('Provider-Profile|' + sectionName + '');
      onClickHandler(sectionName);
    } else {
      HG3Tracker.OmnitureTrackLink('dashboard|' + sectionName + '');
      let fullPath = url.replace('{pwid}', providerId);
      window.location.href = fullPath;
    }
  };

  const getWindowDimensions = () => {
    const { innerWidth: width, innerHeight: height } = window;
    return { width, height };
  };
  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

  const getFilteredFields = (data) => {
    let filteredData = data.filter(function (el) {
      return missingProviderFields[el.fieldName] == false;
    });
    return filteredData;
  };

  const generateMissingFields = (data) => {
    let filteredData = getFilteredFields(data);
    let index = 0;
    let tempArray = [];
    if (windowDimensions.width > 769) minMissingFields = 4;
    for (index = 0; index < filteredData.length; index += minMissingFields) {
      let myChunk = filteredData.slice(index, index + minMissingFields);
      tempArray.push(myChunk);
    }

    return (
      <Carousel
        showArrows={false}
        showStatus={false}
        showIndicators={
          pendingCount == 1
            ? false
            : pendingCount >= 5 || windowDimensions.width <= 768
            ? true
            : false
        }
        infiniteLoop={true}
        showThumbs={false}
        autoFocus={false}
        useKeyboardArrows={true}
        autoPlay={false}
        swipeable={true}
        interval={8000}>
        {tempArray.map((data, mainIndex) => (
          <div key={mainIndex} className='missing-section'>
            {data.map((value, index) => (
              <Fragment key={index}>
                <div key={index} className={`goals-card less-pending-tasks`}>
                  <div className='goals-card-image-container'>
                    <img className='goals-card-image' src={value.iconUrl} alt='icon' />
                  </div>
                  <div className='goals-card-brief'>
                    <p className='goals-card-brief'>{value.description}</p>
                  </div>
                  <div className='goals-card-button-container'>
                    <button
                      id={`${mainIndex}-btn-update-${index}`}
                      className='btn goals-update-button'
                      aria-label={`${mainIndex}-update-${index}`}
                      onClick={() => redirectToSection(value.fieldName, value.redirectUrl)}>
                      {value.buttonContent.includes('AcceptNewPatients')
                        ? 'Accept New Patients'
                        : value.buttonContent.includes('AffiliatedHospitals')
                        ? 'Hospital Affiliated'
                        : value.buttonContent}
                    </button>
                  </div>
                </div>
              </Fragment>
            ))}
          </div>
        ))}
      </Carousel>
    );
  };

  useEffect(() => {}, [windowDimensions]);

  return <>{missingProviderFields != undefined && generateMissingFields(missingFields)}</>;
};

Cards.propTypes = {};

export default Cards;
