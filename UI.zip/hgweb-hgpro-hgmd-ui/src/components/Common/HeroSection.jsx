import React, { useState } from 'react';
import PropTypes from 'prop-types';
import icon_manager from '../../assets/images/RosterPage/icon_manager.svg';

import _ from 'lodash';

//import stylesheet
import './_heroSection.less';

//components imports
import HighlightSection from '../Common/HighlightSection';

//media imports
//import Doctors from '../../assets/images/ClaimYourProfile/doctors-grp.png';
import hgLogo from '../../assets/images/logo.png';

const HeroSection = (props) => {
  const [manageTab, setManageTab] = useState(false);

  const [isUserAdmin, setIsUserAdmin] = useState(props.isUserAdmin);
  const isRosterPage =
    !_.isEmpty(props.RosterJsonData) && !_.isEmpty(props.RosterJsonData['UserType'])
      ? props.RosterJsonData['UserType'].includes('Roster')
      : false;

  const isMobileView = window.innerWidth <= 768;

  const { userDetails } = props;

  const manageTabahandler = () => {
    setManageTab(!manageTab);
  };
  const openModalAccTab = () => {
    props.openModal_Acc(true);
  };
  const onDeleteModalTab = () => {
    props.onDeleteModal_Acc(true);
  };
  const onDuplicateAssignModalTab = () => {
    props.onDuplicateAssign_Modal(true);
  };

  return (
    <div>
      <div className='claim-container'>
        <div className='claim-inner-container'>
          {/* {props.showDoctorImage != undefined && !props.showDoctorImage ? (
          <></>
        ) : (
          <img className='fixed-top-left-ellipse' src={Ellipse} alt='eclipse' />
        )} */}
          <div className='banner-section'>
            <div className='herobanner-container'>
              <div className='herobanner-inner-container'>
                <div className='banner-section claim-inner-section'>
                  {/* <div className='header-navigation'></div> */}
                  <div className='header-section'>
                    <div className='top-sect'>
                      <h1
                        className={`header ${
                          props.showDoctorImage != undefined && !_.isEmpty(props.showDoctorImage)
                            ? 'text-center'
                            : ''
                        }`}>
                        <span
                          className={`${
                            props.header1 != 'Report' ? 'header-one' : 'header-report'
                          }`}>
                          {props.header1}
                        </span>
                        {props.header2 && (
                          <span
                            className={`header-two  ${
                              props.showDoctorImage != undefined &&
                              !_.isEmpty(props.showDoctorImage)
                                ? 'header-2'
                                : ''
                            }`}>
                            {props.header2}
                          </span>
                        )}
                      </h1>
                      {isUserAdmin && (
                        <span id='icon-image_1'>
                          <icon>
                            <img
                              src={icon_manager}
                              className='icon-image'
                              onClick={manageTabahandler}
                              alt='manager-icon'
                            />
                          </icon>
                        </span>
                      )}
                      {isUserAdmin && manageTab && (
                        <div id='manage-tab' className='manage-roster-items'>
                          <ul
                            className='dropdown-item'
                            onMouseEnter={() => {
                              setManageTab(true);
                            }}
                            onMouseLeave={() => {
                              setManageTab(false);
                            }}>
                            <li>
                              <span onClick={openModalAccTab}>Account Settings</span>
                            </li>
                            <li className='disabled-list-item'>
                              <span onClick={onDeleteModalTab}>Delete Account</span>
                            </li>
                            {isRosterPage && 
                            props.isActive && (
                              <li className='disabled-list-item'>
                                <span onClick={onDuplicateAssignModalTab}>
                                  Duplicate and Assign
                                </span>
                              </li>
                            )}
                          </ul>
                        </div>
                      )}
                    </div>

                    <h6
                      className={`sub-header ${
                        props.registrationSuccess != undefined && props.registrationSuccess
                          ? 'sub-header-center'
                          : ''
                      }`}>
                      {
                        props.registrationSuccess != undefined && props.registrationSuccess && (
                          <>Your registration is complete</>
                        )
                        //  : (
                        //   <>
                        //     Healthgrades is the leading destination for patients looking for providers
                        //   </>)
                      }
                      {props.subHeading != undefined && props.subHeading != '' && (
                        <>{props.subHeading}</>
                      )}
                    </h6>
                  </div>
                </div>
                {props.displayHighlight && (
                  <div className='desktop-view'>
                    <HighlightSection />
                  </div>
                )}
              </div>
              {props.showDoctorImage != undefined && !props.showDoctorImage ? (
                <img className='claim-page-right-align-logo hg-logo' src={hgLogo} alt='HG Logo' />
              ) : (
                <>
                  <img className='claim-page-right-align-logo design-snap' alt='Design Snap' />
                  <img
                    className='claim-page-right-align-logo design-snap-bg'
                    alt='Design Snap Background'
                  />
                </>
              )}
            </div>
          </div>
          <svg
            className='hero-background-svg'
            data-qa-target='hero-background-svg'
            preserveAspectRatio='none'
            viewBox='45 0 1200 149'>
            <path
              d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
              fill={props.backgroundColor}></path>
          </svg>

          <svg
            className='hero-background-svg-mobile'
            data-qa-target='hero-background-svg-mobile'
            preserveAspectRatio='none'
            viewBox='0 0 375 120'>
            <path
              d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
              fill={props.backgroundColor}></path>
          </svg>
        </div>
      </div>
    </div>
  );
};

HeroSection.propTypes = {
  backgroundColor: PropTypes.string,
  isUserAdmin: PropTypes.bool,
  openModal_Acc: PropTypes.func,
  onDeleteModalTab: PropTypes.func,
  onDuplicateAssignModalTab: PropTypes.func,
  RosterJsonData: PropTypes.object,
  isActive: PropTypes.bool,
};

HeroSection.defaultProps = {
  backgroundColor: '#FFFFFF',
  isUserAdmin: false,
  isActive: false,
};

export default HeroSection;
