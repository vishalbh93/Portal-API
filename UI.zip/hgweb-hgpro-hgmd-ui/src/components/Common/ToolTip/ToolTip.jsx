// Externals
import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
// Styling
import Styles from './_toolTip.less';

const propTypes = {
  id: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired
};

const ToolTip = ({ id, children }) => {
  const node = useRef();
  const [isClicked, setState] = useState(false);

  let trigger = null;
  let content = null;

  React.Children.forEach(children, (child) => {
    if (!child.type) {
      return;
    }

    if (child.type.displayName === 'Trigger') {
      trigger = React.cloneElement(child, {
        'aria-describedby': id,
        'data-testid': 'tooltip-button'
      });
    }

    if (child.type.displayName === 'Content') {
      content = React.cloneElement(child, { id });
    }
  });

  return (
    <span
      className='tooltip-container'
      data-testid='tooltip'
      ref={node}
      onTouchStart={() => setState(!isClicked)}
      onMouseOver={() => setState(!isClicked)}
      onClick={() => setState(!isClicked)}
      onMouseLeave={() => setState(false)}>
      {trigger}
      {isClicked && content}
    </span>
  );
};

ToolTip.propTypes = propTypes;

export default ToolTip;
