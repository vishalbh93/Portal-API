// Externals
import { createElement } from 'react';
import PropTypes from 'prop-types';

const propTypes = {
  children: PropTypes.node
};

const Trigger = ({ as, children, imgsrc, ...otherProps }) => {
  if (as === 'img') return createElement(as, { src: imgsrc, alt:'alt-image'}, null);
  else return createElement(as, { ...otherProps }, children);
};

Trigger.defaultProps = {
  as: 'button'
};

Trigger.displayName = 'Trigger';
Trigger.propTypes = propTypes;

export default Trigger;
