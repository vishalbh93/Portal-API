// Externals
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
// Styling
import './_content.less';
import _ from 'lodash';
import Icons from '../../ProviderReferral/common/Icons/Icons';

const propTypes = {
  placement: PropTypes.string,
  onDisplay: PropTypes.func,
  onDismiss: PropTypes.func,
  children: PropTypes.node.isRequired
};

const Content = ({
  placement,
  onDisplay,
  onDismiss,
  children,
  isArray,
  tooltipContentjsx,
  iconSrc,
  recordCheckDetails,
  ...otherProps
}) => {
  useEffect(() => {
    // called when mounted
    onDisplay && onDisplay();
    // called when unmounted
    return () => {
      onDismiss && onDismiss();
    };
  }, []);

  const filteredTooltipContent =
    tooltipContentjsx != undefined &&
    tooltipContentjsx.length > 1 &&
    tooltipContentjsx.filter((i) => {
      if (i === '' || i.includes('Board certified')) {
        return recordCheckDetails.boardCertificationActionCount > 0;
      }
      return true;
    });

  const _tooltipContentjsx = () => {
    return (
      !_.isEmpty(filteredTooltipContent) && (
        <ul>
          {filteredTooltipContent.map((i, key) => (
            <li key={key}>
              <Icons
                className='records-check-indicator__icon'
                icon={
                  i.includes('No') || recordCheckDetails.boardCertificationActionCount > 0
                    ? 'checkmarkCircle'
                    : 'warning'
                }
                size={1.25}
              />
              {i}
            </li>
          ))}
        </ul>
      )
    );
  };

  return (
    <div
      role='tooltip'
      data-testid='tooltip-content'
      {...otherProps}
      className={`tooltip-inner-container ${placement}`}>
      {/* className={(Styles.container, Styles[placement])}> */}
      <span className='arrow'></span>
      {!isArray ? children : _tooltipContentjsx()}
    </div>
  );
};

Content.defaultProps = {
  placement: 'bottom',
  isArray: false,
  tooltipContentjsx: {},
  iconSrc: 'checkmarkCircle'
};

Content.propTypes = propTypes;
Content.displayName = 'Content';

export default Content;
