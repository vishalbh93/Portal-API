import React, { useState } from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../../Layouts/LayoutA';
import ReactModal from 'react-modal';

//Stylesheet impor
import './_modelPopUpWithAutoSuggest.less';

//helper
//import isEmpty from '../../../utils/validation/isEmpty';
import AutoSuggestWithCheckboxList from '../AutoSuggest/AutoSuggestWithCheckboxList';

//Media imports
import cross from '../../../../assets/images/ProviderProfile/Vector.svg';

const ModelPopUpWithAutoSuggest = (props) => {
  const { id, title, autosuggestOptions, onSaveClick, showModalPopUp, showFromItem } = props;

  const onCloseHandler = () => {
    props.closeModal();
  };

  const onSaveClickHandler = (suggestData) => {
    props.onSaveClick(suggestData);
    props.closeModal();
    //autosuggestOptions.initialValue('');
  };

  return (
    <LayoutA>
      <ReactModal
        overlayClassName='roster-modal-overlay'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={showModalPopUp}
        contentLabel='hospital-model'
        onRequestClose={onCloseHandler}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-sec'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
            </div>
            <div className='modal-row'>
              <div className='container'>
                <div className='title'>
                  <span className='main-title-bold'>
                    {title}
                    {/* <small>
                      ({autosuggestOptions.data.filter((p) => p.Selected == true).length} Selected)
                    </small> */}
                  </span>
                </div>
                <div className='title'>
                  <AutoSuggestWithCheckboxList
                    id='autosuggest-checkbox'
                    label=''
                    name=''
                    placeholder={autosuggestOptions.placeholder}
                    initialValue={autosuggestOptions.initialValue}
                    data={autosuggestOptions.data}
                    onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
                    onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
                    setCurrentSelection={autosuggestOptions.setCurrentSelection}
                    showValidationMsg={autosuggestOptions.showValidationMsg}
                    isSearch={autosuggestOptions.isSearch}
                    buttonNames={['Save', 'Cancel']}
                    onSaveClick={onSaveClickHandler}
                    onCancelClick={onCloseHandler}
                    isFocusOut={false}
                    showList='enable'
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </ReactModal>
    </LayoutA>
  );
};

ModelPopUpWithAutoSuggest.defaultProps = {
  props: { name: '' },
  showFromItem: ''
};

// ModelPopUpWithAutoSuggest.propTypes = {
//   title: PropTypes.string,
//   id: PropTypes.string,
//   showModalDelete: PropTypes.bool,
//   onSaveClick: PropTypes.func,
//   onCloseHandler: PropTypes.func
// };

export default ModelPopUpWithAutoSuggest;
