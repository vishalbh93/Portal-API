import React from 'react';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';

/* #region  style import */
import './_deleteProviderList.less';
/* #endregion */

/* #region media import */
import cross from '../../../../assets/images/ProviderProfile/Vector.svg';
/* #endregion */

/* #region  component import */
import Cta from '../CTA/Cta';
/* #endregion */

const ModalPopup = (props) => {
  const {
    showModalPopUp,
    headMessage,
    buttonName,
    showOfficeName,
    showModallist,
    onRequestClose,
    handleremoveProviders,
    isDeleteAll
  } = props;

  const deleteAllWarning = `<span> Note : You are removing all providers from this office, which will delete this office.</span>`;

  const selectConfirmDeleteHandler = (e) => {
    handleremoveProviders(e);
  };

  const _removeModalJSX = () => {
    let strRemoveMessage = `<span>${headMessage} ${showOfficeName}?`;
    if (showModallist.length === 1) {
      strRemoveMessage = strRemoveMessage.concat('<div><ul>');
      strRemoveMessage = strRemoveMessage.concat(`<li>${showModallist}</li>`);
      strRemoveMessage = strRemoveMessage.concat('</ul></div></span>');
    } else if (showModallist.length > 1) {
      strRemoveMessage = strRemoveMessage.concat('<div><ul>');
      showModallist.forEach((prv) => {
        if (prv != '') {
          strRemoveMessage = strRemoveMessage.concat(`<li>${prv}</li>`);
        }
      });
      strRemoveMessage = strRemoveMessage.concat('</ul></div></span>');
    }
    return `${strRemoveMessage}${isDeleteAll ?deleteAllWarning:''}`;
  };

  return (
    <ReactModal
      overlayClassName='popUp-modal-overlay delete-provider-list'
      className='modal-dialog'
      ariaHideApp={false}
      isOpen={showModalPopUp}
      contentLabel={buttonName}
      onRequestClose={onRequestClose}
      shouldCloseOnOverlayClick={false}>
      <div className='model-window-section'>
        <div className='model-container'>
          <div className='modal-header'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onRequestClose} />
            </div>
          </div>
          <div className='modal-body' dangerouslySetInnerHTML={{ __html: _removeModalJSX() }}></div>
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText={'Cancel'}
              cancelClickHandler={onRequestClose}
              confirmText={buttonName}
              confirmClickHandler={(e) => {
                selectConfirmDeleteHandler(e);
              }}
            />
          </div>
        </div>
      </div>
    </ReactModal>
  );
};

ModalPopup.defaultProps = {
  isDeleteAll: false
};

ModalPopup.propTypes = {
  isDeleteAll: PropTypes.bool
};

export default ModalPopup;
