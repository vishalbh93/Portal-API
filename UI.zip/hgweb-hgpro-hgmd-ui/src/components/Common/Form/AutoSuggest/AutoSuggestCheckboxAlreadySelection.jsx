import React, { useState, useEffect, useRef } from 'react';
import isEmpty from '../../../../utils/validation/isEmpty';
import './_autoSuggestCheckboxAlreadySelection.less';
import Button from '@hg/joy/src/components/Button';
import DownArrow from '../../../../assets/images/ProfileEdit/PracticeAndLocation/icon-down-arrow-black.svg';
import UpArrow from '../../../../assets/images/ProfileEdit/icon-up-arrow.svg';
import _ from 'lodash';

const AutoSuggestCheckboxAlreadySelection = (props) => {
  const {
    id,
    label,
    name,
    placeholder,
    initialValue,
    data,
    onInputChangeHandler,
    onSuggestSelectHandler,
    setCurrentSelection,
    isSearch,
    allowOtherThanList,
    showValidationMsg,
    validationHandler,
    isDisabled,
    buttonNames,
    onSaveClick,
    onCancelClick,
    isFocusOut,
    showList,
    showCount,
    isOpen,
    currentFacArr
  } = props;

  const INIT_VAL = { name: '', val: false, text: '' };
  const [currentValue, setCurrentValue] = useState(initialValue);
  const [suggestData, setSuggestData] = useState([]);
  const [listVisibility, setListVisibility] = useState(data.length > 0 && isOpen);
  const [showNoResultFound, toggleNoResultFound] = useState(true);
  const [err, setErr] = useState({ name: '', val: false, text: '' });
  const [showListClass, setShowListClass] = useState(showList);
  const [ctaValid, setctaValid] = useState('');
  const [count, setCount] = useState(0);
  const [disableCheckBox, setDisableCheckBox] = useState(false);
  const refSearchInput = useRef();
  const invalidText = new RegExp("[^ 0-9A-Za-zÀ-ÿ,&'./()-]");

  const searchTextChangeHandler = (event) => {
    setCurrentValue(event.target.value);
    onInputChangeHandler(event);
    setErr({ ...err, text: event.target.value });
    validationHandler(err);
  };
  const inputChangeHandler = (isChecked, item) => {
    if (!item.Disabled) {
      let _tempSuggestData = [...suggestData];
      setSuggestData(
        _tempSuggestData.map((data) => {
          if (data.Id == item.Id) {
            return { ...data, Checked: isChecked };
          } else {
            return { ...data };
          }
        })
      );
      showCount
        ? setCount(suggestData.filter((i) => i.Checked == true && i.Disabled != true).length)
        : null;
    }
  };
  const handleBlur = (event) => {
    allowOtherThanList
      ? (setCurrentValue(event.target.value), setErr(INIT_VAL))
      : setCurrentValue(initialValue);
    if (event.target.value == null || event.target.value == '') {
      setCurrentValue('');
    }
    if (event.relatedTarget == null) {
      setListVisibility(false);
      setErr(INIT_VAL);
    } else if (!event.relatedTarget.id.startsWith(`wrapper-suggest-item-${id}`))
      setListVisibility(false);
    setErr({ ...err, val: false, text: event.target.value });
  };
  const handleClickOutside = (event) => {
    if (refSearchInput.current && !refSearchInput.current.contains(event.target)) {
      setShowListClass('disable');
    } else if (refSearchInput.current != undefined || refSearchInput.current != null) {
      setShowListClass('enable');
    }
  };

  if (isFocusOut) {
    // Bind the event listener
    document.addEventListener('mousedown', handleClickOutside);
  }

  //effect
  useEffect(() => {
    setCurrentValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    if (showCount) {
      !isEmpty(suggestData) &&
      suggestData.filter((provider) => provider.Checked === true && provider.Disabled != true)
        .length > 0
        ? setctaValid('valid')
        : setctaValid('');
      let existingFacilitiesCount = _.isEmpty(currentFacArr)
        ? 0
        : currentFacArr.filter((p) => !_.isEmpty(p.code)).length;
      /* #region --this is for max- count of facilities is 5 */
      // let isDisable =
      //   suggestData.filter((i) => i.Checked == true && i.Disabled != true).length +
      //     existingFacilitiesCount >=
      //   5;
      /* #endregion */
      let isDisable =
        suggestData.filter((i) => i.Checked == true && i.Disabled != true).length >= 5;
      setDisableCheckBox(isDisable);
    } else {
      if (
        suggestData.find(
          (p) =>
            (p.Checked == true && p.Disabled != true && p.Selected == false) ||
            (p.Checked == false && p.Disabled != true && p.Selected == true)
        )
      ) {
        setctaValid('valid');
      } else {
        setctaValid('');
      }
    }
  }, [suggestData]);

  useEffect(() => {
    let collection = document.getElementsByClassName('search');
    if (collection != null && collection.length != 0) {
      for (let i = 0; i < collection.length; i++) {
        if (collection[i].value.length > 0) {
          !invalidText.test(collection[i].value)
            ? setErr({ name: collection[i].name, val: false, text: collection[i].value })
            : setErr({ name: collection[i].name, val: true, text: collection[i].value });
          setListVisibility(false);
        }
      }
    }
  }, [currentValue]);

  useEffect(() => {
    if (currentValue.length > 0 && data.length == 0 && currentValue != initialValue) {
      toggleNoResultFound(true);
    } else {
      toggleNoResultFound(false);
      setSuggestData(data);
    }
  }, [currentValue, data]);

  useEffect(() => {
    showCount
      ? setCount(suggestData.filter((i) => i.Checked == true && i.Disabled != true).length)
      : null;
  }, [suggestData, isOpen]);

  return (
    <div id={`wrapper-div-${id}`} className={`wrapper-div-${id}`} onBlur={handleBlur}>
      {label.length > 0 && <label htmlFor={`input-auto-suggest-${id}`}>{label}</label>}
      <input
        className={`search-input-${id} ${isSearch} ${
          err.name != undefined && showValidationMsg
            ? (!showValidationMsg ? invalidText.test(err.text) : false)
              ? 'error-message'
              : ''
            : ''
        }`}
        type='text'
        name={name}
        placeholder={placeholder}
        value={!isEmpty(currentValue) ? currentValue : ''}
        id={`input-auto-suggest-${id}`}
        onChange={searchTextChangeHandler}
        onFocus={(e) => setShowListClass('enable')}
        autoComplete='off'
        disabled={isEmpty(isDisabled) ? false : isDisabled}
      />
      <img
        className={`icons ${isOpen ? 'icon-up' : 'icon-down'}`}
        src={isOpen ? UpArrow : DownArrow}
        onClick={() => onCancelClick()}></img>

      {isOpen && (
        <>
          {!err.val ||
            (invalidText.test(err.text) && !showValidationMsg && (
              <span className='error-message-autosuggest '>Invalid characters</span>
            ))}

          {(!invalidText.test(err.text) && listVisibility && currentValue.length > 0) ||
          (!isEmpty(suggestData) && suggestData.length > 0) ? (
            <div
              id={`input-auto-autosuggest-checkbox-${id}`}
              ref={refSearchInput}
              className={`wrapper-suggest-list ${id} mutiple-checkbox ${showListClass}`}>
              {suggestData.filter((data) =>
                data.Text.toLowerCase().includes(currentValue.toLowerCase())
              ).length > 0 && (
                <>
                  <div className='wrapper-suggest-item' id='scrollbar-styles'>
                    {suggestData.filter((data) =>
                      data.Text.toLowerCase().includes(currentValue.toLowerCase())
                    ).length === 0}
                    {suggestData
                      .filter((data) =>
                        data.Text.toLowerCase().includes(currentValue.toLowerCase())
                      )
                      .map((d, index) => (
                        <div
                          key={`key-dv-${d.Id}`}
                          className={`suggest-item ${
                            !isEmpty(d.Disabled) ? (d.Disabled ? 'disable-suggest-item' : '') : ''
                          }`}>
                          <input
                            key={`key-ip-chk-${d.Id}`}
                            id={`ip-chk-${d.Id}`}
                            type='checkbox'
                            className='item-checkbox'
                            checked={d.Checked}
                            onChange={(event) => {
                              inputChangeHandler(event.currentTarget.checked, d);
                              d.Disabled ? null : (d.Checked = event.currentTarget.checked);
                            }}
                            disabled={!d.Checked && disableCheckBox}></input>
                          {/* disabled={!d.Checked && disableCheckBox}></input> */}
                          <label
                            htmlFor={`ip-chk-${d.Id}`}
                            className={`${
                              !isEmpty(d.Disabled) ? (d.Disabled ? 'already-in-list-item' : '') : ''
                            }`}
                            key={index}
                            value={d.Id}
                            disabled={isEmpty(d.Disabled) ? false : d.Disabled}>
                            <>
                              {d.Text}
                              <span>{`(${d.Id})`}</span>
                            </>
                          </label>
                        </div>
                      ))}
                  </div>

                  <div className='action-section'>
                    <Button
                      id='suggest-btn-cancel'
                      text={buttonNames[1]}
                      disabled={false}
                      className={`fac-cancel valid `}
                      size='lg'
                      style='ghost'
                      onClick={onCancelClick}
                    />
                    <Button
                      id='suggest-btn-save'
                      text={`${buttonNames[0]} ${showCount ? `(${count})` : ''}`}
                      disabled={ctaValid != 'valid'}
                      className={`fac-save ${ctaValid}`}
                      size='lg'
                      style='ghost'
                      onClick={() => onSaveClick(suggestData.filter((i) => i.Disabled != true))}
                    />
                  </div>
                </>
              )}
            </div>
          ) : null}

          {invalidText.test(err.text) || showNoResultFound
            ? showValidationMsg && (
                <div className={`wrapper-suggest-list-${id}`}>
                  <button
                    id={`wrapper-suggest-item-${id}-no-result-message`}
                    key={id}
                    value={`No search result`}
                    disabled={true}>
                    No search result for '{err.text}'
                  </button>
                </div>
              )
            : null}
        </>
      )}
    </div>
  );
};

AutoSuggestCheckboxAlreadySelection.defaultProps = {
  setCurrentSelection: false,
  allowOtherThanList: false,
  isSearch: false,
  showValidationMsg: false,
  isDisabled: false,
  isFocusOut: true,
  showList: 'disable',
  showCount: false,
  currentSelectionArr: [],
  validationHandler: function () {}
};

export default AutoSuggestCheckboxAlreadySelection;
