import React, { useState, useEffect, useRef } from 'react';
import isEmpty from '../../../../utils/validation/isEmpty';
import './_autoSuggest.less';
import cross from '../../../../../public/images/cross.png';

const AutoSuggest = (props) => {
  const {
    id,
    label,
    name,
    placeholder,
    initialValue,
    data,
    onInputChangeHandler,
    onSuggestSelectHandler,
    setCurrentSelection,
    isSearch,
    allowOtherThanList,
    showValidationMsg,
    validationHandler,
    onOtherThanListHandler,
    isDisabled,
    showAlreadyInList,
    showAutosuggetClose,
    showHighlightedSerchTerm,
    clearValue
  } = props;

  //refs
  const _mainWrapper = useRef(null);

  //states
  const [currentValue, setCurrentValue] = useState(initialValue);
  const [listVisibility, setListVisibility] = useState(data.length > 0 );
  const [showNoResultFound, toggleNoResultFound] = useState(true);
  const [err, setErr] = useState({ name: '', val: false, text: '' });
  const INIT_VAL = { name: '', val: false, text: '' };
  const invalidText = new RegExp("[^ 0-9A-Za-zÀ-ÿ,&'./()-]");

  //event handlers
  const searchTextChangeHandler = (event) => {
    let _value = event.target.value;
    setCurrentValue(_value);
    event.target.name === 'degree'
      ? onInputChangeHandler(event)
      : _value.length > 1
      ? onInputChangeHandler(event)
      : null;
    setErr({ ...err, text: event.target.value });
    validationHandler(err);
  };

  const suggestSelectHandler = (event) => {
    let id = '';
    event.persist();
    setCurrentSelection || !allowOtherThanList
      ? showHighlightedSerchTerm && (event.target.value == undefined || event.target.value == '')
        ? ((id = event.target.id), setCurrentValue(event.target.id))
        : ((id = event.target.value), setCurrentValue(event.target.value))
      : setCurrentValue('');
    onSuggestSelectHandler(data.find((d) => d.Id == id));
    toggleNoResultFound(false);
    setErr({ ...err, val: false, text: event.target.value });
  };

  const clearSelected = (e, id) => {
    setCurrentValue('');
    clearValue(id);
  };

  const handleBlur = (event) => {
    setListVisibility(false);
    allowOtherThanList 
      ? (setCurrentValue(event.target.value),
        setErr(INIT_VAL),
        onOtherThanListHandler([
          {
            Disabled: false,
            Id: event.target.value,
            Name: null,
            Text: event.target.value
          }
        ]))
      : setCurrentValue(initialValue);
    if (event.relatedTarget == null) {
      setErr(INIT_VAL);
    } else if (!event.relatedTarget.id.startsWith(`wrapper-suggest-item-${id}`))
      setErr({ ...err, val: false, text: event.target.value });
  };

  const preFormatDropdownText = (val) => {
    let txtAlreadyInList = `${showAlreadyInList ? '<strong>(already in list)</strong>' : ''}`;
    let txtDropdown = `<span>${val.Text} ${txtAlreadyInList}</span>`;
    let result = isEmpty(val.Disabled) ? val.Text : val.Disabled ? txtDropdown : val.Text;
    return !showHighlightedSerchTerm ? result : highlightSearchedTerm(result, val.Id);
  };

  const highlightSearchedTerm = (val, id) => {
    if (_mainWrapper.current && _mainWrapper.current.getElementsByTagName('input')) {
      let searchInput = _mainWrapper.current.getElementsByTagName('input')[0];
      let res = displayMatches(val, currentValue, id);
      searchInput.addEventListener('change', displayMatches);
      searchInput.addEventListener('keyup', displayMatches);
      let dom = document.createElement('span');
      let response = (dom.innerHTML = res);
      return response;
    }
  };

  const displayMatches = (val, currentValue, id) => {
    let text = val.toString();
    if (text) {
      let regex = new RegExp(currentValue, 'gi');
      let res = text.replace(regex, function (str) {
        return "<span style='color: red; display: contents;' id='" + id + "'>" + str + '</span>';
      });
      return res;
    }
  };

  //effects
  useEffect(() => {
    setCurrentValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    let collection = document.getElementsByClassName('search');
    if (collection != null && collection.length != 0) {
      for (let i = 0; i < collection.length; i++) {
        if (collection[i].value.length > 0) {
          !invalidText.test(collection[i].value)
            ? setErr({ name: collection[i].name, val: false, text: collection[i].value })
            : setErr({ name: collection[i].name, val: true, text: collection[i].value });
        }
      }
    }
  }, [currentValue]);

  useEffect(() => {
    if (
      currentValue &&
      data &&
      currentValue.length > 0 &&
      data.length == 0 &&
      currentValue != initialValue
    ) {
      toggleNoResultFound(true);
    } else toggleNoResultFound(false);
  }, [currentValue, data]);

  return (
    <div
      ref={_mainWrapper}
      id={`wrapper-div-${id}`}
      className={`wrapper-div-${id} ${showAutosuggetClose ? 'position-cross' : ''}`}
      onFocus={() => setListVisibility(true)}
      onBlur={(e) => handleBlur(e)}>
      {label.length > 0 && <label htmlFor={`input-auto-suggest-${id}`}>{label}</label>}
      <input
        className={`search-input-${id} ${isSearch ? 'search' : ''} ${
          err.name != undefined && showValidationMsg
            ? (!showValidationMsg ? invalidText.test(err.text) : false)
              ? 'error-message'
              : ''
            : ''
        }`}
        type='text'
        name={name}
        placeholder={placeholder}
        value={currentValue}
        id={`input-auto-suggest-${id}`}
        onChange={searchTextChangeHandler}
        autoComplete='off'
        disabled={isEmpty(isDisabled) ? false : isDisabled}
      />
      {currentValue && currentValue.length > 0 && showAutosuggetClose && (
        <span className='clear-search' onClick={(e) => clearSelected(e, id)}>
          <img src={cross} />
        </span>
      )}

      {!err.val ||
        (invalidText.test(err.text) && !showValidationMsg && (
          <span className='error-message-autosuggest '>Invalid characters</span>
        ))}

      {!invalidText.test(err.text) &&
      listVisibility &&
      currentValue &&
      data &&
      currentValue.length > 0 &&
      data.length > 0 ? (
        <div className={`wrapper-div-section wrapper-suggest-list-${id}`}>
          {!invalidText.test(err.text) && (
            <div className='scrollbar' id='scrollbar-styles'>
              {data.map((d, index) => (
                <button
                  id={`wrapper-suggest-item-${id}-${index}`}
                  className={`${
                    !isEmpty(d.Disabled) ? (d.Disabled ? 'already-in-list-item' : '') : ''
                  }`}
                  key={index}
                  value={d.Id}
                  onMouseDown={suggestSelectHandler}
                  disabled={isEmpty(d.Disabled) ? false : d.Disabled}
                  dangerouslySetInnerHTML={{
                    __html: preFormatDropdownText(d)
                  }}></button>
              ))}
            </div>
          )}
        </div>
      ) : null}

      {/* This code was added to have consistency with reference to
      Languages Spoken in old profile design. But as per UX has been disabled for now. */}

      {/* {invalidText.test(err.text) || showNoResultFound
        ? showValidationMsg && (
            <div className={`wrapper-suggest-list-${id}`}>
              <button
                id={`wrapper-suggest-item-${id}-no-result-message`}
                key={id}
                value={`No search result`}
                disabled={true}>
                No search result for '{err.text}'
              </button>
            </div>
          )
        : null} */}
    </div>
  );
};

AutoSuggest.defaultProps = {
  setCurrentSelection: false,
  allowOtherThanList: false,
  isSearch: false,
  showValidationMsg: false,
  validationHandler: function () {},
  onOtherThanListHandler: function () {},
  data: [],
  isDisabled: false,
  showAlreadyInList: true,
  showAutosuggetClose: false,
  showHighlightedSerchTerm: false,
  clearValue: function () {}
};

export default AutoSuggest;
