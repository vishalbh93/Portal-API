import React from 'react';
//styles
import './_listItems.less';
//Components
import ToolTip, { TooltipContent, TooltipTrigger } from '../../../Common/ToolTip/Index';

const ListItems = ({ tagList, clickHandler, currentTab }) => {
  return (
    <div className='list-wrapper'>
      <ul className='list-group'>
        {tagList.map((tag, index) => (
          <li key={index} className='list-item'>
            {currentTab == 'credentials' || currentTab === '' ? (
              <span className='list-item-text'>{tag.Text}</span>
            ) : (
              <>
                <ToolTip id='shippingInfo'>
                  <TooltipTrigger as='span'>
                    <span
                      className={`list-item-text ${
                        Object.keys(tag).length != 0 ? 'long-text' : null
                      } ${tag.UpdateType == 'Delete' ? 'stike-through' : null}`}>
                      {tag.Name}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent placement='bottom'>
                    <p>{`${tag.Name} ${tag.Year != null ? '| ' + tag.Year : ''}`}</p>
                  </TooltipContent>
                </ToolTip>

                {tag.Year != null && (
                  <span
                    className={`list-item-text tag-name ${
                      tag.UpdateType == 'Delete' ? 'stike-through' : null
                    }`}>
                    {tag.Year}
                  </span>
                )}
              </>
            )}
            <span
              className='list-item-close'
              onClick={() => {
                clickHandler(tag);
              }}>
              {`${tag.UpdateType == 'Add' || tag.UpdateType == 'None' ? 'Remove' : 'Undo'}`}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};

ListItems.defaultProps = {
  isStikeThrough: false,
  removedItemObj: {},
  currentTab: ''
};
export default ListItems;
