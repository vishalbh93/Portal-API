import React from 'react';

import './_tags.less';

const Tags = ({ tagList, clickHandler }) => {
  return (
    <div className='tags-wrapper'>
      <ul className='tags-list'>
        {tagList.map((tag, index) => (
          <li
            key={index}
            className='tags-item'
            onClick={() => {
              clickHandler(tag);
            }}>
            <span className='tags-item-text'>{tag.Text}</span>
            <span className='tags-item-close'></span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Tags;
