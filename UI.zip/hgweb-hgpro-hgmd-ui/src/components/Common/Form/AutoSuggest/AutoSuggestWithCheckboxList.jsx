import React, { useState, useEffect, useRef } from 'react';
import isEmpty from '../../../../utils/validation/isEmpty';
import './_autoSuggestWithCheckboxList.less';
import Button from '@hg/joy/src/components/Button';

const AutoSuggestWithCheckboxList = (props) => {
  const {
    id,
    label,
    name,
    placeholder,
    initialValue,
    data,
    onInputChangeHandler,
    onSuggestSelectHandler,
    setCurrentSelection,
    isSearch,
    allowOtherThanList,
    showValidationMsg,
    validationHandler,
    isDisabled,
    buttonNames,
    onSaveClick,
    onCancelClick,
    isFocusOut,
    showList,
    isProviderListInPractice,
    isBatchEditPage
  } = props;

  const INIT_VAL = { name: '', val: false, text: '' };
  const [currentValue, setCurrentValue] = useState(initialValue);
  const [suggestData, setSuggestData] = useState([]);
  const [listVisibility, setListVisibility] = useState(data.length > 0);
  const [showNoResultFound, toggleNoResultFound] = useState(true);
  const [err, setErr] = useState({ name: '', val: false, text: '' });
  const [showListClass, setShowListClass] = useState(showList);
  const [ctaValid, setctaValid] = useState('');
  const [count, setCount] = useState(0);

  const refSearchInput = useRef();

  const invalidText = new RegExp("[^ 0-9A-Za-zÀ-ÿ,&'./()-]");

  const searchTextChangeHandler = (event) => {
    setCurrentValue(event.target.value);
    onInputChangeHandler(event);
    setErr({ ...err, text: event.target.value });
    validationHandler(err);
  };

  const suggestSelectHandler = (event) => {
    event.persist();
    setCurrentSelection || !allowOtherThanList
      ? setCurrentValue(event.target.value)
      : setCurrentValue('');
    onSuggestSelectHandler(data.find((d) => d.Id == event.target.value));
    toggleNoResultFound(false);
    setErr({ ...err, val: false, text: event.target.value });
  };

  const inputChangeHandler = (isChecked, item) => {
    let _tempSuggestData = [...suggestData];
    setSuggestData(
      _tempSuggestData.map((data) => {
        if (data.Id == item.Id) {
          //setctaValid('valid');
          return { ...data, Checked: isChecked };
        } else {
          return { ...data };
        }
      })
    );
    isProviderListInPractice ? setCount(suggestData.filter((i) => i.Checked == true).length) : null;
    isBatchEditPage
      ? props.passCountOfSelected(suggestData.filter((i) => i.Checked == true).length)
      : null;
  };

  const handleBlur = (event) => {
    allowOtherThanList
      ? (setCurrentValue(event.target.value), setErr(INIT_VAL))
      : setCurrentValue(initialValue);
    if (event.target.value == null || event.target.value == '') {
      setCurrentValue('');
    }
    if (event.relatedTarget == null) {
      setListVisibility(false);
      setErr(INIT_VAL);
    } else if (!event.relatedTarget.id.startsWith(`wrapper-suggest-item-${id}`))
      setListVisibility(false);
    setErr({ ...err, val: false, text: event.target.value });
  };

  const addToList = () => {
    props.onSaveClick(suggestData);
  };

  //effect
  useEffect(() => {
    setCurrentValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    if (isProviderListInPractice) {
      !isEmpty(suggestData) &&
      suggestData.filter((provider) => provider.Checked === true).length > 0
        ? setctaValid('valid')
        : setctaValid('');
    } else {
      if (
        suggestData.find(
          (p) =>
            (p.Checked == true && p.Selected == false) || (p.Checked == false && p.Selected == true)
        )
      ) {
        setctaValid('valid');
      } else {
        setctaValid('');
      }
    }
  }, [suggestData]);

  useEffect(() => {
    let collection = document.getElementsByClassName('search');
    if (collection != null && collection.length != 0) {
      for (let i = 0; i < collection.length; i++) {
        if (collection[i].value.length > 0) {
          !invalidText.test(collection[i].value)
            ? setErr({ name: collection[i].name, val: false, text: collection[i].value })
            : setErr({ name: collection[i].name, val: true, text: collection[i].value });
          setListVisibility(false);
        }
      }
    }
  }, [currentValue]);

  useEffect(() => {
    if (currentValue.length > 0 && data.length == 0 && currentValue != initialValue) {
      toggleNoResultFound(true);
    } else {
      toggleNoResultFound(false);
      setSuggestData(data);
    }
  }, [currentValue, data]);

  useEffect(() => {
    isProviderListInPractice ? setCount(suggestData.filter((i) => i.Checked == true).length) : null;
    isBatchEditPage
      ? props.passCountOfSelected(suggestData.filter((i) => i.Checked == true).length)
      : null;
  }, [suggestData]);

  const handleClickOutside = (event) => {
    if (refSearchInput.current && !refSearchInput.current.contains(event.target)) {
      setShowListClass('disable');
    } else if (refSearchInput.current != undefined || refSearchInput.current != null) {
      setShowListClass('enable');
    }
  };

  if (isFocusOut) {
    // //Bind the event listener
    document.addEventListener('mousedown', handleClickOutside);
  }

  return (
    <div id={`wrapper-div-${id}`} className={`wrapper-div-${id}`} onBlur={handleBlur}>
      {label.length > 0 && <label htmlFor={`input-auto-suggest-${id}`}>{label}</label>}
      <input
        className={`search-input-${id} ${isSearch ? 'search' : ''} ${
          err.name != undefined && showValidationMsg
            ? (!showValidationMsg ? invalidText.test(err.text) : false)
              ? 'error-message'
              : ''
            : ''
        }`}
        type='text'
        name={name}
        placeholder={placeholder}
        value={!isEmpty(currentValue) ? currentValue : ''}
        id={`input-auto-suggest-${id}`}
        onChange={searchTextChangeHandler}
        onFocus={(e) => setShowListClass('enable')}
        autoComplete='off'
        disabled={isEmpty(isDisabled) ? false : isDisabled}
      />

      {!err.val ||
        (invalidText.test(err.text) && !showValidationMsg && (
          <span className='error-message-autosuggest '>Invalid characters</span>
        ))}

      {(!invalidText.test(err.text) && listVisibility && currentValue.length > 0) ||
      (!isEmpty(suggestData) && suggestData.length > 0) ? (
        <div
          id={`input-auto-autosuggest-checkbox-${id}`}
          ref={refSearchInput}
          className={`wrapper-suggest-list ${id} mutiple-checkbox ${showListClass}`}>
          {suggestData.filter((data) =>
            data.Text.toLowerCase().includes(currentValue.toLowerCase())
          ).length > 0 && (
            <>
              <div className='wrapper-suggest-item' id='scrollbar-styles'>
                {suggestData.filter((data) =>
                  data.Text.toLowerCase().includes(currentValue.toLowerCase())
                ).length === 0}
                {suggestData
                  .filter((data) => data.Text.toLowerCase().includes(currentValue.toLowerCase()))
                  .map((d, index) => (
                    <div className='suggest-item' key={`key-dv-${d.Id}`}>
                      <input
                        key={`key-ip-chk-${d.Id}`}
                        id={`ip-chk-${d.Id}`}
                        type='checkbox'
                        className='item-checkbox'
                        checked={d.Checked}
                        onChange={(event) => {
                          inputChangeHandler(event.currentTarget.checked, d);
                          d.Checked = event.currentTarget.checked;
                        }}></input>
                      <label
                        htmlFor={`ip-chk-${d.Id}`}
                        className={`${
                          !isEmpty(d.Disabled) ? (d.Disabled ? 'already-in-list-item' : '') : ''
                        }`}
                        key={index}
                        value={d.Id}
                        // onMouseDown={suggestSelectHandler}
                        disabled={isEmpty(d.Disabled) ? false : d.Disabled}>
                        {isEmpty(d.Disabled) ? (
                          d.Text
                        ) : d.Disabled ? (
                          <span>{d.Text} (already in list)</span>
                        ) : (
                          d.Text
                        )}
                      </label>
                    </div>
                  ))}
              </div>

              <div className='action-section'>
                <Button
                  id='suggest-btn-cancel'
                  text={buttonNames[1]}
                  disabled={false}
                  className={`provider-profile-cancel valid `}
                  size='lg'
                  style='ghost'
                  onClick={onCancelClick}
                />
                <Button
                  id='suggest-btn-save'
                  text={`${buttonNames[0]}${isProviderListInPractice ? ` (${count})` : ''}`}
                  disabled={ctaValid != 'valid'}
                  className={`provider-profile-save ${ctaValid}`}
                  size='lg'
                  style='ghost'
                  onClick={() => onSaveClick(suggestData)}
                />
              </div>
            </>
          )}
        </div>
      ) : null}

      {invalidText.test(err.text) || showNoResultFound
        ? showValidationMsg && (
            <div className={`wrapper-suggest-list-${id}`}>
              <button
                id={`wrapper-suggest-item-${id}-no-result-message`}
                key={id}
                value={`No search result`}
                disabled={true}>
                No search result for '{err.text}'
              </button>
            </div>
          )
        : null}
    </div>
  );
};

AutoSuggestWithCheckboxList.defaultProps = {
  setCurrentSelection: false,
  allowOtherThanList: false,
  isSearch: false,
  showValidationMsg: false,
  validationHandler: function () {},
  isDisabled: false,
  isFocusOut: true,
  showList: 'disable',
  isProviderListInPractice: false,
  isBatchEditPage: false,
  passCountOfSelected: function () {}
};

export default AutoSuggestWithCheckboxList;
