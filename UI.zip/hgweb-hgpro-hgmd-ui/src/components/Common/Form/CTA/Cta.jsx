import React from 'react';

import './_cta.less';

import Button from '@hg/joy/src/components/Button';

const Cta = ({
  ctaValid,
  cancelText,
  cancelValid,
  cancelClickHandler,
  confirmText,
  confirmClickHandler,
  showCancel,
  className
}) => {
  return (
    <div className={`action-section ${className}`}>
      {showCancel && (
        <Button
          id='btn-cancel'
          text={cancelText}
          disabled={cancelValid != undefined ? cancelValid : !ctaValid}
          className={`provider-profile-cancel ${
            cancelValid != undefined ? 'valid' : ctaValid ? 'valid' : ''
          }`}
          size='lg'
          style='ghost'
          onClick={cancelClickHandler}
        />
      )}
      <Button
        id='btn-save'
        text={confirmText}
        disabled={!ctaValid}
        className={`provider-profile-save ${ctaValid ? 'valid' : ''}`}
        size='lg'
        style='ghost'
        onClick={confirmClickHandler}
      />
    </div>
  );
};

Cta.defaultProps = {
  ctaValid: 'true',
  cancelText: 'Cancel',
  confirmText: 'Save',
  showCancel: true,
  className:''
};

export default Cta;
