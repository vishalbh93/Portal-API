import React from 'react';
import Toggle from '../Toggle';
import { storiesOf } from '@storybook/react';

let selected = true;
const toggleSelected = () => {
  return selected == false;
};

storiesOf('Common|Toggle-Button', module).add('Toggle', () => (
  <Toggle selected={selected} toggleSelected={toggleSelected} />
));
