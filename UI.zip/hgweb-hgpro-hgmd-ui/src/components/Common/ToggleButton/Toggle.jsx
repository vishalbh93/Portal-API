import React from 'react';
import PropTypes from 'prop-types';
import './_toggle.less';
{
}
const Toggle = (props) => {
  const { selected, toggleSelected, disabled } = props;
  return (
    <div
      className={`toggle-container ${selected && !disabled ? 'enabled' : ''} ${
        disabled ? 'disabled-toogle' : ''
      }`}
      onClick={!disabled ? toggleSelected : null}>
      <div
        className={`dialog-button ${selected && !disabled ? '' : 'disabled'} ${
          disabled ? 'disabled-toogle' : ''
        }`}></div>
    </div>
  );
};

Toggle.defaultProps = {
  disabled: false
};

Toggle.propTypes = {
  selected: PropTypes.bool.isRequired,
  toggleSelected: PropTypes.func.isRequired,
  disabled: PropTypes.bool
};

export default Toggle;
