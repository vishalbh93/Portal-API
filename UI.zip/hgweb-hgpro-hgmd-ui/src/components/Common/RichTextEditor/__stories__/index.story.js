import React from 'react';

import { storiesOf } from '@storybook/react';
import RichTextEditor from '../RichTextEditor';

const defaultContents = `<p><b>Brent Bellotte</b>, MD is board certified by the American Board of Ophthalmology.He completed his ophthalmology training from Texas Tech University Department of Ophthalmology and Visual Sciences where the department heads selected him for the prestigious chief designation of his residency program. During this time he was honored with the coveted Grand Rounds Presentation Award from Texas Tech University. Prior to this, he graduated summa cum laude with honors in biologyfrom West Virginia University, then remained in his home state to receive his medical degree from West Virginia University School of Medicine. At that time, he graduated in the top 1% of the class with honors in nearly every medical specialty. He received the of the Award of Excellence from West Virginia University School of Medicine for outstanding class rank. He also received the acclaimed Peggy Preston Tertiary Scholarship, the Hurlbutt Memorial Endowment, and was awarded the Spurlock Fellowship for work sequencing retroviral DNA. Additionally, he was elected as a judge for the Van Liere Research Convocation.</p>`;
const editorContent = {
  defaultContent: defaultContents,
  maxLength: 4000,
  actualLength: defaultContents.length,
  changeContentHandler
};
const changeContentHandler = () => {
  return editorContent.maxLength - editorContent.actualLength;
};

storiesOf('Common|Rich Text Editor', module).add('Rich Text Editor', () => (
  <RichTextEditor {...editorContent} changeContentHandler={changeContentHandler} />
));
