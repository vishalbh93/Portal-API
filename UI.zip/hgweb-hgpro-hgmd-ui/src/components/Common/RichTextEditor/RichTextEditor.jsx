import React, { useRef, useState, useMemo } from 'react';
import './_richTextEditor.less';
import JoditEditor from 'jodit-react';
import PropTypes from 'prop-types';

import warning from '../../../assets/images/warning.svg';

const RichTextEditor = (props) => {
  const { defaultContent, maxLength, actualLength, changeContentHandler, errorMessage } = props;
  const editorRef = useRef(null);
  const [content, setContent] = useState(defaultContent);

  //Setting properties of editor
  const config = {
    readonly: false,
    buttons: ['bold', 'italic', '|', 'ol', 'ul'],
    showXPathInStatusbar: false,
    toolbarAdaptive: false,
    placeholder: '',
    askBeforePasteFromWord: false,
    askBeforePasteHTML: false,
    defaultActionOnPaste: 'insert_clear_html',
    defaultActionOnPasteFromWord: 'insert_as_text',
    enter: 'p',
    style: {
      font: '14px HgSans',
      color: '@gray90',
      background: '@white'
    },
    beautifyHTML: false,
    //Not compulsory to right here
    // cleanHTML: {
    //   cleanOnPaste: true,
    //   allowTags: 'p,em,ol,ul,strong,b,br'
    // },
    uploader: { url: 'none' },
    hidePoweredByJodit: true
  };

  // For counting remaining character
  // It has its default char counter and word counter but its not counting as per reaqirement
  let remainingChars = maxLength - (defaultContent === '' ? 0 : actualLength);

  return (
    <>
      <div>
        {useMemo(
          () => (
            <JoditEditor
              ref={editorRef}
              value={content}
              config={config}
              tabIndex={1}
              onBlur={(newContent) => {
                //  setContent(newContent);
              }}
              onChange={(newContent) => {
                setContent(newContent);
                changeContentHandler(newContent);
              }}
            />
          ),
          []
        )}
      </div>

      <div className='remaining-area'>
        {errorMessage != undefined && errorMessage != '' && (
          <label className='error-message'>
            <img src={warning} alt='error' />
            {` `}
            {errorMessage}
          </label>
        )}
        {remainingChars >= 0 ? (
          <label>{remainingChars} characters remaining</label>
        ) : (
          <label className='warning-message'>
            Maxiumum {maxLength} characters. You are {Math.abs(remainingChars)} characters over the
            limit.
          </label>
        )}
      </div>
    </>
  );
};

RichTextEditor.defaultProps = {
  defaultContent: '',
  maxLength: 0,
  actualLength: 0,
  changeContentHandler: function () {},
  errorMessage: ''
};

RichTextEditor.propTypes = {
  defaultContent: PropTypes.string,
  maxLength: PropTypes.number,
  actualLength: PropTypes.number,
  changeContentHandler: PropTypes.func,
  errorMessage: PropTypes.string
};
export default RichTextEditor;