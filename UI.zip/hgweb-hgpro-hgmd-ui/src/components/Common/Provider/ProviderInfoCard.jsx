import React from 'react';

//------------------------- Stylesheet import -----------------------
import './_providerInfoCard.less';

//------------------------- Components import -----------------------
import ProviderImage from '@hg/joy/src/components/ProviderImage';
import StarRating from '@hg/joy/src/components/StarRating';

//------------------------- Helper import -----------------------
import isEmpty from '../../../utils/validation/isEmpty';
import { getGenderCode } from '../../../utils/utils';

const ProviderInfoCard = (props) => {
  //----------------------- props destructuring -----------------------
  const { secName, imageObj, informationObj } = props;

  //----------------------- JSX code -----------------------
  return (
    <section id={`section-${secName}`} className='provider-info-card'>
      <div className='pic-container'>
        <ProviderImage
          providerName={imageObj.name}
          src={imageObj.imageSrc}
          id={`pic-${imageObj.id}`}
          className={`${imageObj.className}`}
          providerGender={getGenderCode(imageObj.gender)}
          size={imageObj.size}
        />
      </div>
      <div className='info-container'>
        {!isEmpty(informationObj.displayName) && (
          <h1 className='txt-display-name'>{informationObj.displayName}</h1>
        )}
        <div className='sub-info'>
          {!isEmpty(informationObj.speciality) && (
            <span className='txt-speciality-name'>{informationObj.speciality}</span>
          )}
          {!isEmpty(informationObj.ratingInfo) && (
            <div className='ratings'>
              <StarRating stars={Math.round(informationObj.ratingInfo.stars * 2) / 2} size='xl' /> |{' '}
              <span className='txt-ratings'>{informationObj.ratingInfo.ratings} Ratings</span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ProviderInfoCard;
