import React from 'react';
import { storiesOf } from '@storybook/react';

import ProviderInfoCard from './../ProviderInfoCard';

const imageObj = {
  id: 'story-test',
  className: 'provider-image',
  gender: 'F',
  imageSrc: 'https://photos.healthgrades.com/img/prov/y/7/l/y7lh58z_w90h120_vSJ_Kp246u.jpg',
  name: 'Doctor Name',
  size: 'xl'
};

const informationObj = {
  displayName: 'Dr. Ciccotelli, MD',
  speciality: 'Orthopedic Surgeon',
  ratingInfo: {
    stars: 4,
    ratings: 26
  },
  lastUpdated: null
};

storiesOf('Common | Provider', module).add('Provider Info Card', () => (
  <ProviderInfoCard secName='story-test' imageObj={imageObj} informationObj={informationObj} />
));
