import React, { useState } from 'react';

// svg imports
import svgWarning from '../../../assets/images/ProviderProfile/svg-warning.svg';

//media
import UpArrow from '../../../assets/images/ProfileEdit/icon-up-arrow.svg';
import RightArrow from '../../../assets/images/ProfileEdit/icon-right-arrow-black.svg';
import _ from 'lodash';

const LayoutInfoEducation = (props) => {
  const identifier = props.identifier == undefined ? 'div' : 'div-' + props.identifier;
  const [isExpandClick, toggleIsExpandClick] = useState(false);

  const _missingFields =
    props.bullets.data.length > 0 ? (
      <div id={`${identifier}-bullets`} className='layout-info-bullets'>
        <span>
          {props.bullets.title} <img src={svgWarning} alt='!' />
        </span>
        <ul>
          {props.bullets.data.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    ) : (
      <></>
    );

  const expandEducationHandler = () => {
    toggleIsExpandClick(!isExpandClick);
  };

  return (
    <div id={`${identifier}`} className={`layout-info`}>
      <div id={`${identifier}-label`} className='layout-info-label'>
        {props.windowDimensions < 769 && (
          <div
            id={`${isExpandClick ? 'up-arrow' : 'right-arrow'}`}
            onClick={() => expandEducationHandler()}>
            <img src={` ${isExpandClick ? UpArrow : RightArrow}`} alt='logo-arrow' />
          </div>
        )}
        <div id={`${identifier}-title`} className={`${isExpandClick ? 'expanded-div' : ''}`}>
          <span title={props.title}>{props.title}</span>
          {isExpandClick && <p title={props.description}>{props.description}</p>}
        </div>
        {_missingFields}
      </div>
      <div
        className={`layout-info-children ${!isExpandClick ? 'hide-layout-info-children' : ''}${
          isExpandClick && props.windowDimensions < 769 ? 'show-full-width-mobile' : ''
        }`}>
        {props.children}
      </div>
    </div>
  );
};

export default LayoutInfoEducation;
