import React from 'react';
import { storiesOf } from '@storybook/react/dist/client/preview';

import AutoSuggestWithCheckbox from '../AutoSuggestWithCheckbox.jsx';
import Landing from '../Landing.jsx';

const insuranceObj = {
  id: '414d4441-0052-0000-0000-000000000000',
  code: 'ADMAR',
  title: 'Admar',
  planCount: 4,
  plans: []
};

let checkboxOptions = [
  {
    id: '30525048-3030-3330-3731-360000000000',
    label: 'HealthyBlue 2.0',
    checked: false
  },
  {
    id: '30525048-3030-3230-4645-390000000000',
    label: 'HealthyBlue Advantage',
    checked: true
  }
];

//event handlers
const handleCheckBoxInputClick = (option, checked) => {
  alert(`Checkbox : ${checked ? 'checked' : 'unchecked'}`);
};

const handleCloseClick = () => {};

const autosuggestOptions = {
  placeholder: 'Add Placeholder',
  initialValue: '',
  data: [],
  onInputChangeHandler: () => {},
  onSuggestSelectHandler: () => {},
  setCurrentSelection: false,
  showValidationMsg: true,
  isSearch: true
};

const ctaOptions = {
  isVisibile: true,
  ctaValid: true,
  cancelText: 'Cancel',
  cancelClickHandler: () => {
    alert('Cancel Clicked');
  },
  confirmText: 'Remove Plan',
  confirmClickHandler: () => {
    alert('Confirm Clicked');
  }
};

//-------------------- Landing.jsx story ------------------
const LandingComponent = {
  name: 'story',
  providerInformationObj: {
    imageObj: {
      id: 'story-test',
      className: 'provider-image',
      gender: 'F',
      imageSrc: 'https://photos.healthgrades.com/img/prov/y/7/l/y7lh58z_w90h120_vSJ_Kp246u.jpg',
      name: 'Doctor Name',
      size: 'xl'
    },
    informationObj: {
      displayName: 'Dr. Ciccotelli, MD',
      speciality: 'Orthopedic Surgeon',
      ratingInfo: {
        stars: 4,
        ratings: 26
      },
      lastUpdated: null
    }
  }
};

storiesOf('Common|Layouts', module)
  .add('AutoSuggest-CheckBox', () => (
    <AutoSuggestWithCheckbox
      title={insuranceObj.title}
      checkboxOptions={checkboxOptions}
      checkboxOptionsLimit={1}
      checkBoxInputClick={handleCheckBoxInputClick}
      autosuggestOptions={autosuggestOptions}
      ctaOptions={ctaOptions}
      onCloseClick={handleCloseClick}
    />
  ))
  .add('Landing', () => <Landing name={LandingComponent.name} providerInformationObj={LandingComponent.providerInformationObj} />);
