import React from 'react';

import './_layoutInfo.less';

// svg imports
import svgWarning from '../../../assets/images/ProviderProfile/svg-warning.svg';

const LayoutInfo = (props) => {
  const identifier = props.identifier == undefined ? 'div' : 'div-' + props.identifier;

  const _missingFields =
    props.bullets.data.length > 0 ? (
      <div id={`${identifier}-bullets`} className='layout-info-bullets'>
        <span>
          {props.bullets.title} <img src={svgWarning} alt='!' />
        </span>
        <ul>
          {props.bullets.data.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    ) : (
      <></>
    );

  return (
    <div id={`${identifier}`} className='layout-info'>
      <div id={`${identifier}-label`} className='layout-info-label'>
        <div id={`${identifier}-title`}>
          <span title={props.title}>{props.title}</span>
          <p title={props.description}>{props.description}</p>
        </div>
        {_missingFields}
      </div>
      <div className='layout-info-children'>{props.children}</div>
    </div>
  );
};

LayoutInfo.defaultProps = {
  bullets: {
    title: 'Missing Fields',
    data: []
  }
};

export default LayoutInfo;
