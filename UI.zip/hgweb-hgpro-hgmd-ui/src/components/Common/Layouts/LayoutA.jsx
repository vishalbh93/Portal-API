import React from 'react';

const LayoutA = (props) => {
  const identifier = props.identifier == undefined ? 'div-' : 'div-' + props.identifier;

  return (
    <div id={`${identifier}-section`}>
      <div id={`${identifier}-header`}>{props.header}</div>
      {props.children}
      <div id={`${identifier}-footer`}>{props.footer}</div>
    </div>
  );
};

export default LayoutA;
