import React, { useState, useEffect, useRef } from 'react';

//component imports
import LayoutInfo from './LayoutInfo';
import AutoSuggestWithCheckboxList from '../Form/AutoSuggest/AutoSuggestWithCheckboxList';
import Cta from '../Form/CTA/Cta';
import ReactModal from 'react-modal';

//svg imports
import svgMenudots from '../../../assets/images/icon-menu-dots.svg';
import Close from '../../../assets/images/ProviderProfile/svg-cross.svg';

//styling imports
import './_autosuggestWithCheckBox.less';

const AutoSuggestWithCheckbox = ({
  title,
  description,
  showAutoSuggestTextField,
  checkboxOptions,
  checkboxOptionsLimit,
  checkBoxInputClick,
  autosuggestOptions,
  ctaOptions,
  onCloseClick,
  className,
  id
}) => {
  //refs
  const _closeModal = useRef(null);
  const _delMenu = useRef(null);

  //states
  const [checkboxViewLimit, setCheckboxViewLimit] = useState(checkboxOptionsLimit);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  //event handlers
  const handleViewMoreClick = () => {
    setCheckboxViewLimit(checkboxOptions.length);
  };

  const handleShowLessClick = () => {
    setCheckboxViewLimit(checkboxOptionsLimit);
  };

  const handleClickOutside = (event) => {
    if (_delMenu.current && !_delMenu.current.contains(event.target)) {
      setShowDelete(false);
    }
  };

  //dynamic JSX
  const _closeModalJSX = () => {
    return `<span>Are you sure, you want to remove <br/> <strong>${title}</strong> ?</span>`;
  };

  //effect
  useEffect(() => {
    showDelete
      ? document.addEventListener('click', handleClickOutside, true)
      : document.removeEventListener('click', handleClickOutside, true);
  }, [showDelete]);

  return (
    <>
      <div className={`${className} sec-autosuggest-checkbox`}>
        <div className='delete-menu' ref={_delMenu}>
          <span className='delete-span'>
            <img src={svgMenudots} alt='close' onClick={() => setShowDelete(!showDelete)} />
          </span>
          {showDelete && (
            <div className='delete-items'>
              <a
                onClick={() => {
                  setShowCloseModal(true);
                  setShowDelete(false);
                }}></a>
            </div>
          )}
        </div>
        <LayoutInfo identifier='ascb' title={title} description={description}>
          {showAutoSuggestTextField && (
            <>
              <div className='ip-group'>
                <div className='ip-auto-suggest'>
                  <AutoSuggestWithCheckboxList
                    id={`ele-autosuggest-checkbox-${id}`}
                    label=''
                    name=''
                    placeholder={autosuggestOptions.placeholder}
                    initialValue={autosuggestOptions.initialValue}
                    data={autosuggestOptions.data}
                    onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
                    onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
                    setCurrentSelection={autosuggestOptions.setCurrentSelection}
                    showValidationMsg={autosuggestOptions.showValidationMsg}
                    isSearch={autosuggestOptions.isSearch}
                    buttonNames={autosuggestOptions.buttonNames}
                    onSaveClick={autosuggestOptions.onSaveClick}
                    onCancelClick={autosuggestOptions.onCancelClick}
                  />
                </div>
                <div className='checkbox-list'>
                  {checkboxOptions.length > 0 &&
                    checkboxOptions.map((option, index) => {
                      if (index < checkboxViewLimit)
                        return (
                          <InputCheckBox
                            key={index}
                            index={index}
                            option={option}
                            handleCheckboxClick={checkBoxInputClick}
                          />
                        );
                    })}

                  {checkboxOptions.length > 0 && checkboxOptions.length > checkboxOptionsLimit ? (
                    checkboxViewLimit <= checkboxOptionsLimit ? (
                      <a onClick={handleViewMoreClick}>View More</a>
                    ) : (
                      <a onClick={handleShowLessClick}>Show Less</a>
                    )
                  ) : null}
                </div>
              </div>
              {ctaOptions.isVisibile && (
                <Cta
                  ctaValid={ctaOptions.ctaValid}
                  cancelText={ctaOptions.cancelText}
                  cancelClickHandler={ctaOptions.cancelClickHandler}
                  confirmText={ctaOptions.confirmText}
                  confirmClickHandler={ctaOptions.confirmClickHandler}
                />
              )}
            </>
          )}
        </LayoutInfo>
      </div>
      <ReactModal
        overlayClassName='modal-overlay modal-close-overlay'
        className='modal-dialog modal-close-dialog'
        ariaHideApp={false}
        isOpen={showCloseModal}
        onAfterOpen={() =>
          _closeModal.current.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          })
        }
        contentLabel=''
        onRequestClose={() => {}}
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container' ref={_closeModal}>
          <div className='modal-header'>
            <h4 className='modal-title'></h4>
            <div
              className='modal-close'
              onClick={() => {
                setShowCloseModal(false);
              }}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>
          <div
            className='modal-body close-content'
            dangerouslySetInnerHTML={{ __html: _closeModalJSX() }}></div>
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText='Cancel'
              cancelClickHandler={() => {
                setShowCloseModal(false);
              }}
              confirmText='Confirm'
              confirmClickHandler={() => {
                onCloseClick();
                setShowCloseModal(false);
              }}
            />
          </div>
        </div>
      </ReactModal>
    </>
  );
};

const InputCheckBox = ({ index, option, handleCheckboxClick }) => {
  return (
    <div id={`dv-chk-${index}-${option.id}`}>
      <input
        id={`ip-chk-${index}-${option.id}`}
        type='checkbox'
        checked={option.checked}
        onChange={(event) => {
          handleCheckboxClick(option, event.currentTarget.checked);
        }}
      />
      <label htmlFor={`ip-chk-${index}-${option.id}`}>{option.label}</label>
    </div>
  );
};

AutoSuggestWithCheckbox.defaultProps = {
  description: '',
  className: '',
  showAutoSuggestTextField: true
};

export default AutoSuggestWithCheckbox;
