import React from 'react';

//------------------------- Stylesheet import -----------------------
import './_landing.less';

//----------------------- Helper imports ----------------------------
import isEmpty from '../../../utils/validation/isEmpty';

//------------------------- Components import -----------------------
import ProviderInfoCard from '../Provider/ProviderInfoCard';

const Landing = (props) => {
  //------------------- props destructuring -------------------
  const { providerInformationObj, sponsorInformationObj } = props;

  //------------------- JSX code ------------------------------
  return (
    <>
      <header className='landing-header'>
        <div className='banner-content-wrapper'>
          {!isEmpty(providerInformationObj.informationObj) &&
            !isEmpty(providerInformationObj.imageObj) && (
              <ProviderInfoCard
                secName='banner-landing'
                informationObj={providerInformationObj.informationObj}
                imageObj={providerInformationObj.imageObj}
              />
            )}
          {!isEmpty(sponsorInformationObj) &&
            !isEmpty(sponsorInformationObj.SponsorName) &&
            !isEmpty(sponsorInformationObj.SponsorImageSrc) && (
              <div className='sponsor-content-wrapper'>
                <div className='sponsor-by-text'>Your profile is sponsored by</div>
                <div className='sponsor-logo sponsor-info'>
                  <img
                    className='sponsors-logo'
                    src={sponsorInformationObj.SponsorImageSrc}
                    alt='Logo'
                  />
                </div>
                <div className='sponsor-name'>
                  <span className='sponsor-name-label'>{sponsorInformationObj.SponsorName}</span>
                  <span className='sponsor-name-sublabel'>
                    {!isEmpty(sponsorInformationObj.OfficeAddress) &&
                      !isEmpty(sponsorInformationObj.OfficeCity) && (
                        <span>
                          {sponsorInformationObj.OfficeAddress}, {sponsorInformationObj.OfficeCity}
                        </span>
                      )}
                    {!isEmpty(sponsorInformationObj.OfficeZipcode) &&
                      !isEmpty(sponsorInformationObj.OfficeFax) && (
                        <span>
                          {sponsorInformationObj.OfficeZipcode}, {sponsorInformationObj.OfficeFax}
                        </span>
                      )}
                  </span>
                </div>
              </div>
            )}
        </div>
      </header>
      {/* <main id={`main-${name}`}>
        <aside>
          <ul></ul>
        </aside>
        <section id={`section-${name}`}></section>
      </main> */}
    </>
  );
};

export default Landing;
