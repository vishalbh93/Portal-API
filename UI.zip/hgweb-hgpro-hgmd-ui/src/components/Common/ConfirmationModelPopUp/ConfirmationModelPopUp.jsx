import React, { useState } from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../Layouts/LayoutA';
import ReactModal from 'react-modal';

//Stylesheet impor
import './_confirmationModelPopUp.less';

//Media imports
import cross from '../../../assets/images/ProviderProfile/Vector.svg';

const ConfirmationModelPopUp = (props) => {

  const buttonName = 'Continue';
  const cancelButton='Cancel';

  const onConfirmHandler = (value) => {
    props.onhandleConfirm(value);
  };
 
  const isMobileView = window.innerWidth <= 786;
  const header = '';

  return (
    <LayoutA>
      <ReactModal
        overlayClassName='roster-modal-overlay delete-confirmation-modal-popup'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={props.showModal}
        contentLabel='hospital-model'
        onRequestClose={() => onConfirmHandler(false)}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-section'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={() => onConfirmHandler(false)} />
            </div>
            <div className='modal-row'>
              {isMobileView && <div className='header'>{header}</div>}
              <div className='container'>
                <div className='title'>
                  {props.showModal && (
                    <>
                      You have unsaved changes, are you sure you want to continue?                                          
                    </>
                  )}
                </div>
                <div className = {!isMobileView? "title-btn": "title"}>
                <button
                    title={cancelButton}
                    type='button'
                    className={!isMobileView? 'btn-section-1': 'btn-section'}
                    onClick={() => onConfirmHandler(false)}>
                    {cancelButton}
                  </button>

                  <button
                    title={buttonName}
                    type='button'
                    className={!isMobileView? 'btn-section-1 btn-remove': 'btn-section btn-remove'}
                    onClick={() => onConfirmHandler(true)}>
                    {buttonName}
                  </button>   
                </div>
              </div>
            </div>
          </div>
        </div>
      </ReactModal>
    </LayoutA>
  );
};


ConfirmationModelPopUp.propTypes = { 
  showModal: PropTypes.bool,
  onhandleConfirm: PropTypes.func,
};

export default ConfirmationModelPopUp;
