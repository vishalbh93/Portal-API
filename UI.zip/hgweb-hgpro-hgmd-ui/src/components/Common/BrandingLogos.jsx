import React from 'react';

//stylesheet imports
import './_brandingLogos.less';

//media imports
import svgHG from '../../assets/images/full-logo.svg';
import svgMNT from '../../assets/images/ClaimYourProfile/brand-logo-mnt.svg';
import svgHFC from '../../assets/images/ClaimYourProfile/brand-logo-hfc.svg';
import svgSC from '../../assets/images/ClaimYourProfile/brand-logo-sc.svg';

const BrandingLogos = () => {
  return (
    <div className='branding-logs'>
      <div className='branding-logs-inner'>
        <img src={svgHG} alt='Logo' />
        <p className='inner-content'>
          By updating your data with Healthgrades, your data will also be updated across all of our
          partner solutions.
        </p>

        <a className='logo-link' href='https://www.medicalnewstoday.com/provider-near-me' target='_blank' alt='brand-mnt' ><img className='brand-mnt' src={svgMNT} alt='brand-mnt'/> </a>
        <a className='logo-link' href='https://care.healthline.com/find-care' target='_blank' alt='brand-hfc'><img className='brand-hfc' src={svgHFC} alt='brand-hfc'/></a>
        <a className='logo-link' href='https://www.sharecare.com/find-a-doctor' target='_blank' alt='brand-shareCare'><img className='brand-shareCare' src={svgSC} alt='brand-shareCare'/></a>
      </div>
    </div>
  );
};

export default BrandingLogos;
