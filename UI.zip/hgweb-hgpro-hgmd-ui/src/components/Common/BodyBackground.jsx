import React from 'react';

import './_bodyBackground.less';

//media imports
import designSnap from '../../assets/images/ClaimYourProfile/design-snap.png';
import designSnapM from '../../assets/images/ClaimYourProfile/design-snap-m.png';

export const BodyBackground = () => {
    return (
        <div className='bb-container'>
            <div className='bb-section hg-container'>
                <div className='bb-headers'>
                    <h1>
                        <span className='header-one'>Claim Your</span>
                        <span className='header-two'>
                            Free Profile
                        </span>
                    </h1>
                    <h2
                        className='sub-header'>
                        Healthgrades is the leading destination for patients looking for providers.
                    </h2>
                </div>
                <img className='design-snap' src={designSnap} alt='design-snap' />
                <img className='design-snap-mobile' src={designSnapM} alt='design-snap-mobile'/>
            </div>
            <svg
                className='bb-svg-curve'
                data-qa-target='hero-background-svg'
                preserveAspectRatio='none'
                viewBox='45 0 1200 149'>
                <path
                    d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
                    fill='#FFF'></path>
            </svg>
            <svg
                className='bb-svg-curve-mobile'
                data-qa-target='hero-background-svg-mobile'
                preserveAspectRatio='none'
                viewBox='0 0 375 120'>
                <path
                    d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
                    fill='#FFFFFF'></path>
            </svg>
        </div>
    );
};
