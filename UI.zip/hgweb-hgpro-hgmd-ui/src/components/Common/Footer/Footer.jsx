import React, { Fragment, useState, useEffect } from 'react';
import './_footer.less';
import '@hg/joy/src/globalstyles';
import PropTypes from 'prop-types';

//media imports
import footerLogo from '../../../assets/images/healthgrades_icon.svg';
import providerReferralImg from '../../../assets/images/ProviderReferral/providerRefferal.svg';
import ConfirmationModelPopUp from '../../Common/ConfirmationModelPopUp/ConfirmationModelPopUp';

const Footer = (props) => {
  const hasReferralPage = window.location.pathname
    .split('/')
    .map((val) => val.toLowerCase())
    .includes('providerreferral')
    ? true
    : false;

  const [flag, setFlag] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState();

  const validatePage = () => {     
    let photoVidButton = document.getElementsByClassName('profile-photo-video-main');
    let isProfilePage = document.getElementById('provider-profile-container');
    if (isProfilePage == null || photoVidButton.length !== 0) {
      setShowModal(false);
      setFlag(true);
    }else{
      let eleValidButton = document.getElementsByClassName('provider-profile-save valid');
    let eleValidButton_1 = document.getElementsByClassName('provider-profile-appointments-save valid');
    if (eleValidButton.length !== 0 || eleValidButton_1.length !== 0){
      setShowModal(true);
      setFlag(false);
    }      
    else{
      setShowModal(false);
      setFlag(true);      
    } 
    } 
  };

  const onhandleConfirm =(value) =>{    
    setFlag(value);
    setShowModal(false);
  };

  const redirectFunc=(value)=>{ 
    validatePage(); 
    setRedirectUrl(value); 
  };

  useEffect(() => {
    if (flag) {            
      window.location.href = redirectUrl;
       }
  },[redirectUrl, flag]);

  return (
    <>
    <div className='footer-main'>
      <div className='footer'>
        <div className={`footer-images ${hasReferralPage ? 'referral-footer-images' : ''}`}>
          <img src={footerLogo} alt='Healthgrades' />

          {hasReferralPage && (
            <span className='provider-referral-images'>
              <img src={providerReferralImg} alt='Healthgrades' />
            </span>
          )}
        </div>

        <div>
          <p className='links'>
            <a onClick={()=>redirectFunc('https://www.healthgrades.com/')}
            rel='noreferrer' className='hyper-link'>
              Healthgrades.com
            </a>
            <a  onClick={()=>redirectFunc('https://www.healthgrades.com/about')}
            rel='noreferrer' className='hyper-link'>
              About Us
            </a>
            <a onClick={()=>redirectFunc('/contactus')}
            target='_blank' rel='noreferrer' className='hyper-link'>
              Contact Us
            </a>
            <a onClick={()=>redirectFunc('https://www.healthgrades.com/content/legal-disclaimer')}
              target='_blank'
              rel='noreferrer'
              className='hyper-link'>
              Legal Disclaimer
            </a>
            <a onClick={()=>redirectFunc('https://www.healthgrades.com/content/privacy-policy')}
              target='_blank'
              rel='noreferrer'
              className='hyper-link'>
              Privacy Policy
            </a>
            <a onClick={()=>redirectFunc('https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center')}
              target='_blank'
              rel='noreferrer'
              className='hyper-link no-seperator'>
              Help Center
            </a>
          </p>
          <p className='copyright'>
            © Copyright {new Date().getFullYear()} Healthgrades Marketplace, LLC, a Red Ventures
            Company, Patent US 7,752,060 and 8,719,052. All Rights Reserved. Third Party materials
            included herein protected under copyright law.
          </p>
          <p>
            {' '}
            Use of this website and any information contained herein is governed by the{' '}
            <a onClick={()=>redirectFunc('https://update.healthgrades.com/user-agreement')}  
              target='_blank'
              rel='noreferrer'
              className='link no-seperator'>
              <b className='healthgrades-physician-hyper-link'>Healthgrades Physician User Agreement</b>
            </a>{' '}
            Misrepresenting yourself as a physician violates federal statutes and laws in all 50
            states. Only physicians or their authorized representatives are allowed to manage the
            physician's profile on Healthgrades. Violators will be prosecuted to the fullest extent
            of the law.
          </p>
        </div>
      </div>
    </div>
    {showModal && (<ConfirmationModelPopUp showModal = {showModal} onhandleConfirm = {onhandleConfirm}></ConfirmationModelPopUp>)}
    </>
  );
};

Footer.propTypes = {
  footer: PropTypes.object
};
export default Footer;
