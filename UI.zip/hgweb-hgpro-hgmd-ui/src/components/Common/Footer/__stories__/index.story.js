import React from 'react';
import Footer from '../Footer';
import { storiesOf } from '@storybook/react';

storiesOf('Common|Footer', module).add('Footer', () => (
  <Footer />
));
