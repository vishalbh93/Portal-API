import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';

//Joy Component import
import Card from '@hg/joy/src/components/Card';

//Stylesheet impor
import './_cardwithAutoSuggest.less';

//Image import
import IconDelete from '../../../assets/images/ProviderProfile/ellipsis.svg';
import AutoSuggestWithCheckboxList from '../Form/AutoSuggest/AutoSuggestWithCheckboxList';

const CardWithAutoSuggest = (props, ref) => {
  const {
    id,
    title,
    additionalField,
    code,
    autosuggestOptions,
    onSaveClick,
    onCancelClick,
    showIsPrimary,
    setPrimaryHandler,
    pageName
  } = props;

  const refShowMenu = useRef();

  const identifier = props.id == undefined ? 'div-' : 'div-' + props.id;
  const [isShowMenu, setIsShowMenu] = useState(false);

  //Handler
  const onDeleteHandler = (code, providerId, index) => {
    setIsShowMenu(false);
    props.removeCard(code, providerId, index);
  };

  const onSaveClickHandler = (suggestData) => {
    props.onSaveClick(suggestData);
  };

  const onPrimarySelect = (code) => {
    setIsShowMenu(false);
    props.setPrimaryHandler(code);
  };

  const showMenu = () => {
    setIsShowMenu(true);
  };

  // event listener
  const handleClickOutside = (event) => {
    if (refShowMenu.current && !refShowMenu.current.contains(event.target)) {
      setIsShowMenu(false);
    }
  };

  // //Bind the event listener
  document.addEventListener('mousedown', handleClickOutside);

  return (
    <div className='card' id={`${identifier}-section`} ref={ref}>
      <div className='card-content'>
        {showIsPrimary && (pageName === 'Specialty' || pageName === 'specialties') && (
          <div id={`${identifier}-section-title`} className='card-content-title'>
            <span id='primary-specialty'> PRIMARY </span>
          </div>
        )}
        <div id={`${identifier}-section-title`} className='card-content-title'>
          <span>{props.title}</span>
          {!(showIsPrimary && (pageName === 'Specialty' || pageName === 'specialties')) && (
            <div className='dropdown'>
              <img
                id={`${identifier}-card-delete`}
                className='card-content-delete-icon'
                src={IconDelete}
                alt='flagged'
                onClick={() => showMenu()}
              />
              <ul
                className={isShowMenu ? 'dropdown-content showmenu' : 'dropdown-content'}
                ref={refShowMenu}>
                <li>
                  <a href='#' onClick={() => onDeleteHandler(code)}>
                    Delete {pageName}
                  </a>
                </li>
                {!showIsPrimary && (pageName === 'Specialty' || pageName === 'specialties') && (
                  <li>
                    <a href='#' onClick={() => onPrimarySelect(code)}>
                      Set as Primary Specialty
                    </a>
                  </li>
                )}
              </ul>
            </div>
          )}
        </div>
        {additionalField != undefined && additionalField != '' && (
          <div
            id={`${identifier}-section-additionl-field`}
            className='card-content-additionalfield'>
            <AutoSuggestWithCheckboxList
              id={`autosuggest-checkbox-${identifier}`}
              label=''
              name=''
              placeholder={autosuggestOptions.placeholder}
              initialValue={autosuggestOptions.initialValue}
              data={autosuggestOptions.data}
              onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
              onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
              setCurrentSelection={autosuggestOptions.setCurrentSelection}
              showValidationMsg={autosuggestOptions.showValidationMsg}
              isSearch={autosuggestOptions.isSearch}
              buttonNames={['Save', 'Cancel']}
              onSaveClick={onSaveClickHandler}
              onCancelClick={onCancelClick}
            />
          </div>
        )}
      </div>
    </div>
    // <Card id={`${identifier}-section`}>

    // </Card>
  );
};

const forwardedRef = React.forwardRef(CardWithAutoSuggest);

export default forwardedRef;
//export default CardWithAutoSuggest;
