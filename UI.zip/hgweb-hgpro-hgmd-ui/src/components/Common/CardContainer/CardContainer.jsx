import React from 'react';
import PropTypes from 'prop-types';

//Joy Component import
import Card from '@hg/joy/src/components/Card';

//Stylesheet impor
import './_cardContainer.less';

//Image import
import IconDelete from '../../../assets/images/UserAssociation/icon-delete.svg';
import isEmpty from '../../../utils/validation/isEmpty';

const CardContainer = (props) => {
  const { id, index, title, additionalField, code, providerId, renderType } = props;

  const identifier = props.id == undefined ? 'div-' : 'div-' + props.id;

  const onDeleteHandler = (code, providerId, index) => {
    props.removeCard(code, providerId, index);
  };

  return (
    <div className={`${renderType}`}>
      <Card id={`${identifier}-section`}>
        <div id={`${identifier}-section-title`} className='card-content-title'>
          <span title={props.title}>{props.title}</span>
          <span>
            <img
              d={`${identifier}-card-delete`}
              className='card-content-delete-icon'
              src={IconDelete}
              onClick={() => onDeleteHandler(code, providerId, index)}
            />
          </span>
        </div>
        {!isEmpty(props.additionalField) && (
          <div
            id={`${identifier}-section-additionl-field`}
            className='card-content-additionalfield'>
            {props.additionalField}
          </div>
        )}
      </Card>
    </div>
  );
};

CardContainer.defaultProps = {
  //     props: {addtionalfield:''}
  renderType: 'card-with-column'
};

CardContainer.propTypes = {
  title: PropTypes.string,
  additionalField: PropTypes.string,
  providerId: PropTypes.string,
  code: PropTypes.string,
  id: PropTypes.string,
  index: PropTypes.number,
  removeCard: PropTypes.func,
  renderType: PropTypes.string
};

export default CardContainer;
