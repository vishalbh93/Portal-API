import React, { useState, useEffect, Fragment } from 'react';
import './_menu.less';
import { useDispatch } from 'react-redux';
import _ from 'lodash';

/* #region service import */

/* #endregion */

//media imports
import Close from '../../../assets/images/ClaimYourProfile/icon-cross.svg';
import RightArrow from '../../../assets/images/ClaimYourProfile/icon-right.svg';
import BackArrow from '../../../assets/images/back-arrow.svg';
import Tag from '../../../assets/images/ProfileEdit/icon-new.svg';
import { HG3Tracker } from '../../../utils/tracking';
import { upgradeToPremiumContent } from '../../../utils/constant-data';

const MobileMenu = (props) => {
  const {
    showMenus,
    menuItems,
    setIsShowSideMenu,
    showLogin,
    showClaim,
    infoObject,
    providerInfo,
    showSponsorSection,
    showUpgrade,
    hasFavorites
  } = props;

  const [sideSubMenu, setSideSubMenu] = useState('');
  const [leftToRightTransition, setLeftToRightTransition] = useState(true);
  const [showProviderDetails, setShowProviderDetails] = useState(true);
  const isReferralPage = window.location.pathname?.toLowerCase().includes('providerreferral');
  const _PESComments =
    !_.isEmpty(infoObject) && _.isEmpty(infoObject.NewlyAddedComments)
      ? infoObject.NewlyAddedComments
      : 0;
  const _PESNotifictionVisibility =
    _PESComments !== 0 && infoObject.UserIsProvider && infoObject.ProviderCount == 1;

  // Handle classes
  let _mobileMenuClasses = ['menu-main-container menu-container-inner border'];
  const subMenuHandler = (e, id) => {
    e.preventDefault();
    setSideSubMenu(id);
    if (id.length != 0) {
      setLeftToRightTransition(false);
      setShowProviderDetails(false);
    } else {
      setLeftToRightTransition(true);
      setShowProviderDetails(true);
    }
  };

  // to add transition effect for click on menu-and-submenu-back buttons
  let transit = document.getElementsByClassName('side-menu-bar');
  let transitBar = document.getElementsByClassName('transition-bar');

  if (transitBar.length != 0) {
    transit[0].addEventListener('click', function () {
      leftToRightTransition
        ? (transitBar[0].classList.add('transition-right'),
          transitBar[0].classList.remove('transition-left'))
        : (transitBar[0].classList.add('transition-left'),
          transitBar[0].classList.remove('transition-right'));
    });
  }

  const generateAvatar = (name) => {
    var initials = name
      .split(' ')
      .map(function (str) {
        return str ? str[0].toUpperCase() : '';
      })
      .join('');
    var canvas = document.createElement('canvas');
    var radius = 23;
    var margin = 0;
    canvas.width = radius * 2 + margin * 2;
    canvas.height = radius * 2 + margin * 2;
    var ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.arc(radius, radius, radius, 0, 2 * Math.PI, false);
    ctx.closePath();
    ctx.fillStyle = '#3D3E97';
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '24px HgSans';
    ctx.fontWeight = '700';
    ctx.textAlign = 'center';
    ctx.fillText(initials, 22.5, 30.8);
    return canvas.toDataURL();
  };

  //UseEffect
  useEffect(() => {
    setLeftToRightTransition(leftToRightTransition);
  }, [transit[0]]);

  const generateProvidersMenu = () => {
    if (showProviderDetails && providerInfo != undefined && infoObject != undefined) {
      if (infoObject.ProviderCount === 1 && infoObject.UserIsProvider) {
        return (
          <>
            <div className='provider-details'>
              <img
                src={providerInfo.ImageUrl}
                alt={providerInfo.DisplayFullName}
                className='provider-img'
              />

              <div className='provider-name'>
                <h1>{providerInfo.DisplayFullName}</h1>
                <p className='specility-name'>{providerInfo.PrimarySpecialty}</p>
              </div>
            </div>
          </>
        );
      } else if (
        infoObject.UserIsAdmin ||
        infoObject.ProviderCount > 1 ||
        infoObject.UserIsClientAdmin
      ) {
        return (
          <>
            <div className='provider-details'>
              <div className='provider-name roster-user'>
                <img
                  src={generateAvatar(infoObject.FirstName)}
                  alt='setting icon'
                  className='avatar'
                />
                <div>
                  <h1>
                    {' '}
                    {`${
                      infoObject.UserIsAdmin
                        ? infoObject.FirstName + ' ' + infoObject.LastName
                        : infoObject.DisplayName
                    }`}
                  </h1>
                  <p>Physician Support</p>
                </div>
              </div>
            </div>
          </>
        );
      }
    }
  };

  const redirectToPremium = () => {
    HG3Tracker.OmnitureTrackLink('hgmd:selfservice:landing');
    let fullPath = `${infoObject.PremiumSiteURL}PremiumAdmin/PremiumPreview?pwid=${infoObject.ProviderId}&src=hgmd&email=${infoObject.ProviderEmail}`;
    window.open(fullPath, '_blank') || window.location.replace(fullPath);
  };

  const openAddProvidersModal = () => {
    props.openAddProvidersModal();
  };

  const formateCount = (fCnt) => {
    let val = fCnt >= 1000 ? '999+' : fCnt >= 100 ? '99+' : fCnt.toString();
    return val;
  };

  return (
    <Fragment>
      <div className='menu-main-container border' onClick={() => setIsShowSideMenu(false)}>
        <img src={Close} alt='logo'></img>
        {/* <img className='hg-logo' src={MobileLogo} alt='logo' /> */}
      </div>

      {!showMenus && (
        <div className='menu-main-container menu-container-inner border'>
          {showLogin && (
            <a href='/' alt='Home' className='link'>
              <div>Log In</div>
              <img className='cross-icon' src={RightArrow} alt='logo'></img>
            </a>
          )}
          {showClaim && (
            <a href='/landing/claim?pCID=login' alt='Home' className='link'>
              <div>Claim Your Free Profile</div>
              <img className='cross-icon' src={RightArrow} alt='logo'></img>
            </a>
          )}
        </div>
      )}

      {showMenus && (
        <>
          {generateProvidersMenu()}
          <ul className={`${window.innerHeight <= 670 ? 'auto-height' : ''}`}>
            {menuItems.map(function (menuItem, idx) {
              if (
                menuItem.SubMenu.length != 0 &&
                menuItem.Name !== 'Setting' &&
                sideSubMenu != '' &&
                sideSubMenu == 'mytools'
              ) {
                if (menuItem.Name == 'My Tools')
                  return (
                    <>
                      <li
                        id='myTools-sidebar'
                        className={`menu-main-container menu-container-inner top-back-arrow`}
                        onClick={(e) => {
                          subMenuHandler(e, '');
                        }}
                        key={idx}>
                        <a href='#' className='btns-sub-menu-dismiss'>
                          <img className='back-icon' src={BackArrow} alt='back'></img>
                        </a>
                      </li>

                      {menuItem.SubMenu.map(function (subMenu, i) {
                        return (
                          <li
                            id='myTools-sidebar'
                            className={_mobileMenuClasses.join(' ')}
                            key={idx}>
                            <a href={subMenu.Url} className='btns-sub-menu-dismiss'>
                              <span> {subMenu.Name}</span>
                            </a>{' '}
                          </li>
                        );
                      })}
                    </>
                  );
              } else if (
                menuItem.SubMenu.length != 0 &&
                menuItem.Name !== 'Setting' &&
                sideSubMenu != '' &&
                sideSubMenu == 'experience'
              ) {
                if (menuItem.Name == 'Patient Experience')
                  return (
                    <>
                      <li
                        id='pes-sidebar'
                        className={`menu-main-container menu-container-inner top-back-arrow`}
                        onClick={(e) => {
                          subMenuHandler(e, '');
                        }}
                        key={idx}>
                        <a href='#' className='btns-sub-menu-dismiss'>
                          <img className='back-icon back-arrow' src={BackArrow} alt='logo'></img>
                        </a>
                      </li>
                      {menuItem.SubMenu.map(function (subMenu, i) {
                        return (
                          <li
                            id={`${subMenu.Name}-pes-sidebar`}
                            className={_mobileMenuClasses.join(' ')}
                            key={i}>
                            <a href={subMenu.Url} className='btns-sub-menu-dismiss'>
                              <span> {subMenu.Name}</span>
                            </a>{' '}
                          </li>
                        );
                      })}
                    </>
                  );
              } else if (
                menuItem.Name == 'Setting' &&
                sideSubMenu != '' &&
                sideSubMenu == 'accountsettings'
              ) {
                return (
                  <>
                    <li
                      id='accountsettings-sidebar'
                      className={`menu-main-container menu-container-inner top-back-arrow`}
                      onClick={(e) => {
                        subMenuHandler(e, '');
                      }}
                      key={menuItem.Name}>
                      <a href='#' className='btns-sub-menu-dismiss'>
                        <img className='back-icon back-arrow' src={BackArrow} alt='logo'></img>
                      </a>
                    </li>

                    {infoObject.ProviderCount >= 1 &&
                      !infoObject.UserIsClientAdmin &&
                      !infoObject.UserIsProvider &&
                      !infoObject.UserIsAdmin && (
                        <li className={_mobileMenuClasses} key='add-providers'>
                          <a className='btns-sub-menu-dismiss' onClick={openAddProvidersModal}>
                            <span>Add Providers</span>
                          </a>
                        </li>
                      )}
                    {menuItem.SubMenu.map(function (subMenu, i) {
                      return (
                        <li
                          id={`${subMenu.Name}-accountsettings-sidebar`}
                          className={`${_mobileMenuClasses.join(' ')} ${
                            subMenu.Name == 'Sign Out' ? 'list-border-top' : ''
                          }`}
                          key={i}>
                          <a href={subMenu.Url} className='btns-sub-menu-dismiss'>
                            <span> {subMenu.Name}</span>
                          </a>
                        </li>
                      );
                    })}
                  </>
                );
              } else if (menuItem.SubMenu.length == 0 && sideSubMenu == '') {
                return (
                  <li
                    className={`menu-main-container menu-container-inner border ${
                      menuItem.IsActive ? 'active' : ''
                    } ${menuItem.Name === 'Setting' ? 'setting-link' : ''}`}
                    key={idx}>
                    <a
                      href={menuItem.Url}
                      alt={menuItem.Name}
                      className={`btns ${
                        menuItem.Name === 'Smart Referral' ? 'new-smart-referral' : ''
                      }`}>
                      <span
                        className={`${
                          menuItem.Name === 'Smart Referral'
                            ? 'new-smart-referral-span'
                            : menuItem.Name === 'Patient Experience'
                            ? 'width-unset'
                            : ''
                        }`}>
                        {menuItem.Name=='Patient Experience'?'My Reviews':menuItem.Name}
                      </span>
                      {menuItem.Name === 'Smart Referral' && (
                        // <img className='new-tag' src={Tag} alt='icon' />
                        <span className='badge-common badge-new-tag'>NEW!</span>
                      )}

                      {_PESNotifictionVisibility && menuItem.Name === 'Patient Experience' && (
                        <span className='badge-common badge-count'>
                          {/* {_PESComments <= 10 ? `0${_PESComments}` : `10+`} */}
                          {formateCount(_PESComments)}
                        </span>
                      )}
                    </a>
                  </li>
                );
              } else if (sideSubMenu == '') {
                return (
                  <>
                    <li
                      className={`${_mobileMenuClasses.join(' ')} ${
                        menuItem.Name == 'Setting' ? 'setting-border' : ''
                      }`}
                      onClick={(e) => {
                        subMenuHandler(
                          e,
                          menuItem.Name == 'My Tools'
                            ? 'mytools'
                            : menuItem.Name == 'Patient Experience'
                            ? 'experience'
                            : 'accountsettings'
                        );
                      }}
                      key={menuItem.Name}>
                      <a href={menuItem.Url} alt={menuItem.Name} className='btns'>
                        <span className={`${menuItem.Name == 'Settings' ? 'setting-text' : ''}`}>
                          {menuItem.Name}
                        </span>
                        <img className='cross-icon' src={RightArrow} alt='logo' />
                      </a>
                    </li>
                  </>
                );
              }
            })}
          </ul>
        </>
      )}

      <div className='sponsor-section'>
        {showSponsorSection &&
          infoObject != undefined &&
          infoObject.SponsorName != undefined &&
          infoObject.SponsorName != '' &&
          infoObject.SponsorImg != '' && (
            <div className='sponsor-inner-section'>
              <h1>Your profile is sponsored by</h1>
              <div className='sponsor-logo-section'>
                <img src={infoObject.SponsorImg} alt='Sponsor Logo' />
              </div>
            </div>
          )}

        {showUpgrade && infoObject != undefined && (
          <div className='premium-section'>
            {upgradeToPremiumContent.map((value, index) => (
              <Fragment key={index}>
                <h1>{value.title}</h1>
                <p>{value.content}</p>
              </Fragment>
            ))}
            <button className='btn-upgrade' onClick={() => redirectToPremium()}>
              Upgrade today!
            </button>
          </div>
        )}
      </div>
    </Fragment>
  );
};

MobileMenu.propTypes = {};

export default MobileMenu;
