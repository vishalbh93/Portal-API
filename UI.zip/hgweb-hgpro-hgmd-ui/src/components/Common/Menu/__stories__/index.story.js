import React from 'react';
import MenuComponent from '../Menu';
import { storiesOf } from '@storybook/react';

const getSortedData = () => {
  //Todo yet to implement sort functionality
};

// This can be removed once API is done
let menubar = [
  {
    Id: 1,
    ParentId: 0,
    Name: 'Health Feeds',
    Url: '#',
    IsExternal: false,
    IconClass: '',
    SubMenu: []
  },
  {
    Id: 2,
    ParentId: 0,
    Name: 'Dashboard',
    Url: 'http://update-alpha-testaws.healthgrades.com/dashboard/Index/Y2Y9R',
    IsExternal: false,
    IconClass: '',
    SubMenu: []
  },
  {
    Id: 3,
    ParentId: 0,
    Name: 'My Profile',
    Url: 'http://update-alpha-testaws.healthgrades.com/provider/profile/Y2Y9R',
    IsExternal: false,
    IconClass: '',
    SubMenu: []
  },
  {
    Id: 4,
    ParentId: 0,
    Name: 'My Tools',
    Url: '#',
    IsExternal: false,
    IconClass: '',
    SubMenu: [
      {
        Id: 5,
        ParentId: 4,
        Name: 'Help Center',
        Url: 'https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      }
    ]
  },
  {
    Id: 6,
    ParentId: 0,
    Name: 'Patient Experience',
    Url: '#',
    IsExternal: false,
    IconClass: '',
    SubMenu: [
      {
        Id: 7,
        ParentId: 6,
        Name: 'Patient Reviews',
        Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/provider-reviews',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      },
      {
        Id: 8,
        ParentId: 6,
        Name: 'Analytics',
        Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/analytics',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      },
      {
        Id: 9,
        ParentId: 6,
        Name: 'Resources',
        Url: 'http://update-alpha-testaws.healthgrades.com/patientexperience/resources',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      }
    ]
  },
  {
    Id: 7,
    ParentId: 0,
    Name: 'Setting',
    Url: '#',
    IsExternal: false,
    IconClass: '',
    SubMenu: [
      {
        Id: 8,
        ParentId: 7,
        Name: 'My Account Settings',
        Url: 'http://update-alpha-testaws.healthgrades.com/account/settings',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      },
      {
        Id: 9,
        ParentId: 7,
        Name: 'Change Password',
        Url: 'http://update-alpha-testaws.healthgrades.com/account/ChangePassword',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      },
      {
        Id: 10,
        ParentId: 7,
        Name: 'Sign Out',
        Url: 'http://update-alpha-testaws.healthgrades.com/account/sign-out',
        IsExternal: true,
        IconClass: '',
        SubMenu: []
      }
    ]
  }
];
storiesOf('Common|Menu-Component', module).add('Menu-Component', () => (
  <MenuComponent menuName='Menu' showMenus={true} menuItems={menubar} />
));
