import React, { useState, useEffect, Fragment } from 'react';
import '@hg/joy/src/globalstyles';
import './_menu.less';
import PropTypes from 'prop-types';
import _ from 'lodash';

//media imports
import Logo from '../../../assets/images/healthgrades_headerlogo.svg';
import MenuIcon from '../../../assets/images/menuIcon.svg';
import downarrow from '../../../assets/images/down-arrow.svg';
import cross from '../../../assets/images/ProviderProfile/Vector.svg';

import MobileMenu from './MobileMenu';
import ReactModal from 'react-modal';
import ConfirmationModelPopUp from '../../Common/ConfirmationModelPopUp/ConfirmationModelPopUp';

const MenuComponent = (props) => {
  const {
    showMenus,
    menuItems,
    infoObject,
    providerInfo,
    showSponsorSection,
    showUpgrade,
    hasFavorites
  } = props;

  const [isShowSideMenu, setIsShowSideMenu] = useState(false);
  const [showAddProviderModel, toggleAddProviderModel] = useState(false);
  const [flag, setFlag] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState();
  const _PESComments =
    !_.isEmpty(infoObject) && _.isEmpty(infoObject.NewlyAddedComments)
      ? infoObject.NewlyAddedComments
      : 0;
  const _PESNotifictionVisibility =
    _PESComments !== 0 && infoObject.UserIsProvider && infoObject.ProviderCount == 1;
  const showAvatarWithName = _.isEmpty(infoObject)
    ? false
    : infoObject.UserIsAdmin || infoObject.ProviderCount > 1 || infoObject.UserIsClientAdmin;

  // Handle classes
  let menuClasses = ['menu-main-container scrolled mobile-menu'];

  if (!showMenus) {
    menuClasses.push('menu-height');
  }

  // Handlers
  const openMobileMenu = (e) => {
    e.preventDefault();
    setIsShowSideMenu(!isShowSideMenu);
  };

  const generateAvatar = (name) => {
    var initials = !_.isEmpty(name)
      ? name
          .split(' ')
          .map(function (str) {
            return str ? str[0].toUpperCase() : '';
          })
          .join('')
      : '';
    var canvas = document.createElement('canvas');
    var radius = 19;
    var margin = 0;
    canvas.width = radius * 2 + margin * 2;
    canvas.height = radius * 2 + margin * 2;
    var ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.arc(radius, radius, radius, 0, 2 * Math.PI, false);
    ctx.closePath();
    ctx.fillStyle = '#3D3E97';
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '24px HgSans';
    ctx.fontWeight = '700';
    ctx.textAlign = 'center';
    ctx.fillText(initials, 18.5, 26.8);
    return canvas.toDataURL();
  };

  const generateSettings = () => {
    return (
      <a href='#' className={`settings-section  ${!showAvatarWithName ? 'provider-avatar' : ''}`}>
        <span className='profile-name'>
          <img src={generateAvatar(infoObject.FirstName)} alt='setting icon' className='avatar' />
          {showAvatarWithName && (
            <div className='profile-name-section'>
              <span>
                <strong>
                  {`${
                    infoObject.UserIsAdmin
                      ? infoObject.FirstName + ' ' + infoObject.LastName
                      : infoObject.DisplayName
                  }`}
                </strong>
              </span>
              <span>Physician Support</span>
            </div>
          )}
        </span>
      </a>
    );
  };

  const formateCount = (fCnt) => {
    let val = fCnt >= 1000 ? '999+' : fCnt >= 100 ? '99+' : fCnt.toString();
    return val;
  };

  const openAddProvidersModal = () => {
    toggleAddProviderModel(true);
  };

  const onCloseModelHandler = () => {
    toggleAddProviderModel(false);
  };

  const validatePage = () => {     
    let photoVidButton = document.getElementsByClassName('profile-photo-video-main');
    let isProfilePage = document.getElementById('provider-profile-container');
    if (isProfilePage == null || photoVidButton.length !== 0) {
      setShowModal(false);
      setFlag(true);
    }else{
      let eleValidButton = document.getElementsByClassName('provider-profile-save valid');
    let eleValidButton_1 = document.getElementsByClassName('provider-profile-appointments-save valid');
    if (eleValidButton.length !== 0 || eleValidButton_1.length !== 0){
      setShowModal(true);
      setFlag(false);
    }      
    else{
      setShowModal(false);
      setFlag(true);      
    } 
    } 
  };

  const onhandleConfirm =(value) =>{    
    setFlag(value);
    setShowModal(false);
  };

  const redirectFunc=(value)=>{ 
    validatePage(); 
    setRedirectUrl(value); 
  };

  useEffect(() => {
    if (flag) {            
      window.location.href = redirectUrl;
       }
  },[redirectUrl, flag]);

  return (
    <>
      {/* For Mobile View */}
      <div className={`overlay ${isShowSideMenu ? 'enable' : 'disable'}`}></div>
      <div className={`${isShowSideMenu && 'global-menu-bar'}`}>
        <div className={`${isShowSideMenu && 'side-menu-bar no-opacity'}`}>
          <div className={`${isShowSideMenu && 'transition-bar'}`}></div>

          {isShowSideMenu && (
            <MobileMenu
              showMenus={showMenus}
              menuItems={menuItems}
              setIsShowSideMenu={setIsShowSideMenu}
              showClaim={props.showClaim}
              showLogin={props.showLogin}
              infoObject={infoObject}
              providerInfo={providerInfo}
              showSponsorSection={showSponsorSection}
              showUpgrade={showUpgrade}
              openAddProvidersModal={openAddProvidersModal}
              hasFavorites={hasFavorites}
            />
          )}
        </div>
      </div>

      {/* For Desktop View */}
      <div className={menuClasses.join(' ')}>
        {/* provider-profile-edit */}
        <nav className='header-navbar'>
          <div className='logo'>
            <img
              className='menu-icon'
              src={MenuIcon}
              onClick={openMobileMenu}
              alt='Healthgrades-logo'></img>
            <div>
              <a onClick={()=>redirectFunc('/')}
              //</div>href='/' alt='Home'
              >
                <img src={Logo} alt='Healthgrades' />
              </a>
            </div>
          </div>

          {showMenus && (
            <div className='menu-container'>
              <ul className='menu'>
                {menuItems.map(function (menuItem, idx) {
                  if (menuItem.SubMenu.length != 0 && menuItem.Name != 'Setting') {
                    return (
                      <li key={idx}>
                        <label id={'drop-1'} className='toggle'>
                          {menuItem.Name}
                          <img src={downarrow} alt='close' />
                        </label>
                        <a
                        onClick={()=>redirectFunc(menuItem.Url)}
                          //href={menuItem.Url}
                          className={`${menuItem.IsActive ? 'active' : ''} menu-list`}>
                          {menuItem.Name}
                        </a>
                        <ul>
                          {menuItem.SubMenu.map(function (subMenu, i) {
                            return (
                              <li key={i}>
                                <a className='submenu' 
                                onClick={()=>redirectFunc(subMenu.Url)}
                                //href={subMenu.Url}
                                >
                                  {subMenu.Name}
                                </a>
                              </li>
                            );
                          })}
                        </ul>
                      </li>
                    );
                  } else if (menuItem.Name == 'Setting') {
                    return (
                      <li key={idx} className='menu-settings'>
                        <ul className='menu-settings-inner'>
                          <li key={idx}>
                            {generateSettings()}
                            <ul
                              className={
                                infoObject.UserIsAdmin || infoObject.UserIsClientAdmin
                                  ? 'setting-menu admin'
                                  : 'setting-menu'
                              }>
                              {infoObject.ProviderCount >= 1 &&
                                !infoObject.UserIsClientAdmin &&
                                !infoObject.UserIsProvider &&
                                !infoObject.UserIsAdmin && (
                                  <li key='add-providers'>
                                    <a className='submenu' onClick={openAddProvidersModal}>
                                      Add Providers
                                    </a>
                                  </li>
                                )}

                              {menuItem.SubMenu.map(function (subMenu, i) {
                                return (
                                  <>
                                    <li
                                      key={i}
                                      className={`${
                                        subMenu.Name == 'Sign Out' ? 'list-border-top' : ''
                                      }`}>
                                      <a className='submenu' onClick ={()=> redirectFunc(subMenu.Url)}
                                      //href={subMenu.Url}
                                      >
                                        {subMenu.Name == 'Sign Out' && !showAvatarWithName ? (
                                          <>
                                            Sign Out <br />
                                            <span className='span-provider-avatar'>
                                              Dr. {infoObject.DisplayName}
                                            </span>
                                          </>
                                        ) : (
                                          subMenu.Name
                                        )}
                                      </a>
                                    </li>
                                  </>
                                );
                              })}
                            </ul>
                          </li>
                        </ul>
                      </li>
                    );
                  } else {
                    return (
                      <li key={idx}>
                        <a onClick={()=> redirectFunc(menuItem.Url)}
                          //href={menuItem.Url}
                          className={`${menuItem.IsActive ? 'active' : ''} menu-list ${
                            menuItem.Name === 'Smart Referral' ? 'new-smart-referral' : ''
                          }`}>
                          {menuItem.Name=='Patient Experience'?'My Reviews':menuItem.Name}
                          {menuItem.Name === 'Smart Referral' && (
                            <span className='badge-common badge-new-tag'>NEW!</span>
                          )}
                          {_PESNotifictionVisibility && menuItem.Name === 'Patient Experience' && (
                            <span className='badge-common badge-count'>
                              {/* {_PESComments <= 10 ? `0${_PESComments}` : `10+`} */}
                              {formateCount(_PESComments)}
                            </span>
                          )}
                        </a>
                      </li>
                    );
                  }
                })}
              </ul>
            </div>
          )}
        </nav>

        {/*claim-page */}
        {!showMenus && !isShowSideMenu && (
          <div className='btn-right desktop-view'>
            {props.showLogin && (
              <a href='/' alt='Home' className='btn'>
                Log In
              </a>
            )}
            {props.showClaim && (
              <a href='/landing/claim?pCID=login' alt='Claim Your Free Profile' className='btn'>
                Claim Your Free Profile
              </a>
            )}
          </div>
        )}
      </div>

      <ReactModal
        overlayClassName='roster-modal-overlay add-provider-modal-popup'
        className='add-provider-modal-dialog'
        ariaHideApp={false}
        isOpen={showAddProviderModel}
        contentLabel='add-provider-model'
        onRequestClose={onCloseModelHandler}
        shouldCloseOnEsc={false}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-section'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onCloseModelHandler} />
            </div>
            <div className='modal-row'>
              <div className='container'>
                <div className='heading'>Add Providers</div>
                <div className='title'>
                  <p>
                    Please{' '}
                    <a href='/contactus' alt='contact us'>
                      contact customer service{' '}
                    </a>
                    for assistance with adding providers to your account.
                  </p>
                  <button
                    title='Cancel'
                    type='button'
                    className='btn-section'
                    onClick={onCloseModelHandler}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ReactModal>

      {showModal && (<ConfirmationModelPopUp showModal = {showModal} onhandleConfirm = {onhandleConfirm}></ConfirmationModelPopUp>)}
    </>
  );
};

MenuComponent.defaultProps = {
  showLogin: true,
  showClaim: false,
  menuItems: [],
  providerInfo: {},
  showSponsorSection: false,
  showUpgrade: false,
  isReferralMenu: false,
  hasFavorites: false
};

MenuComponent.propTypes = {
  showMenus: PropTypes.bool,
  showLogin: PropTypes.bool,
  showClaim: PropTypes.bool,
  menuItems: PropTypes.arrayOf(Object),
  providerInfo: PropTypes.object,
  showSponsorSection: PropTypes.bool,
  showUpgrade: PropTypes.bool,
  hasFavorites: PropTypes.bool
};

export default MenuComponent;
