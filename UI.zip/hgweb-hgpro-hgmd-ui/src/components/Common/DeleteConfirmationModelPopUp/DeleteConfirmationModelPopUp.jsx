import React, { useState } from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../../Common/Layouts/LayoutA';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import ReactModal from 'react-modal';

//Stylesheet impor
import './_deleteConfirmationModelPopUp.less';

//helper
import isEmpty from '../../../utils/validation/isEmpty';

//Media imports
import cross from '../../../assets/images/ProviderProfile/Vector.svg';

const DeleteConfirmationModelPopUp = (props) => {
  const { id, title, buttonName, showModalDelete, showFromItem, cancelButton, flag } = props;

  const onDeleteHandler = (id) => {
    props.handleDeleteItem(id);
  };

  const onCloseHandler = () => {
    props.closeModal(id);
  };
  const isMobileView = window.innerWidth <= 786;
  const header = 'Add to Favorites';

  return (
    <LayoutA>
      <ReactModal
        overlayClassName='roster-modal-overlay delete-confirmation-modal-popup'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={showModalDelete}
        contentLabel='hospital-model'
        onRequestClose={onCloseHandler}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-section'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
            </div>
            <div className='modal-row'>
              {isMobileView && <div className='header'>{header}</div>}
              <div className='container'>
                <div className='title'>
                  {flag ? (
                    <>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: `${title}`
                        }}></div>
                    </>
                  ) : (
                    <>
                      Are you sure, you want to remove
                      <span className='main-title-bold'>
                        {title} {isEmpty(showFromItem) ? ' ?' : ''}
                      </span>
                      {isEmpty(showFromItem) ? null : `from ${showFromItem} ?`}
                    </>
                  )}
                </div>
                <div className='title'>
                  <button
                    title={buttonName}
                    type='button'
                    className='btn-section btn-remove'
                    onClick={() => onDeleteHandler(id)}>
                    {buttonName}
                  </button>

                  <button
                    title={cancelButton}
                    type='button'
                    className='btn-section'
                    onClick={onCloseHandler}>
                    {cancelButton}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ReactModal>
    </LayoutA>
  );
};

DeleteConfirmationModelPopUp.defaultProps = {
  props: { name: '' },
  showFromItem: '',
  cancelButton: 'Cancel',
  flag: false
};

DeleteConfirmationModelPopUp.propTypes = {
  title: PropTypes.string,
  id: PropTypes.string,
  showModalDelete: PropTypes.bool,
  handleDeleteItem: PropTypes.func,
  onCloseHandler: PropTypes.func,
  cancelButton: PropTypes.string,
  flag: PropTypes.bool
};

export default DeleteConfirmationModelPopUp;
