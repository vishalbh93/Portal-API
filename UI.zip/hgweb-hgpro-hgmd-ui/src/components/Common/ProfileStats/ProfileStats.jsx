import React, { Fragment } from 'react';

//Media imports
import profileViews from '../../../assets/images/Dashboard/icon-views.svg';
import patientReview from '../../../assets/images/Dashboard/icon-review.svg';
import comments from '../../../assets/images/Dashboard/icon-comment.svg';
import rating from '../../../assets/images/Dashboard/icon-rating.svg';
import pendingCountIcon from '../../../assets/images/Dashboard/icon-pendingCountIcon.svg';

// style Imports
import '../../NewDashboard/MainContent/_profileCompare.less';
import './_profileStats.less';

const ProfileStats = (props) => {
  const { results, pendingCount, isProfileEdit } = props;

  const addZero = (myNumber) => {
    return String(myNumber).length < 2 ? (myNumber = '0' + myNumber) : myNumber;
  };

  return (
    <Fragment>
      <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
        <span className='image-container'>
          <img className='profile-compare-image' src={profileViews} alt='icon' />
        </span>
        <div className='count-details'>
          <span className='count'>{addZero(results.ProfileViewOneYear)}</span>
          <span className='count-description'>Profile Views</span>
          {isProfileEdit && <span className='count-description'>(Past 12 months)</span>}
        </div>
      </div>
      {isProfileEdit && pendingCount != 0 && (
        <>
          <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
            <span className='image-container'>
              <img className='profile-compare-image' src={pendingCountIcon} alt='icon' />
            </span>
            <div className='count-details'>
              <span className='count'>{addZero(pendingCount)}</span>
              <span className='count-description'>Pending Tasks</span>
            </div>
          </div>
        </>
      )}
      <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
        <span className='image-container'>
          <img className='profile-compare-image' src={patientReview} alt='icon' />
        </span>
        <div className='count-details'>
          <span className='count'>{addZero(results.PatientReviews)}</span>
          <span className='count-description'>{isProfileEdit ? 'Total' : ''}</span>
          <span className='count-description'> Patient Reviews</span>
        </div>
      </div>

      {!isProfileEdit && (
        <>
          <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
            <span className='image-container'>
              <img className='profile-compare-image' src={comments} alt='icon' />
            </span>
            <div className='count-details'>
              <span className='count'>{addZero(results.TotalPatientComments)}</span>
              <span className='count-description'>Patient Comments</span>
            </div>
          </div>

          <div className={`divisions  ${pendingCount == 0 && 'divisions-all-complete'}`}>
            <span className='image-container'>
              <img className='profile-compare-image' src={rating} alt='icon' />
            </span>
            <div className='count-details'>
              <span className='count'>{addZero(results.AverageStarRating)}</span>
              <span className='count-description'>
                Average Rating <span className='rating-out-of'>(out of 5 stars)</span>
              </span>
            </div>
          </div>
        </>
      )}
    </Fragment>
  );
};

export default ProfileStats;
