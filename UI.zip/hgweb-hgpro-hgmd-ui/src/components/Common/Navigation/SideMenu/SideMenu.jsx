import React, { useState, useEffect } from 'react';

//---------------------- stylesheet import ----------------------------
import './_sideMenu.less';

//---------------------- components import ----------------------------
import SubMenu from './SubMenu';

//---------------------- media import ---------------------------------
import svgUp from '../../../../assets/images/ProfileEdit/icon-up-arrow.svg';
import svgDown from '../../../../assets/images/ProfileEdit/icon-down-arrow.svg';

//---------------------- helpers import -------------------------------
import isEmpty from '../../../../utils/validation/isEmpty';

const SideMenu = (props) => {
  //------------------------ props destructuring ----------------------
  const { _menuList, _currentSection, _onMenuClick, _currentMenuId } = props;

  //------------------------ states -----------------------------------
  const [menuList, setMenuList] = useState(_menuList);
  const [currentActiveMenu, setCurrentActiveMenu] = useState(
    isEmpty(menuList) ? null : menuList[0]
  );
  const [isResMenuOpen, setIsResMenuOpen] = useState(false);

  //------------------------ event handlers ---------------------------
  const onMenuClick = (menu) => {
    setCurrentActiveMenu(menu);
    _onMenuClick(menu);
  };

  const handleSubMenuClick = (menu) => {
    const _menuList = menuList.map((_menu) => {
      if (menu.id === _menu.id) {
        return {
          ...menu,
          isActive: !_menu.isActive
        };
      } else {
        return { ..._menu, isActive: false };
      }
    });
    setMenuList(_menuList);
  };

  const handlerResMenuClick = () => {
    setIsResMenuOpen(!isResMenuOpen);
  };

  //------------------------ Effects -----------------------------------
  useEffect(() => {
    setIsResMenuOpen(false);
  }, [currentActiveMenu]);

  useEffect(() => {
    if (currentActiveMenu.id !== _currentMenuId) {
      let updatedMenu = menuList.find((menu) => menu.id === _currentMenuId);
      setCurrentActiveMenu(updatedMenu);
    }
  }, [_currentMenuId]);

  //------------------------ JSX code ---------------------------------
  return (
    <>
      <div className='responsive-menu-selection' onClick={handlerResMenuClick}>
        <a href='#'>{currentActiveMenu.name}</a>
        <img src={isResMenuOpen ? svgUp : svgDown} alt='' />
      </div>
      <aside
        id={`sidebar-${_currentSection}`}
        className={`sidebar ${isResMenuOpen ? 'open' : 'close'}`}>
        {/* <h3>Side Navigation</h3> */}
        <nav className='navbar'>
          <SubMenu
            menu={menuList}
            currentActiveMenu={currentActiveMenu}
            onMenuClick={onMenuClick}
            onSubMenuclick={handleSubMenuClick}
          />
        </nav>
      </aside>
    </>
  );
};

export default SideMenu;
