import React, { useState, useEffect, Fragment } from 'react';
import PropTypes from 'prop-types';

//---------------------- media import ---------------------------------
import svgUp from '../../../../assets/images/ProfileEdit/icon-up-arrow.svg';
import svgDown from '../../../../assets/images/ProfileEdit/icon-down-arrow.svg';
import newTag from '../../../../assets/images/ProfileEdit/icon-new.svg';

//---------------------- helpers import -------------------------------
import isEmpty from '../../../../utils/validation/isEmpty';
import * as constants from '../../../../utils/constant-data';

const SubMenu = (props) => {
  const { menu, currentActiveMenu, onMenuClick, onSubMenuclick, showNewIcon, hasSubMenu, profileMenu, currentActiveSubMenu } = props;

  const buttonClickHandler = (menu) => {
    onMenuClick(menu);    
  };   
  return (
  <>{
    hasSubMenu?<>
    <ul className={`menu-list ${currentActiveMenu === profileMenu.Value ? 'selected' : ''}`} key={menu.id}>
      {menu.map((menu) => {
        return (
          <li
            key={menu.id}
            className={`menu-item ${currentActiveSubMenu === menu.value ?'selected' : ''}`}
            onClick={() =>  onMenuClick(menu)}>
            <a>{menu.name}</a>
            {showNewIcon && <img className='new-tag' src={newTag} alt='icon' />}
          </li>
          );
        })}
        </ul>
    </>
    :
    <ul className={`menu-list ${currentActiveMenu.id === menu.id ? 'selected' : ''}`} key={menu.id}>
      {menu.map((menu) => {
        if (isEmpty(menu.subMenu)) {
          return (
            <li
              key={menu.id}
              className={`menu-item ${currentActiveMenu.id === menu.id ? 'selected' : ''}`}
              onClick={() => buttonClickHandler(menu)}>
              <a>{menu.name}</a>
              {showNewIcon && <img className='new-tag' src={newTag} alt='icon' />}
            </li>
          );
        } else {
          return (
            <Fragment key={menu.id}>
              <li key={menu.id} className='menu-item' onClick={() => onSubMenuclick(menu)}>
                <a
                  className={`${
                    currentActiveMenu.id > 3 && menu.isActive ? 'active-menu-item' : ''
                  }`}>
                  {menu.name}
                </a>
                <img src={menu.isActive ? svgUp : svgDown} alt='' />
              </li>
              {menu.isActive && (
                <SubMenu
                  menu={menu.subMenu}
                  currentActiveMenu={currentActiveMenu}
                  onMenuClick={onMenuClick}
                  showNewIcon={showNewIcon}
                />
              )}
            </Fragment>
          );
        }
      })}
    </ul>}
    </>
  );
};
SubMenu.propTypes = {
  showNewIcon: PropTypes.bool,
  hasSubMenu: PropTypes.bool,
  profileMenu: PropTypes.object,
  currentActiveSubMenu: PropTypes.string
};

SubMenu.defaultProps = {
  showNewIcon: false,
  hasSubMenu: false,
  profileMenu:[],
  currentActiveSubMenu:''
};

export default SubMenu;
