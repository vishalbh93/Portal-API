import React, { useEffect, useState } from 'react';

import * as constants from '../../../../utils/constant-data';

import './_tab.less';
import ConfirmationModelPopUp from '../../../Common/ConfirmationModelPopUp/ConfirmationModelPopUp';

const Tab = (props) => {
  const [flag, setFlag] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [tab_1, SetTab_1] = useState(props.Tab);

  const onhandleConfirm =(value) =>{    
    setFlag(value);
    setShowModal(false);
  };

  const buttonClickHandler = (e, tab) => {    
    validatePage(tab);
    SetTab_1(tab);    
  };

  const validatePage = (tab) => {
  let isProfilePage = document.getElementById('provider-profile-container');
  if (isProfilePage == null ||constants.sectionsToExcludeForUnsavedData.includes(props.currentTab.label.toLowerCase())){
      setShowModal(false);
      setFlag(true);
      props.setActive(tab);
    } 
    else {     
    let eleValidButton = document.getElementsByClassName('provider-profile-save valid');
    if (eleValidButton.length !== 0){
      setShowModal(true);
      setFlag(false);
    }      
    else{
      setShowModal(false);
      setFlag(true);
      props.setActive(tab);
    }
  } 
  }; 

  useEffect(() => {
    if (flag) {            
      props.setActive(tab_1);
       }
  },[flag]);

  return (
    <>
    <button
      className={`tab-item ${props.currentTab.label == props.tab.label ? 'active' : ''}`}
      tabIndex={`${props.currentTab == props.tab ? '0' : '-1'}`}
      onClick={(e) => buttonClickHandler(e, props.tab)}>
      {props.tab.badgeEnabled && <span className='badge' />}
      {props.tab.label}
    </button>
    {showModal && (<ConfirmationModelPopUp showModal = {showModal} onhandleConfirm = {onhandleConfirm}></ConfirmationModelPopUp>)}
    </>    
  );
};

export default Tab;
