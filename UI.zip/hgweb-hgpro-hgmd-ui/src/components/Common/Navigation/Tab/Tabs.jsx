import React from 'react';
import { useState, useEffect } from 'react';
import _ from 'lodash';

import Tab from './Tab';

import './_tabs.less';

const Tabs = (props) => {
  const { tabs, selectedTab } = props;
  const [currentTab, setCurrentTab] = useState(tabs[0]);

  const tabSelectHandler = (tab) => {
    if (!_.isEmpty(tab)) setCurrentTab(tab);
  };

  useEffect(() => {
    if (!_.isEmpty(selectedTab)) setCurrentTab(selectedTab);
  }, [selectedTab]);

  useEffect(() => {
    //Add logic after selecting the target tab isUnsavedChanges
    props.onSelectHandler(currentTab);
  }, [currentTab]);

  const TabList = (
    <div className='tab-group' role={'tablist'}>
      {tabs.map((tab, index) => (
        <Tab key={index} tab={tab} currentTab={currentTab} setActive={tabSelectHandler}/>
      ))}
    </div>
  );
  return TabList;
};

// Tabs.defaultProps = {
//   selectedTab: props.tabs[0]
// };

export default Tabs;
