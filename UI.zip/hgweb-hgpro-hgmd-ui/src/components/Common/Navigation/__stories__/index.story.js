import React from 'react';
import { storiesOf } from '@storybook/react/dist/client/preview';

import Tabs from '../Tab/Tabs';
import SideMenu from './../SideMenu/SideMenu';

const tabs = [
  {
    label: 'Basic Info',
    badgeEnabled: true
  },
  {
    label: 'Accepting New Patients',
    badgeEnabled: false
  },
  {
    label: 'Common Questionaire',
    badgeEnabled: true
  }
];

const tabSelectionhandler = (tab) => {
  
}

storiesOf('Common | Navigation', module)
  .add('Tabs', () => <Tabs tabs={tabs} onSelectHandler={tabSelectionhandler} />)
  .add('SideMenu', () => <SideMenu currentSection='story' />);

