import React, { Fragment, Suspense, useEffect, useState } from 'react';
import PropTypes from 'prop-types';

//styling imports
import './_patientExperience.less';

//component import
import Tabs from './Tabs/Tabs';


import UpdateNotification from './UpdateNotification';

import * as constants from '../../utils/constant-data';
import { HG3Tracker } from '../../utils/tracking';
import OverView from './Overview/OverView';
import PatientReview from './PatientReviews/PatientReview';

const PatientExperience = (props) => {
  const {
    patientExperienceInfo,
    islanding,
    windowDimensions,
    openDropdown,
    bannerDisplayName,
    dropDownHandler,
    TabsHandler,
    notify,
    ispatientExperiencePictureEdit
  } = props;
  const [currentTab, setCurrentTab] = useState('overview');
  const [currentInnerTab, setCurrentInnerTab] = useState('');
  const [fixedScrollable, setFixedScrollable] = useState('');

  const tabContent = (tabName) => {
    switch (tabName) {
      case 'overview':
        return (
          <OverView />
        );
      case 'patientreviews':
        return (
          <PatientReview />
        );
    }
  };

  const onInnerTabChangeHandler = (e, innerSection) => {
    if (innerSection != undefined && innerSection != null) {
      let fieldInfo = constants.missingFields.filter((e) => e.fieldName == innerSection)[0];
      setCurrentInnerTab(fieldInfo.tabName);
    }
    onTabsChangeHandler(e);
    TabsHandler(e);
  };

  const onTabsChangeHandler = (e) => {
    setCurrentTab(e);
    TabsHandler(e);
  };

  const setTrackerLink = (linkName) => {
    HG3Tracker.OmnitureTrackLink(`edit|main-nav|patientExperience|${linkName}`);
  };

  const loadTrackerLink = (selectedTab) => {
    switch (selectedTab) {
      case 'overview':
        setTrackerLink('overview');
        break;
      case 'patientreviews':
        setTrackerLink('patient reviews');
        break;    
    }
  };

  const handleScroll = () => {
    const offset = window.scrollY;
    if (offset > 220) {
      setFixedScrollable('fixed-content-container');
    } else {
      setFixedScrollable('');
    }
  };

  useEffect(() => {
    loadTrackerLink(currentTab);
    onTabsChangeHandler(currentTab);
  }, [currentTab]);

  useEffect(() => {
    if (ispatientExperiencePictureEdit) {
      onInnerTabChangeHandler('generalinfo', 'photos');
    }
    props.setIspatientExperienceEdit(false);
  }, [ispatientExperiencePictureEdit]);

  useEffect(() => {
    let _subtab = '';
    let _tab = '';
    _subtab = window.location.href.includes('#') ? window.location.href.split('#')[1] : '';
    let arr = [...constants.missingFields];
    _tab =
      _subtab != ''
        ? arr.length > 0 &&
          arr.filter((e) => e.fieldName.toLowerCase() === _subtab.toLowerCase())[0] != [] &&
          arr.filter((e) => e.fieldName.toLowerCase() === _subtab.toLowerCase())[0].fieldName !=
            undefined
          ? arr.filter((e) => e.fieldName.toLowerCase() === _subtab.toLowerCase())[0].fieldName
          : ''
        : '';
    _tab && subTabsHandler(_tab != '' ? _tab : '');
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  });

  return (
    <>
      <div className='patientExperience-container patientExperience-main-container'>
        <Suspense fallback={<h5>Loading...</h5>}>
          <div className='patientExperience-inner-container'>
            {(openDropdown || windowDimensions > 768) && (
              <Fragment>
                <Tabs
                  onTabsChange={onTabsChangeHandler}
                  openDropdown={openDropdown}
                  dropDownHandler={dropDownHandler}
                  openTab={currentTab}
                  userIsAdmin={patientExperienceInfo.NavigationModel.UserIsAdmin}
                  showBoardCertification={patientExperienceInfo.ProfessionalType === 0 ? true : false}
                  bannerDisplayName={bannerDisplayName}
                />
              </Fragment>
            )}
            <Fragment>
              <div
                id={currentTab}
                className={`${
                  currentTab == 'overview' ? 'content-container-overview' : 'content-container'
                } ${fixedScrollable}`}>
                {tabContent(currentTab)}               
              </div>
            </Fragment>
          </div>
        </Suspense>
      </div>
    </>
  );
};

PatientExperience.propTypes = {
  patientExperienceInfo: PropTypes.object
};

export default PatientExperience;
