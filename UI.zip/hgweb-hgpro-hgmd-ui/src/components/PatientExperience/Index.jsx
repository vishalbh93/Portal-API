import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

//------------------------- Stylesheet import -----------------------
import '@hg/joy/src/globalstyles';
import './../../styles/_dashboardglobalstyle.less';
import './../Spinner/Spinner';
import './_index.less';

//----------------------- Helper imports -----------------------------
import * as service from './../../utils/service';
import isEmpty from '../../utils/validation/isEmpty';

//------------------------- Components import -----------------------
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import Landing from '../Common/Layouts/Landing';
import SideMenu from '../Common/Navigation/SideMenu/SideMenu';
import OverView from './Overview/OverView';
import PatientReview from './PatientReviews/PatientReview';
import ReviewReminderLink from './PatientReviewTools/ReviewReminderLink';
import ReviewReminderCard from './PatientReviewTools/ReviewReminderCard';
import StarRatingBadge from './PatientReviewTools/StarRatingBadge';

const Index = (props) => {
  //------------------------- Props destructuring --------
  //const { name, providerInformationObj } = props;
  const { patientExperienceInfo } = useSelector((state) => state.loadPatientExperienceData);

  let menuItems = patientExperienceInfo.Navigations;
  let navigationModelObject = patientExperienceInfo.NavigationModel;

  //------------------------- States ---------------------
  const [menuContent] = useState([
    {
      id: 1,
      name: 'Overview',
      subMenu: null
    },
    {
      id: 2,
      name: 'Patient Reviews',
      subMenu: null
    },
    {
      id: 3,
      name: 'Patient Review Tools',
      subMenu: [
        {
          id: 4,
          name: 'Review Reminder Cards',
          subMenu: null
        },
        {
          id: 5,
          name: 'Review Reminder Link',
          subMenu: null
        },
        {
          id: 6,
          name: 'Star Rating Badge',
          subMenu: null
        }
      ]
    }
  ]);
  const [currentMainContent, setSelectedMainContent] = useState(menuContent[0]);
  const [providerInformationObj, setProviderInformationObj] = useState({});
  const [sponsorInformationObj, setSponsorInformationObj] = useState({});
  const [analyticsModel, setAnalyticsModel] = useState({});
  const [providerId, setProviderId] = useState('');
  const [recentReviews, setRecentReviews] = useState(null);

  //------------------------- Event handlers -------------
  const handleMenuClick = (menu) => {
    setSelectedMainContent(menu);
  };

  //------------------------- Service calls --------------
  const fetchBannerData = (pwid, currentUser) => {
    service._get(`/api/provider/providerBannerData?providerId=${pwid}`).then((res) => {
      if (res.status === 200) {
        const { data } = res;
        const { ProviderCardInformation, ProviderSponsorShipInformation } = data;
        let providerInformationObj = {
          informationObj: {
            displayName: ProviderCardInformation.DisplayName,
            speciality: ProviderCardInformation.SpecialityName || '',
            ratingInfo: {
              stars: ProviderCardInformation.StarRatings,
              ratings: ProviderCardInformation.Ratings
            },
            lastUpdated: null
          },
          imageObj: {
            id: 'patient-experience',
            className: 'provider-image',
            gender: ProviderCardInformation.Gender,
            imageSrc: ProviderCardInformation.ImageSrc,
            name: ProviderCardInformation.DisplayName,
            size: 'xl'
          }
        };
        setProviderInformationObj(providerInformationObj);
        setSponsorInformationObj(ProviderSponsorShipInformation);
      }
    });
  };

  const fetchAnalyticsData = (providerId) => {
    service._get(`/api/patientexperience/v2/analytics?providerId=${providerId}`).then((res) => {
      const { data = null } = res;
      if (!isEmpty(data)) {
        setAnalyticsModel(data);
      }
    });
  };

  //------------------------- Effects --------------------
  useEffect(() => {
    if (!isEmpty(patientExperienceInfo.CurrentUserId)) {
      let pwid = JSON.parse(patientExperienceInfo.ProviderDetailsJson).Pwid;
      fetchBannerData(pwid, patientExperienceInfo.CurrentUserId);
      fetchAnalyticsData(pwid);
      setProviderId(pwid);

      let recentReviews = JSON.parse(patientExperienceInfo.ReviewsJson) || {};
      setRecentReviews(recentReviews);
    }
  }, [patientExperienceInfo]);

  const clickOnScoreTipCardHandler = (id) => {
    if (!isEmpty(id)) {
      setSelectedMainContent({ ...menuContent[1], isActive: true });
      window.scroll(0, 0);
    }
  };

  //------------------------- JSX helper -----------------
  const getMainContentComponentJSX = () => {
    switch (currentMainContent.id) {
      case 1:
        return (
          <OverView
            _currentSection='patient-experience'
            analyticsModel={analyticsModel}
            recentReviews={recentReviews}
            clickOnScoreTipCardHandler={clickOnScoreTipCardHandler}
          />
        );
      case 2:
        return (
          <PatientReview
            _currentSection='patient-review'
            patientReviewsJson={patientExperienceInfo.ReviewsJson}
          />
        );
      // case 3:
      //   return <OverView _currentSection='patient-experience' />;
      case 4:
        return <ReviewReminderCard _currentSection='patient-experience' />;
      case 5:
        return <ReviewReminderLink _currentSection='patient-experience' providerId={providerId} />;
      case 6:
        return (
          <StarRatingBadge
            inHealthIframeSrc={
              isEmpty(patientExperienceInfo.ResourcesModel)
                ? ''
                : patientExperienceInfo.ResourcesModel.InHealthIframeSrc || ''
            }
          />
        );
      default:
        return <div>Some error occured!!</div>;
    }
  };

  const menuClick = (section) => {
    //  setCurrentTab(section);
  };

  //------------------------- JSX code -----------------------
  return (
    <>
      <MenuComponent
        menuClick={menuClick}
        showMenus={true}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        providerInfo={JSON.parse(patientExperienceInfo.ProviderDetailsJson)}
      />
      <div className='pes-index-container'>
        <Landing
          providerInformationObj={providerInformationObj}
          sponsorInformationObj={sponsorInformationObj}
        />
        <main className='pes-main'>
          <div className='pes-wrapper'>
            <SideMenu
              _menuList={menuContent}
              _currentSection='patient-experience'
              _onMenuClick={handleMenuClick}
              _currentMenuId={currentMainContent.id}
            />
            {getMainContentComponentJSX()}
          </div>
          <Footer />
        </main>
      </div>
    </>
  );
};

Index.propTypes = {};

export default Index;
