import React from 'react';

//----------------------- Stylesheet imports -------------------------
import './_overView.less';

//----------------------- Helper imports -----------------------------
import isEmpty from '../../../utils/validation/isEmpty';

//------------------------------ Components import -------------------
import PatientExperienceAnalytics from './PatientExperienceAnalytics/PatientExperienceAnalytics';
import RecentReviews from './RecentReviews/RecentReviews';

const OverView = (props) => {
  //-------------------- props destructuring -------------------------
  const { _currentSection, analyticsModel, recentReviews, clickOnScoreTipCardHandler } = props;

  //----------------------- JSX code ---------------------------------
  return (
    <div className={`overview-wrapper-${_currentSection}`}>
      {!isEmpty(analyticsModel.ProviderId) && (
        <PatientExperienceAnalytics
          analyticsModel={analyticsModel}
          patientExperienceOverviewSurveys={ !isEmpty(recentReviews) ? recentReviews.PatientExperienceOverviewSurveys : []}
          clickOnScoreTipCardHandler={clickOnScoreTipCardHandler}
        />
      )}
      {!isEmpty(analyticsModel.ProviderId) &&
        !isEmpty(recentReviews) &&
        !isEmpty(recentReviews.Comments) &&
        !isEmpty(recentReviews.FlagReasons) && (
          <RecentReviews
            comments={recentReviews.Comments || []}
            flagReasons={recentReviews.FlagReasons || []}
          />
        )}
    </div>
  );
};

export default OverView;
