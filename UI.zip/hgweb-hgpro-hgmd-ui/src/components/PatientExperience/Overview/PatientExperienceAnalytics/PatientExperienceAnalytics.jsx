import React, { useState } from 'react';

//----------------------- Stylesheet imports -------------------------
import './_patientExperienceAnalytics.less';

//----------------------- Helper imports -----------------------------
import isEmpty from '../../../../utils/validation/isEmpty';

//----------------------- Components imports -------------------------
import StarRating from '@hg/joy/src/components/StarRating';

//----------------------- Media imports ------------------------------
import svgLogo from './../../../../assets/images/ClaimYourProfile/Logo.svg';
import svgReview from './../../../../assets/images/Dashboard/icon-review.svg';
import svgChat from './../../../../assets/images/Dashboard/icon-chat.svg';
import svgIconMonitor from './../../../../assets/images/Dashboard/icon-monitor.svg';
import svgIconSurvey from './../../../../assets/images/Dashboard/icon-survey.svg';
import ReviewsComment from '../../PatientReviews/ReviewsComment';

const scoreTipData = [
  {
    iconSrc: svgChat,
    text: `Respond to patient comments 
    (both positive and negative) in a timely and professional manner.`,
    hyperLink: ''
  },
  {
    iconSrc: svgIconSurvey,
    text: `Seek feedback from your patients.`,
    hyperLink: 'Get the free survey acquisition tools!'
  },
  {
    iconSrc: svgIconMonitor,
    text: `Monitor and review patient comments on a regular Basis.`,
    hyperLink: ''
  }
];

const PatientExperienceAnalytics = ({
  analyticsModel,
  patientExperienceOverviewSurveys,
  clickOnScoreTipCardHandler
}) => {
  //----------------------- States -----------------------------------
  const starRating = analyticsModel.StarRatings;
  const [viewLimit, setviewLimit] = useState(5);

  let whatWentWellList = [];
  let whatCouldImprovedList = [];
  if (!isEmpty(patientExperienceOverviewSurveys)) {
    whatWentWellList = patientExperienceOverviewSurveys
      .filter((p) => p.PositiveLabel != '')
      .map((i) => {
        return {
          textPrimary: i.PositiveLabel,
          textSecondary: i.PositiveResponseCount
        };
      });

    whatCouldImprovedList = patientExperienceOverviewSurveys
      .filter((p) => p.NegativeLabel != '')
      .map((i) => {
        return { textPrimary: i.NegativeLabel, textSecondary: i.NegativeResponseCount };
      });
  }

  const handleViewMoreClick = () => {
    setviewLimit(whatWentWellList.length > 0 ? whatCouldImprovedList.length : whatCouldImprovedList.length);
  };

  const handleShowLessClick = () => {
    setviewLimit(5);
  };

  //----------------------- JSX code ---------------------------------
  return (
    <section id='pes-section' className='pes-container'>
      <div className='hg-logo-container'>
        <img className='hg-logo' src={svgLogo} alt='' />
      </div>
      <article className='pes-article'>
        <h2>Patient Experience Analytics</h2>
        <p>{analyticsModel.Content.HeaderContent}</p>
        <div className='ratings-container'>
          <div className='ratings-group'>
            <div className='ratings-value'>
              <span className='ratings-of'>
                {Number(starRating) === starRating && starRating % 1 === 0
                  ? `${starRating}.0`
                  : starRating}
              </span>
              <span className='ratings-out-of'>/ 5.0</span>
            </div>
            <div className='star-ratings-container'>
              <StarRating stars={Math.round(starRating * 2) / 2} size='xl' />
            </div>
          </div>
          <hr />
          <div className='comments-ratings-group'>
            <div className='patient-ratings-group'>
              <img src={svgReview} alt='' />
              <div className='patient-text-group'>
                <span>{analyticsModel.PatientRatings}</span>
                <span>Patient Ratings</span>
              </div>
            </div>
            <div className='patient-comments-group'>
              <img src={svgChat} alt='' />
              <div className='patient-text-group'>
                <span>{analyticsModel.PatientCommentsCount}</span>
                <span>Patient Comments</span>
              </div>
            </div>
          </div>
        </div>
        <p
          className={`${starRating == 0 ? 'center-align' : ''}`}
          dangerouslySetInnerHTML={{ __html: analyticsModel.Content.ArticleContent }}></p>
      </article>
      {!isEmpty(patientExperienceOverviewSurveys) && (
        <div className='pes-compare-experience-container'>
          <h4 className='pes-subheader'>What patients have to say about their experience</h4>
          <div className='pes-compare-experience pes-sub-section-container'>
            <DescriptiveBullets viewLimit={viewLimit} title='What went well' bulletList={whatWentWellList} />
            <DescriptiveBullets viewLimit={viewLimit} title='What could be improved' bulletList={whatCouldImprovedList} />
          </div>
          {(whatWentWellList.length > 0 && whatWentWellList.length > 5 ) || (whatCouldImprovedList.length > 0 && whatCouldImprovedList.length > 5) ? (
            viewLimit <= 5 ? (
              <a onClick={handleViewMoreClick}>View More</a>
            ) : (
              <a onClick={handleShowLessClick}>Show Less</a>
            )
          ) : null}
        </div>
      )}
      <div className='pes-tips-container'>
        <h4 className='pes-subheader'>Tips to Increase Patient Engagement Scores</h4>
        <div className='pes-tips-card-container'>
          {scoreTipData.map((tip, index) => (
            <ScoreTipsCard
              iconSrc={tip.iconSrc}
              text={tip.text}
              hyperLink={tip.hyperLink}
              providerId={analyticsModel.providerId}
              key={index}
              clickOnScoreTipCardHandler={clickOnScoreTipCardHandler}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PatientExperienceAnalytics;

const DescriptiveBullets = (props) => {
  //----------------------- Destructuring props -----------------------
  const { viewLimit, title, bulletList } = props;


  ///dev temp

  //----------------------- JSX code ---------------------------------
  return (
    <div className='description-container'>
      <div className='bullet-header'>
        <h4 className='bullet-title'>{title}</h4>
      </div>
      <ul className='bullet-list'>
        {bulletList.map((bullet, index) => {
          if (index < viewLimit) {
            return (
              <li className='bullet-item' key={index}>
                <span className='bullet-text-primary'>{bullet.textPrimary}</span>
                <strong className='bullet-text-secondary'>
                  <span>({bullet.textSecondary})</span>
                </strong>
              </li>
            );
          }
        })}
      </ul>
    </div>
  );
};

const ScoreTipsCard = ({ iconSrc, text, hyperLink, providerId, clickOnScoreTipCardHandler }) => {
  return (
    <div className='score-tip-wrapper'>
      <div className='icon-container'>
        {isEmpty(iconSrc) ? <></> : <img src={iconSrc} alt='score' />}
      </div>
      <div className='text-container'>{isEmpty(text) ? <></> : <p>{text}</p>}</div>
      <div className='link-to-survey' onClick={() => clickOnScoreTipCardHandler(2)}>
        {isEmpty(hyperLink) ? <></> : <a>{hyperLink}</a>}
      </div>
    </div>
  );
};
