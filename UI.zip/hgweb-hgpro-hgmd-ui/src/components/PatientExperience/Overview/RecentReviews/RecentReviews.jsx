import React, { useState } from 'react';

//------------------------- Stylesheet import -----------------------
import './_recentReviews.less';

//----------------------- Helper imports ----------------------------
import isEmpty from '../../../../utils/validation/isEmpty';

//------------------------- Components import -----------------------
import ReviewsComment from '../../PatientReviews/ReviewsComment';

const RecentReviews = ({ comments, flagReasons }) => {
  const [currentSelection, setCurrentSelection] = useState(0);

  return (
    <section id='recent-reviews-section' className='recent-reviews-section'>
      <h2>Recent Reviews</h2>
      <div className='comments-container'>
        {!isEmpty(comments) &&
          comments
            .slice(0, 3)
            .map(
              (comment, index) =>
                currentSelection == index && (
                  <ReviewsComment
                    commentDetails={comment}
                    key={index}
                    flagReasons={flagReasons}
                    addOrDeleteCommentReply={() => {}}
                    showFlagModalPopUp={false}
                    showbutton={false}
                  />
                )
            )}
      </div>
      <div className='carousel-container'>
        {comments.length > 1 &&
          comments
            .slice(0, 3)
            .map((comment, index) => (
              <button
                key={index}
                value={index}
                name='recentReviews'
                className={index == currentSelection ? 'btn-active' : ''}
                onClick={() => setCurrentSelection(index)}
                aria-label='review-pagination-button'
              />
            ))}
        {/* <input
          type='radio'
          value='0'
          name='recentReviews'
          onChange={() => setCurrentSelection(0)}
          defaultChecked
        />
        <input
          type='radio'
          value='1'
          name='recentReviews'
          onChange={() => setCurrentSelection(1)}
        />
        <input
          type='radio'
          value='2'
          name='recentReviews'
          onChange={() => setCurrentSelection(2)}
        /> */}
      </div>
    </section>
  );
};

export default RecentReviews;
