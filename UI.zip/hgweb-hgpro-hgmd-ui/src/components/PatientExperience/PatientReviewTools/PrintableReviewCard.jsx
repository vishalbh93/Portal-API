import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { QRCodeCanvas, QRCodeSVG } from 'qrcode.react';

//styles
import './_printableReviewCard.less';

//component import
import { RadioGroup } from '../../FormComponents/RadioGroup';

//media import
import border from '../../../assets/images/PatientExperience/photo-border.png';
import Logo from '../../../assets/images/healthgrades_logo.svg';

const PrintableReviewCard = (props) => {
  const { providerInfo, showLargeCard } = props;
  //const [selectedDay, setSelectedDay] = useState('');

  const days = [
    { Name: 'MON', Value: 'Monday', Show: true },
    { Name: 'TUE', Value: 'Tuesday', Show: true },
    { Name: 'WED', Value: 'Wednesday', Show: true },
    { Name: 'THU', Value: 'Thursday', Show: true },
    { Name: 'FRI', Value: 'Friday', Show: true },
    { Name: 'SAT', Value: 'Saturday', Show: true },
    { Name: 'SUN', Value: 'Sunday', Show: true }
  ];

  // const radioGroupChangeHandler = (event) => {
  //   event.persist();
  //   let value = event.target.value;
  //   setSelectedDay(value);
  // };
  const getProviderDisplayName = () => {
    let dispName = `<strong>${providerInfo.FirstName}<br/>${providerInfo.LastName}${
      providerInfo.Suffix != '' ? ' ' + providerInfo.Suffix : ''
    }${providerInfo.Degree != '' ? ', ' + providerInfo.Degree : ''}</strong>`;

    return dispName;
  };

  return (
    <>
      <section className='review-printable-card-container'>
        <div className='reivew-info-container'>
          <div className='provider-image-container'>
            <img
              src={providerInfo.ImageUrl}
              alt={providerInfo.DisplayFullName}
              width='96'
              title={providerInfo.DisplayFullName}
              className='provider-image'
            />
            <img src={border} alt='border' className='right-border'></img>
          </div>

          <div className='card-info-container'>
            <div className='provider-info-display-name' title={providerInfo.DisplayFullName}>
              <>
                <QRCodeCanvas
                  value={`https://www.healthgrades.com/review/${providerInfo.ProviderId}`}
                  className='qr-img'
                  id='qr-img'
                />

                <span>
                  <strong className='provider-info-name'>
                    {window.innerWidth > 768 ? (
                      providerInfo.LastName.includes('-') ? (
                        <span dangerouslySetInnerHTML={{ __html: getProviderDisplayName() }} />
                      ) : (
                        providerInfo.DisplayFullName
                      )
                    ) : (
                      providerInfo.DisplayFullName
                    )}
                  </strong>
                </span>
                <br />
                <span className='specilaity'>{providerInfo.PrimarySpecialty}</span>
                <br />
                <span className='remove-margin'>{providerInfo.ProviderPhoneNumbers}</span>
                <span className='remove-margin'>{providerInfo.Address},</span>
                <span>{providerInfo.CityStateZip}</span>

                <div className='card-message'>
                  Thank you for supporting our practice! Your feedback helps us deliver the highest
                  quality care.
                </div>
              </>
            </div>
          </div>
        </div>

        <div className='card-link-logo-container'>
          <div className='card-link'>
            Review us at: https://www.healthgrades.com/review/{providerInfo.ProviderId}
          </div>
          <div className='card-logo'>
            <img src={Logo} alt='Healthgrades' />
          </div>
        </div>

        {showLargeCard && (
          <div className='large-card-expanded-div-warpper'>
            <hr />
            <div className='appointments-available'>
              <span>Your next appointment:</span>

              <div className='appointments-available-inner'>
                <RadioGroup
                  radioGroup={days}
                  //selectedOption={selectedDay}
                  //onChangeHandler={(event) => radioGroupChangeHandler(event)}
                  onChangeHandler={() => {}}
                />
              </div>
              <div className='available-time'>
                <div>
                  <span>Date:</span>
                  <span className='filler'> _________________ </span>
                </div>
                <div>
                  <span>Time:</span>
                  <span className='filler'> _________________ </span>
                  <span>am pm</span>
                </div>
              </div>

              <div className='card-bottom-content'>
                Please contact us directly with concerns: {providerInfo.ProviderPhoneNumbers}
              </div>
            </div>
          </div>
        )}
      </section>
    </>
  );
};

PrintableReviewCard.defaultProps = {
  providerInfo: {},
  showLargeCard: false
};

PrintableReviewCard.propTypes = {
  providerInfo: PropTypes.object,
  showLargeCard: PropTypes.bool
};
export default PrintableReviewCard;
