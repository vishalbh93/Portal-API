export const CARD_TYPE_LARGE = 'post-card';
export const CARD_TYPE_SMALL = 'business-card';
