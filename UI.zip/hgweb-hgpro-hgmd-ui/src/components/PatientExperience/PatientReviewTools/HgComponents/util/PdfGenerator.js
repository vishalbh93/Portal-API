/* eslint-disable */
import blobStream from 'blob-stream';
import PDFDocument from './pdfkit';
import resourceDownloader from './resourceDownloader';

const pdfHelper = (function () {
  let helper = function (doc, fonts, images, style) {
    this.doc = doc;
    this.fonts = fonts || {};
    this.images = images || {};
    this.style = style || {};
    this.style.printGuideLineColor = '#808080';
    this.style.printGuideLineWidth = 0.5;
    this.style.mainColor = '#2b318b';
    this.style.secondaryColor = '#626366';
    this.style.urlColor = '#edf2f2';

    this.style.deepBlue50 = '#000073';
    this.style.gray90 = '#4A4A4D';
    this.style.gold70 = '#826C4B';

    this.registerFonts();

    this.fontFallbacks = {
      'sansserif-regular': 'Helvetica',
      'sansserif-bold': 'Helvetica-Bold',
      'sansserif-italic': 'Helvetica-Oblique',
      'sansserif-heavy': 'Helvetica-BoldOblique'
    };
  };

  // adds fonts to the pdf document
  helper.prototype.registerFonts = function () {
    if (!this.doc) {
      return;
    }

    if (!!this.fonts) {
      for (let property in this.fonts) {
        if (this.fonts.hasOwnProperty(property) && this.fonts[property].buffer) {
          this.doc.registerFont(property, this.fonts[property].buffer, property);
        }
      }
    }
  };

  // retrieve image data for use with the PDF
  helper.prototype.getImage = function (type) {
    if (!!this.images[type] && !!this.images[type].buffer) {
      return this.images[type].buffer;
    }
  };

  // set the font, will use fallback if incorrectly loaded
  helper.prototype.setFont = function (type) {
    try {
      if (!!this.fonts[type] && !!this.fonts[type].buffer) {
        this.doc.font(type);
      }
    } catch (ex) {
      if (this.fontFallbacks[type]) {
        this.doc.font(this.fontFallbacks[type]);
      }
    }
  };

  /* draw all the cards onto the pdf document
		columns: number of columns in the card grid,
		rows: number of rows in the card grid,
		cardHeight: the height of a single card (for calculating offset),
		cardWidth: width of a single card (for calculating offset),
		hPadding: additional horizontal padding to account for in the offset,
		vPadding: additional vertical padding to account for in the offset,
		includeBackground: adds a background image if true and image exists in images['background'],
		drawCard: function(x, y, column, row), draws the single card provides x offset, y offset, current row and column
	*/
  helper.prototype.drawCards = function (
    columns,
    rows,
    cardHeight,
    cardWidth,
    hPadding,
    vPadding,
    includeBackground,
    drawCard
  ) {
    if (rows <= 0 || columns <= 0 || !drawCard) {
      return;
    }

    let totalVerticalMarks = columns + 1;
    let totalHorizontalMarks = rows + 1;
    let backgroundImage = this.getImage('background');
    // draw left print markings
    for (let i = 0; i < totalVerticalMarks; i++) {
      for (let j = 0; j < totalHorizontalMarks; j++) {
        // determine offset
        let xOffset = hPadding + i * cardWidth;
        let yOffset = vPadding + j * cardHeight;

        if (!!includeBackground && !!backgroundImage) {
          this.doc.image(backgroundImage, xOffset, yOffset, {
            width: cardWidth,
            height: cardHeight
          });
        }

        // draw marking
        this.doc
          .moveTo(xOffset - 2, yOffset)
          .lineTo(xOffset + 2, yOffset)
          .moveTo(xOffset, yOffset - 2)
          .lineTo(xOffset, yOffset + 2)
          .lineWidth(this.style.printGuideLineWidth)
          .stroke(this.style.printGuideLineColor);
      }
    }

    for (let column = 0; column < columns; column++) {
      for (let row = 0; row < rows; row++) {
        let xOffset = hPadding + column * cardWidth;
        let yOffset = vPadding + row * cardHeight;
        try {
          drawCard.apply(this, [xOffset, yOffset, column, row]);
        } catch (e) {
          console.log(e);
        }
      }
    }
  };

  helper.prototype.base64ToArrayBuffer = (base64) => {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  };

  return helper;
})();

const pdfGenerator = {
  /*
    	generates the PDF document for business cards based on provided details
        details: {
            images: {
                "logo": { url: "url to hg3 logo" },
                "provider": { url: "url to provider profile image" },
                "others": { url: "url to image file" }
            },
            fonts: { "name": { url: "url to font file" } },
            doctorName: "display name of provider"
            practiceName: "display name of provider's pracitce"
            specialty: "display name of provider's specialty"
            reviewUrl: "url to provider's review page"
        }
    */
  generatePdfBlobs(copy, details) {
    let ctx = this;
    details = details || {};

    return new Promise(function (resolve, reject) {
      // if resources are required, download them at the start
      // of the promise chain.
      if (!!details.fonts || !!details.images) {
        let resourcePromise = resourceDownloader.downloadResources(details.fonts, details.images);
        Promise.resolve(resourcePromise).then(function (values) {
          details.fonts = values.fonts;
          details.images = values.images;

          Promise.all(ctx.generatePdfBlobPromises(details, copy)).then(function (blobs) {
            resolve(blobs);
          });
        });
      } else {
        // get the promises directly if no resources required
        Promise.all(ctx.generatePdfBlobPromises(details, copy)).then(function (blobs) {
          resolve(blobs);
        });
      }
    });
  },

  // generates the PDF document for business cards based on provided details
  generatePdfBlobPromises: function (details, copy) {
    let smallPdf = this.getBusinessCardPDF(details, copy);
    let bigPdf = this.getPostCardPDF(details, copy);

    let smallBlobPromise = this.getPdfBlobFromDoc(smallPdf);
    let bigBlobPromise = this.getPdfBlobFromDoc(bigPdf);

    return [smallBlobPromise, bigBlobPromise];
  },

  // generates the PDF document for post cards based on provided details
  getPostCardPDF: function (details, copy) {
    // stop processing if there were no details provided
    if (!details) {
      return new PDFDocument();
    }

    let helper = new pdfHelper(
      new PDFDocument({
        margins: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0
        }
      }),
      details.fonts,
      details.images
    );

    let providerImage = helper.getImage('provider');
    let pictureBackground = helper.getImage('pictureBackground');
    let logoImage = helper.getImage('logo');
    let qrCanvasBase64 = document
      .getElementById('qr-img')
      .toDataURL('image/png')
      .replace(/^data:image\/(png|jpg);base64,/, '');
    let qrImage = helper.base64ToArrayBuffer(qrCanvasBase64);
    //let textDimensions = { width: !!providerImage ? 200 : 266 };
    let textDimensions = { width: !!qrImage ? 133 : 266 };
    let fullWidthTextDimensions = { width: 226 };
    const padding = 24;
    //let xOffset = !!providerImage ? 78 : padding;

    // draws a single post card onto the PDF at a given x, y offset.
    // runs in the context of "helper"
    let postCard = function (x, y, column, row) {
      if (!!pictureBackground) {
        this.doc.lineWidth(0.5);
        this.doc.image(pictureBackground, x + padding + 2, y + padding + 5, {
          width: 65,
          height: 85
        });
      }
      if (!!providerImage) {
        this.doc.lineWidth(0.5);
        this.doc.image(providerImage, x + padding + 2, y + padding + 5, {
          width: 58.5,
          height: 78
        });
      }

      this.setFont('sansserif-bold');
      this.doc
        .fontSize(11)
        .fillColor(this.style.deepBlue50)
        .text(details.doctorName, x + 95, y + padding + 5, textDimensions);

      this.setFont('sansserif-regular');

      this.doc
        .moveDown(0.15)
        .fontSize(9)
        .fillColor(this.style.deepBlue50)
        .text(details.specialty, textDimensions);

      if (!!details.providerSummary.phoneNumber) {
        this.setFont('sansserif-bold');
        this.doc
          .moveDown(0.25)
          .fontSize(9)
          .fillColor(this.style.gray90)
          .text(details.providerSummary.phoneNumber, textDimensions);
      }

      this.setFont('sansserif-regular');
      //this.doc.moveDown(0.25).fontSize(9).fillColor(this.style.secondaryColor);

      if (!!details.practiceName) {
        this.doc.text(details.practiceName);
      }
      this.doc
        .text(details.providerSummary.address1, textDimensions)
        .text(details.providerSummary.cityState, textDimensions);

      // this.setFont('sansserif-bold');
      // this.doc
      //   .fontSize(9)
      //   .fillColor(this.style.secondaryColor)
      //   .text('Thank you for supporting our practice!', x + padding, y + padding + 127);

      // this.setFont('sansserif-regular');
      // this.doc.moveDown(0.5).text(copy['review-cards-cta-large-label'], fullWidthTextDimensions);

      // this.doc.moveDown(0.5).text('Review us at ', fullWidthTextDimensions);

      // this.setFont('sansserif-bold');
      // this.doc
      //   .moveTo(x + 78, y + 200)
      //   .lineTo(x + 247, y + 200)
      //   .lineWidth(3)
      //   .stroke('#efe6d4');

      // this.doc
      //   .fontSize(9.5)
      //   .fillColor(this.style.mainColor)
      //   .text(details.reviewUrl, x + 78, y + 193);

      // this.doc.image(logoImage, x + padding, y + 223, {
      //   height: 13.5
      // });

      this.doc.moveDown(0.5);
      this.doc
        .fontSize(7)
        .fillColor(this.style.gold70)
        .text(copy['review-cards-cta-small-label'], { width: 184 });

      this.doc
        .moveTo(x + padding + 2, y + padding + 110)
        .lineTo(x + padding + 247, y + padding + 110)
        .lineWidth(10)
        .stroke('#000050')
        .fillColor('#FFFFFF')
        .fontSize(9)
        .text(`Review us at ${details.reviewUrl}`, x + padding + 15, y + padding + 107);

      this.doc.image(logoImage, x + 108, y + padding + 123, {
        height: 13.5
      });

      this.doc.image(qrImage, x + padding + 202, y + padding + 5, {
        height: 45
      });

      this.doc
        .moveTo(x, y + 166.5)
        .lineTo(x + 266 + padding * 2, y + 166.5)
        .lineWidth(1)
        .stroke('#E3E3E3');

      this.doc.font('Helvetica-Bold');
      this.doc
        .fontSize(9)
        .fillColor(this.style.gray90)
        .text(copy['review-cards-appointment-label'], x + padding, y + 197.5);

      this.doc.font('Helvetica');
      this.doc
        .moveDown(1)
        .text('    MON       TUE       WED       THU       FRI       SAT       SUN');

      this.doc
        .font('Helvetica-Bold')
        .moveDown(1)
        .text('Date:_____________      Time: ____________  am  pm');

      let drawCircle = function (xPosition) {
        this.doc
          .circle(x + padding + 3.75 + xPosition, y + 221.5, 3.75)
          .lineWidth(0.5)
          .strokeColor(this.style.secondaryColor)
          .stroke();
      };

      drawCircle.apply(this, [0]); // MON
      drawCircle.apply(this, [38]); // TUE
      drawCircle.apply(this, [72.5]); // WED
      drawCircle.apply(this, [110]); // THU
      drawCircle.apply(this, [146]); // FRI
      drawCircle.apply(this, [178.5]); // SAT
      drawCircle.apply(this, [212]); // SUN

      if (!!details.providerSummary.phoneNumber) {
        this.doc.font('Helvetica');
        this.doc
          .moveDown(1)
          .fontSize(8)
          .text(`Please contact us directly with concerns: ${details.providerSummary.phoneNumber}`);
      }
    };

    // draw the cards onto the pdf document
    helper.drawCards(2, 2, 296, 306, 0, 0, true, postCard);

    return helper.doc;
  },

  // generates the PDF document for business cards based on provided details
  getBusinessCardPDF: function (details, copy) {
    // stop processing if there were no details provided
    if (!details) {
      return new PDFDocument();
    }

    let helper = new pdfHelper(
      new PDFDocument({
        margins: {
          top: 36,
          bottom: 36,
          left: 54,
          right: 54
        }
      }),
      details.fonts,
      details.images
    );

    // set the variables for rendering the business card
    let providerImage = helper.getImage('provider');
    let pictureBackground = helper.getImage('pictureBackground');
    let logoImage = helper.getImage('logo');
    let qrCanvasBase64 = document
      .getElementById('qr-img')
      .toDataURL('image/png')
      .replace(/^data:image\/(png|jpg);base64,/, '');
    let qrImage = helper.base64ToArrayBuffer(qrCanvasBase64);
    //let textDimensions = { width: !!providerImage ? 186 : 242 };
    let textDimensions = { width: !!qrImage ? 133 : 242 };
    const padding = 24;
    //let xOffset = !!providerImage ? 61 : xPadding;

    // draws a single business card onto the PDF at a given x, y offset.
    // runs in the context of "helper"
    let businessCard = function (x, y, column, row) {
      if (!!pictureBackground) {
        this.doc.lineWidth(0.5);
        this.doc.image(pictureBackground, x + padding + 2, y + 5, {
          width: 65,
          height: 85
        });
      }
      if (!!providerImage) {
        this.doc.lineWidth(0.5);
        this.doc.image(providerImage, x + padding + 2, y + 5, {
          width: 58.5,
          height: 78
        });
      }

      this.setFont('sansserif-bold');
      this.doc
        .fontSize(11)
        .fillColor(this.style.deepBlue50)
        .text(details.doctorName, x + padding + 72, y + 5, textDimensions);

      this.setFont('sansserif-regular');

      this.doc.fontSize(9).fillColor(this.style.deepBlue50).text(details.specialty, textDimensions);

      this.doc
        .moveDown(0.25)
        .fontSize(9)
        .fillColor(this.style.gray90)
        .text(details.providerSummary.phoneNumber, textDimensions);

      //this.doc.moveDown(0.5).fontSize(9).fillColor(this.style.gray90);

      if (!!details.practiceName) {
        this.doc.text(details.practiceName);
      }
      this.doc
        .text(details.providerSummary.address1, textDimensions)
        .text(details.providerSummary.cityState, textDimensions);

      this.doc.moveDown(0.25);
      this.doc
        .fontSize(7)
        .fillColor(this.style.gold70)
        .text(copy['review-cards-cta-small-label'], { width: 184 });

      this.doc
        .moveTo(x + padding + 2, y + 100)
        .lineTo(x + padding + 247, y + 100)
        .lineWidth(10)
        .stroke('#000050')
        .fillColor('#FFFFFF')
        .fontSize(9)
        .text(`Review us at ${details.reviewUrl}`, x + padding + 15, y + 97);

      this.doc.image(logoImage, x + padding + 95, y + 115, {
        height: 11
      });

      this.doc.image(qrImage, x + padding + 202, y + 5, {
        height: 45
      });
    };

    // render the cards onto the pdf document
    helper.drawCards(2, 5, 144, 306, 0, 50, false, businessCard);

    return helper.doc;
  },

  // convert the PDF document to a blob
  getPdfBlobFromDoc: function (doc) {
    let promise = new Promise(function (resolve, reject) {
      let stream = doc.pipe(blobStream());
      doc.end();
      stream.on('finish', function () {
        let blob = stream.toBlob('application/pdf');
        resolve(blob);
      });
    });

    return Promise.resolve(promise);
  }
};

export default pdfGenerator;
