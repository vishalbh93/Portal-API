/* eslint-disable */
let resourceDownloader = {
  // set the image response up for consumption by PDF kit
  convertToPdfImage: function (response) {
    let array = new Uint8Array(response);
    let chunkSize = 0x800;
    let index = 0;
    let decodedString = '';
    let slice;

    // chunk the response array into pieces
    while (index < array.length) {
      let end = Math.min(index + chunkSize, array.length);
      if (typeof array.slice === 'function') {
        slice = array.slice(index, end);
      } else if (typeof array.subarray === 'function') {
        slice = array.subarray(index, end);
      } else {
        break;
      }
      decodedString += String.fromCharCode.apply(null, slice);
      index += chunkSize;
    }

    // decode the array and store it into the output (buffer)
    let buffer = [];
    for (let i = 0, l = decodedString.length; i < l; i++) {
      buffer.push(decodedString.charCodeAt(i));
      buffer._isBuffer = true;
    }

    // make sure the image type is PNG
    buffer.toString = function () {
      return 'PNG';
    };

    // pdfkit requires this function to be in place
    buffer.readUInt16BE = function (offset, noAssert) {
      var len = this.length;
      if (offset >= len) return;

      var val = this[offset] << 8;
      if (offset + 1 < len) val |= this[offset + 1];
      return val;
    };

    return buffer;
  },

  downloadImage: function (image) {
    let ctx = this;
    image.processed = false;
    image.buffer = null;
    return new Promise(function (resolve, reject) {
      var request = new XMLHttpRequest();
      request.open('GET', image.url + '?d=' + Date.now(), true);
      request.responseType = 'arraybuffer';

      // when the image is done loading, conver the array to a image the PDF
      // can use and resolve the promise
      request.onload = function () {
        if (request.status == 200) {
          image.buffer = ctx.convertToPdfImage(request.response);
        } else {
          image.buffer = null;
        }

        resolve(image);
      };

      // the image request may fail but we do not want to fail
      // the promise if that is the case
      request.onerror = function () {
        image.buffer = null;
        image.processed = true;
        resolve(image);
      };

      // kick off the request
      request.send(null);
    });
  },

  // download a single font through an HTTP request
  // this will return a promise which resolves when the font's
  // download is complete success or failure
  downloadFont: function (font) {
    return new Promise(function (resolve, reject) {
      font.processed = false;
      font.buffer = null;

      // create an http request to load the font
      var request = new XMLHttpRequest();
      request.open('GET', font.url, true);
      request.responseType = 'arraybuffer';

      // when the font is done loading, resolve the promise
      request.onload = function () {
        font.buffer = null;
        font.processed = true;
        if (request.status === 200) {
          font.buffer = request.response;
        }
        resolve(font);
      };

      // the font request may fail but we do not want to fail
      // the promise if that is the case
      request.onerror = function () {
        font.buffer = null;
        font.processed = true;
        resolve(font);
      };

      // kick off the http request
      request.send(null);
    });
  },

  // download an array of images, returns an array of promises of images
  downloadImages: function (images) {
    let imagePromises = [];

    const needsCacheBusting =
      (/safari/i.test(navigator.userAgent) && !/chrome/i.test(navigator.userAgent)) ||
      /edge/i.test(navigator.userAgent);
    if (!!images) {
      for (var property in images) {
        if (images.hasOwnProperty(property) && !!images[property].url) {
          if (needsCacheBusting) {
            images[property].url = images[property].url + '?cacheBust=' + Date.now();
          }
          imagePromises.push(this.downloadImage(images[property]));
        }
      }
    }
    return imagePromises;
  },

  // download an array of fonts, returns an array of promises of fonts
  downloadFonts: function (fonts) {
    let fontPromises = [];
    if (!!fonts) {
      for (var property in fonts) {
        // make sure the font has a url
        if (fonts.hasOwnProperty(property) && !!fonts[property].url) {
          fontPromises.push(this.downloadFont(fonts[property]));
        }
      }
    }
    return fontPromises;
  },

  // download fonts and images through a promise chain
  //	returns a promise of an object {
  // 	fonts: [],
  // 	images: []
  // }
  downloadResources: function (fonts, images) {
    let fontPromises = this.downloadFonts(fonts);
    let imagePromises = this.downloadImages(images);

    return new Promise(function (resolve, reject) {
      let fontsDownloaded = false;
      let imagesDownloaded = false;

      // resolve the promise when both sets of files
      // have been downloaded
      let complete = function () {
        if (fontsDownloaded && imagesDownloaded) {
          resolve({ fonts, images });
        }
      };

      Promise.all(fontPromises).then(function () {
        fontsDownloaded = true;
        complete();
      });

      Promise.all(imagePromises).then(function () {
        imagesDownloaded = true;
        complete();
      });
    });
  }
};

export default resourceDownloader;
