import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

/* #region  Stylesheet */
import './_reviewReminderCard.less';
/* #endregion */

/* #region  Constant Imports */
import { CARD_TYPE_LARGE, CARD_TYPE_SMALL } from './HgComponents/constants';
/* #endregion */

/* #region  Helper Imports */
import * as service from '../../../utils/service';
import isEmpty from '../../../utils/validation/isEmpty';
import PdfGenerator from './HgComponents/util/PdfGenerator';
/* #endregion */

/* #region  Component Imports */
import LayoutA from '../../Common/Layouts/LayoutA';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import PrintableReviewCard from './PrintableReviewCard';
import { RadioGroup } from '../../FormComponents/RadioGroup';
/* #endregion */

const ReviewReminderCard = (props) => {
  /* #region  Store Selectors */
  const { patientExperienceInfo } = useSelector((state) => state.loadPatientExperienceData);
  /* #endregion */

  /* #region States  */
  const [providerInfo, setProviderInfo] = useState({});
  const [showLargeCard, setShowLargeCard] = useState(false);
  const [selectedCardType, setCardType] = useState(CARD_TYPE_SMALL);
  const [smallBlob, setSmallBlob] = useState(undefined);
  const [bigBlob, setBigBlob] = useState(undefined);
  /* #endregion */

  /* #region Constants  */
  const content = [
    { id: 1, text: `Review your practice information to make sure it's accurate.` },
    {
      id: 2,
      text: `Personalize the survey invitation card by uploading the provider's photo in Healthgrades Provider Portal.`
    },
    {
      id: 3,
      text: `Select <b>Small Cards</b> or <b>Large Cards</b>. Click the
        <b>Download as PDF</b> button to open and then print your select from the PDF.For best results, use a color printer and the appropriate Avery template.`
    },
    {
      id: 4,
      text: `Small cards measure 3.5" x 2" and print 10 to a page. Use Avery Template #5371, set right and left margins at 0.75" and top and bottom margins at 0.5".`
    },
    {
      id: 5,
      text: `Large cards measure 5.5" x 4.25" and print 4 to a page. Use Avery  Template #3380 with no margins. `
    }
  ];

  const cardsSize = [
    { Name: 'Small Card', Value: CARD_TYPE_SMALL, Show: true },
    { Name: 'Large Card', Value: CARD_TYPE_LARGE, Show: true }
  ];
  /* #endregion */

  /* #region  Event Handlers,Helper Functions */
  const radioGroupChangeHandler = (event) => {
    event.persist();
    let value = event.target.value;
    setCardType(value);
    setShowLargeCard(!showLargeCard);
  };

  const convertUrl = (url) => {
    if (url && typeof url === 'string') {
      return url.indexOf('testaws') !== -1 ? url.replace('testaws', 'www') : url;
    }
    return '';
  };

  const checkPracticeDuplicate = (practiceName, address) => {
    if (typeof practiceName === 'string' && typeof address === 'string') {
      const checkPracticeName = practiceName.toLowerCase();
      const checkAddress = address.toLowerCase();
      if (checkPracticeName === checkAddress) {
        return '';
      }
      const checkArray = checkAddress.split(' ');
      if (checkArray[0] === checkPracticeName.split(' ')[0]) {
        return '';
      }
      return practiceName;
    }
    return '';
  };

  const mutateDetails = (details) => {
    const practiceName = checkPracticeDuplicate(
      details.practiceName,
      details.providerSummary?.address1
    );
    const reviewUrl = convertUrl(details.reviewUrl);
    return { ...details, practiceName, reviewUrl };
  };

  const pdfGenerated = (sm, lg) => {
    setSmallBlob(sm);
    setBigBlob(lg);
  };

  const getCurrentBlob = () => (selectedCardType === CARD_TYPE_SMALL ? smallBlob : bigBlob);

  const saveCard = () => {
    let fileName = 'cards.pdf';
    //window.navigator.msSaveBlob(getCurrentBlob(), 'cards.pdf');
    var isIE = false || !!document.documentMode;
    if (isIE) {
      window.navigator.msSaveBlob(getCurrentBlob(), fileName);
    } else {
      var url = window.URL || window.webkitURL;
      var link = url.createObjectURL(getCurrentBlob());
      var a = document.createElement('a');
      a.setAttribute('download', fileName);
      a.setAttribute('href', link);
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };
  /* #endregion */

  /* #region  Effects */

  useEffect(() => {
    if (!isEmpty(providerInfo) && Object.values(providerInfo).length > 0) {
      const copy = {
        'review-cards-title': 'Review Cards Helpful Hints',
        'review-cards-business-label': 'Small Cards',
        'review-cards-post-label': 'Large Cards',
        'review-cards-download-label': 'Download PDF to print',
        'review-cards-helpful-hints':
          '<ul class="hintsList">\r\n<li>Review your practice information to make sure it\'s accurate.</li>\r\n<li><span>Personalize the survey invitation card by uploading the provider\'s photo in <a target="_blank" href="http://update.healthgrades.com/landing/claim?pwid=X9Y7G&pCID=reviewcards" onclick="s_objectID=\'http://update.healthgrades.com/landing/claim?pwid=X9Y7G&pCID=reviewcards\'; return this.s_oc?this.s_oc(e):true" title="Link: http://update.healthgrades.com/landing/claim?pwid=X9Y7G&pCID=reviewcards">Healthgrades Provider Portal</a>.</span></li>\r\n<li>Select <b>Small Cards</b> or&nbsp;<b>Large Cards</b>. Click the&nbsp;<b>Download as PDF</b> button to open and then print your select from the PDF. For best results, use a color printer and the appropriate Avery template.</li>\r\n<li class="business-cards"><span>Small cards measure 3.5" x 2" and print 10 to a page. Use Avery Template <a href="http://www.avery.com/avery/en_us/Products/Cards/Business-Cards/Laser-Business-Cards_05371.htm" target="_blank" onclick="s_objectID=&quot;http://www.avery.com/avery/en_us/Products/Cards/Business-Cards/Laser-Business-Cards_05371.htm_1&quot;;return this.s_oc?this.s_oc(e):true"> #5371</a>, set right and left margins at 0.75" and top and bottom margins at 0.5".</span></li>\r\n<li class="post-cards">\r\n<span>Large cards measure 5.5" x 4.25" and print 4 to a page. Use Avery Template <a href="http://www.avery.com/avery/en_us/Products/Cards/Postcards/Ink-Jet-Textured-Postcards_03380.htm" target="_blank" onclick="s_objectID=&quot;http://www.avery.com/avery/en_us/Products/Cards/Postcards/Ink-Jet-Textured-Postcards_03380.htm_1&quot;;return this.s_oc?this.s_oc(e):true" title="Link: http://www.avery.com/avery/en_us/Products/Cards/Postcards/Ink-Jet-Textured-Postcards_03380.htm">#3380</a> with no margins.\r\n</span>\r\n</li>\r\n</ul>',
        'review-cards-preview-label': 'Your PDF should have printable cards that look like this:',
        'review-cards-greeting-label': 'Thank you for visiting',
        'review-cards-cta-header': 'Your opinion matters to me.',
        'review-cards-cta-large-label':
          'Your feedback helps us improve and continue to deliver the highest quality care to you and other patients.',
        'review-cards-cta-small-label':
          'Thank you for supporting our practice! Your feedback helps us deliver the highest quality care.',
        'review-cards-appointment-label': 'Your next appointment:'
      };
      const formattedproviderInfoObj = {
        providerSummary: {
          address1: providerInfo.Address,
          address2: '',
          cityState: providerInfo.CityStateZip,
          code: providerInfo.ProviderId,
          displayName: '',
          fullName: providerInfo.DisplayFullName,
          phoneNumber: providerInfo.ProviderPhoneNumbers,
          possessiveName: '',
          primarySpecialty: providerInfo.PrimarySpecialty
        },
        doctorName: providerInfo.DisplayFullName,
        practiceName: '',
        specialty: providerInfo.PrimarySpecialty,
        reviewUrl: `testaws.healthgrades.com/review/${providerInfo.ProviderId}`,
        images: {
          provider: {
            url: providerInfo.ImageUrl
          },
          logo: {
            url: '//hg-cdn.s3.amazonaws.com/public3/images/logo-blue-full-2209-450.png'
          },
          pictureBackground: {
            url: '//hg-cdn.s3.amazonaws.com/img/pes/dots.png'
          }
        }
      };
      const details = mutateDetails(formattedproviderInfoObj);
      const generatePdf = (copy, details) => {
        Promise.resolve(PdfGenerator.generatePdfBlobs(copy, details)).then((blobs) =>
          pdfGenerated(blobs[0], blobs[1])
        );
      };
      generatePdf(copy, details);
    }
  }, [providerInfo]);

  useEffect(() => {
    if (!isEmpty(patientExperienceInfo.CurrentUserId)) {
      let pwid = JSON.parse(patientExperienceInfo.ProviderDetailsJson).Pwid;
      service._get(`/api/provider/providerOfficeData?providerId=${pwid}`).then((res) => {
        if (res.status === 200) {
          const { data } = res;
          const { ProviderOfficeInformation } = data;
          if (ProviderOfficeInformation != undefined && ProviderOfficeInformation != null) {
            let providerInformationObj = {
              ProviderId: pwid,
              DisplayFullName: ProviderOfficeInformation.DisplayName,
              ImageUrl: ProviderOfficeInformation.ImageSrc,
              PrimarySpecialty: ProviderOfficeInformation.SpecialityName || '',
              ProviderPhoneNumbers: ProviderOfficeInformation.PhoneNumber || '',
              Address: ProviderOfficeInformation.Address || '',
              CityStateZip: ProviderOfficeInformation.CityStateZip,
              FirstName: ProviderOfficeInformation.FirstName,
              LastName: ProviderOfficeInformation.LastName,
              Degree: ProviderOfficeInformation.Degree,
              Suffix: ProviderOfficeInformation.Suffix
            };
            setProviderInfo(providerInformationObj);
          } else setProviderInfo({});
        }
      });
    }
  }, []);
  /* #endregion */

  return (
    <LayoutA identifier='patient-experience-review-reminder-card' header='' footer=''>
      <div id='div-patient-experience-review-reminder-card-main'>
        <div id='div-review-reminder-card-section'>
          <section id='patient-experience-review-reminder-card-section'>
            <LayoutInfo
              identifier='patient-experience-review-reminder-card-layout'
              title='Review Reminder Cards'
              description=''>
              <div className='review-card-info'>
                <span>
                  These survey reminder cards are available for you to print right in your office or
                  send to your local printer - we provide a pdf with one click. You and your office
                  staff can give patients these cards to invite feedback. Make sure your photo is
                  uploaded to your profile first so it appears alongside your name, contact
                  information, and personal Healthgrades survey link.
                </span>
              </div>
              <div className='review-card-hints-list'>
                <span className='list-title'>Review Cards Helpful Hints</span>
                <ul>
                  {content.map((i, index) => (
                    <li key={index} dangerouslySetInnerHTML={{ __html: i.text }} />
                  ))}
                </ul>
              </div>
              <div className='review-card-size'>
                <div className='card-title'>Select Card</div>
                <div className='radio-with-card-size common-for-cards'>
                  <RadioGroup
                    radioGroup={cardsSize}
                    selectedOption={selectedCardType}
                    onChangeHandler={(event) => radioGroupChangeHandler(event)}
                  />
                </div>
                <div className='radio-with-card-dimentions'>
                  <div className='card-labels'>
                    <span>3.5" x 2" (prints 10 to a page) </span>
                    <span> 5.5" x 4.25" (prints 4 to a page)</span>
                  </div>
                </div>
              </div>
            </LayoutInfo>

            {Object.keys(providerInfo).length != 0 && (
              <div id='review-card-wrapper'>
                <div className='dashed-line-divider'>
                  <div className='img-divider-container'>
                    <hr />
                  </div>
                </div>

                <div className='printable-card-title'>
                  Your PDF should have printable cards that look like this:
                </div>

                <div className='review-card-container'>
                  <PrintableReviewCard providerInfo={providerInfo} showLargeCard={showLargeCard} />
                </div>
                <div className='btn-download-container'>
                  <button
                    disabled={smallBlob == undefined && bigBlob == undefined}
                    onClick={saveCard}>
                    Download PDF to print
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </LayoutA>
  );
};

export default ReviewReminderCard;
