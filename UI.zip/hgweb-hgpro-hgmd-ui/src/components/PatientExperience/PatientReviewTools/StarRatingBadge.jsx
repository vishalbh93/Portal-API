import React from 'react';

//------------------------- Stylesheet import -----------------------
import './_starRatingBadge.less';

//----------------------- Media imports ------------------------------
import ImgStarRatingBadge from './../../../assets/images/PatientExperience/Star-Rating-Badge.png';

const StarRatingBadge = ({ inHealthIframeSrc }) => {
  return (
    <section className='star-rating-badge-container'>
      <article className='star-rating-badge-wrapper'>
        <h2>Star Ratings Badge</h2>
        <div className='content-wrapper'>
          <img src={ImgStarRatingBadge} alt='Star Rating Badge' />
          <p>
            You can add the direct link to your Healthgrades' Survey right to your practice website
            with your choice of three badge options. We offer two badge versions that will display
            your up-to-date Healthgrades star rating and a third that does not display the star
            rating. All three options link your patients directly to your Healthgrades survey.
          </p>
        </div>
      </article>
      <article className='star-rating-badge-wrapper'>
        <h4>Click the badge of your choice for your custom html code.</h4>
        <div className='get-code-wrapper'>
          <div className='iframe-card-container'>
            <iframe
              id='badges-containter-frame'
              src={inHealthIframeSrc}
              frameBorder='0'
              title='badge container for patient experience resource'
            />
          </div>
        </div>
      </article>
    </section>
  );
};

export default StarRatingBadge;
