import React, { useState } from 'react';

//----------------------- Stylesheet imports -------------------------
import './_reviewReminderLink.less';

//----------------------- Component imports --------------------------
import Toast from '../../Common/Toast/Toast';

//----------------------- Media imports ------------------------------
import ImgReviewReminderLink from './../../../assets/images/PatientExperience/Review-Reminder-Link.png';
import ImgReviewReminderLinkMobile from './../../../assets/images/PatientExperience/Review-Reminder-Link-mobile.svg';

const ReviewReminderLink = (props) => {
  //-------------------- props destructuring -------------------------
  const { _currentSection, providerId } = props;

  //----------------------- States -----------------------------------
  const [notifyProperties, setNotifyProperties] = useState([]);

  //----------------------- functions --------------------------------
  const copyClickHandler = () => {
    const reviewLinkText = `https://www.healthgrades.com/review/${providerId}?CID=18pslMMP0001`;
    navigator.clipboard.writeText(reviewLinkText);
    toaster.Success('Link copied!');
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //----------------------- JSX code ---------------------------------
  return (
    <>
      <section className='review-reminder-link-container'>
        <article className='review-reminder-link-article'>
          <h2>Review Reminder Link</h2>
          <div className='custom-link-wrapper'>
            <img
              src={window.innerWidth >= 768 ? ImgReviewReminderLink : ImgReviewReminderLinkMobile}
              alt='Review Reminder Mail'
            />
            <button onClick={copyClickHandler}>Copy your Custom Link</button>
          </div>
          <p>
            The Patient Satisfaction Review Link is a custom, mobile-friendly link you can copy and
            paste into digital communications (e.g., email) with your patients. The link sends
            patients directly to your Patient Satisfaction Survey on healthgrades.com
          </p>
        </article>
      </section>
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </>
  );
};

export default ReviewReminderLink;
