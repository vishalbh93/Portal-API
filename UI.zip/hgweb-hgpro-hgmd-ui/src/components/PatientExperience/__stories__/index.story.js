import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../.storybook/store';

import Index from './../Index';
import OverView from '../Overview/OverView';

//------------------------ Index ----------------------
const name = 'story';
const providerInformationObj = {
  informationObj: {
    displayName: 'Dr. Ciccotelli, MD',
    speciality: 'Orthopedic Surgeon',
    ratingInfo: {
      stars: 4,
      ratings: 26
    },
    lastUpdated: null
  },
  imageObj: {
    id: 'story-test',
    className: 'provider-image',
    gender: 'F',
    imageSrc: 'https://photos.healthgrades.com/img/prov/y/7/l/y7lh58z_w90h120_vSJ_Kp246u.jpg',
    name: 'Doctor Name',
    size: 'xl'
  }
};

const patientExperienceInfo = {
  patientReviewsJson: {
    ProviderId: '1QQMYRUO00',
    FlagReasons: [
      {
        Id: 203,
        Desc: 'Inappropriate content',
        Selected: false
      },
      {
        Id: 204,
        Desc: 'Privacy concerns',
        Selected: false
      },
      {
        Id: 205,
        Desc: 'Other',
        Selected: false
      }
    ],
    MostRecentDate: '0001-01-01T00:00:00',
    ShowCommentsSuppressedMessage: false,
    Comments: [
      {
        ProviderId: 'XYN3PMJ',
        ProviderName: 'Debbie A Demo, MD',
        CommentId: '515c4ac1-6867-4f3f-b8ca-e4568fef897d',
        SurveyCommentId: 6676815,
        Comment: 'Staff was nice, but I felt rushed',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'Jake',
        DateDisplay: 'Sep 30, 2022',
        IsNew: false,
        RatingClass: 'fill-to-8',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Demo?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Demo to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-8',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Demo',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'X3R24',
        ProviderName: 'Glorian Test Demo, ADDC',
        CommentId: '3a2ad794-2122-4ad4-9435-662dcbe8fd18',
        SurveyCommentId: 6674196,
        Comment: 'great to be taken of',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'Jeffery',
        DateDisplay: 'Aug 1, 2022',
        IsNew: false,
        RatingClass: 'fill-to-8',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Test Demo?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Test Demo to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-8',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Test Demo',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'YD4NR',
        ProviderName: 'Andrew Peck, MD',
        CommentId: 'cfa69db5-b06b-4484-a62c-7c7cce92d335',
        SurveyCommentId: 6439507,
        Comment: 'No waiting time.    Staff was professional.   Doctor was thorough and friendly ',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: '',
        DateDisplay: 'Mar 31, 2022',
        IsNew: false,
        RatingClass: 'fill-to-10',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: true,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response:
          'Thank you for sharing your positive experience with Dr. Peck and his staff. We love hearing your feedback.',
        ResponseUserName: 'Emily Frederick',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Peck?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Peck to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Office environment, cleanliness, comfort, etc.',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: false,
                  Text: 'Total wait time (waiting & exam rooms)',
                  Answer: 'Under 10 minutes',
                  RatingClass: '',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Peck',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'YD4NR',
        ProviderName: 'Andrew Peck, MD',
        CommentId: '8f299d10-8f25-4e98-bbaa-6ea015ca94f8',
        SurveyCommentId: 6434706,
        Comment:
          'Saw Dr. Peck and as usual he is great at what he does.  If I have questions and I do alot of the time he always has the answers.  I recommend him to anyone I know having kidney issues. ',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'John Staniszewski',
        DateDisplay: 'Mar 30, 2022',
        IsNew: false,
        RatingClass: 'fill-to-2',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: true,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response:
          'Thank you so much for taking the time to write a review John. We are glad to hear your visit with Dr. Peck was a positive one. Can you please call our office manager at 847-439-8780 to discuss any issues or concerns you had as your overall review of a "one star" is less than the service that we strive to provide you. Thank you again, we appreciate your feedback.',
        ResponseUserName: 'Emily Frederick',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Peck?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Peck to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Office environment, cleanliness, comfort, etc.',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: false,
                  Text: 'Total wait time (waiting & exam rooms)',
                  Answer: 'Under 10 minutes',
                  RatingClass: '',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Peck',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: '2XXDS',
        ProviderName: 'Mark Test, M',
        CommentId: '3141265e-b5ab-485a-83a6-962a688b6a4f',
        SurveyCommentId: 6281317,
        Comment:
          'Doctor listened to all my concerns instead of rushing me out of the office!  Happy with the service',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'Christofer',
        DateDisplay: 'Feb 15, 2022',
        IsNew: false,
        RatingClass: 'fill-to-10',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Demo IV?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Demo IV to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Demo IV',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'XYN3PMJ',
        ProviderName: 'Debbie A Demo, MD',
        CommentId: 'fe666099-0f0b-4aac-957d-9b48014d6e17',
        SurveyCommentId: 6180357,
        Comment: 'BAD DOCTOR DONT GO HERE THERE DANGEROUS',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'DONT GO HERE',
        DateDisplay: 'Jan 12, 2022',
        IsNew: false,
        RatingClass: 'fill-to-2',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Demo?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Demo to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Office environment, cleanliness, comfort, etc.',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: false,
                  Text: 'Total wait time (waiting & exam rooms)',
                  Answer: 'Over 45 minutes',
                  RatingClass: '',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Demo',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'XYN3PMJ',
        ProviderName: 'Debbie A Demo, MD',
        CommentId: 'cf1f7d42-7626-4e78-a16e-68fd542aece6',
        SurveyCommentId: 6180352,
        Comment: 'Terrible doctor fired me for no good reason DO NOT GO HERE',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'DONT GO HERE',
        DateDisplay: 'Jan 12, 2022',
        IsNew: false,
        RatingClass: 'fill-to-2',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Demo?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Demo to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Office environment, cleanliness, comfort, etc.',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: false,
                  Text: 'Total wait time (waiting & exam rooms)',
                  Answer: 'Over 45 minutes',
                  RatingClass: '',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Demo',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'YBHBR',
        ProviderName: 'Panagiotis Vlagopoulos, MD',
        CommentId: 'b28a7359-9c30-45b3-a845-3c867118fa0f',
        SurveyCommentId: 6129939,
        Comment:
          'Never got to see him, when I went for my initial appointment, they said he was on vacation. I tried calling the office and and always got the automated message.',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: '',
        DateDisplay: 'Dec 21, 2021',
        IsNew: false,
        RatingClass: 'fill-to-6',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Vlagopoulos?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Vlagopoulos to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-6',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'XYN3PMJ',
        ProviderName: 'Debbie A Demo, MD',
        CommentId: '134629a2-0122-428c-98dc-16347ae4b9f5',
        SurveyCommentId: 6014031,
        Comment: 'great service!',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: 'Carol',
        DateDisplay: 'Nov 9, 2021',
        IsNew: false,
        RatingClass: 'fill-to-10',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Demo?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Demo to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about the office & staff',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Ease of scheduling urgent appointments',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Office environment, cleanliness, comfort, etc.',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Staff friendliness and courteousness',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: false,
                  Text: 'Total wait time (waiting & exam rooms)',
                  Answer: 'Under 10 minutes',
                  RatingClass: '',
                  IsOverall: false
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Demo',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider listens and answers questions',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'Spends appropriate amount of time with patients',
                  Answer: null,
                  RatingClass: 'fill-to-10',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      },
      {
        ProviderId: 'YDKLG',
        ProviderName: 'Harnath Singh, MD',
        CommentId: 'da06b4b9-a08c-4740-a6c7-fe88f6a48fdc',
        SurveyCommentId: 6006000,
        Comment:
          'He saw my mother in the hospital. She went in weighing 116 pounds and 5 days later came home and weighed 140. All fluid (24#). Her legs are horribly swollen. In an attempt to jump start a failing kidney he created a worse problem. ',
        IsFlagged: false,
        FlagDisabled: false,
        ByLine: '',
        DateDisplay: 'Nov 6, 2021',
        IsNew: false,
        RatingClass: 'fill-to-2',
        VerifiedPatient: false,
        ShowDetails: false,
        HasResponse: false,
        HelpfulCount: 0,
        NotHelpfulCount: 0,
        Response: '',
        ResponseUserName: '',
        AllowResponseEdit: false,
        SurveyResponse: {
          Groups: [
            {
              GroupText: 'How was your experience with Dr. Singh?',
              IsOverall: true,
              Questions: [
                {
                  IsStars: true,
                  Text: 'Likelihood of recommending Dr. Singh to family and friends',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: true
                }
              ]
            },
            {
              GroupText: 'Tell us about Dr. Singh',
              IsOverall: false,
              Questions: [
                {
                  IsStars: true,
                  Text: "Level of trust in provider's decisions",
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                },
                {
                  IsStars: true,
                  Text: 'How well provider explains medical condition(s)',
                  Answer: null,
                  RatingClass: 'fill-to-2',
                  IsOverall: false
                }
              ]
            }
          ]
        }
      }
    ],
    TotalPages: 19,
    TotalCount: 181,
    NewCount: 0,
    PatientSatisfactionLink: '/patientexperience/resources/1QQMYRUO00',
    ShowResponse: true,
    VideoSource: '//healthguides.healthgrades.com/video/00000155-db96-d5b7-a977-ffbea01b0000',
    MultipleProviders: true
  }
};

storiesOf('Patient Experience|Index', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Index', () => <Index name={name} providerInformationObj={providerInformationObj} />)
  .add('Overview-component', () => <OverView />);
