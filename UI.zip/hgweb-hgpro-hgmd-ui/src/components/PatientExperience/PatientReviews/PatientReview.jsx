import React, { useState, Fragment, useEffect } from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../../Common/Layouts/LayoutA';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import PaginationUI from '../../Pagination/Pagination';
import ReviewsComment from './ReviewsComment';
import Button from '@hg/joy/src/components/Button';
import Spinner from '../../Spinner/Spinner';
import Toast from '../../Common/Toast/Toast';
import ReviewsCommentFlagPopUp from './ReviewsCommentFlagPopUp';
import DropDown from '../../ProviderProfile/PracticeAndLocation/DropDown/DropDown';

//service
import * as service from '../../../utils/service';

//styling imports
import './_patientReview.less';

const PatientReview = (props) => {
  const {userFlag, patientReviewsJson } = props;

  //States
  const [page, setPage] = useState(1);
  const [expanded, setExpanded] = useState(false);
  const [sortBy, setSortBy] = useState(['date', 'desc']);
  const [recentSelected, setRecentSelected] = useState(false);
  const [highestSelected, setHighestSelected] = useState(false);
  const [lowesetSelected, setLowestSelected] = useState(false);
  const [oldestSelected, setOldestSelected] = useState(false);
  const [highestNameSelected, setHighestNameSelected] = useState(false);
  const [lowesetNameSelected, setLowestNameSelected] = useState(false);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showFlagModal, toggleFlagModal] = useState(false);
  const [comment, setComment] = useState();
  const [flagReasons, setFlagReasons] = useState([]);

  const buttonsList = [
    { Id: 'date|desc', Text: userFlag ? 'Most Recent':'Recent' },
    { Id: 'date|asc', Text: 'Oldest' },
    { Id: 'score|desc', Text: userFlag?'Highest Rated':'Highest' },
    { Id: 'score|asc', Text: userFlag?'Lowest Rated':'Lowest' },
    userFlag && ({ Id: 'name|asc', Text: 'Name A-Z'}),
    userFlag && ({ Id: 'name|desc', Text: 'Name Z-A'})
  ];

  const width = window.innerWidth;

  const [initialPatientReviewsObj, UpdatePatientReviewsObj] = useState(
    JSON.parse(patientReviewsJson)
  );

  const patientReviewsCount = initialPatientReviewsObj.TotalCount;

  const sortList = [
    { Id: 'date|desc', Value: 'Recent' },
    { Id: 'date|asc', Value: 'Oldest' },
    { Id: 'score|desc', Value: 'Highest' },
    { Id: 'score|asc', Value: 'Lowest' }
  ];

  //Handler

  const showFullText = () => {
    setExpanded(true);
  };

  const showLessText = () => {
    setExpanded(false);
  };

  const onSortByRecentClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(true);
    setHighestSelected(false);
    setLowestSelected(false);
    setOldestSelected(false);
    setHighestNameSelected(false);
    setLowestNameSelected(false);
  };

  const onSortByHighestClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(false);
    setHighestSelected(true);
    setLowestSelected(false);
    setOldestSelected(false);
    setHighestNameSelected(false);
    setLowestNameSelected(false);
  };

  const onSortByOldestClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(false);
    setHighestSelected(false);
    setLowestSelected(false);
    setOldestSelected(true);
    setHighestNameSelected(false);
    setLowestNameSelected(false);
  };

  const onSortByLowestClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(false);
    setHighestSelected(false);
    setLowestSelected(true);
    setOldestSelected(false);
    setHighestNameSelected(false);
    setLowestNameSelected(false);
  };

  const onSortByNameHighestClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(false);
    setHighestSelected(false);
    setLowestSelected(false);
    setOldestSelected(false);
    setHighestNameSelected(true);
    setLowestNameSelected(false);
  };

  const onSortByNameLowestClick = (arr) => {
    setSortBy(arr);
    setRecentSelected(false);
    setHighestSelected(false);
    setLowestSelected(false);
    setOldestSelected(false);
    setHighestNameSelected(false);
    setLowestNameSelected(true);
  };

  const closeModal = () => {
    toggleFlagModal(false);
  };

  const showFlagModalPopUp = (isShowFlagModal, commentDetails, flagReasons) => {
    toggleFlagModal(isShowFlagModal);
    setComment(commentDetails);
    setFlagReasons(flagReasons);
  };

  const loadPatientReviews = (pageNumber) => {
    service
      ._get(
        `/api/patientexperience/reviews?page=${pageNumber}&providerId=${initialPatientReviewsObj.ProviderId}&singleProvider=${userFlag?'false':'true'}&sortby=${sortBy[0]}&sortorder=${sortBy[1]}`,
        true
      )
      .then((res) => {
        if (res.status == 200) {
          let data = res.data;
          UpdatePatientReviewsObj(data);
        }
      })
      .catch((err) => {
        toaster.Error(err.response.data.ErrorMessage);
      });
  };

  const addOrDeleteCommentReply = async (request) => {
    await service
      ._post(`/api/patientexperience/response`, request, true)
      .then((res) => {
        if (res.status == 200) {
          let tmpComments = initialPatientReviewsObj.Comments;

          let _tempPatientReviewsInfo = {
            ...initialPatientReviewsObj,
            FlagReasons: initialPatientReviewsObj.FlagReasons,
            MostRecentDate: initialPatientReviewsObj.MostRecentDate,
            ShowCommentsSuppressedMessage: initialPatientReviewsObj.ShowCommentsSuppressedMessage,
            Comments: tmpComments.map((comment) => {
              return {
                ...comment,
                Response:
                  comment.SurveyCommentId == request.SurveyCommentId
                    ? request.RemoveResponse == true
                      ? ''
                      : request.Response
                    : comment.Response
              };
            }),
            TotalPages: initialPatientReviewsObj.TotalPages,
            TotalCount: initialPatientReviewsObj.TotalCount,
            NewCount: initialPatientReviewsObj.NewCount,
            PatientSatisfactionLink: initialPatientReviewsObj.PatientSatisfactionLink,
            ShowResponse: initialPatientReviewsObj.ShowResponse,
            VideoSource: initialPatientReviewsObj.VideoSource,
            MultipleProviders: initialPatientReviewsObj.MultipleProviders
          };
          UpdatePatientReviewsObj(_tempPatientReviewsInfo);
          if (request.RemoveResponse == true) toaster.Success('Success');
          else toaster.Success(`${userFlag?'Thank you for submitting your reply. It may take up to 72 hours to display your response on profile'
          :'Thank you for replying to your Patient comment!'}`);
          return true;
        }
      })
      .catch((err) => {
        toaster.Error(err.response.data);
        throw new Error(false);
      });
  };

  const addFlagHandler = (request) => {
    service
      ._post(`/api/patientexperience/flagcomment`, request, true)
      .then((res) => {
        if (res.status == 200) {
          let tmpComments = initialPatientReviewsObj.Comments;
          let _tempPatientReviewsInfo = {
            ...initialPatientReviewsObj,
            FlagReasons: initialPatientReviewsObj.FlagReasons,
            MostRecentDate: initialPatientReviewsObj.MostRecentDate,
            ShowCommentsSuppressedMessage: initialPatientReviewsObj.ShowCommentsSuppressedMessage,
            Comments: tmpComments.map((comment) => {
              return {
                ...comment,
                IsFlagged: comment.CommentId == request.CommentId ? true : comment.IsFlagged
              };
            }),
            TotalPages: initialPatientReviewsObj.TotalPages,
            TotalCount: initialPatientReviewsObj.TotalCount,
            NewCount: initialPatientReviewsObj.NewCount,
            PatientSatisfactionLink: initialPatientReviewsObj.PatientSatisfactionLink,
            ShowResponse: initialPatientReviewsObj.ShowResponse,
            VideoSource: initialPatientReviewsObj.VideoSource,
            MultipleProviders: initialPatientReviewsObj.MultipleProviders
          };
          UpdatePatientReviewsObj(_tempPatientReviewsInfo);
          toaster.Success('Success');
        }
      })
      .catch((err) => {
        toaster.Error(err.response.data.ErrorMessage);
      });
  };

  const onPageChange = (pageNumber) => {
    setPage(pageNumber);
    loadPatientReviews(pageNumber);
    if (sortBy[0] == 'score' && sortBy[1] == 'asc') {
      setRecentSelected(false);
      setHighestSelected(false);
      setLowestSelected(true);
      setOldestSelected(false);
    } else if (sortBy[0] == 'score' && sortBy[1] == 'desc') {
      setRecentSelected(false);
      setHighestSelected(true);
      setLowestSelected(false);
      setOldestSelected(false);
    } else if (sortBy[0] == 'date' && sortBy[1] == 'asc') {
      setRecentSelected(false);
      setHighestSelected(false);
      setLowestSelected(false);
      setOldestSelected(true);
    } else if (sortBy[0] == 'date' && sortBy[1] == 'desc') {
      setRecentSelected(true);
      setHighestSelected(false);
      setLowestSelected(false);
      setOldestSelected(false);
    }else if (sortBy[0] == 'name' && sortBy[1] == 'asc') {
      setRecentSelected(true);
      setHighestSelected(false);
      setLowestSelected(false);
      setOldestSelected(false);
    }else if (sortBy[0] == 'name' && sortBy[1] == 'desc') {
      setRecentSelected(true);
      setHighestSelected(false);
      setLowestSelected(false);
      setOldestSelected(false);
    }
  };

  const onStateDropDownSelectHandler = (item) => {
    let txt = item.Text;
    if (txt == 'Lowest' || txt == 'Lowest Rated') {
      onSortByLowestClick(['score', 'asc']);
    } else if (txt == 'Highest' || txt == 'Highest Rated') {
      onSortByHighestClick(['score', 'desc']);
    } else if (txt == 'Oldest') {
      onSortByOldestClick(['date', 'asc']);
    } else if(txt == 'Recent' || txt == 'Most Recent'){
      onSortByRecentClick(['date', 'desc']);
    } else if(txt == 'Name A-Z'){
      onSortByNameHighestClick(['name', 'asc']);
    } else {
      onSortByNameLowestClick(['name', 'desc']);
    }
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //Effects
  useEffect(() => {
    setRecentSelected(true);
  }, []);

  useEffect(() => {
    loadPatientReviews(1);
    setPage(1);
  }, [sortBy]);

  useEffect(() => {}, [initialPatientReviewsObj]);

  return (
    <Fragment>
      <LayoutA identifier='patient-experience-patient-review' header='' footer=''>
        <div id='div-patient-experience-patient-review-main'>
          <div id='div-patient-review-section'>
            <section id='patient-experience-patient-review-section'>
              <LayoutInfo
                identifier='patient-experience-patient-review-layout'
                title= {!userFlag? 'Patient Reviews': ''}
                description=''
                bullets={{
                  title: 'Missing Fields',
                  data: []
                }}>
                <div>
                  <span>
                    Millions of potential patients on healthgrades.com cite reviews as a top factor
                    when considering the right doctor for their right care. The reviews below
                    reflect your reputation on healthgrades.com. In addition to the review, ratings
                    detail is also available.
                    {!expanded && <a onClick={showFullText}> Read More</a>}
                  </span>
                </div>
                {expanded && (
                  <div id='full-description'>
                    {' '}
                    <span>
                      Keep in mind Healthgrades is a community-driven site. All comments, both from
                      patients and providers, are filtered for inappropriate content prior to being
                      published. We remove reviews we believe violate our
                      <a
                        className='toggle-links'
                        href='https://www.healthgrades.com/content/editorial-policy'
                        target='_blank'>
                        {' '}
                        Editorial Policy
                      </a>
                      .
                    </span>
                    <span>
                      If there is a review you feel violates the Healthgrades Editorial Policy,
                      please flag the review and our editorial team will respond with feedback,
                      which may take several days.
                    </span>
                    <span>
                      Please{' '}
                      <a href='/contactus' target='_blank'>
                        contact customer service
                      </a>{' '}
                      with any questions.
                      <a onClick={showLessText}> Less</a>
                    </span>
                  </div>
                )}
                {initialPatientReviewsObj && initialPatientReviewsObj.Comments.length > 0 && (
                  <>
                    <div
                      className={`div-patient-review-sortby ${width < 768 ? 'sortby-mobile' : ''}`}>
                      {width >= 768 ? (
                        <>
                          <span className='span-sort-by'>Sort By :</span>
                          <Button
                            id={'button-patient-review-sortby-recent'}
                            text={userFlag? 'Most Recent':'Recent'}
                            disabled={false}
                            className={userFlag? 'button-patient-review-sortby-new' :`button-patient-review-sortby ${
                              recentSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByRecentClick(['date', 'desc']);
                            }}
                          />
                          <Button
                            id='button-patient-review-sortby-oldest'
                            text='Oldest'
                            disabled={false}
                            className={`button-patient-review-sortby ${
                              oldestSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByOldestClick(['date', 'asc']);
                            }}
                          />
                          <Button
                            id={'button-patient-review-sortby-highest'}
                            text={userFlag? 'Highest Rated':'Highest'}
                            disabled={false}
                            className={userFlag? 'button-patient-review-sortby-new' :`button-patient-review-sortby ${
                              highestSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByHighestClick(['score', 'desc']);
                            }}
                          />
                          <Button
                            id={'button-patient-review-sortby-lowest'}
                            text={userFlag?'Lowest Rated':'Lowest'}
                            className={userFlag? 'button-patient-review-sortby-new' :`button-patient-review-sortby ${
                              lowesetSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByLowestClick(['score', 'asc']);
                            }}
                          />
                          { userFlag && <>
                            <Button
                            id='button-patient-review-sortby-highest-name'
                            text='Name A-Z'
                            className={userFlag? 'button-patient-review-sortby-new' :`button-patient-review-sortby ${
                              highestNameSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByNameHighestClick(['name', 'asc']);
                            }}
                          />
                          <Button
                            id='button-patient-review-sortby-lowest-name'
                            text='Name Z- A'
                            className={userFlag? 'button-patient-review-sortby-new' :`button-patient-review-sortby ${
                              lowesetNameSelected ? 'selected' : 'unselected'
                            }`}
                            size='lg'
                            style='ghost'
                            onClick={() => {
                              onSortByNameLowestClick(['name', 'desc']);
                            }}
                          />
                          </>
                          }
                        </>
                      ) : (
                        <>
                          <label className='dropdown-label'>Sort by</label>
                          <DropDown
                            id={`office-location-state-${recentSelected}`}
                            list={buttonsList}
                            selectedName={
                              recentSelected
                                ? userFlag? 'Most Recent': 'Recent'
                                : oldestSelected
                                ? 'Oldest'
                                : highestSelected
                                ? userFlag?'Highest Rated':'Highest' 
                                :lowesetSelected
                                ? userFlag?'Lowest Rated':'Lowest'
                                : highestNameSelected
                                ? 'Name A-Z'
                                : 'Name Z-A'
                            }
                            positionFixed={true}
                            onDropDownSelectHandler={onStateDropDownSelectHandler}
                          />
                        </>
                      )}
                    </div>
                    {initialPatientReviewsObj.Comments.map((comment, index) => (
                      <ReviewsComment
                        commentDetails={comment}
                        key={index}
                        flagReasons={initialPatientReviewsObj.FlagReasons}
                        addOrDeleteCommentReply={addOrDeleteCommentReply}
                        showFlagModalPopUp={showFlagModalPopUp}
                        userFlag={userFlag}  
                        showbutton={true}                     
                      />
                    ))}
                  </>
                )}
              </LayoutInfo>
            </section>
            {patientReviewsCount > 10 && (
              <div className='joy-pagination'>
                <PaginationUI
                  recordsFound={patientReviewsCount}
                  onPageChange={onPageChange}
                  recordsPerPage={10}
                  showJoyPagination={true}
                  showPerPage={false}
                  currentPage={page}
                />
              </div>
            )}
          </div>
        </div>
        <ReviewsCommentFlagPopUp
          showModalPopUp={showFlagModal}
          commentDetails={comment}
          flagReasons={flagReasons}
          closeModal={closeModal}
          addFlag={addFlagHandler}
          userFlag={userFlag}
        />
      </LayoutA>
      <>
        <Toast
          toastList={notifyProperties}
          position={`bottom-center ${userFlag? `review-notification-${width < 768 ? 'tost-mobile' : 'toast-desktop'}`: '' }`}
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </Fragment>
  );
};
PatientReview.propTypes = {
  userFlag : PropTypes.bool
};
PatientReview.defaultProps = {
  userFlag : false
}
export default PatientReview;
