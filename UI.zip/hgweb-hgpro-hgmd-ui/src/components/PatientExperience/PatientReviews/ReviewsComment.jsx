import React, { useState, useRef, Fragment, useEffect } from 'react';
import PropTypes from 'prop-types';

//components import
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import Cta from '../../Common/Form/CTA/Cta';
import Toast from '../../Common/Toast/Toast';
import TextArea from '../Common/TextArea/TextArea';

//svg imports
import FlagIcon from '../../../assets/images/PatientExperience/Flag.svg';
import ReplyIcon from '../../../assets/images/PatientExperience/Reply.svg';
import SelectedStar from '../../../assets/images/PatientExperience/Selected-Star.svg';
import NonSelectedStar from '../../../assets/images/PatientExperience/Non-Selected-Star.svg';
import svgMenudots from '../../../assets/images/PatientExperience/linear-vertical-icon.svg';

//styling imports
import StarRating from '@hg/joy/src/components/StarRating';
import './_reviewsComment.less';
import isEmpty from '../../../utils/validation/isEmpty';

//lodash
import _ from 'lodash';

const ReviewsComment = (props) => {
  const { commentDetails, flagReasons, showbutton, userFlag, showStars = true} = props;
  const [expanded, setExpanded] = useState(false);
  const [isReplied, setIsReplied] = useState(false);
  const [newContext, setNewContext] = useState(
    commentDetails.Response != undefined ? commentDetails.Response : ''
  );

  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showFlagModal, toggleFlagModal] = useState(false);
  const [showButtons, setShowButtons] = useState(showbutton);
  const [showEditDeleteObj, setShowEditDeleteObj] = useState({ show: false, showFor: '' });
  const [showEditRemoveReplyObj, setShowEditRemoveReplyObj] = useState({
    show: false,
    showFor: ''
  });
  const _sideMenu = useRef(null);
  const _saveEditReplyMenu = useRef(null);
  const [replyValid, setReplyValid] = useState(true);
  const [_translateTxt, setTranslateTxt] = useState(true);
  const [isShowMoreComment, setIsShowMoreComment] = useState(false);
  const [surveyResponse, setSurveyResponse] = useState(
    !_.isEmpty(commentDetails.SurveyResponse)
      ? commentDetails.SurveyResponse.Groups.filter((x) => !x.IsOverall)
      : []
  );
  const isMobileView = window.innerWidth <= 768 ? true : false;

  const onReplyClickHandler = (responseText) => {
    setIsReplied(true);
    setNewContext(responseText);
  };

  const cancelHandler = () => {
    setIsReplied(false);
  };

  const onAddReplyHandler = async (providerId, commentId, replytext, type) => {
    let removeResponse = type == 'add' ? false : true;
    let request = {
      ProviderId: providerId,
      SurveyCommentId: commentId,
      Response: replytext,
      RemoveResponse: removeResponse
    };
    //replyValid ? props.addOrDeleteCommentReply(request) : null;
    if (replyValid) {
      props
        .addOrDeleteCommentReply(request)
        .then((res) => {
          setIsReplied(false);
          setReplyValid(true);
        })
        .catch((res) => {});
    }
    if (type == 'add') {
      setShowButtons(true);
    }
  };

  const onAddFlagHandler = (request) => {
    props.addFlag(request);
  };

  const changeContentHandler = (content) => {
    if (content != undefined) {
      setNewContext(content);
    }
  };

  const closeModal = () => {
    toggleFlagModal(false);
  };

  const showFlagModalPopup = (commentDetails, flagReasons) => {
    props.showFlagModalPopUp(true, commentDetails, flagReasons);
  };

  const handleClickOutside = (event) => {
    if (_sideMenu.current && !_sideMenu.current.contains(event.target)) {
      setShowEditDeleteObj({ ...showEditDeleteObj, show: false });
    }
    if (_saveEditReplyMenu.current && !_saveEditReplyMenu.current.contains(event.target)) {
      setShowEditRemoveReplyObj({ ...showEditRemoveReplyObj, show: false });
    }
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };
  const ratingClass = Number(commentDetails.RatingClass.substring(8, 10));

  const textTtranslatedHandler = (e) => {
    e.preventDefault();
    setTranslateTxt(!_translateTxt);
  };

  const getReviewComment = (comment, flag) => {
    var reviewComment = '';
    if (flag) {
      reviewComment = comment;
    } else {
      reviewComment = comment.slice(0, 350);
    }
    return <span>{reviewComment}</span>;
  };

  const onClickShowComment = (changeFlag) => {
    setIsShowMoreComment(!changeFlag);
  };

  const displaySurveyData = (value) => {
    let overallRate = getRatingCount(value.RatingClass);
    return (
      <div className='rating-section'>
        {!_.isEmpty(value) ? (
          <>
            <div className='survey-txt'>{value.Text}</div>
            {!_.isEmpty(value.Answer) ? (
              <div className='div-star-survey'>{value.Answer}</div>
            ) : (
              <div className='div-star-survey'>
                <StarRating stars={Math.round(overallRate / 2)} size='xl' />
              </div>
            )}
            {isMobileView && <div className='divider-hori' />}
          </>
        ) : (
          ''
        )}
      </div>
    );
  };

  const getRatingCount = (ratingClass) => {
    switch (ratingClass) {
      case 'fill-to-2':
        return 2;
      case 'fill-to-4':
        return 4;
      case 'fill-to-6':
        return 6;
      case 'fill-to-8':
        return 8;
      case 'fill-to-10':
        return 10;
      default:
        return 0;
    }
  };

  //useEffect
  useEffect(() => {
    showEditDeleteObj.show
      ? document.addEventListener('click', handleClickOutside, true)
      : document.removeEventListener('click', handleClickOutside, true);
  }, [showEditDeleteObj.show]);

  useEffect(() => {
    showEditRemoveReplyObj.show
      ? document.addEventListener('click', handleClickOutside, true)
      : document.removeEventListener('click', handleClickOutside, true);
  }, [showEditRemoveReplyObj.show]);

  return (
    <LayoutInfo
      identifier='provider-profile-ReviewsComment-layout'
      title=''
      description=''
      bullets={{
        title: 'Missing Fields',
        data: []
      }}>
      <div className='div-review-comments-and-reply'>
        <div className='div-review-comments'>
          {userFlag && !_.isEmpty(commentDetails.ProviderName) && (
            <div className='div-provider-info'>
              <a
                className='comments-provider-info'
                href={`/patientexperience/reviews/${commentDetails.ProviderId}`}>
                {commentDetails.ProviderName}
              </a>
            </div>
          )}      
            <div className='div-star-rating'>
              {showStars && (<StarRating stars={Math.round(ratingClass / 2)} size='xl' />)}
              {showbutton && (window.innerWidth >= 768 ? (
                  <div className='div-reply-flag'>
                    {commentDetails.Response == '' && (
                      <span>
                        <img src={ReplyIcon} alt='reply-icon'/>
                        <a
                          className='reply-flag'
                          onClick={() => {
                            onReplyClickHandler();
                          }}>
                          Reply
                        </a>
                      </span>
                    )}
                    {!commentDetails.IsFlagged ? (
                      <span>
                        <img src={FlagIcon} alt='flag-icon'/>
                        <a
                          className='reply-flag'
                          onClick={() => {
                            showFlagModalPopup(commentDetails, flagReasons);
                          }}>
                          Flag
                        </a>
                      </span>
                    ) : (
                      <span className='flagged'>Flagged</span>
                    )}
                  </div>
                ) : (
                  <div
                    className='div-reply-flag-mobile-menu'
                    value={commentDetails.ByLine}
                    ref={_sideMenu}
                    onClick={(e) =>
                      setShowEditDeleteObj({
                        ...showEditDeleteObj,
                        show: !showEditDeleteObj.show,
                        showFor: commentDetails.ByLine
                      })
                    }>
                    <span className='reply-flag-mobile-menu-span reply-flag-mobile-menu-close-span'>
                      <img src={svgMenudots} alt='close' />
                    </span>

                    {showEditDeleteObj.show &&
                      showEditDeleteObj.showFor == commentDetails.ByLine && (
                        <div className='reply-flag-mobile-menu-items'>
                          {commentDetails.Response == '' && (
                            <div className='row'>
                              <img src={ReplyIcon} alt='reply-icon'/>
                              <a
                                className='reply-flag'
                                onClick={() => {
                                  onReplyClickHandler();
                                }}>
                                Reply
                              </a>
                            </div>
                          )}
                          {!commentDetails.IsFlagged ? (
                            <div className='row'>
                              <img src={FlagIcon} alt='flag-icon' />
                              <a
                                className='reply-flag'
                                onClick={() => {
                                  showFlagModalPopup(commentDetails, flagReasons);
                                }}>
                                Flag
                              </a>
                            </div>
                          ) : (
                            <span className='flagged'>Flagged</span>
                          )}
                        </div>
                      )}
                  </div>
                ))}
            </div>         
          {!isEmpty(commentDetails.ByLine) && (
            <div className='div-comment-heading'>
              <h4>{_translateTxt && !_.isEmpty(commentDetails.TranslateCommentText) ?commentDetails.TranslatedCommentTitle :commentDetails.ByLine}</h4>
            </div>
          )}
          <div className={`div-comment-descrption  ${userFlag ? 'comment-set' : ''}`}>
            {_translateTxt && !_.isEmpty(commentDetails.TranslateCommentText) ? (
              userFlag ? (
                getReviewComment(commentDetails.TranslateCommentText, isShowMoreComment)
              ) : (
                <span>{commentDetails.TranslateCommentText}</span>
              )
            ) : userFlag ? (
              getReviewComment(commentDetails.Comment, isShowMoreComment)
            ) : (
              <span>{commentDetails.Comment}</span>
            )}

            {userFlag && isShowMoreComment && (
              <div className='div-comment-descrption-list'>
                <div className='survey-info'>
                  <div className='div-comment-descrption-set'>
                    <div className='title-txt'>Office & Staff</div>
                    {!_.isEmpty(surveyResponse) &&
                      surveyResponse.map((survey) => (
                        <>
                          {survey.GroupText == 'Tell us about the office & staff' && (
                            <>
                              {survey.Questions.map((question) => (
                                <>
                                  <ul>
                                    <li>{displaySurveyData(question)}</li>
                                  </ul>
                                </>
                              ))}
                            </>
                          )}
                        </>
                      ))}
                  </div>
                  <div className='div-comment-descrption-set'>
                    <div className='title-txt'>{`About Dr. ${commentDetails.ProviderName}`}</div>
                    {!_.isEmpty(surveyResponse) &&
                      surveyResponse.map((survey) => (
                        <>
                          {survey.GroupText != 'Tell us about the office & staff' && (
                            <>
                              {survey.Questions.map((question) => (
                                <>
                                  <ul>
                                    <li>{displaySurveyData(question)}</li>
                                  </ul>
                                </>
                              ))}
                            </>
                          )}
                        </>
                      ))}
                  </div>
                </div>
                <div className='overall-rating'>
                  <div className='star-overall'>{commentDetails.OverallScore}</div>
                  <div className='div-star-overall'>
                    <StarRating stars={Math.round(commentDetails.OverallScore)} size='xl' />
                  </div>
                  <div className='title-name'>
                    <span>Rating</span>
                  </div>
                </div>
              </div>
            )}
            {userFlag && (
              <a className='btn-comment' onClick={(e) => onClickShowComment(isShowMoreComment)}>
                {isShowMoreComment ? 'Less details' : 'More details'}
              </a>
            )}
          </div>
          {!_.isEmpty(commentDetails.TranslateCommentText) && (
            <div className='div-translate-text'>
              {_translateTxt ? (
                <span>
                  {`Translated from the original ${commentDetails.Language}`}.{' '}
                  <a onClick={(e) => textTtranslatedHandler(e)}>Show original review</a>
                </span>
              ) : (
                <span>
                  <a onClick={(e) => textTtranslatedHandler(e)}>Show translated review</a>
                </span>
              )}
            </div>
          )}
          <div className='div-footer'>
            <div className='div-footer-left'>
              {userFlag && commentDetails.HelpfulCount != 0 && (
                <span>{commentDetails.HelpfulCount} people found this helpful</span>
              )}
            </div>           
              <div className='div-footer-right'>
                <span>
                  {userFlag && !_.isEmpty(commentDetails.ResponseUserName) ? (
                    <>{`${commentDetails.ResponseUserName}-${commentDetails.DateDisplay}`}</>
                  ) :  
                  (
                    `${!_.isEmpty(commentDetails.DisplayName)? `${commentDetails.DisplayName} -` :""}  ${commentDetails.DateDisplay}`                    
                  ) 
                  }
                </span>
              </div>          
          </div>
          {isReplied && (
            <>
              <div className='div-reply-comment'>
                {commentDetails.ResponseUserName ? (
                  <span>Your Reply to {commentDetails.ResponseUserName}</span>
                ) : (
                  <span>Reply to this Comment</span>
                )}
              </div>
              <div className='div-reply-comment-rich-textEditor'>
                <TextArea
                  initialText={newContext}
                  range={500}
                  placeholder={`Type here to reply this comment`}
                  onChangeTextHandler={changeContentHandler}
                  isValidCheck={true}
                  isValid={replyValid}
                  validationText={'There is no reply to save'}
                />
              </div>
              <Cta
                ctaValid={newContext != undefined ? newContext.length <= 500 : true}
                cancelText='Cancel'
                cancelClickHandler={cancelHandler}
                confirmText='Save'
                confirmClickHandler={() => {
                  newContext != '' && newContext.length != 0
                    ? onAddReplyHandler(
                        commentDetails.ProviderId,
                        commentDetails.SurveyCommentId,
                        newContext,
                        'add'
                      )
                    : (setReplyValid(false), toaster.Error('There is no reply to save'));
                }}
              />
            </>
          )}
        </div>
        {commentDetails.Response != '' && commentDetails.Response != undefined && !isReplied && (
          <div className='div-reply-response'>
            <span className='reply-comment'>
              <img src={ReplyIcon} className='reply-icon' alt='reply-icon'/> Your Reply to {commentDetails.ByLine}
            </span>
            {              
              showButtons && window.innerWidth >= 768 ? (
                <>
                  <span>
                    <a
                      onClick={() => {
                        onReplyClickHandler(commentDetails.Response);
                      }}>
                      Edit
                    </a>
                  </span>
                  <span>
                    <a
                      onClick={() => {
                        onAddReplyHandler(
                          commentDetails.ProviderId,
                          commentDetails.SurveyCommentId,
                          newContext,
                          'remove'
                        );
                      }}>
                      Remove
                    </a>
                  </span>
                </>
              ) :
              <div
                className='div-reply-save-edit-mobile-menu'
                value={commentDetails.ByLine}
                ref={_saveEditReplyMenu}
                onClick={(e) =>
                  setShowEditRemoveReplyObj({
                    ...showEditRemoveReplyObj,
                    show: !showEditRemoveReplyObj.show,
                    showFor: commentDetails.ByLine
                  })
                }>
                <span className='reply-flag-mobile-menu-span reply-flag-mobile-menu-close-span'>
                  <img src={svgMenudots} alt='close' />
                </span>

                {showEditRemoveReplyObj.show &&
                  showEditRemoveReplyObj.showFor == commentDetails.ByLine && (
                    <div className='reply-flag-mobile-menu-items'>
                      <div className='row'>
                        <span>
                          <a
                            onClick={() => {
                              onReplyClickHandler(commentDetails.Response);
                            }}>
                            Edit
                          </a>
                        </span>
                        <span>
                          <a
                            onClick={() => {
                              onAddReplyHandler(
                                commentDetails.ProviderId,
                                commentDetails.SurveyCommentId,
                                newContext,
                                'remove'
                              );
                            }}>
                            Remove
                          </a>
                        </span>
                      </div>
                    </div>
                  )}
              </div>
            }
            <div className='div-reply-response-comment'>
              <div>{commentDetails.Response}</div>
            </div>
          </div>
        )}
      </div>
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </LayoutInfo>
  );
};

ReviewsComment.defaultProps = {
  showbutton: true,
  userFlag: false,
  showStars :true
};

ReviewsComment.propTypes = {
  addOrDeleteCommentReply: PropTypes.func,
  showFlagModalPopup: PropTypes.func,
  flagReasons: PropTypes.array,
  userFlag: PropTypes.bool,
  showbutton: PropTypes.bool,
  showStars: PropTypes.bool,
};

export default ReviewsComment;
