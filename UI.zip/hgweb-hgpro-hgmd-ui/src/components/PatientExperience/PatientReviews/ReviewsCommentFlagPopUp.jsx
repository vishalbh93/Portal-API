import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

//styling imports
import './_reviewsCommentFlagPopUp.less';

//components import
import ReactModal from 'react-modal';
import Cta from '../../Common/Form/CTA/Cta';
import ReviewsComment from './ReviewsComment';
import TextArea from '../Common/TextArea/TextArea';
import { RadioGroup } from '../../FormComponents/RadioGroup';

//svg import
import Close from '../../../assets/images/PatientExperience/Cross-Close.svg';

const ReviewsCommentFlagPopUp = (props) => {
  const { showModalPopUp, commentDetails, flagReasons, userFlag } = props;
  const [newContext, setNewContext] = useState('');
  const [selectedFlagReason, setSelectedFlagReason] = useState('');
  const [isShowTextEditor, setIsShowTextEditor] = useState(false);
  const [replyValid, setReplyValid] = useState(true);

  let _flagReasons = [];
  flagReasons.map((reason) => {
    _flagReasons.push({
      Name: reason.Desc,
      Value: reason.Id.toString(),
      Show: true
    });
  });

  const onAddFlagHandler = (commentDetails, flagReason, flagNote) => {
    if (flagReason === '205' && newContext.length == 0) {
      setReplyValid(false);
    } else {
      let request = {
        CommentId: commentDetails.CommentId,
        FlagReason: flagReason,
        FlagNote: flagNote
      };
      setReplyValid(true);
      props.addFlag(request);
      props.closeModal();
      setSelectedFlagReason('');
      setNewContext('');
      setIsShowTextEditor(false);
    }
  };

  const onCloseHandler = () => {
    props.closeModal();
    setSelectedFlagReason('');
    setNewContext('');
    setIsShowTextEditor(false);
  };

  const radioGroupChangeHandler = (event) => {
    event.persist();
    let value = event.target.value;
    setSelectedFlagReason(value);
    if (value == '205') {
      setIsShowTextEditor(true);
    } else {
      setIsShowTextEditor(false);
      setNewContext('');
    }
  };

  const changeContentHandler = (content) => {
    if (content != undefined) setNewContext(content);
  };

  return (
    <ReactModal
      overlayClassName='modal-overlay alert-box flag-comment-overlay'
      className='modal-dialog flag-comment-modal-dialog'
      ariaHideApp={false}
      isOpen={showModalPopUp}
      contentLabel='Flag this comment'
      shouldCloseOnOverlayClick={false}>
      <div className='modal-container'>
        <div className='modal-header'>
          <span className='modal-title'>Flag this comment</span>
          <div className='modal-close' onClick={onCloseHandler}>
            <img className='close-icon' src={Close} alt='Close' />
          </div>
        </div>
        <div className='line-break'></div>
        <div className='modal-body'>
          <div className='modal-body-container'>
            <ReviewsComment
              commentDetails={commentDetails}
              flagReasons={flagReasons}
              showbutton={false}
              showStars={false}

            />
          </div>
          <div className='flag-comment-reasons-title'>
            <span>Please select your reason for Flagging</span>
          </div>
          <div className='flag-comment-reasons'>
            <RadioGroup
              radioGroup={_flagReasons}
              selectedOption={selectedFlagReason}
              onChangeHandler={(event) => radioGroupChangeHandler(event)}
            />
          </div>
          {isShowTextEditor && (
            <div className='flag-comment-text-editor'>
              <TextArea
                initialText={newContext}
                range={250}
                placeholder={`Type your reasoning here`}
                onChangeTextHandler={changeContentHandler}
                isValidCheck={true}
                isValid={replyValid}
                validationText={'Please select or enter a reason for flagging'}
              />
            </div>
          )}
          <div className='flag-comment-footer-description'>
            <span>
              By clicking "Submit" below you are confirming that this comment needs to be reviewed
              for removal by Healthgrades
            </span>
          </div>
        </div>

        <div className='modal-footer ReviewsCommentFlagPopUp'>
          <Cta
            ctaValid={newContext.length <= 250}
            cancelText='Cancel'
            cancelClickHandler={() => {
              onCloseHandler();
            }}
            confirmText='Submit'
            confirmClickHandler={() => {
              onAddFlagHandler(commentDetails, selectedFlagReason, newContext);
            }}
          />
          {/* {spinnerVisibility && <Spinner cta={true} />} */}
        </div>
      </div>
    </ReactModal>
  );
};

ReviewsCommentFlagPopUp.propTypes = {
  addFlag: PropTypes.func,
  closeModal: PropTypes.func,
  userFlag: PropTypes.bool
};
ReviewsComment.defaultProps = {
  userFlag: false
}

export default ReviewsCommentFlagPopUp;
