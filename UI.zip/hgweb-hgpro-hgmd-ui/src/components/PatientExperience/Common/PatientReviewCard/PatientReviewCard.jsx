import React, { useState } from 'react';

// Stylesheet imports
import './_patientReviewCard.less';

//Components imports
import StarRating from '@hg/joy/src/components/StarRating';
import LayoutInfo from '../../../Common/Layouts/LayoutInfo';

//media imports
import FlagIcon from '../../../../assets/images/PatientExperience/Flag.svg';
import ReplyIcon from '../../../../assets/images/PatientExperience/Reply.svg';
import isEmpty from '../../../../utils/validation/isEmpty';

const PatientReviewCard = (props) => {
  const { reviewCardObject } = props;
  const [isFlagDisabled, setIsFlagDisable] = useState(reviewCardObject.isFlagDisabled);
  const [showMoreDetails, setShowMoreDetails] = useState(reviewCardObject.Comment.length > 380);

  return (
    <LayoutInfo identifier='provider-profile-review-card' title='' description=''>
      <div className='div-provider-profile-review-card-container'>
        <div className='div-review-comments-inner-container'>
          <div className='div-star-rating'>
            <div className='star-ratings-container'>
              <StarRating stars={4} size='xl' />
            </div>

            {!isFlagDisabled && (
              <div className='div-reply-flag'>
                <>
                  <span>
                    <img src={ReplyIcon} alt='reply-icon' />
                  </span>
                  <span>Reply</span>
                </>

                {!reviewCardObject.IsFlagged ? (
                  <>
                    <span>
                      <img src={FlagIcon} alt='flag-icon'/>
                    </span>
                    <span> Flag</span>
                  </>
                ) : (
                  <span className='flagged'>Flagged</span>
                )}
              </div>
            )}
          </div>

          {!isEmpty(reviewCardObject.ByLine) && (
            <div className='div-comment-heading'>
              <h4>{reviewCardObject.ByLine}</h4>
            </div>
          )}

          <div className={`div-comment-description ${!showMoreDetails ? 'expand-comment' : ''}`}>
            <span>{reviewCardObject.Comment}</span>
          </div>

          {reviewCardObject.Comment.length > 380 && (
            <a onClick={() => setShowMoreDetails(!showMoreDetails)}>
              {showMoreDetails ? 'More Details' : 'Less'}{' '}
            </a>
          )}

          <div className='div-footer'>
            <div className='div-footer-left'>
              <span>{reviewCardObject.HelpfulCount} people found this helpful</span>
            </div>
            <div className='div-footer-right'>
              {/* <span>
                {`${reviewCardObject.ByLine.length > 0 ? reviewCardObject.ByLine + ' -' : ''}${
                  reviewCardObject.DateDisplay
                }`}
              </span> */}
              <span>{reviewCardObject.DateDisplay}</span>
            </div>
          </div>
        </div>
      </div>
    </LayoutInfo>
  );
};

export default PatientReviewCard;
