import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../../../.storybook/store';
import PatientReviewCard from '../PatientReviewCard';

const reviewCardObject = {
  ProviderId: 'XYN3PMJ',
  ProviderName: 'Debbie A Demo, MD',
  CommentId: '515c4ac1-6867-4f3f-b8ca-e4568fef897d',
  SurveyCommentId: 6676815,
  Comment:
    'I have seen Dr Peck for several years. I was forced to find a new provider as I have become fed up with the lack of communication. The office rarely answers calls, rarely follows up and IF you get an appointment you can expect 1 hour plus wait times. Every time my Humira comes up for refill it takes their office 2-4 weeks to respond. This last time I had been out of medicine for over a month and no one returned my calls. I sought out a new Dr in desperation and am very happy I did. The difference has been night and day. I really liked Dr Abrol and his staff, but my health comes first. I am saddened that I have to leave a bad review, but folks should know what they are dealing with in advance.',
  IsFlagged: false,
  FlagDisabled: false,
  ByLine: 'Alice Smith in Houston, TX',
  DateDisplay: 'Sep 30, 2022',
  IsNew: false,
  RatingClass: 'fill-to-8',
  ShowDetails: false,
  HasResponse: true,
  HelpfulCount: 6,
  Response:
    'Thank you so much for taking the time to write a review Emily. We are glad to hear your visit with Dr. Peck was a positive one. Can you please call our office manager at 847-439-8780 to discuss any issues or concerns you had as your overall review of a "one star" is less than the service that we strive to provide you. Thank you again, we appreciate your feedback.',
  ResponseUserName: 'Emily Frederick'
};

storiesOf('Patient Experience', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Review Card', () => <PatientReviewCard reviewCardObject={reviewCardObject} />);
