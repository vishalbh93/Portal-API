import React, { useState, useRef } from 'react';
import './_textarea.less';

const TextArea = (props) => {
  const {
    range,
    placeholder,
    onChangeTextHandler,
    initialText,
    isValidCheck,
    isValid,
    validationText
  } = props;

  const [characterCount, setCount] = useState(range - initialText.length);
  const refContent = useRef();

  const handleClick = (event) => {
    let currentValue;
    if (refContent.current && refContent.current.contains(event.target)) {
      currentValue = refContent.current.value;
      let typedchar = refContent.current.value.length;
      let remainingChar = range - typedchar;
      setCount(remainingChar);
      onChangeTextHandler(currentValue);
    } else {
      onChangeTextHandler('');
    }
  };

  return (
    <div className='wrapper'>
      {isValidCheck && !isValid && <label id={'err-msg-label'}>{validationText}</label>}
      <textarea
        name='the-textarea'
        id='the-textarea'
        //maxLength={range}
        placeholder={placeholder}
        autoFocus
        ref={refContent}
        value={initialText}
        onChange={(event) => handleClick(event)}></textarea>

      {characterCount >= 0 && characterCount <= range ? (
        <div id='the-count'>
          <div id='maximum'>{characterCount} characters remaining</div>
        </div>
      ) : (
        <div id='the-count'>
          <div>
            Maxiumum {range} characters. You are {Math.abs(characterCount)} characters over the
            limit.
          </div>
        </div>
      )}
    </div>
  );
};

TextArea.defaultProps = {
  range: 250,
  initialText: '',
  isValidCheck: false,
  isValid: true,
  validationText: ''
};

export default TextArea;
