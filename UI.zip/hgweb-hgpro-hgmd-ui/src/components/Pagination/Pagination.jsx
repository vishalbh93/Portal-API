import React, { useEffect, useState, useRef } from 'react';
import Pagination from 'react-js-pagination';
import './_pagination.less';
import PropTypes from 'prop-types';
import JoyPagination from '@hg/joy/src/components/Pagination';
import UpArrow from '../../assets/images/up-arrow.svg';
import DownArrow from  '../../assets/images/down-arrow.svg';

export function PaginationUI(props) {
  const {
    recordsFound,
    onPageChange,
    showPerPage,
    recordsPerPage,
    onPageFilterChange,
    currentPage,
    showJoyPagination,
    isBulkProviders,
    isClientPage
  } = props;
  const [activePage, setActivePage] = useState(currentPage);

  const [enablePerPage, setEnablePerPage] = useState(false);

  const [perPage, setItemsPerPage] = useState(recordsFound<=500?10:100);

  const [totalNumOfPages, setTotalNumOfPages] = useState(1);
  const [moveTop, setMoveTop] = useState(false);

  useEffect(() => {
    if (recordsFound > 0) {
      setTotalNumOfPages(Math.ceil(recordsFound / perPage));
      if (activePage > totalNumOfPages) setActivePage(1);
    }
  }, [totalNumOfPages, activePage, recordsFound]);

  useEffect(() => {
    setActivePage(currentPage);
  }, [recordsFound]);

  useEffect(() => {
    setEnablePerPage(showPerPage);
  }, [showPerPage]);

  useEffect(() => {
    if (recordsPerPage != undefined) setItemsPerPage(recordsPerPage);
    else setItemsPerPage(30);
  }, [recordsPerPage]);

  useEffect(() => {
    setActivePage(currentPage);
  }, [currentPage]);

  const pageStart = perPage * (activePage - 1) + 1;
  const pageEnd = perPage * activePage > recordsFound ? recordsFound : perPage * activePage;

  const handlePageChange = (pageNumber) => {
    setActivePage(pageNumber);
    onPageChange(pageNumber);
  };

  const pageFilterChange = (e) => {
    setItemsPerPage(Number(e.target.value));
    setActivePage(1);
    onPageFilterChange(Number(e.target.value));
    setTotalNumOfPages(Number(e.target.value));
    setDropdown(false);
  };
  const handleOpen = (e) => {
    setDropdown(!dropdown);
    setMoveTop(innerHeight / 2 > e.clientY);
    let dropdownRect = e.currentTarget.getBoundingClientRect();
    let spaceBelow = window.innerHeight - dropdownRect.bottom;
    spaceBelow <= 250 ? setMoveTop(false) : setMoveTop(true);
  };

  const providersFound = props.providersFound;

  const [dropdown, setDropdown] = useState(false);
  let menuRef = useRef();
  useEffect(() => {
    let handler = (e) => {
      if (menuRef.current != undefined && !menuRef.current.contains(e.target)) {
        setDropdown(false);
      }
    };
    document.addEventListener('mousedown', handler);

    return () => {
      document.removeEventListener('mousedown', handler);
    };
  }, []);
  return (
    <>
      {showJoyPagination ? (
        <>
          <JoyPagination
            className='paginations'
            currentPage={activePage}
            lastPage={totalNumOfPages}
            generateHref={(page) => `?pg=${page}`}
            onPageClick={(page, event) => {
              event.preventDefault();
              setActivePage(totalNumOfPages);
              handlePageChange(page);
            }}
          />
          {enablePerPage && (
            <>
              <div className='show-page-filter'>
                <div className='filter-content'>
                  <span className='filter-title'>Show </span>
                  <div className='pagination-dropdown' ref={menuRef}>
                    <button type='button' className='dropdown-button' onClick={(e) =>handleOpen(e)}>
                      {recordsPerPage} results per Page{' '}
                      <img className='down-arrow' src={dropdown ? UpArrow : DownArrow} alt='arrow-image'></img>
                    </button>
                    {dropdown ? (
                      <ul
                        className={`pages-select ${!moveTop? isBulkProviders?isClientPage?'move-top-box-client-user': 'move-top-box-user':!isClientPage?'move-to-top-user':'move-to-top-cp':''}`}
                        name='state'
                        id='state'
                        placeholder='10 Results Per Page'>
                        <li value={10} onClick={pageFilterChange}>
                          10 Results Per Page
                        </li>
                        <li value={20} onClick={pageFilterChange}>
                          20 Results Per Page
                        </li>
                        <li value={30} onClick={pageFilterChange}>
                          30 Results Per Page
                        </li>
                        {recordsFound <= 500 ? (
                          <li value={recordsFound} onClick={pageFilterChange}>
                            All Results
                          </li>
                        ): (<>
                          <li value={100} onClick={pageFilterChange}>
                          100 Results Per Page
                        </li>
                        <li value={300} onClick={pageFilterChange}>
                          300 Results Per Page
                        </li>
                        <li value={500} onClick={pageFilterChange}>
                          500 Results Per Page
                        </li></>
                        )}
                      </ul>
                    ) : null}
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      ) : (
        <div className='pagination-content'>
          <span className={`${enablePerPage ? 'span-result' : ''}`}>
            Results {pageStart}-{pageEnd} of {recordsFound}
          </span>
          {enablePerPage && (
            <div className='show-page-filter'>
              <p className='filter-content'>
                <span className='filter-title'>| Show </span>
                <select
                  className='pages-select'
                  name='state'
                  id='state'
                  data-recurly='state'
                  placeholder='10 Results Per Page'
                  onChange={pageFilterChange}>
                  <option value={10}>10 Results Per Page</option>
                  <option value={20}>20 Results Per Page</option>
                  <option value={30}>30 Results Per Page</option>
                </select>
              </p>
            </div>
          )}
          <div className='pagination-align-right'>
            <Pagination
              activePage={activePage}
              itemsCountPerPage={perPage}
              totalItemsCount={recordsFound}
              onChange={handlePageChange}
              prevPageText='‹'
              nextPageText='›'
              linkClassNext='nextOrPrev'
              linkClassPrev='nextOrPrev'
            />
          </div>
        </div>
      )}
    </>
  );
}

PaginationUI.propTypes = {
  recordsFound: PropTypes.number,
  onPageChange: PropTypes.func,
  showPerPage: PropTypes.bool,
  recordsPerPage: PropTypes.number,
  onPageFilterChange: PropTypes.func,
  showJoyPagination: PropTypes.bool,
  isBulkProviders: PropTypes.bool,
  isClientPage: PropTypes.bool
};

PaginationUI.defaultProps = {
  currentPage: 1,
  showJoyPagination: false,
  isBulkProviders: false,
  isClientPage:false
};
export default PaginationUI;
