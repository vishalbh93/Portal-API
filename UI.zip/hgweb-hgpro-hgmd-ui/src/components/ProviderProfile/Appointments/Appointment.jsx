import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import './_appointment.less';

function Appointment(props) {
  const { AvailabilityCode, AvailabilityDescription, ItemSelected, id } = props;
  const [isChecked, setIsChecked] = useState(ItemSelected);

  const CheckboxOnChangeHandler = (event, index) => {
    let itemChecked = event.target.checked;
    setIsChecked(itemChecked);
    props.ItemSelectedOnChange(event, index);
  };

  useEffect(() => {
    setIsChecked(ItemSelected);
  }, [ItemSelected]);

  return (
    <div
      className={
        isChecked ? 'appointment-main-section appointment-checked' : 'appointment-main-section'
      }>
      <label htmlFor={id}>
        <span>{AvailabilityDescription}</span>
      </label>
      <input
        id={id}
        type='checkbox'
        className='appointment-checkbox'
        checked={isChecked}
        onChange={(event) => CheckboxOnChangeHandler(event, id)}
      />
    </div>
  );
}

Appointment.propTypes = {
  AvailabilityCode: PropTypes.string,
  AvailabilityDescription: PropTypes.string,
  ItemSelected: PropTypes.bool,
  ItemSelectedOnChange: PropTypes.func
};

export default Appointment;
