import React, { useState, Fragment, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '../../../store/actions';
import * as service from '../../../utils/service';
import * as trackingService from '../trackingServices';

//Component imports
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import LayoutA from '../../Common/Layouts/LayoutA';
import Button from '@hg/joy/src/components/Button';
import Spinner from '../../Spinner/Spinner';
import Toast from '../../Common/Toast/Toast';
import Appointment from './Appointment';

//styling imports
import '@hg/joy/src/globalstyles';
import './_appointments.less';

const Appointments = (props) => {
  //selector
  const dispatch = useDispatch();
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);

  //states
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const appointmentInformation = JSON.parse(providerProfileInfo.AppointmentsJson);

  const [appointInformation, setAppointInformation] = useState({
    ProviderId: appointmentInformation.ProviderId,
    MissingData: appointmentInformation.MissingData,
    AvailabilityStatement: appointmentInformation.AvailabilityStatement,
    AppointmentServices: appointmentInformation.AppointmentServices.map((availability) => ({
      AvailabilityCode: availability.AvailabilityCode,
      AvailabilityDescription: availability.AvailabilityDescription,
      ItemSelected: availability.ItemSelected
    }))
  });

  const [providerAppointmentInformationObj, setProviderAppointmentInformationObj] =
    useState(appointInformation);

  // cta validation
  const _ctaValid = providerAppointmentInformationObj.AppointmentServices.every(
    (value, index) =>
      value.ItemSelected == appointmentInformation.AppointmentServices[index].ItemSelected
  )
    ? ''
    : 'valid';

  // header
  const navTabData = [
    {
      label: 'Appointments',
      badgeEnabled: false // appointmentInformation.MissingData
    }
  ];
  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);

  //handlers
  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
  };

  const CheckBoxChangeHandler = (event, index) => {
    event.persist();

    let _tempAppointmentService = [...providerAppointmentInformationObj.AppointmentServices];

    let _tempAppointmentToUpdate = {
      ..._tempAppointmentService[index],
      ItemSelected: event.target.checked
    };
    _tempAppointmentService[index] = _tempAppointmentToUpdate;

    setProviderAppointmentInformationObj((prev) => ({
      ...prev,
      AppointmentServices: _tempAppointmentService
    }));
  };

  const updateappointmentsHandler = () => {
    service
      .post(`/api/provider/update-availability`, providerAppointmentInformationObj)
      .then((res) => {
        if (res.Success) {
          let _tempProviderProfileInfo = {
            ...providerProfileInfo,
            AppointmentsJson: res.ReturnData
          };
          dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
          trackingService.editPageTracking('provider', 'save', 'appointments');
          toaster.Success('Success');
        }
      })
      .catch(() => toaster.Error('Some error occurred, please try again!!'))
      .finally(() => setSpinnerVisibility(false));
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //effects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'appointments');
  }, []);

  useEffect(() => {
    let _appointmentsJson = JSON.parse(providerProfileInfo.AppointmentsJson);
    setAppointInformation({
      ProviderId: _appointmentsJson.ProviderId,
      MissingData: _appointmentsJson.MissingData,
      AvailabilityStatement: _appointmentsJson.AvailabilityStatement,
      AppointmentServices: _appointmentsJson.AppointmentServices.map((availability) => ({
        AvailabilityCode: availability.AvailabilityCode,
        AvailabilityDescription: availability.AvailabilityDescription,
        ItemSelected: availability.ItemSelected
      }))
    });
  }, [providerProfileInfo]);

  // jsx constant(s)
  const _header = (
    <>
      <NavTabs tabs={navTabData} onSelectHandler={tabSelectionhandler} />
    </>
  );
  const _footer = <></>;

  return (
    <Fragment>
      <LayoutA identifier='provider-profile-appointments' header={_header} footer={_footer}>
        <div id='div-provider-profile-appointments-main'>
          <div id='div-appointments-section'>
            <section id='provider-profile-appointments-section'>
              <div id='div-provider-profile-appointments-get-badge-title'>
                <span>Appointment Availability</span>
                <p>
                  Tell patients about your availability. Your availability will be applied to all of
                  your locations.
                </p>
              </div>

              <div id='div-provider-profile-appointments-get-badge-title'>
                <span className='availbility-title'>
                  I am available for the following appointments:
                </span>
              </div>
              <div className='appointment-group'>
                {providerAppointmentInformationObj.AppointmentServices.map((appointment, index) => (
                  <Appointment
                    {...appointment}
                    key={index}
                    id={index}
                    ItemSelectedOnChange={CheckBoxChangeHandler}
                  />
                ))}
              </div>
              <div className='action-section'>
                <Button
                  id='appointments-btn-cancel'
                  text='Cancel'
                  disabled={_ctaValid != 'valid'}
                  className={`provider-profile-appointments-cancel ${_ctaValid} `}
                  size='lg'
                  style='ghost'
                  onClick={() => {
                    trackingService.editPageTracking('provider', 'cancel', 'appointments');
                    setProviderAppointmentInformationObj(appointmentInformation);
                  }}
                />
                <Button
                  id='appointments-btn-save'
                  text='Save'
                  disabled={_ctaValid != 'valid'}
                  className={`provider-profile-appointments-save ${_ctaValid} `}
                  size='lg'
                  style='ghost'
                  onClick={() => {
                    setSpinnerVisibility(true);
                    updateappointmentsHandler();
                  }}
                />
              </div>
            </section>
          </div>
        </div>
      </LayoutA>
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </Fragment>
  );
};

export default Appointments;
