import React, { useState, useEffect, Fragment } from 'react';

//stylesheet import
import './_education.less';

//components import
import ListItems from '../../Common/Form/AutoSuggest/ListItems';
import LayoutInfoEducation from '../../Common/Layouts/LayoutInfoEducation';
import Toggle from '../../Common/ToggleButton/Toggle';

//media imports
import SvgAdd from '../../../assets/images/ProviderProfile/svg-add.svg';

//helper
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
import isEmpty from '../../../utils/validation/isEmpty';

const EducationCard = (props) => {
  const {
    EducationType,
    Name,
    Title,
    Institutions,
    TempInstitutions,
    educationChangeHandler,
    educationAutoSuggest,
    educationSelectHandler,
    show,
    inputValue,
    addSelectedInstituteHandler,
    removeInstitute,
    yearHandler,
    windowDimensions,
    validFreeText
  } = props;

  //states
  const [year, setYear] = useState({ yearFor: '', val: null });
  const [err, setErr] = useState({ name: null, val: false, text: '' });
  const [isYearValid, setYearValid] = useState({ val: true, msg: '' });

  const [currentInstitutions, setCurrentInstitutions] = useState(Institutions);
  const [tempInstitutions, setTempInstitutions] = useState(TempInstitutions);
  const [isMedToggleSelect, setIsMedToggleSelect] = useState(EducationType === 'MEDSCH');

  //flags
  const toDisableAddButtonForFreeText = show.name != 'MEDSCH'? true : validFreeText;

  const _isAddValid =
    !isEmpty(inputValue.value) &&
    show.name == EducationType &&
    !err.val &&
    isYearValid.val &&
    currentInstitutions.every((ins) => ins.Name.toLowerCase() !== inputValue.value.toLowerCase()) &&
    tempInstitutions.every((ins) => ins.Name.toLowerCase() !== inputValue.value.toLowerCase()) &&
    toDisableAddButtonForFreeText;

  //handlers
  const yearValidationHandler = () => {
    if (year.val != null) {
      let yearRegex = /^\d{4}$/;
      let intYear = parseInt(year.val);
      let currentYear = new Date().getFullYear();
      let startYear = currentYear - 70;
      if (year.val == '') {
        setYearValid({ val: true, msg: '' });
        return;
      }
      if (!yearRegex.test(year.val)) {
        setYearValid({
          ...isYearValid,
          val: false,
          msg: 'Invalid characters'
        });
        return;
      }
      if (intYear < startYear || intYear > currentYear) {
        setYearValid({
          ...isYearValid,
          val: false,
          msg: 'Unacceptable range'
        });
        return;
      }
    }
    setYearValid({ val: true, msg: '' });
    setYear(year);
  };

  const validationHandler = (err) => {
    setErr({ name: err.name, val: err.val, text: err.text });
  };

  const OnAddClick = () => {
    addSelectedInstituteHandler();
  };

  const suggestSelectHandler = (instituteObj) => {
    educationSelectHandler(instituteObj);
  };

  const currentInstituitionRemoveHandler = (obj) => {
    removeInstitute(obj, EducationType, false);
  };

  const temporaryInstituitionRemoveHandler = (obj) => {
    removeInstitute(obj, EducationType, true);
  };

  const updateToggle = (val) => {
    setIsMedToggleSelect(val);
    props.setToogle(val);
  };

  //effects
  useEffect(() => {
    setCurrentInstitutions(Institutions);
  }, [Institutions]);

  useEffect(() => {
    setTempInstitutions(TempInstitutions);
  }, [TempInstitutions]);

  return (
    <Fragment>
      <LayoutInfoEducation
        identifier='provider-profile-education'
        title={`${
          windowDimensions < 769
            ? 'Add ' + Title
            : `Add ${Title.toLowerCase().includes('school') ? Title : Title + ' School'}`
        }`}
        description={
          EducationType == 'MEDSCH'
            ? 'Selecting your medical school from this list ensures accurate formatting and enhances your visibility to potential patients.'
            : ''
        }
        bullets={{ title: '', data: [] }}
        windowDimensions={windowDimensions}>
        <>
          {EducationType == 'MEDSCH' && (
            <div className='toogle-med-school flex-row'>
              <span>Search Medical schools within United States</span>
              <span className='span-toggle'>
                <Toggle
                  selected={isMedToggleSelect}
                  toggleSelected={() => {
                    updateToggle(!isMedToggleSelect);
                  }}
                />
              </span>
            </div>
          )}
          <AutoSuggest
            id={`provider-profile-education-${Name}`}
            label={`${Title}`}
            name={EducationType}
            placeholder={Title}
            initialValue={inputValue.type === EducationType ? inputValue.value : ''}
            onInputChangeHandler={educationChangeHandler}
            data={educationAutoSuggest}
            onSuggestSelectHandler={suggestSelectHandler}
            isSearch={true}
            allowOtherThanList={true}
            validationHandler={validationHandler}
            setCurrentSelection={true}
            onOtherThanListHandler={props.onOtherThanListHandler}
          />

          <TextInput
            id={`input-provider-profile-education-yearfor-${Name}`}
            name='year'
            label='Year'
            placeholder='Year Completed'
            onChange={(name, value) => {
              setYear((prev) => ({
                ...prev,
                yearFor: EducationType,
                val: value.trim()
              }));
            }}
            value={`${
              isEmpty(year.val)
                ? ''
                : isEmpty(inputValue.type == EducationType)
                ? setYear({ yearFor: '', val: null })
                : year.val
            }`}
            required={!isEmpty(year.val)}
            invalidErrorMessage={isYearValid.msg}
            onBlur={() => {
              yearValidationHandler();
              yearHandler(year);
            }}
            validating={!isYearValid.val}
            valid={!(inputValue.type == EducationType)}
          />

          {_isAddValid && (
            <div className='add-institute' onClick={OnAddClick}>
              <img src={SvgAdd} alt='Add' />
              <a>Add</a>
            </div>
          )}
        </>
        <div className='institute-list-wrapper'>
          {!isEmpty(currentInstitutions) ? (
            <ListItems
              tagList={currentInstitutions}
              clickHandler={currentInstituitionRemoveHandler}
              currentTab='education'
            />
          ) : null}
          {!isEmpty(tempInstitutions) ? (
            <ListItems
              tagList={tempInstitutions}
              clickHandler={temporaryInstituitionRemoveHandler}
              currentTab='education'
            />
          ) : null}
        </div>
      </LayoutInfoEducation>
    </Fragment>
  );
};

export default EducationCard;
