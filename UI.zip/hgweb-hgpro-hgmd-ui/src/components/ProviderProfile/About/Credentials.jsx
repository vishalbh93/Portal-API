import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//stylesheet import
import './_credentials.less';

//components import
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import ListItems from '../../Common/Form/AutoSuggest/ListItems';
import DeleteConfirmationModelPopUp from '../../Common/DeleteConfirmationModelPopUp/DeleteConfirmationModelPopUp';
import Cta from '../../Common/Form/CTA/Cta';

//helper
import isEmpty from '../../../utils/validation/isEmpty';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';

const Credentials = (props) => {
  const { info, displayName } = props;
  // setup
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const credentialJson = JSON.parse(providerProfileInfo.CredentialJson);
  const providerInformation = JSON.parse(providerProfileInfo.InformationJson);
  const dispatch = useDispatch();

  //states
  const [INIT_STATE_DEG, UPDATE_INIT_STATE_DEG] = useState({
    ProviderId: credentialJson.ProviderId,
    Degree: credentialJson.Degree
  });
  const [providerDegreeObj, setProviderDegreeObj] = useState(INIT_STATE_DEG);
  const [INIT_STATE_LIC, UPDATE_INIT_STATE_LIC] = useState(
    credentialJson.StateLicenses.map((licence) => ({
      Id: licence.Id,
      StateName: licence.StateName,
      Text: licence.StateName,
      UpdateType: licence.UpdateType
    }))
  );
  const [providerStateLicenseObj, setProviderStateLicenseObj] = useState(INIT_STATE_LIC);

  const [degreeAutoSuggest, setDegreeAutoSuggest] = useState([]);
  const [stateLicenseAutoSuggest, setStateLicenseAutoSuggest] = useState([]);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [showModalDelete, toggleModalDelete] = useState(false);
  const [removedItemObj, setRemovedItemObj] = useState();
  const [temAddedLic, setTempAddedLic] = useState(
    providerStateLicenseObj.filter((v) => v.UpdateType == 'Add')
  );
  const [disableCTA, setDisableCTA] = useState(false || temAddedLic.length == 0);

  //isValid => ClassName => CTA
  const UpdatedDegree =
    (displayName != undefined || displayName != null) &&
    (displayName.split(',')[1] != null || displayName.split(',')[1] != undefined)
      ? displayName.split(',')[1].trim()
      : providerDegreeObj.Degree;

  const _ctaDegreeEqual =
    providerDegreeObj.Degree == credentialJson.Degree || UpdatedDegree == providerDegreeObj.Degree;
  const _ctaStateLicenseEqual =
    credentialJson.StateLicenses.length ===
    providerStateLicenseObj.filter((lic) => lic.UpdateType !== 'Delete').length
      ? credentialJson.StateLicenses.every(
          (value, index) => value.UpdateType === providerStateLicenseObj[index].UpdateType
        )
      : false || temAddedLic == 0;

  const _ctaValid = _ctaDegreeEqual && _ctaStateLicenseEqual && disableCTA ? '' : 'valid';

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const sortLicenseArray = (temp) => {
    let _sortedLicenses = temp.sort(function (a, b) {
      var textA = a.StateName.toUpperCase();
      var textB = b.StateName.toUpperCase();
      return textA < textB ? -1 : textA > textB ? 1 : 0;
    });
    let __sortedUniqueLicenses = [...new Map(_sortedLicenses.map((m) => [m.Id, m])).values()];
    return __sortedUniqueLicenses;
  };

  const degreeChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length == 0) {
      setProviderDegreeObj({ Id: '', Degree: '' });
      setDegreeAutoSuggest([]);
    }
    if (value.trim().length > 0) {
      service
        .get(`/api/autosuggest?term=${value}&type=Degree`)
        .then((res) => {
          let _tempDegreeData =
            res.length > 0
              ? res.map((e) => {
                  return providerDegreeObj.Degree.includes(e.text)
                    ? { ...e, Disabled: true }
                    : { ...e, Disabled: false };
                })
              : [];
          setDegreeAutoSuggest(_tempDegreeData);
        })
        .catch((err) => console.log(err));
    } else {
      setDegreeAutoSuggest([]);
    }
    setDisableCTA(false);
  };

  const degreeSelectHandler = (degreeObj) => {
    let _tempProviderDegree = {};
    if (degreeObj.Id != null) {
      _tempProviderDegree['Id'] = degreeObj.Id;
      _tempProviderDegree['Degree'] = degreeObj.Text.trim();
    }
    setProviderDegreeObj(_tempProviderDegree);
    setDegreeAutoSuggest([]);
    setDisableCTA(false);
  };

  const licenseChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length > 1) {
      service
        .get(`/api/autosuggest/states?term=${value}`)
        .then((res) => {
          let _tempLicenseObj = providerStateLicenseObj
            .filter((e) => e.UpdateType != 'Delete')
            .map((e) => e.Text);
          let _tempLicenseData =
            res.length > 0
              ? res.map((e) => {
                  if (_tempLicenseObj.includes(e.Text)) {
                    return { ...e, Disabled: true };
                  } else return { ...e, Disabled: false };
                })
              : [];
          setStateLicenseAutoSuggest(_tempLicenseData);
        })
        .catch((err) => console.log(err));
    } else setStateLicenseAutoSuggest([]);
  };

  const licenseSelectHandler = (licenceObj) => {
    let _tempProviderStateLicence = [...providerStateLicenseObj];
    if (_tempProviderStateLicence.findIndex((lic) => lic.Id === licenceObj.Id) == -1) {
      _tempProviderStateLicence.push({
        Id: licenceObj.Id,
        StateName: licenceObj.Text,
        Text: licenceObj.Text,
        UpdateType: 'Add'
      });
      setProviderStateLicenseObj(sortLicenseArray(_tempProviderStateLicence));
    } else if (
      _tempProviderStateLicence.find((lic) => lic.Id === licenceObj.Id).UpdateType == 'Delete'
    ) {
      _tempProviderStateLicence = _tempProviderStateLicence.map((lic) => {
        if (lic.Id === licenceObj.Id) return { ...lic, UpdateType: 'None' };
        else {
          return lic;
        }
      });
      setProviderStateLicenseObj(sortLicenseArray(_tempProviderStateLicence));
    }
    setDisableCTA(false);
    setStateLicenseAutoSuggest([]);
  };

  const licenseDeSelectHandler = (licenceObj, temp) => {
    if (temp) {
      let idx = providerStateLicenseObj.findIndex((lic) => lic.Id === licenceObj.Id);
      let _tempStateLicense = providerStateLicenseObj;
      if (idx !== -1) {
        _tempStateLicense.splice(idx, 1);
      }
      setProviderStateLicenseObj(_tempStateLicense);
      setDisableCTA(true);
    } else {
      setSpinnerVisibility(true);
      setDisableCTA(true);
      let _tempStateLicenseRemoved = providerStateLicenseObj
        .filter((v) => v.UpdateType != 'Add')
        .map((lic) => {
          if (lic.Id == licenceObj.Id) {
            return { ...lic, UpdateType: 'Delete' };
          } else {
            return lic;
          }
        });
      let _tempStateLicenseAdded = providerStateLicenseObj.filter((v) => v.UpdateType == 'Add');
      setTempAddedLic([..._tempStateLicenseAdded]);
      // setProviderStateLicenseObj(_tempStateLicenseRemoved);
      let payload = {
        Degree: providerDegreeObj.Degree,
        ProviderId: credentialJson.ProviderId,
        StateLicenses: _tempStateLicenseRemoved
      };
      _updateCredentials(payload);
      toggleModalDelete(false);
    }
  };

  const _updateCredentials = async (data) => {
    let _promises = [];
    _promises.push(service.post(`/api/provider/update-credentials`, data));
    const _result = await Promise.allSettled(_promises);
    if (_result.every((res) => res.status === 'fulfilled')) {
      let totalCredentialsJson = _result[0].value.ReturnData;
      let _tempCredentialsInfo = {
        ...providerProfileInfo,
        CredentialJson: totalCredentialsJson
      };
      setProviderStateLicenseObj([
        ...JSON.parse(totalCredentialsJson).StateLicenses,
        ...temAddedLic
      ]);
      dispatch(actions.loadProviderProfileData(_tempCredentialsInfo, false));
      trackingService.editPageTracking('provider', 'save', 'credentials');
      toaster.Success('Success');
      props.bannerChangeHandler(providerDegreeObj.Degree, providerInformation);
    } else {
      toaster.Error('Some error occurred, please try again!!');
    }
    setSpinnerVisibility(false);
  };

  const closeModal = () => {
    toggleModalDelete(false);
  };

  //effects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'credentials');
  }, []);

  useEffect(() => {
    let credentialJson = JSON.parse(providerProfileInfo.CredentialJson);
    let licArr = [];
    licArr = credentialJson.StateLicenses.map((lic) => ({
      ...lic,
      Id: lic.Id,
      StateName: lic.StateName,
      Text: lic.StateName,
      UpdateType: lic.UpdateType
    }));
    UPDATE_INIT_STATE_DEG({ ProviderId: credentialJson.ProviderId, Degree: credentialJson.Degree });
    UPDATE_INIT_STATE_LIC([...licArr, ...temAddedLic]);
    setProviderDegreeObj({ ProviderId: credentialJson.ProviderId, Degree: credentialJson.Degree });
    setProviderStateLicenseObj([...licArr, ...temAddedLic]);
    temAddedLic.length == 0 ? setDisableCTA(true) : setDisableCTA(false);
  }, [providerProfileInfo]);

  //useEffect for updates in --general-info-degree ---should update here
  useEffect(() => {
    let updatedDegreeValue =
      displayName != undefined || displayName != null
        ? displayName.split(',')[1] != undefined
          ? displayName.split(',')[1].trim()
          : ''
        : providerDegreeObj.Degree;
    UPDATE_INIT_STATE_DEG({
      ProviderId: credentialJson.ProviderId,
      Degree: updatedDegreeValue
    });
    setProviderDegreeObj((prev) => ({
      ...prev,
      Degree: updatedDegreeValue.trim()
    }));
    setDisableCTA(true);
  }, [displayName]);

  
  return (
    <section id='provider-profile-credentials-section'>
      <LayoutInfo
        identifier='provider-profile-credentials'
        title='Add your academic degree or certification'
        description={info.STAT_CRED}
        bullets={{ title: 'Missing Fields', data: [] }}>
        {/* Degree */}
        <AutoSuggest
          id='provider-profile-credentials-degree'
          label='Degree'
          name='degree'
          placeholder='Add Degree'
          initialValue={providerDegreeObj.Degree}
          onInputChangeHandler={degreeChangeHandler}
          data={degreeAutoSuggest}
          onSuggestSelectHandler={degreeSelectHandler}
          isSearch={true}
          value={providerDegreeObj.Degree}
          showValidationMsg={true}
          setCurrentSelection={true}
        />

        {/* State-Licence */}
        <AutoSuggest
          id='provider-profile-credentials-license'
          label='State License'
          name='state-license'
          placeholder='Add State License'
          initialValue=''
          onInputChangeHandler={licenseChangeHandler}
          data={stateLicenseAutoSuggest}
          onSuggestSelectHandler={licenseSelectHandler}
          isSearch={true}
          showValidationMsg={true}
        />
        {providerStateLicenseObj.length > 0 ? (
          <ListItems
            tagList={[...new Map(providerStateLicenseObj.map((m) => [m.Id, m])).values()].filter(
              (lang) => lang.UpdateType !== 'Delete'
            )}
            clickHandler={(e) => {
              setRemovedItemObj(e);
              e.UpdateType != 'None' ? licenseDeSelectHandler(e, true) : toggleModalDelete(true);
            }}
            currentTab='credentials'
          />
        ) : null}
      </LayoutInfo>
      <Cta
        ctaValid={_ctaValid}
        cancelText='Cancel'
        cancelClickHandler={() => {
          setProviderDegreeObj(INIT_STATE_DEG);
          setProviderStateLicenseObj(INIT_STATE_LIC);
          trackingService.editPageTracking('provider', 'cancel', 'credentials');
          setDisableCTA(true);
        }}
        confirmText='Save'
        confirmClickHandler={() => {
          setSpinnerVisibility(true);
          let payload = {
            Degree: providerDegreeObj.Degree,
            ProviderId: credentialJson.ProviderId,
            StateLicenses: providerStateLicenseObj
          };
          if (!_ctaDegreeEqual || !_ctaStateLicenseEqual || !disableCTA) {
            setTempAddedLic([]);
            _updateCredentials(payload);
          }
        }}
      />

      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
      {!isEmpty(removedItemObj) && (
        <DeleteConfirmationModelPopUp
          id={removedItemObj.Id}
          title={removedItemObj.StateName}
          buttonName='Remove State License'
          showModalDelete={showModalDelete}
          closeModal={closeModal}
          handleDeleteItem={() =>
            licenseDeSelectHandler(removedItemObj, false)
          }></DeleteConfirmationModelPopUp>
      )}
    </section>
  );
};

export default Credentials;
