import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//stylesheet import
import './_biographyCarePhilosophy.less';

//components import
import RichTextEditor from '../../Common/RichTextEditor/RichTextEditor';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import isEmpty from '../../../utils/validation/isEmpty';
import Cta from '../../Common/Form/CTA/Cta';
import Tip from '../TrustedPartners/Tip';

//helper
import * as constants from '../TrustedPartners/Constants';

const BiographyCarePhilosophy = (props) => {
  const { info, onTabsChangeHandler } = props;
  // setup
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const aboutMeJson = JSON.parse(providerProfileInfo.AboutMeJson);
  const dispatch = useDispatch();

  const [newBio, setNewBio] = useState('');
  const [newCare, setNewCare] = useState('');
  const [newContext, setNewContext] = useState('');
  const [newCareContext, setNewCareContext] = useState('');
  const [actualLength, setActualLength] = useState(0);
  const [actualLengthCare, setActualLengthCare] = useState(0);
  const [_ctaValid, set_ctaValid] = useState('');

  //states
  const [INIT_STATE, UPDATE_INIT_STATE] = useState({
    ProviderId: aboutMeJson.ProviderId,
    AboutMeList: [
      {
        HasText: aboutMeJson.AboutMeList[0].HasText,
        MaxCharacters: aboutMeJson.AboutMeList[0].MaxCharacters,
        SectionText: aboutMeJson.AboutMeList[0].SectionText.replace(
          /[\u200B-\u200D\uFEFF|﻿]/g,
          ''
        ),
        SectionType: aboutMeJson.AboutMeList[0].SectionType
      },
      {
        HasText: aboutMeJson.AboutMeList[1].HasText,
        MaxCharacters: aboutMeJson.AboutMeList[1].MaxCharacters,
        SectionText: aboutMeJson.AboutMeList[1].SectionText.replace(
          /[\u200B-\u200D\uFEFF|﻿]/g,
          ''
        ),
        SectionType: aboutMeJson.AboutMeList[1].SectionType
      }
    ]
  });
  const [providerBioCareObj, updateProviderBioCareObj] = useState(INIT_STATE.AboutMeList);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [disableCTA, setDisableCTA] = useState(true);

  const [careErrorMessage, setCareErrorMessage] = useState('');
  const [bioErrorMessage, setBioErrorMessage] = useState('');
  const [showError, setShowError] = useState(undefined);

  const extractText = (content) => {
    const span = document.createElement('span');
    span.innerHTML = content;
    return (span.textContent || span.innerText).replace(/[\u200B-\u200D\uFEFF]/g, '');
  };

  providerBioCareObj.map((item) => {
    if (item.SectionText === '<p><br></p>') item.SectionText = '';
  });

  // CTA enable/disable
  const _ctaBioEqual =
    !isEmpty(aboutMeJson.AboutMeList) && !isEmpty(providerBioCareObj)
      ? (newBio.localeCompare(aboutMeJson.AboutMeList[0].SectionText.replace(/[\u200B-\u200D\uFEFF|﻿]/g, ''))== 0? true:false)
      : false;
  const _ctaCareEqual =
    !isEmpty(aboutMeJson.AboutMeList) && !isEmpty(providerBioCareObj)
      ? (newCare.localeCompare(aboutMeJson.AboutMeList[1].SectionText.replace(/[\u200B-\u200D\uFEFF|﻿]/g, ''))== 0? true: false)
      : false;
  


  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const changeContentHandler = (content, section) => {
    content = content.replace('<p>﻿<br></p>', '');
    let newContent = extractText(content);
    let len = newContent.length;
    if (section === 'bio') {
      setBioErrorMessage('');
      setActualLength(len);
      setNewContext(
        newContent != undefined ? newContent.replace(/[\u200B-\u200D\uFEFF|﻿]/g, '') : null
      );
    } else if (section === 'care') {
      setCareErrorMessage('');
      setActualLengthCare(len);
      setNewCareContext(
        newContent != undefined ? newContent.replace(/[\u200B-\u200D\uFEFF|﻿]/g, '') : null
      );
    }
  };

  const updateError = (type, message) => {
    const error_message = 'Embed tags, Hyper link are not allowed.';
    if (type == 'care')
      setCareErrorMessage(message != undefined && message != '' ? message : error_message);
    else setBioErrorMessage(message != undefined && message != '' ? message : error_message);

    setSpinnerVisibility(false);
  };

  const updateProviderBioCare = async () => {
    let bioCont = newBio;
    let careCont = newCare;
    bioCont = bioCont.toString().replace('<p>﻿<br></p>', '').replace(
      /[\u200B-\u200D\uFEFF|﻿]/g,
      '');
    careCont = careCont.toString().replace('<p>﻿<br></p>', '').replace(
      /[\u200B-\u200D\uFEFF|﻿]/g,
      '');
    let Payload = {
      ProviderId: aboutMeJson.ProviderId,
      AboutMeList: [
        {
          HasText: aboutMeJson.AboutMeList[0].MaxCharacters != 4000,
          MaxCharacters: aboutMeJson.AboutMeList[0].MaxCharacters,
          SectionText: bioCont,
          SectionType: aboutMeJson.AboutMeList[0].SectionType
        },
        {
          HasText: aboutMeJson.AboutMeList[1].MaxCharacters != 1000,
          MaxCharacters: aboutMeJson.AboutMeList[1].MaxCharacters,
          SectionText: careCont,
          SectionType: aboutMeJson.AboutMeList[1].SectionType
        }
      ]
    };
    

    if (!_ctaBioEqual || !_ctaCareEqual) {
      service
        .post('/api/provider/update-aboutme', Payload)
        .then((res) => {
          if (res.Success) {
            setBioErrorMessage('');
            setCareErrorMessage('');
            setShowError(false);
          } else {
            setShowError(true);
            if (e.SectionName == 'About'){
              updateError('bio', e.IsError ? e.ErrorMessage : '');
            }            
            else {
              updateError('care', e.IsError ? e.ErrorMessage : '');
            }
          }
        })
        .catch((e) => {
          setShowError(true);
          if (e.SectionName == 'About'){
            updateError('bio', e.IsError ? e.ErrorMessage : '');
          }            
          else {
            updateError('care', e.IsError ? e.ErrorMessage : '');
          }
        })
        .finally(() => {});
    }

    let combinedJson = aboutMeJson;
    let _tempObject = {};
    if (_ctaValid == 'valid') {
      _tempObject = {
        ...aboutMeJson,
        AboutMeList: [
          {
            HasText: newBio.length > 0,
            MaxCharacters: 4000,
            SectionText: newBio,
            SectionType: 'About'
          },
          {
            HasText: newCare.length > 0,
            MaxCharacters: 1000,
            SectionText: newCare,
            SectionType: 'CarePhilosophy'
          }
        ]
      };
      combinedJson = JSON.stringify(_tempObject);
    }
    UPDATE_INIT_STATE(_tempObject);
    let _tempAboutMeJson = {
      ...providerProfileInfo,
      AboutMeJson: combinedJson
    };
    dispatch(actions.loadProviderProfileData(_tempAboutMeJson, false));
    setDisableCTA(true);
    trackingService.editPageTracking('provider', 'save', 'biographycarephilosophy');
  };

  const cancelHandler = () => {
    let elem1 = document.getElementById('div-provider-profile-biography');
    let elem2 = document.getElementById('div-provider-profile-care-philosophy');
    if (elem1 != undefined && elem2 != undefined) {
      elem1.getElementsByClassName('jodit-wysiwyg')[0].innerHTML =
        providerBioCareObj[0].SectionText;
      elem2.getElementsByClassName('jodit-wysiwyg')[0].innerHTML =
        providerBioCareObj[1].SectionText;
    }
    trackingService.editPageTracking('provider', 'cancel', 'biographycarephilosophy');
    setDisableCTA(true);
    set_ctaValid('');
  };

  const onTabsChangeHandlerForBioAndCare = (selectedTab) => {
    onTabsChangeHandler(selectedTab);
  };

  //effects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'biographycarephilosophy');
  }, []);

  useEffect(() => {
    let elem1 = document.getElementById('div-provider-profile-biography');
    let elem2 = document.getElementById('div-provider-profile-care-philosophy');

    if (elem1 != null && elem1.getElementsByClassName('jodit-workplace')[0] != null) {
      let len =
        elem1.getElementsByClassName('jodit-workplace')[0].innerText == '﻿\n' ||
        elem1.getElementsByClassName('jodit-workplace')[0].innerText == ' ﻿\n'
          ? 0
          : elem1.getElementsByClassName('jodit-workplace')[0].innerText.length;
      setNewBio(
        elem1.getElementsByClassName('jodit-wysiwyg')[0] != undefined
          ? elem1
              .getElementsByClassName('jodit-wysiwyg')[0]
              .innerHTML.replace(/<\/?span[^>]*>/g, '')
          : newBio != undefined
          ? newBio.replace(/[\u200B-\u200D\uFEFF|﻿]/g, '')
          : ''
      );
      setActualLength(len);
    }
    if (elem2 != null && elem2.getElementsByClassName('jodit-workplace')[0] != null) {
      let len2 =
        elem2.getElementsByClassName('jodit-workplace')[0].innerText == '﻿\n' ||
        elem2.getElementsByClassName('jodit-workplace')[0].innerText == ' ﻿\n'
          ? 0
          : elem2.getElementsByClassName('jodit-workplace')[0].innerText.length;
      setNewCare(
        elem2.getElementsByClassName('jodit-wysiwyg')[0] != undefined
          ? elem2
              .getElementsByClassName('jodit-wysiwyg')[0]
              .innerHTML.replace(/<\/?span[^>]*>/g, '')
          : newCare != undefined
          ? newCare.replace(/[\u200B-\u200D\uFEFF|﻿]/g, '')
          : ''
      );
      setActualLengthCare(len2);
    }
  });

  useEffect(() => {
    let aboutMeJson = JSON.parse(providerProfileInfo.AboutMeJson);
    UPDATE_INIT_STATE({
      ...aboutMeJson,
      AboutMeList: providerBioCareObj.map((obj) => {
        return {
          HasText: obj.HasText,
          MaxCharacters: obj.MaxCharacters,
          SectionText: obj.SectionText,
          SectionType: obj.SectionType
        };
      })
    });
  }, [providerProfileInfo]);

  //For disable CTA -Exceeding limit
  useEffect(() => {
    providerBioCareObj
      .filter((val) => val.SectionType == 'About')
      .map((i) =>
        i.MaxCharacters - actualLength >= 0 ? setDisableCTA(false) : setDisableCTA(true)
      );
    providerBioCareObj
      .filter((val) => val.SectionType == 'CarePhilosophy')
      .map((i) =>
        i.MaxCharacters - actualLengthCare >= 0 ? setDisableCTA(false) : setDisableCTA(true)
      );
  }, [actualLength, actualLengthCare]);

  useEffect(() => {
    if (showError != undefined && !showError) {
      toaster.Success('content updated successfully!.');
      setShowError(undefined);
    }
    setSpinnerVisibility(false);
  }, [showError]);

  useEffect(() => {
    if ((_ctaBioEqual && _ctaCareEqual) || disableCTA){
      set_ctaValid('');   
    } else{
      set_ctaValid('valid');        
    };
  });
   
  return (
    <section id='provider-profile-biography-and-carephilosophy-section'>
      <>
        <LayoutInfo
          identifier='provider-profile-biography'
          title='Biography'
          description={info.STAT_BIO}
          bullets={{
            title: 'Missing Fields',
            data: []
          }}>
          {providerBioCareObj
            .filter((val, idx) => val.SectionType == 'About')
            .map((i, index) => (
              <RichTextEditor
                key={index}
                maxLength={i.MaxCharacters}
                defaultContent={
                  newContext.length != 0
                    ? newContext.toString().replace('<p><br></p>', '')
                    : i.SectionText.toString().replace('<p><br></p>', '')
                }
                actualLength={actualLength}
                changeContentHandler={(e) => {
                  changeContentHandler(e, 'bio');
                }}
                errorMessage={newContext != '' ? bioErrorMessage : ''}
              />
            ))}
        </LayoutInfo>

        <Tip
          currentTip='outcare'
          onTabsChangeHandler={onTabsChangeHandlerForBioAndCare}
          content={constants.outcareHealthTip}
          infoObj={providerProfileInfo.NavigationModel}
        />

        <LayoutInfo
          identifier='provider-profile-care-philosophy'
          title='Care Philosophy'
          description={info.STAT_CARE}
          bullets={{
            title: 'Missing Fields',
            data: []
          }}>
          {providerBioCareObj
            .filter((val, idx) => val.SectionType == 'CarePhilosophy')
            .map((i, index) => (
              <RichTextEditor
                key={index}
                maxLength={i.MaxCharacters}
                defaultContent={
                  newCareContext.length != 0
                    ? newCareContext.toString().replace('<p><br></p>', '')
                    : i.SectionText.toString().replace('<p><br></p>', '')
                }
                actualLength={actualLengthCare}
                changeContentHandler={(e) => {
                  changeContentHandler(e, 'care');
                }}
                errorMessage={newCareContext != '' ? careErrorMessage : ''}
              />
            ))}
        </LayoutInfo>
      </>
      <>
        <Cta
          ctaValid={_ctaValid}
          cancelText='Cancel'
          cancelClickHandler={cancelHandler}
          confirmText='Save'
          confirmClickHandler={() => {
            setSpinnerVisibility(true);
            updateProviderBioCare();
          }}
        />

        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </section>
  );
};

export default BiographyCarePhilosophy;
