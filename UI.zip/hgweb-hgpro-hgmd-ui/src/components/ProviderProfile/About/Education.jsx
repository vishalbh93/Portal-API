import React, { useState, useEffect, Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//stylesheet import
import './_education.less';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//components import
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import EducationCard from './EducationCard';
import Toast from '../../Common/Toast/Toast';
import Cta from '../../Common/Form/CTA/Cta';

//helper
import _ from 'lodash';

const Education = (props) => {
  const { info, windowDimensions } = props;
  // setup
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const educationJson = JSON.parse(providerProfileInfo.EducationJson);
  const dispatch = useDispatch();

  //states
  const [INIT_STATE, UPDATE_INIT_STATE] = useState({
    ProviderId: educationJson.ProviderId,
    Educations: educationJson.Educations.map((edu) => ({
      EducationType: edu.EducationType,
      Title: edu.Title,
      Institutions: edu.Institutions.map((inst) => ({
        Name: inst.Name,
        Year: inst.Year,
        OriginalYear: inst.OriginalYear,
        UpdateType: inst.UpdateType
      })),
      TempInstitutions: []
    }))
  });
  const [providerEducationObj, setProviderEducationObj] = useState(INIT_STATE);

  const [tempEducationObj, setTempEducationObj] = useState({
    ProviderId: educationJson.ProviderId,
    Educations: educationJson.Educations.map((edu) => ({
      EducationType: edu.EducationType,
      Title: edu.Title,
      Institutions: edu.Institutions.map((inst) => ({
        Name: inst.Name,
        Year: inst.Year,
        OriginalYear: inst.OriginalYear,
        UpdateType: inst.UpdateType
      }))
    }))
  });
  const [educationAutoSuggest, setEducationAutoSuggest] = useState([]);
  const [autosuggestInput, setAutosuggestInput] = useState('');
  const [show, setShow] = useState({ name: '', val: false });
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [temInstituteObj, setTemInstituteObj] = useState({});
  const [isSelectedFromSuggessions, setIsSelectedFromSuggessions] = useState(false);
  const [validFreeText, setValidFreeText] = useState(false);
  const [currentText, setCurrentText] = useState('');
  const [medicalToggleSelected, setMedicalToggleSelected] = useState(true);
  let tempArr = [];

  const _ctaValid = !providerEducationObj.Educations.every(
    (edu) =>
      edu.TempInstitutions.length === 0 &&
      edu.Institutions.every((ins) => ins.UpdateType === 'None')
  );
  const [inputValue, setInputValue] = useState({ type: '', value: '' });

  //Functions
  const educationChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    setCurrentText(value);
    let isValid =
      _.some(event.target.value, (char) => /\d/.test(char)) || event.target.value.length > 90;
    setValidFreeText(isValid);
    setAutosuggestInput(event.target.name);
    setShow({ ...show, name: event.target.name });
    setIsSelectedFromSuggessions(false);
    if (value.length == 0) {
      setTempEducationObj(INIT_STATE);
      setEducationAutoSuggest([]);
    }
    if (value.trim().length > 0) {
      service
        .get(`/api/autosuggest?term=${value}&type=Education`)
        .then((res) => {
          let _tempEduData =
            res.length > 0
              ? res.map((e) => {
                  let eduIndex = providerEducationObj.Educations.findIndex(
                    (edu) => edu.EducationType === autosuggestInput
                  );
                  return {
                    ...e,
                    Disabled:
                      providerEducationObj.Educations[eduIndex].Institutions.some(
                        (ins) => ins.Name.toLowerCase() === e.Text.toLowerCase()
                      ) ||
                      providerEducationObj.Educations[eduIndex].TempInstitutions.some(
                        (ins) => ins.Name.toLowerCase() === e.Text.toLowerCase()
                      )
                  };
                })
              : [];
          res.length == 0 ? setShow({ ...show, val: true }) : '';
          setEducationAutoSuggest(_tempEduData);
        })
        .catch((err) => {});
    } else {
      setEducationAutoSuggest([]);
      setAutosuggestInput('');
    }
  };

  const educationSelectHandler = (instituteObj) => {
    setValidFreeText(true);
    setTemInstituteObj(instituteObj);
    setIsSelectedFromSuggessions(true);
    setEducationAutoSuggest([]);
  };

  const yearHandler = (yr) => {
    let arr = document.querySelectorAll('input');
    for (var i = 0; i < arr.length; i++) {
      arr[i].value != '' ? tempArr.push(arr[i].value) : null;
    }
    tempEducationObj.Educations.map((i) => {
      if (i.EducationType == inputValue.type)
        i.Institutions.map((inst) => {
          inst.Name === tempArr[0] ? (inst.Year = yr.val) : null;
        });
    });
  };

  const cancelHandler = () => {
    setProviderEducationObj(INIT_STATE);
    setShow({ name: '', val: false });
    setInputValue({ type: '', value: '' });
    clearFields();
  };

  const clearFields = () => {
    var elements = document.getElementsByTagName('input');
    for (var i = 0; i < elements.length; i++) {
      if (elements[i].type == 'text' || elements[i].type == 'number') {
        elements[i].value = '';
      }
    }
    setInputValue({ type: '', value: '' });
  };

  const onOtherThanListHandler = (val) => {
    setInputValue({ type: autosuggestInput, value: val[0].Id });
    !isSelectedFromSuggessions ? setTemInstituteObj(val[0]) : null;
  };

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  const addSelectedInstitute = () => {
    let tempEducations = providerEducationObj.Educations.map((education) => {
      if (education.EducationType == autosuggestInput) {
        let tempInstitutions = [...education.TempInstitutions];
        tempInstitutions.push({
          Name: temInstituteObj.Id,
          OriginalYear: null,
          UpdateType: 'Add',
          Year: !_.isEmpty(tempArr) ? tempArr[tempArr.length - 1] : null, //_.isEmpty(tempArr) ? null : tempArr.length > 1 ? tempArr[tempArr.length - 1] : null,
          justAdded: true
        });
        return {
          ...education,
          TempInstitutions: tempInstitutions
        };
      } else return { ...education };
    });
    setProviderEducationObj({
      ...providerEducationObj,
      Educations: tempEducations
    });
    clearFields();
  };

  const removeInstituteHandler = (instObj, eduType, isTemp) => {
    if (isTemp) {
      let tempEducations = providerEducationObj.Educations.map((education) => {
        if (education.EducationType == eduType) {
          let tempInstitutions = education.TempInstitutions.filter(
            (ins) => ins.Name !== instObj.Name
          );
          return {
            ...education,
            TempInstitutions: tempInstitutions
          };
        } else return { ...education };
      });
      setProviderEducationObj({
        ...providerEducationObj,
        Educations: tempEducations
      });
    } else {
      let tempEducations = providerEducationObj.Educations.map((education) => {
        if (education.EducationType == eduType) {
          let institutions = education.Institutions.map((ins) => {
            if (ins.Name === instObj.Name) {
              return {
                ...ins,
                UpdateType: ins.UpdateType === 'Delete' ? 'None' : 'Delete'
              };
            } else {
              return { ...ins };
            }
          });
          return {
            ...education,
            Institutions: institutions
          };
        } else return { ...education };
      });
      setProviderEducationObj({
        ...providerEducationObj,
        Educations: tempEducations
      });
    }
  };

  const updateEducation = async () => {
    let formattedEducations = providerEducationObj.Educations.map((edu) => {
      return {
        EducationType: edu.EducationType,
        Institutions: [...edu.Institutions, ...edu.TempInstitutions],
        Title: edu.Title
      };
    });
    let payload = {
      ProviderId: providerEducationObj.ProviderId,
      Educations: formattedEducations
    };

    service._post('/api/provider/update-education', payload, true).then((res) => {
      if (res.status === 200) {
        let data = res.data;
        let returnData = data.ReturnData;
        let _tempProviderProfileInfo = {
          ...providerProfileInfo,
          EducationJson: returnData
        };
        dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
        setShow({ name: '', val: false });
        toaster.Success('Success');
      } else {
        toaster.Error('Some error occurred, please try again!!');
      }
    });
  };

  const setToogle = (val) => {
    setMedicalToggleSelected(val);
  };

  //effects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'education');
  }, []);

  useEffect(() => {
    let _updatedEducationJson = JSON.parse(providerProfileInfo.EducationJson);
    let obj = {
      ProviderId: _updatedEducationJson.ProviderId,
      Educations: _updatedEducationJson.Educations.map((edu) => ({
        EducationType: edu.EducationType,
        Title: edu.Title,
        Institutions: edu.Institutions.map((inst) => ({
          Name: inst.Name,
          Year: inst.Year,
          OriginalYear: inst.OriginalYear,
          UpdateType: inst.UpdateType
        })),
        TempInstitutions: []
      }))
    };
    UPDATE_INIT_STATE(obj);
  }, [providerProfileInfo]);

  useEffect(() => {
    setTempEducationObj(INIT_STATE);
    setProviderEducationObj(INIT_STATE);
  }, [INIT_STATE]);

  useEffect(() => {
    let isValid =
      !(_.some(currentText, (char) => /\d/.test(char)) || currentText.length > 90) &&
      (medicalToggleSelected ? isSelectedFromSuggessions : true);
    setValidFreeText(isValid);
  }, [isSelectedFromSuggessions, currentText]);

  return (
    <section id='provider-profile-education-section'>
      <LayoutInfo
        identifier='provider-profile-education-container'
        title='Add Education'
        description={info.STAT_EDU}
        bullets={{ title: '', data: [] }}></LayoutInfo>

      {educationJson != null &&
        providerEducationObj.Educations.map((val, idx) => (
          <Fragment key={idx}>
            <EducationCard
              EducationType={val.EducationType}
              Name={val.Title.replaceAll(/\s/g, '')}
              Title={val.Title}
              Institutions={val.Institutions}
              TempInstitutions={val.TempInstitutions}
              educationChangeHandler={educationChangeHandler}
              educationAutoSuggest={educationAutoSuggest}
              educationSelectHandler={educationSelectHandler}
              show={show}
              inputValue={inputValue}
              addSelectedInstituteHandler={addSelectedInstitute}
              removeInstitute={removeInstituteHandler}
              yearHandler={yearHandler}
              windowDimensions={windowDimensions}
              onOtherThanListHandler={onOtherThanListHandler}
              validFreeText={validFreeText}
              setToogle={setToogle}
            />
          </Fragment>
        ))}
      {/* <hr /> */}
      <Cta
        ctaValid={_ctaValid}
        cancelText='Cancel'
        cancelClickHandler={cancelHandler}
        confirmText='Save'
        confirmClickHandler={updateEducation}
      />

      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </section>
  );
};

export default Education;
