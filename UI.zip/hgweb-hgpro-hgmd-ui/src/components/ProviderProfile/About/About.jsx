import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

//Component imports
import LayoutA from '../../Common/Layouts/LayoutA';
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import BiographyCarePhilosophy from './BiographyCarePhilosophy';
import Credentials from './Credentials';
import Education from './Education';

//styling imports
import './_about.less';

//helper
import isEmpty from '../../../utils/validation/isEmpty';

const About = (props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const educationJson = JSON.parse(providerProfileInfo.EducationJson);
  const credentialJson = JSON.parse(providerProfileInfo.CredentialJson);
  const aboutMeJson = JSON.parse(providerProfileInfo.AboutMeJson);
  const content = providerProfileInfo.Content;
  const staticContent = {
    STAT_BIO: content.BiographyContent,
    STAT_CARE: content.CarePhilosophyContent,
    STAT_EDU: content.EducationContent,
    STAT_CRED: content.DegreeContent
  };

  const [isBioCareMissing, setIsBioCareMissing] = useState(
    (!aboutMeJson.AboutMeList[0].HasText ||
      aboutMeJson.AboutMeList[0].SectionText == '' ||
      aboutMeJson.AboutMeList[0].SectionText == '<p>﻿<br></p>') &&
      (!aboutMeJson.AboutMeList[1].HasText ||
        aboutMeJson.AboutMeList[1].SectionText == '' ||
        aboutMeJson.AboutMeList[1].SectionText == '<p>﻿<br></p>')
  );
  const [isCredMissing, setIsCredMissing] = useState(
    credentialJson.MissingData || credentialJson.StateLicenses.length === 0
  );

  const [isEducationMissing, setIsEducationMissing] = useState(false);

  const educationTypes = ['UNDUNI', 'MEDSCH', 'RESIDE', 'INTERN'];

  const educationMissingCount = () => {
    let count = 0;
    educationTypes.map((item) => {
      let edu = educationJson.Educations.find((ed) => ed.EducationType === item);

      if (edu.EducationType === item && edu.Institutions.length > 0) {
        let ins = edu.Institutions.filter((inst) => inst.Year !== null && inst.Year !== '');
        if (ins.length === 0) count = count + 1;
      } else if (edu.Institutions.length === 0) {
        count = count + 1;
      }
    });
    return count;
  };

  const navTabData = [
    {
      label: 'Biography & Care Philosophy',
      badgeEnabled: isBioCareMissing,
      value: 'biography&carephilosophy'
    },
    {
      label: 'Education',
      badgeEnabled: isEducationMissing,
      value: 'education'
    },
    {
      label: 'Credentials',
      badgeEnabled: isCredMissing,
      value: 'credentials'
    }
  ];
  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);

  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
    props.onTabsChangeHandler(tab.value);
  };

  const onTabsChangeHandlerForBioCare = (selctionFor) => {
    props.onTabsChangeHandler(selctionFor);
  };

  // jsx constant(s)
  const _header = (
    <NavTabs
      tabs={navTabData}
      onSelectHandler={tabSelectionhandler}
      selectedTab={currentSelection}
    />
  );
  const _footer = <></>;
  const _main = (selection) => {
    switch (selection) {
      case 'Biography & Care Philosophy':
        return (
          <BiographyCarePhilosophy
            info={staticContent}
            onTabsChangeHandler={onTabsChangeHandlerForBioCare}
          />
        );
      case 'Education':
        return <Education info={staticContent} windowDimensions={props.windowDimensions} />;
      case 'Credentials':
        return (
          <Credentials
            info={staticContent}
            bannerChangeHandler={props.bannerChangeHandler}
            displayName={props.bannerDisplayName}
          />
        );
      default:
        break;
    }
  };

  //useEffects
  useEffect(() => {
    setIsEducationMissing(educationMissingCount() == 0 ? false : true);
  }, []);
  useEffect(() => {
    let currSel = navTabData.filter((e) =>
      e.value.toLowerCase().includes(props.selectTab.toLowerCase())
    )[0];
    if (currSel != undefined) setCurrentSelection(currSel);
    else setCurrentSelection(navTabData[0]);
  }, [props.selectTab]);

  useEffect(() => {
    let credentialJson = JSON.parse(providerProfileInfo.CredentialJson);
    let educationJson = JSON.parse(providerProfileInfo.EducationJson);
    let aboutMeJson = JSON.parse(providerProfileInfo.AboutMeJson);

    setIsCredMissing(credentialJson.StateLicenses.length === 0);
    setIsEducationMissing(educationMissingCount() == 0 ? false : true);
    setIsBioCareMissing(
      (!aboutMeJson.AboutMeList[0].HasText ||
        aboutMeJson.AboutMeList[0].SectionText == '' ||
        aboutMeJson.AboutMeList[0].SectionText == '<p>﻿<br></p>') &&
        (!aboutMeJson.AboutMeList[1].HasText ||
          aboutMeJson.AboutMeList[1].SectionText == '' ||
          aboutMeJson.AboutMeList[1].SectionText == '<p>﻿<br></p>')
    );
  }, [providerProfileInfo]);

  return (
    <LayoutA identifier='provider-profile-about' header={_header} footer={_footer}>
      <div id='div-provider-profile-about-main'>{_main(currentSelection.label)}</div>
    </LayoutA>
  );
};

About.defaultProps = {
  selectTab: 'biography&carephilosophy'
};

About.propTypes = {};

export default About;
