import React, { useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//components import
import AutoSuggestWithCheckbox from '../../Common/Layouts/AutoSuggestWithCheckbox';
import Toast from '../../Common/Toast/Toast';
import ReactModal from 'react-modal';
import Cta from '../../Common/Form/CTA/Cta';

//svg imports
import Close from '../../../assets/images/ProviderProfile/svg-cross.svg';

//styling imports
import './_insuranceCard.less';

const InsuranceCard = ({ insuranceData, insurancePlans }) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const insuranceInformation = JSON.parse(providerProfileInfo.InsuranceJson);
  const dispatch = useDispatch();

  //refs
  const _removePlanModal = useRef(null);

  //states
  const [insuranceObj, setInsuranceObj] = useState({
    PayorId: insuranceData.PayorId,
    PayorCode: insuranceData.PayorCode,
    Payor: insuranceData.Payor,
    PayorPlanCount: insuranceData.PayorPlanCount,
    UpdateType: insuranceData.UpdateType
  });

  let _tempInsurancePlans = insurancePlans.map((ins) => {
    return {
      id: ins.PlanId,
      label: ins.Plan,
      checked: false,
      obj: ins
    };
  });
  const [currentInsurancePlans, setCurrentInsurancePlans] = useState(_tempInsurancePlans);
  const [insurancePlanAutoSuggestData, setInsurancePlanAutoSuggestData] = useState([]);
  const [insurancePlanSearchText, setInsurancePlanSearchText] = useState('');

  const [showRemovePlanModal, setShowRemovePlanModal] = useState(false);

  const [notifyProperties, setNotifyProperties] = useState([]);

  //event handlers
  const handleCheckboxClick = (option, checked) => {
    let _tempCurrentInsurancePlans = currentInsurancePlans.map((ins) => {
      return ins.id == option.id ? { ...ins, checked: checked } : { ...ins };
    });
    setCurrentInsurancePlans(_tempCurrentInsurancePlans);
  };

  const handleDeleteClick = () => {
    let _tempInsurance = insuranceInformation.Insurance;

    let payload = {
      Insurance: _tempInsurance.map((ins) => {
        if (ins.PayorId == insuranceObj.PayorId) return { ...ins, UpdateType: 'Delete' };
        else {
          return { ...ins };
        }
      }),
      ProviderId: insuranceInformation.ProviderId
    };
    updateInsurancePlans(payload);
  };

  const removeSelectedPlans = () => {
    let _tempInsurance = insuranceInformation.Insurance;
    let currentInsuranceIndex = _tempInsurance.findIndex((i) => insuranceObj.PayorId == i.PayorId);

    _tempInsurance[currentInsuranceIndex] = {
      ..._tempInsurance[currentInsuranceIndex],
      InsurancePlans: currentInsurancePlans.map((ins) => ({
        ...ins.obj,
        UpdateType: ins.checked ? 'Delete' : 'None'
      }))
    };

    let payload = {
      Insurance: _tempInsurance,
      ProviderId: insuranceInformation.ProviderId
    };
    updateInsurancePlans(payload);
    setShowRemovePlanModal(false);
  };

  const selectedPlanCancelClickHandler = () => {
    let _tempCurrentInsurancePlans = currentInsurancePlans.map((ins) => ({
      ...ins,
      checked: false
    }));
    setCurrentInsurancePlans(_tempCurrentInsurancePlans);
  };

  //service calls
  const fetchInsurancePlans = () => {
    let payload = {
      CurrentCodes: currentInsurancePlans.map((plan) => plan.PlanId),
      ItemCode: insuranceObj.PayorCode
    };
    return service._post(`/api/autosuggest/insuranceplans`, payload, false);
  };

  const updateInsurancePlans = (payload) => {
    service._post('/api/provider/update-insurance', payload, true).then((res) => {
      if (res.status == 200) {
        let data = res.data;
        updateInsuranceInStore(data.ReturnData);
        toaster.Success('Success!');
      } else {
        let data = res.data;
        toaster.Error(data.ErrorMessage);
      }
    });
  };

  //dispatch
  const updateInsuranceInStore = (insuranceJson) => {
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      InsuranceJson: insuranceJson
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
  };

  const autosuggestOptions = {
    placeholder: 'Add Plan',
    initialValue: insurancePlanSearchText,
    data: insurancePlanAutoSuggestData,
    onInputChangeHandler: (event) => {
      if (event.currentTarget.value.trim().length > 0)
        setInsurancePlanSearchText(event.currentTarget.value);
    },
    onSuggestSelectHandler: () => {},
    setCurrentSelection: false,
    showValidationMsg: true,
    isSearch: true,
    onSaveClick: (suggestData) => {
      let _tempInsurance = insuranceInformation.Insurance;
      let currentInsuranceIndex = _tempInsurance.findIndex(
        (i) => insuranceObj.PayorId == i.PayorId
      );

      let checkedInsurancePlans = suggestData.filter((data) => data.Checked);
      _tempInsurance[currentInsuranceIndex] = {
        ..._tempInsurance[currentInsuranceIndex],
        InsurancePlans: checkedInsurancePlans.map((ins) => ({
          PlanId: ins.Id,
          Plan: ins.Name,
          UpdateType: 'Add'
        }))
      };

      let payload = {
        Insurance: _tempInsurance,
        ProviderId: insuranceInformation.ProviderId
      };
      updateInsurancePlans(payload);
      setInsurancePlanAutoSuggestData([]);
      setInsurancePlanSearchText('');
    },
    onCancelClick: () => {
      setInsurancePlanAutoSuggestData([]);
      setInsurancePlanSearchText('');
    },
    buttonNames: ['Save', 'Cancel']
  };

  const ctaOptions = {
    isVisibile:
      currentInsurancePlans.length > 0 && currentInsurancePlans.some((ins) => ins.checked),
    ctaValid: currentInsurancePlans.some((ins) => ins.checked),
    cancelText: 'Cancel',
    cancelClickHandler: selectedPlanCancelClickHandler,
    confirmText: 'Remove Plan',
    confirmClickHandler: () => setShowRemovePlanModal(true)
  };

  //jsx
  const _removeModalJSX = () => {
    let plansToRemove = currentInsurancePlans.filter((ins) => ins.checked);
    let strRemoveMessage = '';
    if (plansToRemove.length === 1) {
      strRemoveMessage = `<span style="text-align: center;">Are you sure, you want to remove <br/><strong>${plansToRemove[0].label}</strong> from ${insuranceObj.Payor}?</span>`;
    } else if (plansToRemove.length > 1) {
      strRemoveMessage = `<span>Are you sure, you want to remove the following Insurance Plans?</span>`;
      strRemoveMessage = strRemoveMessage.concat('<div><ul>');
      plansToRemove.forEach((ins) => {
        strRemoveMessage = strRemoveMessage.concat(`<li>${ins.label}</li>`);
      });
      strRemoveMessage = strRemoveMessage.concat('</ul></div>');
    }
    return strRemoveMessage;
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //effects
  useEffect(() => {
    if (insurancePlanSearchText.length > 0) {
      if (insurancePlanAutoSuggestData.length === 0) {
        fetchInsurancePlans().then((res) => {
          if (res.status == 200) {
            let insurancePlans = res.data;
            setInsurancePlanAutoSuggestData(
              insurancePlans.map((plan) => ({
                ...plan,
                Id: plan.Id,
                Text: plan.Name,
                Checked: currentInsurancePlans.findIndex((cplan) => cplan.id == plan.Id) > -1
              }))
            );
          }
        });
      }
    }
  }, [insurancePlanSearchText]);

  useEffect(() => {
    let _tempInsurancePlans = insurancePlans.map((ins) => {
      return {
        id: ins.PlanId,
        label: ins.Plan,
        checked: false,
        obj: ins
      };
    });
    setCurrentInsurancePlans(_tempInsurancePlans);
  }, [insurancePlans]);

  useEffect(() => {
    setInsuranceObj({
      PayorId: insuranceData.PayorId,
      PayorCode: insuranceData.PayorCode,
      Payor: insuranceData.Payor,
      PayorPlanCount: insuranceData.PayorPlanCount,
      UpdateType: insuranceData.UpdateType
    });
  }, [insuranceData]);

  return (
    <>
      <AutoSuggestWithCheckbox
        title={`${insuranceObj.Payor}${
          currentInsurancePlans.length !== 0 ? ` (${currentInsurancePlans.length})` : ''
        }`}
        showAutoSuggestTextField={insuranceObj.PayorPlanCount !== 0}
        checkboxOptions={currentInsurancePlans}
        checkboxOptionsLimit={2}
        checkBoxInputClick={handleCheckboxClick}
        autosuggestOptions={autosuggestOptions}
        ctaOptions={ctaOptions}
        onCloseClick={handleDeleteClick}
        id={insuranceData.PayorId}
      />
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
      </>
      <ReactModal
        overlayClassName='modal-overlay modal-close-overlay'
        className='modal-dialog modal-close-dialog'
        ariaHideApp={false}
        isOpen={showRemovePlanModal}
        onAfterOpen={() =>
          _removePlanModal.current.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          })
        }
        contentLabel='Profile Photo'
        onRequestClose={() => {}}
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container' ref={_removePlanModal}>
          <div className='modal-header'>
            <h4 className='modal-title'></h4>
            <div
              className='modal-close'
              onClick={() => {
                setShowRemovePlanModal(false);
                selectedPlanCancelClickHandler();
              }}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>
          <div className='modal-body' dangerouslySetInnerHTML={{ __html: _removeModalJSX() }}></div>
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText='Cancel'
              cancelClickHandler={() => {
                setShowRemovePlanModal(false);
                selectedPlanCancelClickHandler();
              }}
              confirmText='Remove Insurance Plan'
              confirmClickHandler={removeSelectedPlans}
            />
          </div>
        </div>
      </ReactModal>
    </>
  );
};

export default InsuranceCard;
