import React, { useState, useEffect } from 'react';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//components import
import InsuranceCard from './InsuranceCard';

//styling imports
import './_insuranceCardList.less';

const InsuranceCardList = ({ insurances }) => {
  //states
  const [_insurances, setInsurances] = useState(insurances);
  const [cardsVisibilityLimit, setCardsVisibilityLimit] = useState(5);

  //jsx helpers
  const _viewMoreLess = () => {
    if (_insurances.length > 5) {
      if (cardsVisibilityLimit === 5)
        return <a onClick={() => setCardsVisibilityLimit(_insurances.length)}>View More</a>;
      else return <a onClick={() => setCardsVisibilityLimit(5)}>Show Less</a>;
    }
    return null;
  };

  useEffect(() => {
    let _tempInsurances = insurances.filter((ins) => ins.UpdateType != 'Delete');
    setInsurances(_tempInsurances);
  }, [insurances]);

  return (
    <section className='sec-insurance-list'>
      {_insurances.map((insurance, index) => {
        if (index < cardsVisibilityLimit) {
          return (
            <InsuranceCard
              key={index}
              insuranceData={insurance}
              insurancePlans={insurance.InsurancePlans}
            />
          );
        }
      })}
      {_viewMoreLess()}
    </section>
  );
};

export default InsuranceCardList;
