import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

//Component imports
import LayoutA from '../../Common/Layouts/LayoutA';
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import AddInsurance from './AddInsurance';
import InsuranceCardList from './InsuranceCardList';

//Services imports
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//styling imports
import './_insurance.less';

const Insurance = () => {

  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const insuranceInformation = JSON.parse(providerProfileInfo.InsuranceJson);

  //states
  const [insurances, setInsurances] = useState(insuranceInformation.Insurance);
  const [topInsurance, setTopInsurance] = useState(JSON.parse(providerProfileInfo.TopInsuranceJson));

  //Navigation Tabs Section Start
  const navTabData = [
    {
      label: 'Insurance',
      badgeEnabled: insuranceInformation.MissingData
    }
  ];
  // jsx constant(s)
  const _header = <NavTabs tabs={navTabData} onSelectHandler={() => {}} />;
  const _footer = <></>;

  //effects
  useEffect(() => {
    let insuranceInformation = JSON.parse(providerProfileInfo.InsuranceJson);
    setInsurances(insuranceInformation.Insurance);
  }, [providerProfileInfo]);


  return (
    <LayoutA identifier='provider-profile-insurance' header={_header} footer={_footer}>
      <div id='div-provider-profile-insurance-main'>
        <AddInsurance
          providerId={insuranceInformation.ProviderId}
          currentInsurances={insurances}
        />
        <hr />
        {insurances.length > 0 && (
          <>
            <span>Accepted Insurance:</span>
            <InsuranceCardList insurances={insurances} />
          </>
        )}
      </div>
    </LayoutA>
  );
};

Insurance.propTypes = {};

export default Insurance;
