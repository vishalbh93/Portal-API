import React, { useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//Component imports
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import AddInsuranceCardList from './AddInsuranceCardList';
import Toast from '../../Common/Toast/Toast';
import TopInsurance from '../../Common/Form/ModelPopUp/ModelPopUpWithAutoSuggest';

//Services imports
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//styling imports
import './_addInsurance.less';
import isEmpty from '../../../utils/validation/isEmpty';

const AddInsurance = ({ providerId, currentInsurances }) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const insuranceInformation = JSON.parse(providerProfileInfo.InsuranceJson);
  const dispatch = useDispatch();

  //refs
  const _div = useRef(null);

  //states
  const [currentInsuranceValue, setCurrentInsuranceValue] = useState('');
  const [selectedInsuranceArray, setSelectedInsuranceArray] = useState([]);
  const [insuranceSuggestData, setInsuranceSuggesData] = useState([]);

  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showModalPopUpTopInsurance, toggleShowModalPopUpTopInsurance] = useState(false);
  const [topInsuranceearchText, setTopInsuranceearchText] = useState('');
  const [topInsurance, setTopInsurance] = useState(
    JSON.parse(providerProfileInfo.TopInsuranceJson).map((con) => ({
      ...con,
      Id: con.PayorId,
      Text: con.Name,
      Checked: con.Selected
    }))
  );

  //service(s)
  const fetchInsuranceData = () => {
    service
      ._get(`/api/autosuggest/insurance?term=${currentInsuranceValue}`, false)
      .then((res) => {
        if (res.status == 200) {
          let data = res.data;
          let _tempInsuranceData = data.map((insurance) => ({
            Id: insurance.med_term_id,
            Text: insurance.s_query,
            Disabled:
              currentInsurances.findIndex((ins) => ins.PayorId == insurance.med_term_id) > -1 ||
              selectedInsuranceArray.findIndex((ins) => ins.Id == insurance.med_term_id) > -1,
            Obj: insurance,
            updateType: 'Add'
          }));
          setInsuranceSuggesData(_tempInsuranceData);
        }
      })
      .catch((err) => {});
  };

  const updateInsurancePlans = (payload) => {
    service._post('/api/provider/update-insurance', payload, true).then((res) => {
      if (res.status == 200) {
        let data = res.data;
        let TopInsuranceJson = updateTopInsuranceInStore(data.ReturnData);
        updateInsuranceInStore(data.ReturnData, TopInsuranceJson);
        setSelectedInsuranceArray([]);
        setTopInsuranceearchText('');
        scrollToCenter();
        trackingService.editPageTracking('provider', 'save', 'insurance');
        toaster.Success('Success!');
      } else {
        let data = res.data;
        toaster.Error(data.ErrorMessage);
      }
    });
  };

  const updateTopInsuranceInStore = (insuranceJson) => {
    let _tempInsuranceJson = JSON.parse(insuranceJson);
    let _tmpTopInsuranceJson = providerProfileInfo.TopInsuranceJson;
    let _tempTopProcedure = {
      TopInsurance: JSON.parse(_tmpTopInsuranceJson).map((topPro) => {
        return {
          ...topPro,
          Selected: _tempInsuranceJson.Insurance.find(
            (item) => item.PayorId.toLowerCase() == topPro.PayorId.toLowerCase()
          )
            ? true
            : false
        };
      })
    };
    _tmpTopInsuranceJson = JSON.stringify(_tempTopProcedure.TopInsurance);
    return _tmpTopInsuranceJson;
  };

  //dispatch
  const updateInsuranceInStore = (insuranceJson, topInsuranceJson) => {
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      InsuranceJson: insuranceJson,
      TopInsuranceJson: topInsuranceJson
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
  };

  //event handlers
  const onCurrentInsuranceChangeHandler = (event) => {
    let { value } = event.target;
    setCurrentInsuranceValue(value);
  };
  const onInsuranceSelectHandler = (insurance) => {
    setCurrentInsuranceValue('');
    if (selectedInsuranceArray.findIndex((ins) => ins.Id == insurance.Id) == -1) {
      let tempArr = [...selectedInsuranceArray, insurance];
      setSelectedInsuranceArray(
        tempArr.reduce((filtered, item) => {
          if (
            !filtered.some((filteredItem) => JSON.stringify(filteredItem) == JSON.stringify(item))
          )
            filtered.push(item);
          return filtered;
        }, [])
      );
    }
  };

  // const addBulkInsuranceToCard = (insurance) => {
  //   let selectedInsurance = insurance.filter(
  //     (i) =>
  //       selectedInsuranceArray.findIndex(
  //         (ins) => ins.Id.toLowerCase() == i.PayorId.toLowerCase()
  //       ) == -1 &&
  //       ((i.Checked == true && i.Selected == false) || (i.Checked == false && i.Selected == true))
  //   );
  //   let _tempInsuranceData = selectedInsurance.map((item) => ({
  //     Id: item.PayorId,
  //     Text: item.Name,
  //     Disabled: false,
  //     Obj: {
  //       med_term_id: item.PayorId,
  //       payor_code: item.PayorCode,
  //       payor_plan_count: item.PlanCount,
  //       s_query: item.Name
  //     },
  //     updateType: item.Checked == false && item.Selected == true ? 'Delete' : 'Add',
  //     InsurancePlans: []
  //   }));
  //   let _tmpSelectedInsuranceArray = [...selectedInsuranceArray];

  //   _tmpSelectedInsuranceArray = _tmpSelectedInsuranceArray.filter((p) =>
  //     insurance.find(
  //       (i) =>
  //         i.PayorId.toLowerCase() == p.Id.toLowerCase() &&
  //         ((i.Checked == true && i.Selected == false) || (i.Selected == true && i.Checked == false))
  //     )
  //   );

  //   let _tmpAllSelectedInsuranceArray = _tmpSelectedInsuranceArray.concat(_tempInsuranceData);

  //   setSelectedInsuranceArray(_tmpAllSelectedInsuranceArray);
  //   setTopInsuranceearchText('');
  // };

  const handleTop20SaveClick = (insurances) => {
    const _currentInsurance = insuranceInformation.Insurance;
    const _tempCheckedInsurances = insurances
      .filter(
        (ins) =>
          ins.Checked &&
          _currentInsurance.findIndex(
            (_ins) => _ins.PayorId.toLowerCase() === ins.PayorId.toLowerCase()
          ) < 0
      )
      .map((ins) => {
        return {
          InsurancePlans: [],
          Payor: ins.Name,
          PayorCode: ins.PayorCode,
          PayorId: ins.PayorId.toLowerCase(),
          PayorPlanCount: ins.PlanCount,
          UpdateType: 'Add'
        };
      });
    const _tempUnCheckedInsurances = insurances
      .filter(
        (ins) =>
          !ins.Checked &&
          _currentInsurance.findIndex(
            (_ins) => _ins.PayorId.toLowerCase() === ins.PayorId.toLowerCase()
          ) > -1
      )
      .map((ins) => {
        return {
          InsurancePlans: [],
          Payor: ins.Name,
          PayorCode: ins.PayorCode,
          PayorId: ins.PayorId.toLowerCase(),
          PayorPlanCount: ins.PlanCount,
          UpdateType: 'Delete'
        };
      });
    const mergedTop20Insurances = [..._tempCheckedInsurances, ..._tempUnCheckedInsurances];
    const insurancesNotToBeUpdated = _currentInsurance
      .filter(
        (ins) =>
          mergedTop20Insurances.findIndex(
            (_ins) => _ins.PayorId.toLowerCase() === ins.PayorId.toLowerCase()
          ) < 0
      )
      .map((ins) => {
        return {
          InsurancePlans: ins.InsurancePlans,
          Payor: ins.Payor,
          PayorCode: ins.PayorCode,
          PayorId: ins.PayorId.toLowerCase(),
          PayorPlanCount: ins.PayorPlanCount,
          UpdateType: 'None'
        };
      });

    const insurancePayloadObject = [...mergedTop20Insurances, ...insurancesNotToBeUpdated];
    const payload = {
      ProviderId: providerId,
      Insurance: insurancePayloadObject
    };

    updateInsurancePlans(payload);
  };

  const handleAddInsurance = (insurances) => {
    let _tempInsurances = insurances
      .filter((ins) => ins.updateType == 'Add')
      .map((insurance) => ({
        PayorId: insurance.Obj.med_term_id,
        PayorCode: insurance.Obj.payor_code,
        Payor: insurance.Obj.s_query,
        UpdateType: insurance.Obj.updateType,
        PayorPlanCount: insurance.Obj.payor_plan_count,
        InsurancePlans: insurance.InsurancePlans.map((plan) => ({
          PlanId: plan.Id,
          Plan: plan.Text,
          UpdateType: 'Add'
        })),
        justAdded: false
      }));
    let currentInsurance = insuranceInformation.Insurance;
    let payload = {
      ProviderId: providerId,
      Insurance: currentInsurance
        .map((ins) => {
          if (
            insurances.filter(
              (i) => i.updateType == 'Delete' && i.Id.toLowerCase() == ins.PayorId.toLowerCase()
            ).length > 0
          )
            return { ...ins, UpdateType: 'Delete' };
          else {
            return { ...ins };
          }
        })
        .concat(_tempInsurances)
    };

    updateInsurancePlans(payload);
  };

  //Top 20 ModelPopup
  const showModelPopupTopInsurance = () => {
    toggleShowModalPopUpTopInsurance(true);
  };
  const closeModalPopUpTopInsurance = () => {
    const topInsurance = JSON.parse(providerProfileInfo.TopInsuranceJson);
    setTopInsurance(
      topInsurance.map((pro) => ({
        ...pro,
        Id: pro.PayorId,
        Text: pro.Name,
        Checked: currentInsurances.find(
          (item) => item.PayorId.toLowerCase() == pro.PayorId.toLowerCase()
        )
          ? true
          : selectedInsuranceArray.find((p) => p.Id.toLowerCase() == pro.PayorId.toLowerCase())
          ? true
          : false
      }))
    );
    toggleShowModalPopUpTopInsurance(false);
  };

  const autosuggestOptions = {
    placeholder: '',
    initialValue: topInsuranceearchText,
    data: topInsurance,
    onInputChangeHandler: (event) => {
      setTopInsuranceearchText(event.currentTarget.value);
    },
    onSuggestSelectHandler: () => {},
    setCurrentSelection: false,
    showValidationMsg: true,
    isSearch: true
  };

  //scrolls
  const scrollToCenter = () => {
    _div.current.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    });
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  // topInsurance Function
  const getTopInsurances = () => {
    const topInsurance = JSON.parse(providerProfileInfo.TopInsuranceJson);
    setTopInsurance(
      topInsurance.map((pro) => ({
        ...pro,
        Id: pro.PayorId,
        Text: pro.Name,
        Checked: currentInsurances.find(
          (item) => item.PayorId.toLowerCase() == pro.PayorId.toLowerCase()
        )
          ? true
          : false
      }))
    );
  };
  //effect(s)
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'insurance');
  }, []);

  useEffect(() => {
    if (currentInsuranceValue.length > 0) fetchInsuranceData();
  }, [currentInsuranceValue]);

  useEffect(() => {
    let tempInsuranceSuggestData = insuranceSuggestData.map((insurance) => ({
      ...insurance,
      Disabled:
        currentInsurances.findIndex((ins) => ins.PayorId == insurance.Obj.med_term_id) > -1 ||
        selectedInsuranceArray.findIndex((ins) => ins.Id == insurance.Obj.med_term_id) > -1
    }));
    setInsuranceSuggesData(tempInsuranceSuggestData);
  }, [currentInsurances, selectedInsuranceArray]);

  useEffect(() => {
    getTopInsurances();
  }, [currentInsurances]);

  useEffect(() => {
    if (selectedInsuranceArray.length >= 0) {
      const topInsurance = JSON.parse(providerProfileInfo.TopInsuranceJson);
      setTopInsurance(
        topInsurance.map((pro) => ({
          ...pro,
          Id: pro.PayorId,
          Text: pro.Name,
          Checked: selectedInsuranceArray.find(
            (p) =>
              p.Id.toLowerCase() == pro.PayorId.toLowerCase() && p.updateType.toLowerCase() == 'add'
          )
            ? true
            : selectedInsuranceArray.find(
                (p) =>
                  p.Id.toLowerCase() == pro.PayorId.toLowerCase() &&
                  p.updateType.toLowerCase() == 'delete'
              )
            ? false
            : currentInsurances.find(
                (item) => item.PayorId.toLowerCase() == pro.PayorId.toLowerCase()
              )
            ? true
            : false
        }))
      );
    }
  }, [selectedInsuranceArray]);

  return (
    <>
      <div ref={_div} style={{ display: 'contents' }}></div>
      <LayoutInfo
        identifier='add-insurance'
        title='Add Insurance'
        description='List the insurance carriers you accept. Patients filter by insurance carrier. Keep your list up to date.'
        bullets={{
          title: 'Missing Fields',
          data: []
        }}>
        <AutoSuggest
          id='as-add-insurance'
          label=''
          name='asAddInsurance'
          placeholder='Add Insurance'
          initialValue=''
          onInputChangeHandler={onCurrentInsuranceChangeHandler}
          data={insuranceSuggestData}
          onSuggestSelectHandler={onInsuranceSelectHandler}
          setCurrentSelection={false}
        />
        <div className='div-choose-insurance desktop-view'>
          <span className='mobile-view right-space'>Or</span>
          <a href='#' onClick={showModelPopupTopInsurance}>
            Choose from top 20 Nationwide Carriers
          </a>
        </div>
      </LayoutInfo>
      {selectedInsuranceArray.length != 0 && (
        <AddInsuranceCardList
          selectedInsurances={selectedInsuranceArray}
          updateSelectedInsurances={setSelectedInsuranceArray}
          addInsurances={handleAddInsurance}
        />
      )}
      <TopInsurance
        id='TopInsurance'
        title='Top 20 Nationwide Carriers'
        showModalPopUp={showModalPopUpTopInsurance}
        closeModal={closeModalPopUpTopInsurance}
        autosuggestOptions={autosuggestOptions}
        onSaveClick={handleTop20SaveClick}></TopInsurance>
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </>
  );
};

export default AddInsurance;
