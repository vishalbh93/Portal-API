import React, { useState, useEffect } from 'react';

//styling imports
import './_addInsuranceCard.less';

//Component imports
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import ListItems from '../../Common/Form/AutoSuggest/ListItems';

//Services imports
import * as service from '../../../utils/service';

//media import
import Close from '../../../assets/images/ProviderProfile/svg-cross.svg';

const AddInsuranceCard = (props) => {
  const { insuranceDetails, setInsuranceDetails } = props;
  const isAddCard = insuranceDetails.updateType == 'Add' ? true : false;

  //states
  const [currentInsuranceValue, setCurrentInsuranceValue] = useState('');
  const [insurancePlans, setInsurancePlans] = useState([]);
  const [insurancePlansAutoSuggestData, setInsurancePlansAutosuggestData] = useState([]);
  const [selectedInsurancePlans, setSelectedInsurancePlans] = useState([]);

  //service(s)
  const fetchInsurancePlans = () => {
    let payload = { ItemCode: insuranceDetails.Obj.payor_code, CurrentCodes: [] };
    service
      .post(`/api/autosuggest/insuranceplans`, payload)
      .then((res) => {
        if (res.length > 0) {
          let data = res;
          let _tempInsurancePlans = data.map((insurance) => ({
            Id: insurance.Id,
            Disabled: selectedInsurancePlans.findIndex((ins) => ins.Id == insurance.Id) > -1,
            Text: insurance.Name,
            Selected: insurance.Selected
          }));
          setInsurancePlans(_tempInsurancePlans);
        }
      })
      .catch((err) => {});
  };

  //event handlers
  const onCurrentInsuranceChangeHandler = (event) => {
    let { value } = event.target;
    setCurrentInsuranceValue(value);
  };
  const onInsurancePlanSelect = (insurance) => {
    if (selectedInsurancePlans.findIndex((i) => i.Id == insurance.Id) == -1) {
      let _tempInsurancePlans = [...selectedInsurancePlans];
      let selectedInsurancePlan = insurancePlansAutoSuggestData.find((i) => i.Id == insurance.Id);
      _tempInsurancePlans.push({
        Id: selectedInsurancePlan.Id,
        Text: selectedInsurancePlan.Text,
        UpdateType: 'Add',
        Disabled: true,
        Obj: selectedInsurancePlan
      });
      setSelectedInsurancePlans(_tempInsurancePlans);
    }
    setInsurancePlansAutosuggestData([]);
  };
  const planRemoveHandler = (insurancePlanObj) => {
    let updatedInsurancePlans = selectedInsurancePlans.filter(
      (ins) => ins.Id != insurancePlanObj.Id
    );
    setSelectedInsurancePlans(updatedInsurancePlans);
  };

  //scrolls

  //effect(s)
  useEffect(() => {
    if (currentInsuranceValue.length > 1 && insurancePlans.length == 0) fetchInsurancePlans();

    let tempInsurancePlansAutoSuggestData = insurancePlans
      .filter((plans) => plans.Text.toLowerCase().includes(currentInsuranceValue.toLowerCase()))
      .map((plan) => ({
        ...plan,
        Disabled: selectedInsurancePlans.findIndex((ins) => ins.Id == plan.Id) > -1
      }));
    setInsurancePlansAutosuggestData(tempInsurancePlansAutoSuggestData);
  }, [currentInsuranceValue, selectedInsurancePlans]);

  useEffect(() => {
    let tempInsuranceObj = { ...insuranceDetails };
    tempInsuranceObj.InsurancePlans = selectedInsurancePlans;
    setInsuranceDetails(tempInsuranceObj);
  }, [selectedInsurancePlans]);

  return isAddCard ? (
    <LayoutInfo identifier='add-insurance-card' title={insuranceDetails.Text} description=''>
      <AutoSuggest
        id='as-add-insurance-card'
        label=''
        name='asAddInsurance-card'
        placeholder='Add Plan'
        initialValue=''
        onInputChangeHandler={onCurrentInsuranceChangeHandler}
        data={insurancePlansAutoSuggestData}
        onSuggestSelectHandler={onInsurancePlanSelect}
        setCurrentSelection={false}
        showValidationMsg={true}
      />
      <div className='close-card' onClick={() => props.removeCardHandler(insuranceDetails)}>
        <img className='close-icon' src={Close} alt='Close' />
      </div>
      {selectedInsurancePlans.length > 0 ? (
        <ListItems tagList={selectedInsurancePlans} clickHandler={planRemoveHandler} />
      ) : null}
    </LayoutInfo>
  ) : (
    <LayoutInfo identifier='remove-insurance-card' title={insuranceDetails.Text} description=''>
      <div className='close-card' onClick={() => props.removeCardHandler(insuranceDetails)}>
        <img className='close-icon' src={Close} alt='Close' />
      </div>
    </LayoutInfo>
  );
};

export default AddInsuranceCard;
