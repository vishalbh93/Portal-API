import React, { useState, useEffect, Fragment } from 'react';

//styling imports
import './_addInsuranceCardList.less';

//Component imports
import Cta from '../../Common/Form/CTA/Cta';
import AddInsuranceCard from './AddInsuranceCard';

const AddInsuranceCardList = ({ selectedInsurances, updateSelectedInsurances, addInsurances }) => {
  //states
  const [insurances, setInsurances] = useState(selectedInsurances);

  //event handlers
  const updateInsuranceDetails = (insuranceObj) => {
    let _tempInsurances = [...insurances];
    let objIndex = _tempInsurances.findIndex((ins) => ins.Id == insuranceObj.Id);
    objIndex == -1
      ? _tempInsurances.push(insuranceObj)
      : (_tempInsurances[objIndex] = { ...insuranceObj });
    updateSelectedInsurances(_tempInsurances);
  };
  const addInsuranceHandler = () => {
    addInsurances(insurances);
  };
  const removeCardHandler = (insurance) => {
    let tempSelectedInsurances = insurances.filter(function (el) {
      return el.Id != insurance.Id;
    });
    updateSelectedInsurances(tempSelectedInsurances);
  };

  //effects
  useEffect(() => {
    setInsurances(selectedInsurances);
  }, [selectedInsurances]);

  return (
    <div className='add-insurance-card-list' title='' description=''>
      {insurances.length != 0 ? (
        <>
          {insurances.map((card, index) => (
            <Fragment key={index}>
              <AddInsuranceCard
                insuranceDetails={card}
                setInsuranceDetails={updateInsuranceDetails}
                removeCardHandler={removeCardHandler}
              />
            </Fragment>
          ))}
          <Cta
            ctaValid={insurances.length > 0}
            cancelText='Cancel'
            cancelClickHandler={() => {
              updateSelectedInsurances([]);
            }}
            confirmText='Save'
            confirmClickHandler={addInsuranceHandler}
          />
        </>
      ) : null}
    </div>
  );
};

export default AddInsuranceCardList;
