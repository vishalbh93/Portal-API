import React, { useState, Fragment, useRef, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '../../../store/actions';
import * as service from '../../../utils/service';
import * as trackingService from '../trackingServices';

//Component imports
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import LayoutA from '../../Common/Layouts/LayoutA';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
import Button from '@hg/joy/src/components/Button';
import Toggle from '../../Common/ToggleButton/Toggle';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import CardContainer from '../../Common/CardContainer/CardContainer';
import DeleteConfirmationModelPopUp from '../../Common/DeleteConfirmationModelPopUp/DeleteConfirmationModelPopUp';
import isEmpty from '../../../utils/validation/isEmpty';

//styling imports
import '@hg/joy/src/globalstyles';

//styling imports
import './_hospitalAffiliation.less';

const HospitalAffiliation = (props) => {
  //selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);

  const affiliatedHospitalInfo = JSON.parse(providerProfileInfo.AffiliatedHospitalJson);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);

  const dispatch = useDispatch();

  const content = 'Include all hospitals where you actively admit and write orders.';

  const [hospitalAutoSuggest, setHospitalAutoSuggest] = useState([]);

  const refHospital = useRef();

  const [hospitalList, setHospitalList] = useState(affiliatedHospitalInfo.Items);

  const [showModalDelete, toggleModalDelete] = useState(false);

  const [name, setName] = useState('');

  const [selectedHospitalId, setSelectedHospital] = useState('');

  const [notifyProperties, setNotifyProperties] = useState([]);

  //states
  const navTabData = [
    {
      label: 'Hospital Affiliations',
      badgeEnabled:
        JSON.parse(providerProfileInfo.AffiliatedHospitalJson).Items.length == 0 ? true : false
    }
  ];

  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
  };
  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);
  const [displaySpinner, setDisplaySpinner] = useState(false);

  const [INIT_STATE_HA, UPDATE_INIT_STATE_HA] = useState(
    affiliatedHospitalInfo.Items.map((tempdata) => {
      return { ...tempdata };
    })
  );

  // jsx constant(s)
  const _header = (
    <>
      <NavTabs tabs={navTabData} onSelectHandler={tabSelectionhandler} />
    </>
  );
  const _footer = <></>;

  // effects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'hospitals');
  }, []);

  useEffect(() => {
    const affiliatedHospital = JSON.parse(providerProfileInfo.AffiliatedHospitalJson);
    UPDATE_INIT_STATE_HA(
      affiliatedHospital.Items.map((tempdata) => {
        return { ...tempdata };
      })
    );
  }, [providerProfileInfo]);

  const hospitalInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length > 0) {
      service
        .get(`/api/provider/hospitals?term=${value}&latlon=26.10554,-80.13734`)
        .then((res) => {
          if (res.length > 0) filterAutocomplete(res);
        })
        .catch((err) => console.log(err));
    } else setHospitalAutoSuggest([]);
  };

  const filterAutocomplete = (response) => {
    var existingItems = hospitalList.map((item) => {
      return item.Code;
    });

    response.map((tempdata) => {
      if (existingItems.indexOf(tempdata.Id) > -1) {
        tempdata.Id = '';
        tempdata.Disabled = true;
      }
      return { ...tempdata };
    });

    setHospitalAutoSuggest(response);
  };

  const hospitalSelectHandler = (item) => {
    if (hospitalList.findIndex((p) => p.Code === item.Id) === -1 && !isEmpty(item.Id)) {
      //setHospitalList(arr => [...arr, { Code: item.Id, Name: item.Text, ActualName: item.Name, NameExtension: item.NameExtension, UpdateType: "Add" }]);

      let newdata = {
        Code: item.Id,
        Name: item.Text,
        ActualName: item.Name,
        NameExtension: item.NameExtension,
        UpdateType: 'Add'
      };

      _updateHospitalsInfo(newdata, 'Add');
    }
    setHospitalAutoSuggest([]);
  };

  const deleteitem = (code) => {
    setSelectedHospital(code);
    setName(hospitalList.find((data) => data.Code === code).Name);
    toggleModalDelete(true);
  };

  const handleRemoveHospital = (code) => {
    let tempHospitalList = hospitalList.map((tempdata) => {
      return { ...tempdata };
    });

    tempHospitalList.find((data) => data.Code === code).UpdateType = 'Delete';
    setHospitalList(tempHospitalList);

    _updateHospitalsInfo(code, 'Delete');

    toggleModalDelete(false);
  };

  const _ctaHospitalListEqual = !isEmpty(hospitalList)
    ? hospitalList.findIndex((hs) => hs.UpdateType === 'Delete' || hs.UpdateType === 'Add') > -1
    : false;

  const _ctaValid = _ctaHospitalListEqual ? 'valid' : '';

  const closeModal = () => {
    toggleModalDelete(false);
  };

  const _updateHospitalsInfo = async (item, type) => {
    setSpinnerVisibility(true);
    let updateHospitalPayload = {
      Items: hospitalList,
      ProviderId: providerProfileInfo.ProviderCode
    };

    if (type === 'Add') {
      updateHospitalPayload.Items.push(item);
      setHospitalList(updateHospitalPayload.Items);
    } else {
      updateHospitalPayload.Items.find((data) => data.Code === item).UpdateType = 'Delete';
    }

    let _promises = [];
    _promises.push(service.post(`/api/provider/update-hospitals`, updateHospitalPayload));

    const _result = await Promise.allSettled(_promises);

    if (_result.every((res) => res.status === 'fulfilled')) {
      let _affiliatedHospitalJson = providerProfileInfo.AffiliatedHospitalJson;

      let _tempAffiliatedHospitalInfo = {
        ...affiliatedHospitalInfo,
        Items: hospitalList
          .filter((p) => p.UpdateType !== 'Delete')
          .map((tempdata) => {
            return { ...tempdata, UpdateType: 'None' };
          })
      };
      setHospitalList(_tempAffiliatedHospitalInfo.Items);
      _affiliatedHospitalJson = JSON.stringify(_tempAffiliatedHospitalInfo);

      let _tempProviderProfileInfo = {
        ...providerProfileInfo,
        AffiliatedHospitalJson: _affiliatedHospitalJson
      };
      dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
      trackingService.editPageTracking('provider', 'save', 'hospitals');
      toaster.Success('Success');
    } else {
      toaster.Error('Some error occurred, please try again!!');
    }
    setSpinnerVisibility(false);
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  return (
    <Fragment>
      <LayoutA identifier='provider-profile-hospital-affiliation' header={_header} footer={_footer}>
        <div id='div-provider-profile-hospital-affiliation-main'>
          <div id='div-hospital-affiliation-section'>
            <section id='provider-profile-hospital-affiliation-section'>
              <LayoutInfo
                identifier='provider-profile-hospital-affiliation-add-hospital'
                title='Add Affiliated Hospitals'
                description={providerProfileInfo.Content.AffiliatedHospitalContent}
                bullets={{
                  title: 'Missing Fields',
                  data: []
                }}>
                <AutoSuggest
                  id='input-provider-profile-hospital-affiliation-add-hospital'
                  label=''
                  name='AddHospital'
                  placeholder='Add Hospital'
                  initialValue=''
                  onInputChangeHandler={hospitalInputChangeHandler}
                  data={hospitalAutoSuggest}
                  onSuggestSelectHandler={hospitalSelectHandler}
                  isSearch={true}
                />
                <div className='div-input-provider-profile-hospital-affiliation-choose-hospital'>
                  <span className='mobile-view right-space'>Or</span>
                  <a href='api/nearbyHospitals'>Choose from nearby Hospitals</a>
                </div>
              </LayoutInfo>

              {hospitalList.length > 0 && (
                <>
                  <div id='div-provider-profile-hospital-affiliation-section-separetor'></div>
                  <LayoutInfo
                    identifier='provider-profile-hospital-affiliation-display-hospital'
                    title='Your Affiliated Hospitals:'
                    description=''
                    bullets={{
                      title: 'Missing Fields',
                      data: []
                    }}>
                    {hospitalList.map((p, index) => {
                      if (p.UpdateType !== 'Delete') {
                        return (
                          <CardContainer
                            key={index}
                            index={index}
                            id='hospital-affiliations'
                            title={p.Name}
                            additionalField={''}
                            providerId={p.Code}
                            code={p.Code}
                            removeCard={deleteitem}
                          />
                        );
                      }
                    })}
                  </LayoutInfo>
                </>
              )}
              <Toast
                toastList={notifyProperties}
                position='bottom-center'
                autoDelete={true}
                autoDeleteTime={5000}
              />
              <>{spinnerVisibility && <Spinner cta={true} />}</>
            </section>
          </div>
        </div>

        <DeleteConfirmationModelPopUp
          id={selectedHospitalId}
          title={name}
          buttonName='Remove Hospital'
          showModalDelete={showModalDelete}
          closeModal={closeModal}
          handleDeleteItem={handleRemoveHospital}></DeleteConfirmationModelPopUp>
      </LayoutA>
      {displaySpinner && <Spinner cta={true} />}
    </Fragment>
  );
};

HospitalAffiliation.propTypes = {};

export default HospitalAffiliation;
