import React, { useState, useEffect, Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//stylesheet imports
import './_boardCertificate.less';

//components import
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import SelectInput from '@hg/joy/src/components/formElements/SelectInput';
import SingleDateInput from '@hg/joy/src/components/formElements/SingleDateInput';
import Button from '@hg/joy/src/components/Button';

import CardContainer from '../../Common/CardContainer/CardContainer';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';
import DeleteConfirmationModelPopUp from '../../Common/DeleteConfirmationModelPopUp/DeleteConfirmationModelPopUp';

//helper
import LayoutA from '../../Common/Layouts/LayoutA';
import isDateValid from '../../../utils/validation/isDateValid';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import * as dateFormat from '../../../utils/dateFormat';

// image import
import DividerLine from '../../../assets/images/BoardCertifications/DividerLine.svg';

const BoardCertificate = (Props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const boardCertificationJson = JSON.parse(providerProfileInfo.BoardCertificationJson);
  const content = providerProfileInfo.Content.BoardCertificationContent;
  const agencyListJson = JSON.parse(
    providerProfileInfo.BoardCertificationAgencyListJson.replaceAll('Value', 'Text')
  );
  const dispatch = useDispatch();

  //states
  const [agencyValue, setAgencyValue] = useState('');
  const [boardValue, setBoardValue] = useState('');
  const [specialtyValue, setSpecialtyValue] = useState('');
  const [agencyCode, setAgencyCode] = useState('');
  const [boardCode, setBoardCode] = useState('');
  const [specialtyCode, setSpecialtyCode] = useState('');
  const [expiryDateValue, setExpiryDateValue] = useState('');
  const [agencyList, setAgencyList] = useState();
  const [boardList, setBoardList] = useState();
  const [specialtyList, setSpecialtyList] = useState();
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);

  const [selectedAgencyList, setSelectedAgencyList] = useState([]);
  const [selectedBoardList, setSelectedBoardList] = useState([]);
  const [selectedSpecialtyList, setSelectedSpecialtyList] = useState([]);
  const [selectedCardIndex, setSelectedCardIndex] = useState();
  const [showModalDelete, toggleModalDelete] = useState(false);
  const [modelPopUpTitle, setModelPopUpTitle] = useState('');
  const [selectedAutoSuggestBoardList, setSelectedAutoSuggestBoardList] = useState([]);
  const [selectedAutoSuggestSpecialtyList, setSelectedAutoSuggestSpecialtyList] = useState([]);
  const [expiryDateValidation, setExpiryDateValidation] = useState({
    isValid: true,
    errorMessage: ''
  });
  const navTabData = [
    {
      label: 'Board Certifications',
      badgeEnabled: false
    }
  ];

  const [INIT_STATE, UPDATE_INIT_STATE] = useState({
    ProviderId: boardCertificationJson.ProviderId,
    Certifications: boardCertificationJson.Certifications
  });
  const [boardCertificationsObj, setBoardCertificationsObj] = useState(INIT_STATE);

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //handlers
  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
  };
  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);

  // Load all dropdown list on page load
  const getList = (url) => {
    service
      .get(url)
      .then((res) => {
        if (url.includes('agency-list')) {
          let _formattedRes = res.filter(
            (data) =>
              data.Id !== '' &&
              data.Value.toLowerCase() !== 'Select a Certifying Agency'.toLowerCase()
          );
          setAgencyList(
            JSON.parse(
              JSON.stringify(_formattedRes).replaceAll('Value', 'Text').replaceAll('id', 'Id')
            )
          );
        } else if (url.includes('board-list')) {
          let _formattedRes = res.filter(
            (data) =>
              data.Id !== '' &&
              data.Value.toLowerCase() !== 'Select a Certifying Board'.toLowerCase()
          );
          setBoardList(
            JSON.parse(
              JSON.stringify(_formattedRes).replaceAll('Value', 'Text').replaceAll('id', 'Id')
            )
          );
        } else if (url.includes('specialty-list')) {
          let _formattedRes = res.filter(
            (data) =>
              data.Id !== '' &&
              data.Value.toLowerCase() !== 'Select a Certifying Specialty'.toLowerCase()
          );
          setSpecialtyList(
            JSON.parse(
              JSON.stringify(_formattedRes).replaceAll('Value', 'Text').replaceAll('id', 'Id')
            )
          );
        }
      })
      .catch(() => console.log('Some error occurred, please try again!!'))
      .finally();
  };

  if (agencyList === undefined) {
    getList('/api/autosuggest/agency-list');
  }

  if (boardList === undefined) {
    getList('/api/autosuggest/board-list');
  }

  if (specialtyList === undefined) {
    getList('/api/autosuggest/specialty-list');
  }

  const agencyInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length > 0) {
      setSelectedAgencyList(loadListByValue(agencyList, value));
    } else {
      cancelHandler();
    }
  };

  const boardInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (selectedBoardList.length == 0) GetBoardSpecialtyList(agencyCode, '', '');
    if (value.length > 0) {
      setSelectedAutoSuggestBoardList(loadListByValue(selectedBoardList, value));
    } else {
      setBoardValue('');
      setBoardCode('');
      setSelectedAutoSuggestBoardList([]);
    }
  };

  const specialtyInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (selectedSpecialtyList.length == 0) GetBoardSpecialtyList(agencyCode, boardCode, '');
    if (value.length > 0) {
      setSelectedAutoSuggestSpecialtyList(loadListByValue(selectedSpecialtyList, value));
    } else {
      setSpecialtyValue('');
      setSpecialtyCode('');
      setSelectedAutoSuggestSpecialtyList([]);
    }
  };

  const loadListByValue = (list, value) => {
    let _tmpFiltedList = list.filter((r) => r.Text.toLowerCase().includes(value));
    return _tmpFiltedList.length > 0 ? _tmpFiltedList : [];
    //: [{ Id: '', Text: 'No results found for "' + value + '"' }];
  };

  // Dropdown and Date change event handler

  const agencyAutoSuggestChangeHandler = (selectedAgencyObj) => {
    handleBoardCertificationSelectChange({ target: { value: selectedAgencyObj, name: 'agency' } });
  };

  const boardAutoSuggestChangeHandler = (selectedBoardObj) => {
    handleBoardCertificationSelectChange({ target: { value: selectedBoardObj, name: 'board' } });
  };

  const specialtyAutoSuggestChangeHandler = (selectedSpecialtyObj) => {
    handleBoardCertificationSelectChange({
      target: { value: selectedSpecialtyObj, name: 'specialty' }
    });
  };

  const handleBoardCertificationSelectChange = (event) => {
    const { value, name } = event.target;
    switch (name) {
      case 'agency':
        setAgencyValue(value.Text);
        let tmpAgencyCode = value.Id; //GetOptionCodeByValue(agencyList, value);
        GetBoardSpecialtyList(tmpAgencyCode, '', '');
        setAgencyCode(tmpAgencyCode);
        setSelectedAgencyList([]);
        break;
      case 'board':
        setBoardValue(value.Text);
        let tmpBoardCode = value.Id; //GetOptionCodeByValue(boardList, value);
        GetBoardSpecialtyList('', tmpBoardCode, '');
        setBoardCode(tmpBoardCode);
        setSelectedAutoSuggestBoardList([]);
        setSelectedBoardList([]);
        break;
      case 'specialty':
        setSpecialtyValue(value.Text);
        let tmpSpecialtyCode = value.Id; // GetOptionCodeByValue(specialtyList, value);
        GetBoardSpecialtyList('', '', tmpSpecialtyCode);
        setSpecialtyCode(tmpSpecialtyCode);
        setSelectedAutoSuggestSpecialtyList([]);
        setSelectedSpecialtyList([]);
        break;
      case 'expirationdate':
        const standardizedOutput = value;
        setExpiryDateValue(standardizedOutput);
        setExpiryDateValidation(handlePastDateValidate(value));

        break;
      default:
        break;
    }
  };

  const GetOptionCodeByValue = (list, value) => {
    return list.filter((r) => r.Text === value)[0].Id.toString();
  };

  // Get Board and specialty based dropdown change of Agency or board or Speciality
  const GetBoardSpecialtyList = (_agencyCode, _boardCode, _spcialtyCode) => {
    _agencyCode = _agencyCode === undefined ? '' : _agencyCode;
    _boardCode = _boardCode === undefined ? '' : _boardCode;
    _spcialtyCode = _spcialtyCode === undefined ? '' : _spcialtyCode;
    service
      .get(
        `/api/autosuggest/board-specialty-list?agencyCode=${_agencyCode}&boardCode=${_boardCode}&specialtyCode=${_spcialtyCode}`
      )
      .then((res) => {
        if (res.length > 0 && res != null) {
          if (boardList != null && _boardCode === '' && _spcialtyCode === '') {
            let _tmpBoardList = boardList.filter((o) =>
              res.some((r) => o.Id === r.board_code || o.Id == '')
            );
            setSelectedBoardList(_tmpBoardList);
            let _autoSelectBoard = GetAutoSelectDropDown(_tmpBoardList);
            setBoardValue(_autoSelectBoard.Text);
            setBoardCode(_autoSelectBoard.Id);
          }
          if (specialtyList != null && _spcialtyCode === '') {
            let _tmpSpecialtyList = specialtyList.filter((o) =>
              res.some((r) => o.Id === r.specialty_code || o.Id == '')
            );
            setSelectedSpecialtyList(_tmpSpecialtyList);
            let _autoSelectSpecialty = GetAutoSelectDropDown(_tmpSpecialtyList);
            setSpecialtyValue(_autoSelectSpecialty.Text);
            setSpecialtyCode(_autoSelectSpecialty.Id);
          }
        }
      })
      .catch(() => console.log('Some error occurred, please try again!!'))
      .finally();
  };

  const GetAutoSelectDropDown = (list) => {
    let selectedList = {
      Text: list.length == 2 ? list[1].Text : list[0].Text,
      Id: list.length == 2 ? list[1].Id : list[0].Id
    };
    return selectedList;
  };
  // Past date validation
  const [validating, setValidating] = useState({
    expiryDate: false
  });
  const handlePastDateValidate = (value) => {
    if (isDateValid(value)) {
      let now = new Date();
      let todaysDate = Date.parse(now),
        expiryDate = Date.parse(value);
      if (expiryDate < todaysDate) {
        return {
          isValid: false,
          errorMessage: 'Please enter a valid expiration date (in the future)'
        };
      }
      var futureDateInt = Date.parse(dateFormat.getFutureDateFormatted(11));
      if (expiryDate > futureDateInt) {
        return {
          isValid: false,
          errorMessage:
            'Please enter a valid expiration date (less than 11 years from now). If you have a lifetime certification, please leave this blank.'
        };
      }
    } else {
      return {
        isValid: false,
        errorMessage: 'The Expiration Date must be in the following format: mm/dd/yyyy'
      };
    }
    return { isValid: true, errorMessage: '' };
  };

  // Cancel button clear all select and input fields
  const cancelHandler = () => {
    setAgencyValue('');
    setBoardValue('');
    setSpecialtyValue('');
    setExpiryDateValue('');
    setAgencyValue('');
    setAgencyCode('');
    setExpiryDateValidation({ isValid: true, errorMessage: '' });
    setSelectedAgencyList([]);
    setSelectedBoardList([]);
    setSelectedSpecialtyList([]);
    setSelectedAutoSuggestBoardList([]);
    setSelectedAutoSuggestSpecialtyList([]);

    trackingService.editPageTracking('provider', 'cancel', 'board certification');
  };

  // Save Board Certifications
  const IsDuplicateValidate = () => {
    let isDuplicateBoardCertificate =
      boardCertificationsObj.Certifications.filter(
        (r) =>
          r.AgencyCode == agencyCode && r.BoardCode == boardCode && r.SpecialtyCode == specialtyCode
      ).length > 0;
    if (isDuplicateBoardCertificate) {
      toaster.Error('This Certifying Board already exists');
    }
    // setIsDuplicate(isDuplicateBoardCertificate);
    return isDuplicateBoardCertificate;
  };

  const updateBoardCertifications = () => {
    let Certifications = {
      AgencyCode: agencyCode,
      AgencyDescription: agencyValue,
      BoardCode: boardCode,
      BoardDescription: boardValue,
      SpecialtyCode: specialtyCode,
      SpecialtyDescription: specialtyValue,
      ExpDateDisplay: expiryDateValue === undefined ? '' : expiryDateValue,
      UpdateType: 'Add',
      justAdded: true
    };

    let _tempBoardCertification = [...boardCertificationsObj.Certifications];
    _tempBoardCertification.push(Certifications);

    let _tempBoardCertificationsObj = boardCertificationsObj;
    _tempBoardCertificationsObj.Certifications = _tempBoardCertification;
    trackingService.editPageTracking(
      'provider',
      'add certification to list',
      'board certification'
    );
    UpdateBoardCertification(_tempBoardCertificationsObj);
  };

  //Delete Model Popup
  const deleteitem = (code, providerId, index) => {
    let _certificate = boardCertificationsObj.Certifications[index];
    setSelectedCardIndex(index);
    setModelPopUpTitle(
      `${_certificate.AgencyCode} - ${_certificate.BoardDescription} - ${_certificate.SpecialtyDescription}`
    );
    toggleModalDelete(true);
  };

  const closeModal = () => {
    toggleModalDelete(false);
  };

  // Remove Board Certifications
  const boardCertificationRemoveHandler = (index) => {
    toggleModalDelete(false);
    setSpinnerVisibility(true);
    //let codes = code.split('-');
    let _tempCertifications = [...boardCertificationsObj.Certifications];

    let _tempCertificationsToUpdate = {             
      ..._tempCertifications[index],
      UpdateType: 'Delete'
    };
    _tempCertifications[index] = _tempCertificationsToUpdate;

    let _tempBoardCertificationsObj = boardCertificationsObj;
    _tempBoardCertificationsObj.Certifications = _tempCertifications;
    UpdateBoardCertification(_tempBoardCertificationsObj);
  };

  const UpdateBoardCertification = (_tempBoardCertificationsObj) => {
    service
      .post(`/api/provider/update-certifications`, _tempBoardCertificationsObj)
      .then((res) => {
        if (res.Success) {
          let _tempProviderProfileInfo = {
            ...providerProfileInfo,
            BoardCertificationJson: res.ReturnData
          };
          cancelHandler();
          setSelectedBoardList([]);
          setSelectedSpecialtyList([]);
          setBoardCertificationsObj(JSON.parse(_tempProviderProfileInfo.BoardCertificationJson));
          dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
          toaster.Success('Success');
        }
      })
      .catch(() => toaster.Error('Some error occurred, please try again!!'))
      .finally(() => setSpinnerVisibility(false));

    trackingService.editPageTracking('provider', 'save', 'board certification');
  };

  //effects after save and remove board certification update the providerProfileInfo State.
  useEffect(() => {
    let _boardCertificationJson = JSON.parse(providerProfileInfo.BoardCertificationJson);
    UPDATE_INIT_STATE({
      ProviderId: _boardCertificationJson.ProviderId,
      Certifications: _boardCertificationJson.Certifications
    });
  }, [providerProfileInfo]);

  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'board certification');
    trackingService.editPageTracking('provider', 'add board certification', 'board certification');
  }, []);

  //isValid => ClassName => CTA
  const _ctaBoardCertificationEmpty =
    agencyValue === undefined ||
    agencyValue === '' ||
    agencyValue === 'Select a Certifying Agency' ||
    boardValue === undefined ||
    boardValue === '' ||
    boardValue === 'Select a Certifying Board' ||
    specialtyValue === undefined ||
    specialtyValue === '' ||
    specialtyValue === 'Select a Certifying Specialty' ||
    (expiryDateValue != undefined &&
      expiryDateValue != '' &&
      expiryDateValidation.isValid == false);

  const _ctaBoardCertificationNonEmpty =
    (agencyValue != undefined &&
      agencyValue != '' &&
      agencyValue != 'Select a Certifying Agency') ||
    (boardValue != undefined && boardValue != '' && boardValue != 'Select a Certifying Board') ||
    (specialtyValue != undefined &&
      specialtyValue != '' &&
      specialtyValue != 'Select a Certifying Specialty') ||
    (expiryDateValue != undefined && expiryDateValue != '');

  const _ctaValid = _ctaBoardCertificationEmpty ? '' : 'valid';
  const _ctaCancelButton = !_ctaBoardCertificationNonEmpty ? '' : 'valid';

  const _ctaAgencyAutoSuggestValid = agencyValue == '' ? true : false;
  const _ctaBoardAutoSuggestValid = boardValue == '' ? true : false;

  // jsx constant(s)
  const _header = (
    <>
      <NavTabs tabs={navTabData} onSelectHandler={tabSelectionhandler} />
      {/* <img className='new-tag' src={Tag} alt='icon' /> */}
    </>
  );
  const _footer = <></>;

  // jsx

  return (
    <Fragment>
      <LayoutA identifier='provider-profile-board-certificate' header={_header} footer={_footer}>
        <div id='div-provider-profile-board-certificate-main'>
          <div id='div-board-certificate-section'>
            <section id='provider-profile-board-certificate-section'>
              <LayoutInfo
                identifier='provider-profile-board-certificate-get-badge'
                title='Add Board Certifications'
                description={content}
                bullets={{
                  title: 'Missing Fields',
                  data: []
                }}></LayoutInfo>
              <LayoutInfo
                identifier='provider-profile-board-certificate-get-badge'
                title=''
                description=''
                bullets={{
                  title: 'Missing Fields',
                  data: []
                }}>
                <AutoSuggest
                  id='board-certificate-agency'
                  label='Agency'
                  name='agency'
                  placeholder='Search Certifying Agency'
                  initialValue={agencyValue}
                  onInputChangeHandler={agencyInputChangeHandler}
                  data={selectedAgencyList}
                  onSuggestSelectHandler={agencyAutoSuggestChangeHandler}
                  setCurrentSelection={true}
                  isSearch={true}
                />
                <AutoSuggest
                  id='board-certificate-board'
                  label='Board'
                  name='board'
                  placeholder='Search Certifying Board'
                  initialValue={boardValue}
                  onInputChangeHandler={boardInputChangeHandler}
                  data={
                    selectedAutoSuggestBoardList.length > 0
                      ? selectedAutoSuggestBoardList
                      : selectedBoardList
                  }
                  onSuggestSelectHandler={boardAutoSuggestChangeHandler}
                  setCurrentSelection={true}
                  isSearch={true}
                  isDisabled={_ctaAgencyAutoSuggestValid}
                />
                <AutoSuggest
                  id='board-certificate-specialty'
                  label='Specialty'
                  name='specialty'
                  placeholder='Search Certifying Specailty'
                  initialValue={specialtyValue}
                  onInputChangeHandler={specialtyInputChangeHandler}
                  data={
                    selectedAutoSuggestSpecialtyList.length > 0
                      ? selectedAutoSuggestSpecialtyList
                      : selectedSpecialtyList
                  }
                  onSuggestSelectHandler={specialtyAutoSuggestChangeHandler}
                  setCurrentSelection={true}
                  isSearch={true}
                  isDisabled={_ctaBoardAutoSuggestValid}
                />
                <SingleDateInput
                  name='expirationdate'
                  id='input-provider-profile-board-certificate-expirationdate'
                  className='input-provider-profile-board-certificate-expirationdate'
                  label='Expiration Date'
                  required={false}
                  value={expiryDateValue}
                  onBlur={() => {
                    let tmpExpiryDate =
                      expiryDateValue != undefined && expiryDateValue != '' ? true : false;
                    setValidating((prev) => ({ ...prev, expiryDate: tmpExpiryDate }));
                  }}
                  validating={validating.expiryDate}
                  valid={expiryDateValidation.isValid}
                  invalidErrorMessage={expiryDateValidation.errorMessage}
                  onChange={(name, value) =>
                    handleBoardCertificationSelectChange({ target: { name: name, value: value } })
                  }
                />
              </LayoutInfo>
              <div className='action-section'>
                <Button
                  id='board-certificate-btn-cancel'
                  text='Cancel'
                  disabled={_ctaCancelButton != 'valid'}
                  className={`provider-profile-cancel ${_ctaCancelButton}`}
                  size='lg'
                  style='ghost'
                  onClick={cancelHandler}
                />
                <Button
                  id='board-certificate-btn-save'
                  text='Save'
                  disabled={_ctaValid != 'valid'}
                  className={`provider-profile-save ${_ctaValid}`}
                  size='lg'
                  style='ghost'
                  onClick={() => {
                    if (!IsDuplicateValidate()) {
                      setSpinnerVisibility(true);
                      updateBoardCertifications();
                    }
                  }}
                />
              </div>

              {boardCertificationsObj.Certifications.length > 0 && (
                <>
                  <div id='div-divider'>
                    <img src={DividerLine} className='divider-line'></img>
                  </div>
                  <LayoutInfo
                    identifier='provider-profile-board-certificate-get-badge-card-container'
                    title='Your Board Certifications:'
                    description=''
                    bullets={{
                      title: 'Missing Fields',
                      data: []
                    }}>
                    {boardCertificationsObj.Certifications.map((certificate, index) => (
                      <CardContainer
                        key={index}
                        index={index}
                        id='board-certifications'
                        title={`${certificate.AgencyCode} - ${certificate.BoardDescription} - ${certificate.SpecialtyDescription}`}
                        additionalField={
                          certificate.ExpDateWordDisplay != undefined &&
                          certificate.ExpDateWordDisplay != ''
                            ? `Expires : ${certificate.ExpDateWordDisplay}`
                            : ''
                        }
                        providerId={boardCertificationsObj.ProviderId}
                        code={`${certificate.AgencyCode} - ${certificate.BoardCode} - ${certificate.SpecialtyCode} `}
                        removeCard={deleteitem}
                      />
                    ))}
                  </LayoutInfo>
                </>
              )}
            </section>
          </div>
        </div>
        <DeleteConfirmationModelPopUp
          id={selectedCardIndex}
          title={modelPopUpTitle}
          buttonName='Remove Board Certification'
          showModalDelete={showModalDelete}
          closeModal={closeModal}
          handleDeleteItem={boardCertificationRemoveHandler}></DeleteConfirmationModelPopUp>
      </LayoutA>
      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
      {spinnerVisibility && <Spinner cta={true} />}
    </Fragment>
  );
};

export default BoardCertificate;
