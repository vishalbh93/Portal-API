import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import LayoutA from '../../Common/Layouts/LayoutA';
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import BrandingLogo from './BrandingLogo';
import BrandingBanner from './BrandingBanner';

import './_brandCustomization.less';

const BrandCustomization = (props) => {
  //Navigation
  const navTabData = [
    {
      label: 'Logo',
      badgeEnabled: false,
      value: 'logo'
    },
    {
      label: 'Banner',
      badgeEnabled: false,
      value: 'banner'
    }
  ];

  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);

  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
    props.onTabsChangeHandler(tab.value);
  };

  useEffect(() => {
    let currSel = navTabData.filter((e) =>
      e.value.toLowerCase().includes(props.selectTab.toLowerCase())
    )[0];
    if (currSel != undefined) setCurrentSelection(currSel);
    else setCurrentSelection(navTabData[0]);
  }, [props.selectTab]);

  // jsx constant(s)
  const _header = <NavTabs tabs={navTabData} onSelectHandler={tabSelectionhandler} selectedTab={currentSelection} />;
  const _footer = <></>;
  const _main = (selection) => {
    switch (selection) {
      case 'Logo':
        return <BrandingLogo />;
      case 'Banner':
        return <BrandingBanner />;
    }
  };


  return (
    <LayoutA identifier='provider-profile-branding' header={_header} footer={_footer}>
      <div id='div-provider-profile-branding-main'>{_main(currentSelection.label)}</div>
    </LayoutA>
  );
};

export default BrandCustomization;
