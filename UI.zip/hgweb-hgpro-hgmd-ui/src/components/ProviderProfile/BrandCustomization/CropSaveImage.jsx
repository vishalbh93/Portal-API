import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
import ReactCrop, { centerCrop, makeAspectCrop } from 'react-image-crop';

//styles
import './_brandingLogo.less';
import 'react-image-crop/dist/ReactCrop.css';

//media
import Close from '../../../assets/images/ProviderProfile/svg-cross.svg';
import svgTrash from '../../../assets/images/ProviderProfile/trash-no-border.png';

//component
import UploadInput from '@hg/joy/src/components/formElements/UploadInput';
import Cta from '../../Common/Form/CTA/Cta';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import isEmpty from '../../../utils/validation/isEmpty';
import DeleteConfirmationModelPopUp from '../../Common/DeleteConfirmationModelPopUp/DeleteConfirmationModelPopUp';

//helper fn
function centerAspectCrop(mediaWidth, mediaHeight, aspect, defaultWidth) {
  return centerCrop(
    makeAspectCrop(
      {
        unit: 'px',
        width: defaultWidth
      },
      aspect,
      mediaWidth,
      mediaHeight
    ),
    mediaWidth,
    mediaHeight
  );
}

const CropSaveImage = (props) => {
  const { brandingInfo, type, aspect } = props;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [fileInformation, setFileInformation] = useState({ name: '', size: null });
  const [imgSrc, setImgSrc] = useState('');
  const [url, setUrl] = useState('');
  const imgRef = useRef(null);
  const [crop, setCrop] = useState();

  const [logo, setNewLogo] = useState(
    brandingInfo[0] != undefined && brandingInfo[0].Url != undefined ? brandingInfo[0].Url : ''
  );
  const [selectedCardIndex, setSelectedCardIndex] = useState('1');
  const [showModalDelete, toggleModalDelete] = useState(false);
  const [modelPopUpTitle, setModelPopUpTitle] = useState('');
  const [isFormNotValid, setIsFormNotValid] = useState(false);
  const [invalidErrorMessage, setInvalidErrorMessage] = useState('');
  const clearUploadInputButton = () => {
    let uploadInputEle = document.getElementById('upload-input--for-upload-branding-logo');
    isEmpty(uploadInputEle) ? null : (uploadInputEle.value = null);
    let uploadInputInnerEle = document.getElementById('upload-input--for-upload-branding-logo-new');
    isEmpty(uploadInputInnerEle) ? null : (uploadInputInnerEle.value = null);
  };

  const handleBrandingLogoModalClose = () => {
    clearUploadInputButton();
    setFileInformation({ name: '', size: null });
    setIsModalOpen(false);
  };

  const handleLogoSelection = (id, files) => {
    if (files[0].name != undefined && files[0].name.length > 50) {
      handleBrandingLogoModalClose();
      setInvalidErrorMessage('File name too long! The file name of the image you uploaded exceeds the maximum allowed length of 50 characters. Please rename the file to a shorter name and try uploading it again. ');
    } else {
      setFileInformation({ name: files[0].name, size: Math.round(files[0].size / 1024) });
      setIsFormNotValid(false);
      setInvalidErrorMessage('');
      props.getFileInfoHandler(files[0]);
      const reader = new FileReader();
      reader.addEventListener('load', () => setImgSrc(reader.result.toString() || ''));
      reader.readAsDataURL(files[0]);
      setIsModalOpen(true);
    }
  };

  const closeModal = () => {
    toggleModalDelete(false);
  };

  const deleteitem = () => {
    // if (brandingInfo.length > 0) {
    setModelPopUpTitle('Provider');
    toggleModalDelete(true);
    setSelectedCardIndex('1');
    // } else {
    //   props.removeLogoHandler();
    //   setNewLogo('');
    //   setFileInformation({ name: '', size: null });
    // }
  };

  // -------------- For uploading new image , croping , saving------------------

  const onImageLoaded = (e) => {
    setCrop(undefined);
    if (aspect) {
      const { clientWidth, clientHeight } = e.currentTarget;
      let defaultWidth = type == 'logo' ? 180 : 300;
      setCrop(centerAspectCrop(clientWidth, clientHeight, aspect, defaultWidth));
    }
  };

  const onCropComplete = (crop) => {
    makeClientCrop(crop);
  };

  const makeClientCrop = async (crop) => {
    if (imgRef && crop.width && crop.height) {
      const croppedImageUrl = await getCroppedImg(imgRef, crop, fileInformation.name);
      setUrl(croppedImageUrl);
      clearUploadInputButton();
    }
  };

  const getCroppedImg = (image, crop, fileName) => {
    const canvas = document.createElement('Canvas');
    const scaleX = image.current.naturalWidth / image.current.width;
    const scaleY = image.current.naturalHeight / image.current.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(
      image.current,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );

    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          console.error('Canvas is empty');
          return;
        }
        blob.name = fileName;
        window.URL.revokeObjectURL(blob.name);
        let fileUrl = window.URL.createObjectURL(blob);
        setFileInformation({
          name: fileName,
          size: Math.round(blob.size / 1024)
        });
        let tempFile = new File(
          [blob],
          fileName,
          { type: 'image/jpg', lastModified: new Date().getTime() },
          'utf-8'
        );
        props.getFileInfoHandler(tempFile);
        resolve(fileUrl);
      }, 'image/jpg');
    });
  };

  const saveCroppedImage = () => {
    toggleModalDelete(false);
    let scaleFactor = imgRef.current.naturalWidth / imgRef.current.clientWidth;
    scaleFactor = Math.floor(scaleFactor * 10) / 10;
    url.length > 0
      ? (setNewLogo(url), props.newLogoHandler(url))
      : (setNewLogo(imgSrc), props.newLogoHandler(imgSrc));
    setIsModalOpen(false);
    clearUploadInputButton();
  };

  //jsx
  const _removeLogoJSX = (
    <>
      <img className='profile-photo-trash' src={svgTrash} alt='Delete Logo' onClick={deleteitem} />
      <DeleteConfirmationModelPopUp
        id={selectedCardIndex}
        title={modelPopUpTitle}
        buttonName={`Remove ${type}`}
        showModalDelete={showModalDelete}
        closeModal={closeModal}
        showFromItem={`Published ${type} List`}
        handleDeleteItem={() => {
          props.removeLogoHandler();
          setNewLogo('');
          setFileInformation({ name: '', size: null });
          toggleModalDelete(false);
        }}></DeleteConfirmationModelPopUp>
    </>
  );

  return (
    <>
      <div className='branding-logo-container'>
        {brandingInfo != undefined && logo.length > 0 && (
          <>
            <div className='branding-logo-img-container'>
              <img src={logo} alt='logo' className='branding-logo' />
              {_removeLogoJSX}
            </div>
          </>
        )}

        {((Object.keys(fileInformation).length != 0 && fileInformation.name.length > 0) ||
          brandingInfo.length > 0) &&
          logo.length > 0 && (
            <LayoutInfo
              identifier='upload-logo-details'
              title={
                brandingInfo.length > 0 && !isEmpty(brandingInfo[0].ImageName)
                  ? type == 'logo'
                    ? brandingInfo[0].ImageName
                    : ''
                  : fileInformation.name
              }
              description={
                fileInformation.size != 0 && fileInformation.size != null
                  ? `Size: ${fileInformation.size} KB`
                  : ''
              }
              bullets={{ title: 'Missing Fields', data: [] }}></LayoutInfo>
          )}
      </div>

      <UploadInput
        acceptedFileTypes='image/png, image/jpeg'
        id={isFormNotValid ? '' : 'upload-branding-logo'}
        buttonText={`${
          type == 'logo'
            ? logo.length > 0
              ? 'Upload New Logo'
              : 'Choose Logo'
            : logo.length > 0
            ? 'Upload New Banner'
            : 'Choose Banner'
        }`}
        multiple={false}
        onChange={handleLogoSelection}
        required
        showValidation={isFormNotValid}
        invalidErrorMessage={invalidErrorMessage}
      />
      {invalidErrorMessage != undefined && invalidErrorMessage != '' && <div className='invalid-error-message'>{invalidErrorMessage}</div>}

      <ReactModal
        overlayClassName='modal-overlay crop-pop-up'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={isModalOpen}
        contentLabel='Branding Logo'
        onRequestClose={handleBrandingLogoModalClose}
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container'>
          <div className='modal-header'>
            <h4 className='modal-title bold'>{type == 'logo' ? 'Upload Logo' : 'Upload Banner'}</h4>
            <div className='modal-close' onClick={handleBrandingLogoModalClose}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>

          <div className='modal-body'>
            {imgSrc && (
              <ReactCrop
                className='react-crop-container branding-section'
                src={imgSrc}
                crop={crop}
                onChange={(pixelCrop, percentCrop) => setCrop(pixelCrop)}
                aspect={aspect}
                onComplete={onCropComplete}
                minWidth={
                  isEmpty(imgRef.current)
                    ? type == 'logo'
                      ? '180'
                      : '300'
                    : `${
                        (type == 'logo' ? 180 : 300) /
                        (imgRef.current.naturalWidth / imgRef.current.clientWidth)
                      }`
                }
                minHeight={type == 'logo' ? '65' : '200'}>
                <div className='image-cropper-container'>
                  <img
                    ref={imgRef}
                    alt='Crop Area'
                    className='img-area'
                    src={imgSrc}
                    onLoad={onImageLoaded}
                  />
                </div>
              </ReactCrop>
            )}

            <LayoutInfo
              identifier='upload-logo-details'
              title={fileInformation.name}
              description={`Size: ${fileInformation.size} KB`}
              bullets={{ title: 'Missing Fields', data: [] }}>
              <UploadInput
                acceptedFileTypes='image/png, image/jpeg'
                id='upload-branding-logo-new'
                buttonText='Upload New'
                multiple={false}
                onChange={handleLogoSelection}
                required
                showValidation={false}
                invalidErrorMessage={invalidErrorMessage}
              />
            </LayoutInfo>
          </div>

          <hr />
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText='Cancel'
              cancelClickHandler={handleBrandingLogoModalClose}
              confirmText='Confirm'
              confirmClickHandler={saveCroppedImage}
            />
          </div>
        </div>
      </ReactModal>
    </>
  );
};

CropSaveImage.propTypes = {
  type: PropTypes.string
};

export default CropSaveImage;
