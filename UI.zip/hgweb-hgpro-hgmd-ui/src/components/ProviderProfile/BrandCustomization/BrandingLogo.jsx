import React, { useState, useEffect, useImperativeHandle } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import PropTypes from 'prop-types';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';
//style
import './_brandingLogo.less';

//component import
import Button from '@hg/joy/src/components/Button';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import isEmpty from '../../../utils/validation/isEmpty';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';
import CropSaveImage from './CropSaveImage';
import DeleteConfirmationModelPopUp from '../../Common/DeleteConfirmationModelPopUp/DeleteConfirmationModelPopUp';
import BrandingCards from './BrandingCards';
import Guidelines from './Guidelines';

const BrandingLogo = (props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const brandingInfo = JSON.parse(providerProfileInfo.BrandingInformationJson);
  const brandingLogoInfo = brandingInfo.BrandingInfo.BrandingLogoInfo;
  const [officeInfo, setOfficeInfo] = useState(JSON.parse(providerProfileInfo.OfficeJson));
  const providerCode = providerProfileInfo.ProviderCode;
  const dispatch = useDispatch();

  //states
  const [logo, setNewLogo] = useState(
    isEmpty(logo)
      ? brandingLogoInfo[0] && brandingLogoInfo[0].Url != undefined
        ? brandingLogoInfo[0].Url
        : ''
      : logo
  );
  const [isChecked, setIsChecked] = useState(false);
  const [allSelected, setAllSelected] = useState(false);
  const [selectedCardIndex, setSelectedCardIndex] = useState();
  const [showModalDelete, toggleModalDelete] = useState(false);
  const [modelPopUpTitle, setModelPopUpTitle] = useState('');
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [unPublishedLogoCards, setUnPublishedLogoCards] = useState([]);
  const [publishedLogoCards, setPublishedLogoCards] = useState([]);
  const [imageInfo, setImageInfo] = useState({});
  const [selectedCardToDelete, setSelectedCardToDelete] = useState({});
  const [removeLogo, setRemoveLogo] = useState(false);
  const [loadCardsAgain, setloadCardsAgain] = useState(false);
  const [init, setInit] = useState([]);
  const [brandingLogoDetails, setbrandingLogoDetails] = useState(brandingLogoInfo);
  const closeModal = () => {
    toggleModalDelete(false);
  };

  const deleteitem = (cards) => {
    setModelPopUpTitle(
      cards.OfficeName && cards.OfficeName.length > 0 ? `"${cards.OfficeName}"` : `"Provider"`
    );
    toggleModalDelete(true);
    setSelectedCardToDelete(cards);
  };

  const AddPublishCard = (brandingLogoInfo) => {
    brandingLogoInfo.map((listItem, index) => {
      if (listItem.Type === 'Provider' || listItem.Type === 'Office') {
        let publishedCard = {
          Type: listItem.Type,
          Id: listItem.Id,
          Pwid: listItem.Pwid,
          isPublished: true,
          ProviderImageSetId: listItem.ProviderImageSetId,
          OfficeProviderImageSetId: listItem.OfficeProviderImageSetId,
          ProviderImageId: listItem.ProviderImageId,
          FullAddress: listItem.Address,
          OfficeName: '',
          IsPrimary: false
        };

        if (
          !publishedLogoCards.find((item) => item.Id.toUpperCase() == listItem.Id.toUpperCase())
        ) {
          let itemIndex = unPublishedLogoCards.findIndex(
            (i) => i.Id.toUpperCase() == listItem.Id.toUpperCase()
          );
          if (itemIndex != -1) {
            unPublishedLogoCards[itemIndex].isPublished = true;
            publishedCard.FullAddress = unPublishedLogoCards[itemIndex].FullAddress;
            publishedCard.OfficeName = unPublishedLogoCards[itemIndex].OfficeName;
            publishedCard.IsPrimary = unPublishedLogoCards[itemIndex].IsPrimary;
          }
          publishedLogoCards.push(publishedCard);
        }
      }
    });
  };

  const updateProviderProfileInfo = (returnData) => {
    let tempLogoInfo = returnData.BrandingLogoInfo.filter(
      (value, index, self) => index === self.findIndex((t) => t.Id === value.Id)
    );
    let finalResult = {
      BrandingLogoInfo: tempLogoInfo,
      BrandingBannerInfo: returnData.BrandingBannerInfo
    };
    let tempBrandingLogoInfo = {
      ProviderId: providerProfileInfo.ProviderCode,
      BrandingInfo: finalResult
    };
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      BrandingInformationJson: JSON.stringify(tempBrandingLogoInfo)
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
    AddPublishCard(tempLogoInfo);
    setIsChecked(false);
  };

  const publishLogo = () => {
    let file = imageInfo;
    let cards = [...unPublishedLogoCards]
      .filter((i) => i.Selected === true)
      .map((j) => {
        return [j.Type, j.Id];
      });
    let temObject = cards.map((k) => {
      return k[0] === 'Office' ? { Office: k[1] } : { Provider: k[1] };
    });

    let list = JSON.stringify(temObject);

    let tempProviderImgIdList = brandingLogoInfo.map((i) => i.ProviderImageId);
    let providerimgidlist = JSON.stringify(tempProviderImgIdList);
    if (
      file != undefined &&
      file.name != undefined &&
      file.name.length > 0 &&
      brandingLogoInfo.length <= 0
    ) {
      service
        ._postImage(
          `/api/provider/upload-branding-logo?pwid=${providerCode}`,
          file,
          list,
          providerimgidlist,
          true
        )
        .then((res) => {
          if (!isEmpty(res) && res.status == 200 && res.data.Success) {
            updateProviderProfileInfo(JSON.parse(res.data.ReturnData));
            trackingService.editPageTracking('provider', 'save', 'brandinglogo');
            toaster.Success('Success');
            setRemoveLogo(false);
          } else {
            toaster.Error('Some error occured please try again!');
          }
        })
        .catch((error) => {
          if (error.response) {
            toaster.Error('There was a problem uploading your Logo');
          }
        });
    } else {
      if (brandingLogoInfo.some((i) => i.Url.length > 0)) {
        let id = tempProviderImgIdList[0];
        service
          ._postImage(
            `/api/provider/upload-branding-logo?pwid=${providerCode}&providerImageId=${id}&hasImgUrl=${true}`,
            undefined,
            list,
            undefined,
            true
          )
          .then((res) => {
            if (!isEmpty(res) && res.status == 200 && res.data.Success) {
              updateProviderProfileInfo(JSON.parse(res.data.ReturnData));
              trackingService.editPageTracking('provider', 'save', 'brandinglogo');
              toaster.Success('Success');
              setRemoveLogo(false);
            } else {
              toaster.Error('Some error occured please try again!');
            }
          })
          .catch((error) => {
            if (error.response) {
              toaster.Error('There was a problem uploading your Logo');
            }
          });
      }
    }
    // setloadCardsAgain(false);
  };

  const publishcardremoveHandler = (card) => {
    toggleModalDelete(false);
    let parameter = {
      pwid: card.Pwid,
      id: card.Id,
      providerImageId: card.ProviderImageId,
      providerImageSetId: card.ProviderImageSetId,
      officeProviderImageSetId: card.OfficeProviderImageSetId,
      type: card.Type
    };
    let url = `/api/provider/remove-branding-logo?pwid=${parameter.pwid}&id=${parameter.id}&providerImageId=${parameter.providerImageId}&providerImageSetId=${parameter.providerImageSetId}&officeProviderImageSetId=${parameter.officeProviderImageSetId}&type=${parameter.type}`;
    service._get(url, true).then((res) => {
      if (res.status == 200) {
        setAllSelected(false);
        let publish_index = publishedLogoCards.findIndex(
          (i) => i.Id.toUpperCase() == card.Id.toUpperCase()
        );
        let unpublish_index = unPublishedLogoCards.findIndex(
          (i) => i.Id.toUpperCase() == card.Id.toUpperCase()
        );
        if (publish_index != -1) {
          publishedLogoCards.splice(publish_index, 1);
        }
        if (unpublish_index != -1) {
          unPublishedLogoCards[unpublish_index].isPublished = false;
          unPublishedLogoCards[unpublish_index].Selected = false;
        }

        const tempUnPublishedLogoCards = [...unPublishedLogoCards];
        setUnPublishedLogoCards(
          tempUnPublishedLogoCards.map((tempdata) => {
            return { ...tempdata, Selected: false };
          })
        );

        let tempBrandingInfoObj = {
          ...brandingInfo.BrandingInfo,
          BrandingLogoInfo: brandingInfo.BrandingInfo.BrandingLogoInfo.filter(
            (i) => i.Id != card.Id
          )
        };
        updateProviderProfileInfo(tempBrandingInfoObj);
        trackingService.editPageTracking('provider', 'save', 'brandinglogo');
        toaster.Success('Success');
      } else {
        toaster.Error('There was a problem deleteing branding image');
      }
    });
  };

  const removeallpublishedcardHandler = () => {
    if (publishedLogoCards.length > 0) {
      setSpinnerVisibility(true);
      let payload = publishedLogoCards.map((card) => ({
        Pwid: card.Pwid,
        Id: card.Id,
        ProviderImageId: card.ProviderImageId,
        ProviderImageSetId: card.ProviderImageSetId,
        OfficeProviderImageSetId: card.OfficeProviderImageSetId,
        Type: card.Type
      }));

      service.post('/api/provider/remove-all-published-branding-logo', payload).then((res) => {
        if (res.status == 200) {
          setAllSelected(false);
          publishedLogoCards.splice();
          const tempUnPublishedLogoCards = [...unPublishedLogoCards];
          setUnPublishedLogoCards(
            tempUnPublishedLogoCards.map((tempdata) => {
              return { ...tempdata, Selected: false, isPublished: false };
            })
          );

          let tempBrandingInfoObj = {
            ...brandingInfo.BrandingInfo,
            BrandingLogoInfo: []
          };
          updateProviderProfileInfo(tempBrandingInfoObj);
          trackingService.editPageTracking('provider', 'save', 'brandinglogo');
          toaster.Success('Success');
        } else {
          toaster.Error('There was a problem deleteing branding logo');
        }
      });
    }
  };

  const generateBrandingList = (firstTimeLoad) => {
    let brandingInfo = firstTimeLoad ? brandingInfo : [];
    let unPublished = [];
    let Published = [];
    let primaryOfficeAddress = '';

    if (officeInfo != undefined && officeInfo != null && officeInfo.Practices != null) {
      officeInfo.Practices.map((practice) => {
        practice.Offices.map((officeItem) => {
          if (officeItem.IsPrimary)
            primaryOfficeAddress = `${officeItem.Address},${officeItem.City},${officeItem.State},${officeItem.ZipCode}`;

          let offName =
            officeItem.Name != null && officeItem.Name != '' ? officeItem.Name : practice.Name;

          if (officeItem.OfficeCode != null) {
            let unPublishedCard = {
              Id: officeItem.OfficeCode,
              Selected: false,
              FullAddress: `${officeItem.Address},${officeItem.City},${officeItem.State},${officeItem.ZipCode}`,
              IsPrimary: officeItem.IsPrimary,
              Type: 'Office',
              IsPublished: false,
              ImageSection: 'Logo',
              OfficeName: offName
            };

            unPublished.push(unPublishedCard);
          }
        });
      });
    }
    let providerDataForLogo = {
      Id: providerCode,
      Selected: false,
      FullAddress: primaryOfficeAddress,
      Type: 'Provider',
      IsPublished: false,
      ImageSection: 'Logo',
      IsPrimary: false,
      OfficeName: ''
    };

    unPublished.push(providerDataForLogo);

    if (brandingLogoInfo != null && brandingLogoInfo.length != 0) {
      let publishedCard = brandingLogoInfo;
      {
        brandingLogoInfo.map((listItem, index) => {
          if (listItem.Type === 'Provider' || listItem.Type === 'Office') {
            publishedCard = {
              Type: listItem.Type,
              Id: listItem.Id,
              Pwid: listItem.Pwid,
              isPublished: true,
              ProviderImageSetId: listItem.ProviderImageSetId,
              OfficeProviderImageSetId: listItem.OfficeProviderImageSetId,
              ProviderImageId: listItem.ProviderImageId,
              FullAddress: listItem.Address,
              OfficeName: '',
              IsPrimary: false
            };

            let itemIndex = unPublished.findIndex(
              (item) => item.Id.toUpperCase() == listItem.Id.toUpperCase()
            );
            if (itemIndex != -1) {
              unPublished[itemIndex].isPublished = true;
              publishedCard.FullAddress = unPublished[itemIndex].FullAddress;
              publishedCard.OfficeName = unPublished[itemIndex].OfficeName;
              publishedCard.IsPrimary = unPublished[itemIndex].IsPrimary;
            }
            Published.push(publishedCard);
          }
        });
      }
    }
    let tempUnPublished = unPublished.filter(
      (value, index, self) => index === self.findIndex((t) => t.Id === value.Id)
    );
    let tempPublished = Published.filter(
      (value, index, self) => index === self.findIndex((t) => t.Id === value.Id)
    );
    setInit([tempUnPublished, tempPublished]);
    setUnPublishedLogoCards(tempUnPublished);
    setPublishedLogoCards(tempPublished);
    setloadCardsAgain(false);
  };

  const selectallHandler = (event) => {
    let selectAll = event.target.checked;
    let _unpublishtemcard = [...unPublishedLogoCards];
    _unpublishtemcard.map((item, index) => {
      item.Selected = selectAll;
    });
    setIsChecked(selectAll);
    setAllSelected(selectAll);
    setUnPublishedLogoCards([..._unpublishtemcard]);
  };

  const deselectHandler = (e) => {
    let _unpublishtemcard = [...unPublishedLogoCards];
    let index = _unpublishtemcard.findIndex((i) => i.Id === e.target.id);
    if (index > -1) _unpublishtemcard[index].Selected = false;
    setUnPublishedLogoCards([..._unpublishtemcard]);
    setIsChecked(_unpublishtemcard.some((i) => i.Selected === true));
    if (_unpublishtemcard.every((i) => i.Selected === false)) {
      setIsChecked(false);
    }
  };

  //event handlers
  const getFileInfoHandler = (file) => {
    setImageInfo(file);
  };

  const removeLogoHandler = (isNewLogo = false) => {
    if (publishedLogoCards.length > 0) {
      if (!isNewLogo) {
        setSpinnerVisibility(true);
      }
      let temp = publishedLogoCards.map((i) => ({
        Address: i.FullAddress,
        Id: i.Id,
        OfficeProviderImageSetId: i.OfficeProviderImageSetId,
        ProviderImageId: i.ProviderImageId,
        ProviderImageSetId: i.ProviderImageSetId,
        Pwid: i.Pwid,
        Type: i.Type
      }));
      let payload = {
        BrandingLogoInfos: temp,
        providerId: providerCode
      };
      service
        .post('/api/provider/remove-branding-images', payload)
        .then((res) => {
          if (res.Success) {
            let tmpBrandingBannerInfo = brandingInfo.BrandingInfo.BrandingBannerInfo;
            let finalResult = {
              BrandingLogoInfo: [],
              BrandingBannerInfo: tmpBrandingBannerInfo
            };
            let tempBranding = {
              ProviderId: providerProfileInfo.ProviderCode,
              BrandingInfo: finalResult
            };
            let tempproviderProfileInfo = {
              ...providerProfileInfo,
              BrandingInformationJson: JSON.stringify(tempBranding)
            };
            dispatch(actions.loadProviderProfileData(tempproviderProfileInfo, false));
            setloadCardsAgain(true);

            setRemoveLogo(true);
            setPublishedLogoCards([]);
            trackingService.editPageTracking('provider', 'save', 'brandinglogo');
            if (!isNewLogo) {
              setNewLogo('');
              toaster.Success('Success');
            }
          } else toaster.Error(res.ErrorMessage);
        })
        .catch((err) => toaster.Error('There was a problem removing your image'))
        .finally(() => {
          if (!isNewLogo) {
            setSpinnerVisibility(false);
          }
        });
    } else {
      setNewLogo('');
    }
  };

  const newLogoHandler = (src) => {
    if (brandingLogoInfo.length > 0) {
      removeLogoHandler(true);
      setNewLogo(src);
      let tempBrandingInfoObj = {
        ...brandingInfo.BrandingInfo,
        BrandingLogoInfo: []
      };
      updateProviderProfileInfo(tempBrandingInfoObj);
      generateBrandingList(true);
    } else {
      setNewLogo(src);
    }
  };

  const checkAll = (e) => {
    let idx = unPublishedLogoCards.findIndex((i) => i.Id == e.target.id);
    if (idx > -1) {
      unPublishedLogoCards[idx].Selected = true;
      unPublishedLogoCards.some((i) => i.Selected == true)
        ? setIsChecked(true)
        : setIsChecked(false);
      unPublishedLogoCards.every((i) => i.Selected == true)
        ? setAllSelected(true)
        : setAllSelected(false);
    } else if (idx > -1) {
      unPublishedLogoCards[idx].Selected = false;
      unPublishedLogoCards.every((i) => i.Selected == false)
        ? setIsChecked(false)
        : setIsChecked(true); //__publish button
    }
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //useEffects
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'brandinglogo');
  }, []);

  useEffect(() => {
    generateBrandingList(true);
  }, []);

  useEffect(() => {
    unPublishedLogoCards.every((i) => i.Selected == true) //__forAllCheckbox selction
      ? setAllSelected(true)
      : setAllSelected(false);
  }, [unPublishedLogoCards]);

  //useEffect(() => {}, [publishedLogoCards, unPublishedLogoCards]);

  useEffect(() => {
    if (removeLogo) {
      init[0].length > 0
        ? init[0].find((i) => i.isPublished == true).length > 0
          ? (init[0].find((i) => i.isPublished == true).isPublished = false)
          : null
        : null;
      init[1].length > 0 ? init[1].map((i) => (i.isPublished = false)) : null;
      setUnPublishedLogoCards([...init[0]]);
      setPublishedLogoCards([]);
    }
  }, [removeLogo]);

  useEffect(() => {
    let brandingInfo = JSON.parse(providerProfileInfo.BrandingInformationJson);
    let brandingLogoInfo = brandingInfo.BrandingInfo.BrandingLogoInfo;
    let officeInfo = JSON.parse(providerProfileInfo.OfficeJson);
    // removeLogo
    //   ? (setNewLogo(''), (brandingLogoInfo = []))
    //   : setNewLogo(
    //       brandingLogoInfo[0] && brandingLogoInfo[0].Url != undefined ? brandingLogoInfo[0].Url : ''
    //     );
    setOfficeInfo(officeInfo);
    loadCardsAgain ? generateBrandingList(removeLogo) : null;
  }, [providerProfileInfo, removeLogo]);

  useEffect(() => {}, [unPublishedLogoCards]);

  useEffect(() => {}, [logo]);

  return (
    <>
      <section id='provider-profile-brandinglogo-section'>
        <LayoutInfo
          identifier='provider-profile-brandinglogo'
          title='Office Logo'
          description={
            'Add office logo to your Healthgrades profile. You can also bulk assign the uploaded logo to your associated office(s) in one go!'
          }>
          <Guidelines type='logo' />

          <CropSaveImage
            type='logo'
            aspect={180 / 65}
            brandingInfo={brandingLogoDetails}
            removeLogoHandler={removeLogoHandler}
            newLogoHandler={newLogoHandler}
            getFileInfoHandler={getFileInfoHandler}
          />

          {logo && logo.length > 0 && (
            <>
              {!(unPublishedLogoCards.length === publishedLogoCards.length) && (
                <div className='pending-cards'>
                  <h4>
                    Choose from the following provider's association to which you want to assign the
                    above Logo:
                  </h4>
                  <div className='unpublished-logos'>
                    <div className='logo-cards'>
                      {unPublishedLogoCards.map(
                        (item, index) =>
                          !item.isPublished && (
                            <BrandingCards
                              className='unpublished'
                              key={item.Id}
                              id={item.Id}
                              selected={item.Selected}
                              address={item.FullAddress}
                              officeName={item.OfficeName}
                              isPublished={item.IsPublished}
                              isPrimary={item.IsPrimary}
                              type={item.Type}
                              deselectHandler={deselectHandler}
                              checkAll={checkAll}
                            />
                          )
                      )}
                    </div>
                  </div>
                </div>
              )}

              {!(unPublishedLogoCards.length === publishedLogoCards.length) && (
                <div className='selectall-checkbox'>
                  <input
                    id='SelectAll'
                    type='checkbox'
                    selectall='SelectAll'
                    disabled=''
                    className='allSelect-Checkbox'
                    value={allSelected}
                    checked={allSelected}
                    onChange={(event) => {
                      selectallHandler(event);
                    }}
                  />
                  <label htmlFor='selectall' className='logo-hide-link'>
                    <a className='selectalltext'>{allSelected ? 'Deselect All' : 'Select All'}</a>
                  </label>
                </div>
              )}

              {isChecked && (
                <div className='action-section'>
                  <Button
                    id='btn-publish'
                    text='Publish'
                    className='btn-small'
                    disabled={!isChecked}
                    size='sm'
                    style='ghost'
                    onClick={publishLogo}
                  />
                </div>
              )}

              {publishedLogoCards.length > 0 &&
                publishedLogoCards.map((i) => i.isPublished == true).length > 0 && (
                  <>
                    <div className='published-association'>
                      <hr />
                      <h4>Published association</h4>
                      <div className='published-logos'>
                        {publishedLogoCards.map(
                          (item, index) =>
                            item.isPublished && (
                              <BrandingCards
                                className='published'
                                key={item.Id}
                                id={item.Id}
                                address={item.FullAddress}
                                officeName={item.OfficeName}
                                isPublished={item.isPublished}
                                isPrimary={item.IsPrimary}
                                type={item.Type}
                                removeCard={() => deleteitem(item)}
                              />
                            )
                        )}
                      </div>
                      {/* <div className='logo-hide-link'>
                        <a className='deleteall' onClick={removeallpublishedcardHandler}>
                          Remove all Published associations
                        </a>
                      </div> */}
                    </div>
                    {/* <div className='logo-hide-link'>
                    <a onClick={removeAllToUnpublishHandler}>Remove all Published associations</a>
                  </div> */}
                  </>
                )}
            </>
          )}

          <>
            <DeleteConfirmationModelPopUp
              id={selectedCardIndex}
              title={modelPopUpTitle}
              buttonName='Remove association'
              showModalDelete={showModalDelete}
              closeModal={closeModal}
              showFromItem='published association'
              handleDeleteItem={() =>
                publishcardremoveHandler(selectedCardToDelete)
              }></DeleteConfirmationModelPopUp>
            <Toast
              toastList={notifyProperties}
              position='bottom-center'
              autoDelete={true}
              autoDeleteTime={5000}
            />
            {spinnerVisibility && <Spinner cta={true} />}
          </>
        </LayoutInfo>
      </section>
    </>
  );
};

export default BrandingLogo;
