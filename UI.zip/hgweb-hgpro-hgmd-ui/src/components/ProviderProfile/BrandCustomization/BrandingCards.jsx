import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import TickCircle from '../../../assets/images/ProviderProfile/tick-icon.svg';
import deleteicon from '../../../assets/images/ProviderProfile/icon-delete.svg';

const BrandingCards = (props) => {
  const { className, id, selected, address, type, isPublished, isPrimary, officeName } = props;

  const [cards, setCards] = useState(props);
  const [isSelected, setIsSelected] = useState(selected);

  const selectUnPublishCardHandler = (event) => {
    let chkstatus = event.target.checked;
    setIsSelected(chkstatus);
    chkstatus === false ? props.deselectHandler(event) : props.checkAll(event);
  };

  const onPublishCardDeleteHandler = (cards) => {
    props.removeCard(cards);
  };

  useEffect(() => {
    setIsSelected(selected);
  }, [selected]);

  return (
    <>
      <div className={isSelected || selected ? `${className} unpublishedselect` : className}>
        {isPublished ? (
          <div className='publishdeleteIcon'>
            <div className={isPrimary ? 'deletePublishCard move-delete' : 'deletePublishCard'}>
              <img
                id={id}
                src={deleteicon}
                alt='delete-icon'
                onClick={() => onPublishCardDeleteHandler(cards)}
              />
            </div>
          </div>
        ) : (
          <div className={isPrimary ? 'unpublishcheckboxCard Top' : 'unpublishcheckboxCard'}>
            <input
              id={id}
              name='selectCard'
              value={selected}
              type='checkbox'
              className='published-checkbox'
              checked={isSelected}
              onChange={(event) => selectUnPublishCardHandler(event)}
            />
          </div>
        )}

        <div className='title-section'>
          {isPrimary ? <div className='primaryHighlight'>PRIMARY</div> : ''}
          <h3>{type === 'Provider' ? 'Provider' : officeName}</h3>
        </div>

        <p>ID : {id}</p>
        <p>Address : {address}</p>
        {isPublished && (
          <p className='published-label'>
            <img src={TickCircle} alt='published_icon' /> <span>Published</span>
          </p>
        )}
      </div>
    </>
  );
};

BrandingCards.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string,
  selected: PropTypes.bool,
  address: PropTypes.string,
  type: PropTypes.string,
  isPublished: PropTypes.bool,
  imageSection: PropTypes.string,
  isPrimary: PropTypes.bool,
  removeCard: PropTypes.func,
  selectedUnPublishcard: PropTypes.func,
  officeName: PropTypes.string,
  deselectHandler: PropTypes.func,
  checkAll: PropTypes.func
};

export default BrandingCards;
