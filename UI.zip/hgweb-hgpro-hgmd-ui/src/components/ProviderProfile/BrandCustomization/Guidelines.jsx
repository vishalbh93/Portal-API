import React, { useState } from 'react';
import PropTypes from 'prop-types';

const Guidelines = (props) => {
  const { type } = props;

  const [logoGuidelinesVisibility, toggleLogooGuidelinesVisibility] = useState(false);
  return (
    <>
      {logoGuidelinesVisibility && (
        <div className='guidelines'>
          <h5> {`${type == 'logo' ? ' Logo Upload Guidelines' : ' Banner Upload Guidelines'}`}</h5>
          <ul>
            <li>
              {`Image Dimensions: For best results, use a blur free image (cropped to ${
                type == 'logo' ? '180x65' : '300x250'
              } pixels).
              We have an image editor built to assist you.`}
            </li>
            <li>Image format accepted: We support Jpeg, Jpg &amp; Png. </li>
            <li>{`Image size: Image file can’t exceed ${type == 'logo' ? '3MB' : '5MB'}.`}</li>
            <li>{`Image name: File name not to exceed 50 characters.`}</li>
          </ul>
        </div>
      )}
      <div className='logo-hide-link'>
        <a onClick={() => toggleLogooGuidelinesVisibility(!logoGuidelinesVisibility)}>
          {logoGuidelinesVisibility ? 'Hide ' : 'Show '}
          {`${type == 'logo' ? ' Logo Upload Guidelines' : ' Banner Upload Guidelines'}`}
        </a>
      </div>
    </>
  );
};

Guidelines.propTypes = {
  type: PropTypes.string
};

export default Guidelines;
