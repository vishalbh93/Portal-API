import React, { useState, useRef, useEffect, Fragment } from 'react';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
// import ReactCrop, { centerCrop, makeAspectCrop } from 'react-image-crop';
import { useSelector, useDispatch } from 'react-redux';

// import crossIcon from '../../../../assets/images/brandingimages/CrossIcon.svg';
import CropSaveImage from './CropSaveImage';
import * as actions from '../../../store/actions';
import * as trackingService from '../trackingServices';

//components import
import Spinner from '../../Spinner/Spinner';
import Toast from '../../Common/Toast/Toast';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
// import UploadInput from '@hg/joy/src/components/formElements/UploadInput';
import Button from '@hg/joy/src/components/Button';
// import isEmpty from '../../../utils/validation/isEmpty';
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import Guidelines from './Guidelines';
import * as service from '../../../utils/service';
//media imports
import crossIcon from '../../../assets/images/ProviderProfile/CrossIcon.svg';

//styles impots
import './_brandingBanner.less';
import isEmpty from '../../../utils/validation/isEmpty';

const BrandingBanner = (props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const brandingInfo = JSON.parse(providerProfileInfo.BrandingInformationJson);
  const BrandingBannerInfo = brandingInfo.BrandingInfo.BrandingBannerInfo;
  const [officeInfo, setofficeInfo] = useState(JSON.parse(providerProfileInfo.OfficeJson));
  const providerCode = providerProfileInfo.ProviderCode;
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [imageInfo, setImageInfo] = useState({});
  const [enablePublish, setEnablePublish] = useState(false);
  const [removeBanner, setRemoveBanner] = useState(false);
  const [linkHeadingText, setlinkHeadingText] = useState(
    BrandingBannerInfo[0] && !isEmpty(BrandingBannerInfo[0].BadgeTargetUrl)
      ? BrandingBannerInfo[0].BadgeTargetUrl
      : ''
  );
  const [isLinkShow, setLinkShow] = useState(!isEmpty(linkHeadingText) ? true : false);
  const [brandingofficeInfoList, setbrandingofficeInfoList] = useState(officeInfo);
  //const [loadCardsAgain, setloadCardsAgain] = useState(false);
  const dispatch = useDispatch();

  //states
  const [Banner, setNewBanner] = useState(
    BrandingBannerInfo[0] && BrandingBannerInfo[0].Url != undefined ? BrandingBannerInfo[0].Url : ''
  );

  // UseEffect
  useEffect(() => {
    trackingService.editPageTracking('provider', 'edit', 'brandingbanner');
  }, []);

  useEffect(() => {
    let brandingInfo = JSON.parse(providerProfileInfo.BrandingInformationJson);
    let BrandingBannerInfo = brandingInfo.BrandingInfo.BrandingBannerInfo;
    let officeInfo = JSON.parse(providerProfileInfo.OfficeJson);
    setNewBanner(
      BrandingBannerInfo[0] && BrandingBannerInfo[0].Url != undefined
        ? BrandingBannerInfo[0].Url
        : ''
    );

    setofficeInfo(officeInfo);
    setImageInfo();
    setImageInfo(imageInfo);
    setRemoveBanner(false);
  }, [providerProfileInfo, removeBanner]);

  useEffect(() => {
    generateBrandingBannerList(true);
  }, []);

  const updateProviderProfileInfo = (returnData) => {
    let tempBannerInfo = returnData.BrandingBannerInfo;
    let finalResult = {
      BrandingLogoInfo: returnData.BrandingLogoInfo,
      BrandingBannerInfo: tempBannerInfo
    };
    let tempBrandingBannerInfo = {
      BrandingInfo: finalResult,
      ProviderId: providerProfileInfo.ProviderCode
    };
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      BrandingInformationJson: JSON.stringify(tempBrandingBannerInfo)
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
  };

  const generateBrandingBannerList = () => {
    let officeInfoData = [];
    let primaryOfficeAddress = '';

    if (officeInfo != undefined && officeInfo != null && officeInfo.Practices != null) {
      officeInfo.Practices.map((practice) => {
        practice.Offices.map((officeItem) => {
          if (officeItem.IsPrimary)
            primaryOfficeAddress = `${officeItem.Address},${officeItem.City},${officeItem.State},${officeItem.ZipCode}`;

          let offName =
            officeItem.Name != null && officeItem.Name != '' ? officeItem.Name : practice.Name;

          if (officeItem.OfficeCode != null) {
            let officeInfoList = {
              Id: officeItem.OfficeCode,
              Selected: false,
              FullAddress: `${officeItem.Address},${officeItem.City},${officeItem.State},${officeItem.ZipCode}`,
              IsPrimary: officeItem.IsPrimary,
              Type: 'Office',
              IsPublished: false,
              ImageSection: 'Banner',
              OfficeName: offName
            };

            officeInfoData.push(officeInfoList);
          }
        });
      });
    }
    let providerDataForLogo = {
      Id: providerCode,
      Selected: true,
      FullAddress: primaryOfficeAddress,
      Type: 'Provider',
      IsPublished: false,
      ImageSection: 'Banner',
      IsPrimary: false,
      OfficeName: ''
    };

    officeInfoData.push(providerDataForLogo);
    let tempOffice = officeInfoData.filter(
      (value, index, self) => index === self.findIndex((t) => t.Id === value.Id)
    );

    setbrandingofficeInfoList(officeInfoData);
  };

  const publishBanner = () => {
    let file = imageInfo;
    if (file.name != undefined) {
      var hasImgSrcForBanner = true;
    }
    if (!hasImgSrcForBanner) {
      let tempOfficeList = [...brandingofficeInfoList]
        .filter((i) => i.Selected === true || i.Selected === false)
        .map((j) => {
          return [j.Type, j.Id];
        });
      let temObject = tempOfficeList.map((k) => {
        return k[0] === 'Office' ? { Office: k[1] } : { Provider: k[1] };
      });
      let list = JSON.stringify(temObject);

      let tempProviderBadgeIdList = BrandingBannerInfo.map((i) => i.BadgeId);
      let providerbadgeidlist = JSON.stringify(tempProviderBadgeIdList);
      let targetUrl = linkHeadingText;
      let defaultWidth = 300;
      let defaultHeight = 250;

      service
        ._postImage(
          `/api/provider/upload-branding-banner?pwid=${providerCode}&targetUrl=${targetUrl}&alternateText=''&defaultWidth=${defaultWidth}&defaultHeight=${defaultHeight}`,
          file,
          list,
          providerbadgeidlist,
          true,
          true
        )
        .then((res) => {
          if (!isEmpty(res) && res.status == 200 && res.data.Success) {
            {
              linkHeadingText ? setLinkShow(true) : setLinkShow(false);
            }
            updateProviderProfileInfo(JSON.parse(res.data.ReturnData));

            // generateBrandingBannerList();
            trackingService.editPageTracking('provider', 'save', 'brandingbanner');
            toaster.Success('Success');
            setEnablePublish(false);
          } else {
            toaster.Error(
              'There is a problem please referesh the page and try again if your banner is not uploaded!'
            );
            setLinkShow(false);
          }
        })
        .catch((error) => {
          if (error.response) {
            toaster.Error('There was a problem uploading your Banner');
          }
          setLinkShow(false);
        });
    } else if (hasImgSrcForBanner) {
      let tmpBrandingOfficeInfoList = [...brandingofficeInfoList]
        .filter((i) => i.Selected === true || i.Selected === false)
        .map((j) => {
          return [j.Type, j.Id];
        });
      let tmpList = tmpBrandingOfficeInfoList.map((k) => {
        return k[0] === 'Office' ? { Office: k[1] } : { Provider: k[1] };
      });
      let list = JSON.stringify(tmpList);

      let tempProviderBadgeIdList = BrandingBannerInfo.map((i) => i.BadgeId);
      let providerbadgeidlist = JSON.stringify(tempProviderBadgeIdList);
      let targetUrl = linkHeadingText;
      let defaultWidth = 300;
      let defaultHeight = 250;
      let hasImageUrl = true;
      service
        ._postImage(
          `/api/provider/upload-branding-banner?pwid=${providerCode}&targetUrl=${targetUrl}&alternateText=''&defaultWidth=${defaultWidth}&defaultHeight=${defaultHeight}&hasImageUrl=${hasImageUrl}`,
          file,
          list,
          providerbadgeidlist,
          true
        )
        .then((res) => {
          if (!isEmpty(res) && res.status == 200 && res.data.Success) {
            {
              linkHeadingText ? setLinkShow(true) : setLinkShow(false);
            }
            updateProviderProfileInfo(JSON.parse(res.data.ReturnData));
            trackingService.editPageTracking('provider', 'save', 'brandingbanner');
            toaster.Success('Success');
            setEnablePublish(false);
          } else {
            toaster.Error(
              'There is a problem please referesh the page and try again if your banner is not uploaded!'
            );
            setLinkShow(false);
          }
        })
        .catch((error) => {
          if (error.response) {
            toaster.Error(
              'Looks like there is a timeout, please referesh the page and try again if your banner is not uploaded!'
            );
            setLinkShow(false);
          }
        });
    }
  };

  const removeBannerHandler = () => {
    if (BrandingBannerInfo.length > 0) {
      setSpinnerVisibility(true);
      let temp = BrandingBannerInfo.map((i) => ({
        Pwid: i.Pwid,
        Id: i.Id,
        ImageName: '',
        Url: i.Url,
        BadgeSetName: i.BadgeSetName,
        ImageSetType: i.ImageSetType,
        ImgSetType: 'Banner',
        Type: i.Type,
        BadgeId: i.BadgeId,
        BadgeText: '',
        BadgeAlternateText: i.BadgeAlternateText,
        BadgeTargetUrl: i.BadgeTargetUrl,
        BadgeType: i.BadgeType,
        IsActive: true,
        ProviderBadgeSetID: i.ProviderBadgeSetID,
        ProviderBadgeSet_ProviderBadgeID: i.ProviderBadgeSet_ProviderBadgeID,
        Published: false,
        OfficeProviderBadgeSetId: i.OfficeProviderBadgeSetId
      }));
      let payload = {
        ProviderId: providerCode,
        BrandingBannerInfos: temp
      };
      service
        .post('/api/provider/remove-branding-images', payload)
        .then((res) => {
          if (res.Success) {
            let tmpBrandingLogo = brandingInfo.BrandingInfo.BrandingLogoInfo;
            let finalResult = {
              BrandingBannerInfo: [],
              BrandingLogoInfo: tmpBrandingLogo
            };
            let tempBranding = {
              ProviderId: providerProfileInfo.ProviderCode,
              BrandingInfo: finalResult
            };
            let tempproviderProfileInfo = {
              ...providerProfileInfo,
              BrandingInformationJson: JSON.stringify(tempBranding)
            };
            dispatch(actions.loadProviderProfileData(tempproviderProfileInfo, false));
            trackingService.editPageTracking('provider', 'save', 'brandingbanner');
            toaster.Success('Success');
            setLinkShow(false);
            // toggleModalDelete(false);
          } else toaster.Error(res.ErrorMessage);
        })
        .catch((err) => toaster.Error('There was a problem removing your image'))
        .finally(() => {
          setSpinnerVisibility(false);
          setNewBanner('');
          setlinkHeadingText('');
          setImageInfo({});
          setRemoveBanner(true);
          setLinkShow(false);
        });
    } else {
      setNewBanner('');
      setlinkHeadingText('');
      setImageInfo({});
    }
  };

  const getFileInfoHandler = (file) => {
    setImageInfo(file);
    setLinkShow(false);
  };

  const newLogoHandler = (src) => {
    setNewBanner(src);
    setEnablePublish(true);
  };

  const bannerLinkHandler = (e) => {};

  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  return (
    <section id='provider-profile-branding-banner-section'>
      <LayoutInfo
        identifier='provider-profile-branding-banner'
        title='Profile Banner'
        description={
          'Add banner to your Healthgrades profile to get more traction! You can add a click through URL which upon clicking    will take the user to the linked page.'
        }>
        <Guidelines type='Banner' />
        <CropSaveImage
          type='Banner'
          aspect={300 / 250}
          brandingInfo={BrandingBannerInfo}
          removeLogoHandler={removeBannerHandler}
          newLogoHandler={newLogoHandler}
          getFileInfoHandler={getFileInfoHandler}
        />

        {Banner && (
          <Fragment>
            <div className='banner-link-wrapper'>
              {!isLinkShow && (
                <>
                  <TextInput
                    id='banner-upload-link'
                    className='banner-upload-link'
                    name='upload-link'
                    label='Add a Link to Banner:'
                    placeholder='https://www.unikitypaincenter.com'
                    onChange={(name, value) => (setlinkHeadingText(value), setEnablePublish(true))}
                    value={linkHeadingText}
                  />
                  {enablePublish && (
                    <span className='action-section'>
                      <Button
                        id='btn-publish'
                        text='Publish'
                        className='btn-small addlink'
                        disabled={!enablePublish}
                        size='sm'
                        style='ghost'
                        onClick={publishBanner}
                      />
                    </span>
                  )}
                </>
              )}

              {isLinkShow && (
                <div className='bannerNewHeading'>
                  <span className='addlinkToBanner'>Banner Link:</span>
                  <span className='headingSpan'>
                    {linkHeadingText}{' '}
                    <img
                      src={crossIcon}
                      alt=''
                      className='crossIconSpan'
                      onClick={() => {
                        setLinkShow(false);
                        setEnablePublish(true);
                      }}
                    />
                  </span>
                </div>
              )}
            </div>
          </Fragment>
        )}

        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </LayoutInfo>
    </section>
  );
};

BrandingBanner.propTypes = {};

export default BrandingBanner;
