import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//stylesheet import
import './_acceptingNewPatients.less';

//components import
import { RadioGroup } from '../../FormComponents/RadioGroup';
import Button from '@hg/joy/src/components/Button';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';

//const imports
import { _radioOptionsYesNo } from '../../../utils/constant-data';

const AcceptingNewPatients = () => {
  // setup
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const acceptingNewPatientsJson = JSON.parse(providerProfileInfo.AcceptingNewPatientsJson);
  const dispatch = useDispatch();

  //states
  const [INIT_STATE, UPDATE_INIT_STATE] = useState({
    ProviderId: acceptingNewPatientsJson.ProviderId,
    MissingAvailability: acceptingNewPatientsJson.MissingAvailability,
    GeneralMissingText: acceptingNewPatientsJson.GeneralMissingText,
    AcceptingNewPatients: acceptingNewPatientsJson.AcceptingNewPatients,
    AcceptingNewPatientsDisplay: acceptingNewPatientsJson.AcceptingNewPatientsDisplay
  });
  const [providerAcceptingNewPatientsObj, updateProviderAcceptingNewPatientsObj] =
    useState(INIT_STATE);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);

  //isValid => ClassName => CTA
  const _ctaValid =
    acceptingNewPatientsJson.AcceptingNewPatients ==
    providerAcceptingNewPatientsObj.AcceptingNewPatients
      ? ''
      : 'valid';

  //event handlers
  const radioGroupChangeHandler = (event) => {
    event.persist();
    let value = event.target.value;
    updateProviderAcceptingNewPatientsObj((prev) => ({
      ...prev,
      AcceptingNewPatients: value == 'Yes',
      AcceptingNewPatientsDisplay: value
    }));
  };

  const _updateAcceptingNewPatients = () => {
    service
      .post(`/api/provider/update-accepting-patients`, providerAcceptingNewPatientsObj)
      .then((res) => {
        let informationObj = JSON.parse(providerProfileInfo.InformationJson);
        let _tempInformationObj = {
          ...informationObj,
          AcceptingNewPatientsMissing: false
        };
        let _tempProviderProfileInfo = {
          ...providerProfileInfo,
          AcceptingNewPatientsJson: res.ReturnData,
          InformationJson: JSON.stringify(_tempInformationObj)
        };
        dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
        toaster.Success('Success');
      })
      .catch(() => toaster.Error('Some error occurred, please try again!!'))
      .finally(() => setSpinnerVisibility(false));
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //effects
  useEffect(() => {
    UPDATE_INIT_STATE({
      ProviderId: acceptingNewPatientsJson.ProviderId,
      MissingAvailability: acceptingNewPatientsJson.MissingAvailability,
      GeneralMissingText: acceptingNewPatientsJson.GeneralMissingText,
      AcceptingNewPatients: acceptingNewPatientsJson.AcceptingNewPatients,
      AcceptingNewPatientsDisplay: acceptingNewPatientsJson.AcceptingNewPatientsDisplay
    });
  }, [providerProfileInfo]);

  return (
    <section id='provider-profile-accepting-new-patients-section'>
      <div id='dv-rdbtn-section-accepting-new-patients'>
        <span className='rdbtn-section-accepting-new-patients-question'>
          Are you accepting new patients?
        </span>
        <div className='rdbtn-section-accepting-new-patients'>
          <RadioGroup
            radioGroup={_radioOptionsYesNo}
            selectedOption={providerAcceptingNewPatientsObj.AcceptingNewPatientsDisplay}
            onChangeHandler={radioGroupChangeHandler}
          />
        </div>
      </div>
      <div className='action-section'>
        <Button
          id='btn-cancel'
          text='Cancel'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-cancel ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            updateProviderAcceptingNewPatientsObj(INIT_STATE);
          }}
        />
        <Button
          id='btn-save'
          text='Save'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-save ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            setSpinnerVisibility(true);
            _updateAcceptingNewPatients();
          }}
        />
      </div>
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </section>
  );
};

export default AcceptingNewPatients;
