import React, { useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../../utils/service';
import * as actions from '../../../../store/actions';

//helpers
import isEmpty from '../../../../utils/validation/isEmpty';
import * as constants from '../../TrustedPartners/Constants';

//stylesheet imports
import './_profileVideo.less';

//svg imports
import Close from '../../../../assets/images/ProviderProfile/svg-cross.svg';

//components import
import TextInput from '@hg/joy/src/components/formElements/TextInput';
import UploadInput from '@hg/joy/src/components/formElements/UploadInput';

import Cta from '../../../Common/Form/CTA/Cta';
import Toast from '../../../Common/Toast/Toast';
import Spinner from '../../../Spinner/Spinner';
import LayoutInfo from '../../../Common/Layouts/LayoutInfo';
import ReactModal from 'react-modal';
import Tip from '../../TrustedPartners/Tip';

const ProfileVideo = (props) => {
  //ref
  const dropContainer = useRef(null);
  const localVideoContainer = useRef(null);
  const sectionVideoPreview = useRef(null);
  const sectionVideoUpload = useRef(null);
  const linkShowHideGuidelines = useRef(null);

  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const dispatch = useDispatch();

  const videoInformation = JSON.parse(providerProfileInfo.VideoInformationJson);
  const IS_BRIGHTSPOT = videoInformation.VideoHostCode.toUpperCase() === 'BRIGHTSPOT';

  //states
  const [videoInformationObj, setVideoInformationObj] = useState(videoInformation);
  const [providerHasVideo, setProviderHasVideo] = useState(providerProfileInfo.HasVideo);

  const [minifyCurrentVideo, setMinifyCurrentVideo] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const [videoGuidelinesVisibility, toggleVideoGuidelinesVisibility] = useState(
    !providerProfileInfo.HasVideo
  );

  const [youtubeVideoUrl, setYoutubeVideoUrl] = useState('');
  const [isYoutubeVideoUpload, setIsYoutubeVideoUpload] = useState(false);
  const [youtubeVideoMetadata, setYoutubeVideoMetadata] = useState({});

  const [isLocalVideoUpload, setIsLocalVideoUpload] = useState(false);
  const [localVideoMetadata, setLocalVideoMetadata] = useState({});
  const [isLocalVideoUploading, setIsLocalVideoUploading] = useState(false);
  const [videoUploadProgress, setVideoUploadProgress] = useState(0);

  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);

  //event handlers
  const currentVideoDeleteHandler = () => {
    service
      ._delete(`/api/video/delete-profilevideo?pwid=${videoInformation.ProviderId}`, true)
      .then((res) => {
        if (res.status == 200) {
          let data = res.data;
          if (data.Success) {
            setProviderHasVideo(false);
            let _tempProviderProfileInfo = {
              ...providerProfileInfo,
              HasVideo: false
            };
            dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
            toaster.Success('Video deleted successfully');
          } else {
            toaster.Error(data.ErroMessage);
          }
        } else {
          toaster.Error('Some error occured!!');
        }
      })
      .catch((err) => {
        toaster.Error(err.response.data.ErrorMessage);
      });
  };

  const currentVideoUploadHandler = () => {
    setMinifyCurrentVideo(true);
    sectionVideoUpload.current.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    });
  };

  const loadYoutubePreview = () => {
    service
      ._get(`/api/video/get-metadata?videoUrl=${youtubeVideoUrl}`)
      .then((res) => {
        if (res.status == 200) {
          let data = res.data;
          if (data.Success) {
            setProviderHasVideo(false);
            setMinifyCurrentVideo(false);
            setIsYoutubeVideoUpload(true);
            setIsLocalVideoUpload(false);
            toggleVideoGuidelinesVisibility(false);
            setYoutubeVideoMetadata(JSON.parse(data.ReturnData));
          }
        }
      })
      .catch((err) => {
        toaster.Error(err.response.data.ErrorMessage);
      });
  };

  const localFilePreview = (file) => {
    if (isEmpty(file)) {
      toaster.Error('Some error occured');
      return;
    }
    setProviderHasVideo(false);
    setMinifyCurrentVideo(false);
    setIsYoutubeVideoUpload(false);
    setIsLocalVideoUpload(true);
    toggleVideoGuidelinesVisibility(false);

    let videoElement = document.createElement('video');
    videoElement.controls = true;
    videoElement.onloadedmetadata = () => {
      const minDuration = 1;
      const maxDuration = 300;

      if (videoElement.duration < minDuration || videoElement.duration > maxDuration) {
        toaster.Error('Recommended video length is 30sec - 2min');
        videoElement.src = '';
        setIsLocalVideoUpload(false);
      } else {
        let min = Math.floor(videoElement.duration / 60);
        let sec = Math.floor(videoElement.duration - min * 60);
        setLocalVideoMetadata((prev) => ({
          ...prev,
          Duration: `${min > 9 ? min : '0' + min}:${sec > 9 ? sec : '0' + sec}`,
          Size: (file.size / Math.pow(1024, 2)).toFixed(2),
          File: file,
          Uri: videoElement.src
        }));
      }
    };
    let tempVideoObjectUrl = URL.createObjectURL(file);
    videoElement.src = tempVideoObjectUrl;

    isEmpty(localVideoContainer.current)
      ? setTimeout(() => {
          isEmpty(localVideoContainer.current)
            ? null
            : localVideoContainer.current.prepend(videoElement);
        }, 2000)
      : localVideoContainer.current.prepend(videoElement);
  };

  const uploadSelectHandler = (id, files) => {
    if (validateVideoFile(files[0])) {
      localFilePreview(files[0]);
    } else {
      let el = document.getElementById(id);
      id.value = '';
    }
  };

  const handleYoutubePreviewCancel = () => {
    setProviderHasVideo(!isEmpty(videoInformation.Url));
    setYoutubeVideoMetadata({});
    setIsYoutubeVideoUpload(false);
    toggleVideoGuidelinesVisibility(true);
    setYoutubeVideoUrl('');
  };

  const handleYoutubePreviewConfirm = () => {
    try {
      service
        ._post(
          `/api/video/upload-video?pwid=${videoInformation.ProviderId}&videoUrl=${youtubeVideoUrl}`
        )
        .then((res) => {
          if (!isEmpty(res) && res.status == 200) {
            let data = res.data;
            if (data.Success) {
              let tempVideoInformationObj = {
                ...videoInformationObj,
                Duration: youtubeVideoMetadata.Duration,
                Size: youtubeVideoMetadata.Size,
                Url: youtubeVideoMetadata.Uri
              };
              let _tempProviderProfileInfo = {
                ...providerProfileInfo,
                VideoInformationJson: JSON.stringify(tempVideoInformationObj),
                HasVideo: true
              };
              setYoutubeVideoMetadata({});
              setIsYoutubeVideoUpload(false);
              setYoutubeVideoUrl('');
              dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
              toaster.Success('The video is being uploaded and may take several minutes, please check back later.  ');
            }
          } else {
            toaster.Error('Some error occured please try again!');
          }
        })
        .catch((error) => {
          if (error.response.status == 200) {
            let data = error.response.data;
            toaster.Error(data.ErrorMessage);
          } else {
            toaster.Error('There was a problem uploading your video, please try again.');
          }
        });
    } catch (error) {
      toaster.Error('An error Occurred, Please try again');
    }
  };

  const handleLocalPreviewCancel = () => {
    setProviderHasVideo(!isEmpty(videoInformation.Url));
    setIsLocalVideoUpload(false);
    toggleVideoGuidelinesVisibility(true);
    setLocalVideoMetadata({});
  };

  const handleLocalPreviewConfirm = () => {
    setIsLocalVideoUploading(true);
    service
      ._postFile(
        `/api/video/upload-profilevideo?pwid=${
          videoInformationObj.ProviderId
        }&duration=${localVideoMetadata.Duration.replace(':', '.')}&size=${
          localVideoMetadata.Size
        }`,
        localVideoMetadata.File,
        (event) => {
          let uploadPercent = Math.round((100 * event.loaded) / event.total);
          setVideoUploadProgress(`${uploadPercent}%`);
          if (uploadPercent >= 100) setSpinnerVisibility(true);
        }
      )
      .then((res) => {
        if (!isEmpty(res) && res.status == 200) {
          let data = res.data;
          if (data.Success) {
            let tempVideoInformationObj = {
              ...videoInformationObj,
              Duration: localVideoMetadata.Duration,
              Size: localVideoMetadata.Size,
              Url: localVideoMetadata.Uri
            };
            let _tempProviderProfileInfo = {
              ...providerProfileInfo,
              VideoInformationJson: JSON.stringify(tempVideoInformationObj),
              HasVideo: true
            };
            setLocalVideoMetadata({});
            setIsLocalVideoUpload(false);
            dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
          }
        } else {
          toaster.Error('Some error occured please try again!');
        }
      })
      .catch((error) => {
        if (error.response) {
          let data = error.response.data;
          if(data.ErroMessage != undefined)
          {
          toaster.Error(data.ErrorMessage);
          }
          else {
            let htmlContent = error.response.data;
            if(htmlContent.includes("Request Entity Too Large"))
            {
              toaster.Error("Request length is too long, please try again with a smaller file");
              setIsLocalVideoUploading(false);
              setIsYoutubeVideoUpload(false);
            }
            else
            {
              toaster.Error('Some error occured, please try again');F
            }
          }

        } else {
          toaster.Error('Some error occured, please try again');
        }
      });
  };

  const onTabsChangeHandlerForVideo = (selectedTab) => {
    props.onTabsChangeHandler(selectedTab);
  };

  //drag drop handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();

    const files = [...e.dataTransfer.files];

    if (files.length !== 1) {
      toaster.Error(`Only 1 file can be uploaded at a time`);
      return;
    }

    if (validateVideoFile(files[0])) {
      localFilePreview(files[0]);
    }
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //validation helpers
  const validateLink = (link) => {
    if (link) {
      var regExp =
        /^(?:https?:\/\/)?(?:m\.|www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
      if (link.match(regExp)) {
        return true;
      }
    }
    return false;
  };

  const validateVideoFile = (file) => {
    const maxSize = 300;

    const formats = ['video/mp4', 'video/x-ms-wmv'];

    if (formats && !formats.includes(file.type)) {
      toaster.Error(`Only following file formats are acceptable: ${formats.join(', ')}`);
      return false;
    }

    if (file.size < 1) {
      return false;
    }

    let size = file.size / Math.pow(1024, 2);
    if (size > maxSize) {
      toaster.Error('Max file size supported is 300Mb');
      return false;
    }

    setLocalVideoMetadata({
      Title: file.name,
      Duration: '',
      Size: size
    });
    return true;
  };

  //effects
  useEffect(() => {
    if (
      !minifyCurrentVideo &&
      isYoutubeVideoUpload &&
      !isLocalVideoUpload &&
      !videoGuidelinesVisibility
    ) {
      linkShowHideGuidelines.current.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }, [
    minifyCurrentVideo,
    isYoutubeVideoUpload,
    isLocalVideoUpload,
    videoGuidelinesVisibility,
    youtubeVideoMetadata
  ]);

  useEffect(() => {
    if (validateLink(youtubeVideoUrl)) {
      loadYoutubePreview();
    } else {
      setIsYoutubeVideoUpload(false);
    }
  }, [youtubeVideoUrl]);

  useEffect(() => {
    const videoInformation = JSON.parse(providerProfileInfo.VideoInformationJson);
    setVideoInformationObj(videoInformation);
    setProviderHasVideo(providerProfileInfo.HasVideo);
  }, [providerProfileInfo]);

  //jsx
  const _youtubeVideoUpload = (

    <div className='video-metadata-container'>
      <video src={isEmpty(youtubeVideoMetadata.Uri) ? '' : youtubeVideoMetadata.Uri} controls />
      <LayoutInfo
        identifier='profile-video-youtube-video-description'
        title='Profile Video'
        description={
          isEmpty(youtubeVideoMetadata.Duration)
            ? ''
            : `Duration : ${youtubeVideoMetadata.Duration}Min \nSize : ${youtubeVideoMetadata.Size}Mb`
        }
        bullets={{ title: 'Missing Fields', data: [] }}>
        <Cta
          ctaValid={true}
          cancelText='Cancel'
          cancelClickHandler={handleYoutubePreviewCancel}
          confirmText='Confirm'
          confirmClickHandler={handleYoutubePreviewConfirm}
        />
      </LayoutInfo>
    </div>
  );

  const _localVideoUpload = (
    <div className='video-metadata-container' ref={localVideoContainer}>
      {isLocalVideoUploading ? (
        <div className='upload-progress-container'>
          <span className='upload-title'>Uploading Profile Video</span>
          <span className='upload-progress-text'>{videoUploadProgress}</span>
          <div className='progress'>
            <div style={{ width: videoUploadProgress }} className='progress-bar'></div>
            <a className='cancel-upload' onClick={() => setIsLocalVideoUploading(false)}>
              Cancel
            </a>
          </div>
          <div className='upload-video-metadata'>
            <span>Duration: {localVideoMetadata.Duration}Min</span>
            <span>Size: {localVideoMetadata.Size}Mb</span>
          </div>
        </div>
      ) : (
        <LayoutInfo
          identifier='profile-video-video-description'
          title='Profile Video'
          description={
            isEmpty(localVideoMetadata.Duration)
              ? ''
              : `Duration : ${localVideoMetadata.Duration}Min \nSize : ${localVideoMetadata.Size}Mb`
          }
          bullets={{ title: 'Missing Fields', data: [] }}>
          <Cta
            ctaValid={true}
            cancelText='Cancel'
            cancelClickHandler={handleLocalPreviewCancel}
            confirmText='Confirm'
            confirmClickHandler={handleLocalPreviewConfirm}
          />
        </LayoutInfo>
      )}
    </div>
  );

  const _showCurrentVideo = providerHasVideo && (
    <div className='video-metadata-container' style={minifyCurrentVideo ? { width: '70%' } : {}}>
      {!IS_BRIGHTSPOT ? (
        <video src={isEmpty(videoInformationObj.Url) ? '' : videoInformationObj.Url} controls />
      ) : (
        <iframe
          width={438}
          height={window.innerWidth > 768 ? 297 : 200}
          preload='metadata'
          controls='controls'
          id='current-brightspot-video'
          src={videoInformationObj.Url}
        />
      )}
      <LayoutInfo
        identifier='current-video-description'
        title='Profile Video'
        description={
          isEmpty(videoInformationObj.Duration)
            ? ''
            : `Duration : ${videoInformationObj.Duration}Min \nSize : ${videoInformationObj.Size}Mb`
        }
        bullets={{ title: 'Missing Fields', data: [] }}>
        {!minifyCurrentVideo && (
          <Cta
            ctaValid={true}
            cancelText='Delete Video'
            cancelClickHandler={() => setIsDeleteModalOpen(true)}
            confirmText='Upload New Video'
            confirmClickHandler={currentVideoUploadHandler}
          />
        )}
      </LayoutInfo>
    </div>
  );

  const _dragAndUploadContainer = (minifyCurrentVideo || !providerHasVideo) &&
    !(isYoutubeVideoUpload || isLocalVideoUpload) && (
      <>
        <div className='profile-video-separator'>
          <div>
            <span>Or</span>
          </div>
        </div>
        <div
          ref={dropContainer}
          className='profile-video-upload-drag-drop'
          onDragOver={handleDragOver}
          onDrop={handleDrop}>
          <UploadInput
            acceptedFileTypes='video/mp4, video/x-ms-wmv'
            id='upload-profile-video'
            label='Drag & Drop your Video file to Upload'
            buttonText='Choose Video file'
            multiple={false}
            onChange={uploadSelectHandler}
            showValidation={false}
          />
        </div>
      </>
    );

  const _youtubeUrlContainer = (minifyCurrentVideo || !providerHasVideo) &&
    !(isYoutubeVideoUpload || isLocalVideoUpload) && (
      <div className='profile-video-upload-url'>
        <TextInput
          id='youtube-url'
          name='youtubeUrl'
          label='Insert a video URL:'
          placeholder='Eg : https://www.youtube.com/watch?v=fC_fbFsCWRw'
          onChange={(name, value) => setYoutubeVideoUrl(value)}
          value={youtubeVideoUrl}
        />
      </div>
    );

  const _videoBestPracticesGuidelines = (
    <>
      <div className='profile-video-best-practices'>
        <h5 className='profile-video-subheading'>Best practices for video creating</h5>
        <ul className='profile-video-list'>
          <li className='profile-video-list-item'>
            Introduce yourself: Be clear, concise. Show your energy and confidence while you
            introduce yourself.
          </li>
          <li className='profile-video-list-item'>
            Length of your intro video: Short videos are best, people have short attention spans,
            hence be mindful of the length of your intro video.
          </li>
          <li className='profile-video-list-item'>
            Think of questions that your patients would ask: Know your audience. Try to answer FAQ's
            you hear from your patients.
          </li>
        </ul>
      </div>
      <div className='profile-video-guidelines'>
        <h5 className='profile-video-subheading'>Video upload Guidelines</h5>
        <ul className='profile-video-list'>
          <li className='profile-video-list-item'>
            Recommended video dimensions of 1280 x 720 for Landscape and Portrait with a maximum
            size of 4GB.
          </li>
          <li className='profile-video-list-item'>
            Minimum width of 1200 pixels (length depends on aspect ratio) for Landscape and
            Portrait.
          </li>
          <li className='profile-video-list-item'>
            Aspect ratio: Landscape is 16:9 and Portrait is 9:16. Mobile renders both video types to
            aspect ratio 2:3.
          </li>
        </ul>
      </div>
    </>
  );

  return (
    <>
      <div className='profile-video-container'>
        <div className='profile-video-header-wrapper'>
          <div className='profile-video-header'>
            <h2 className='profile-video-heading'>Profile Video</h2>
            <p className='profile-video-content'>
              You can add a link of your video from sites like youtube or upload the video from your
              computer. Approved videos will be processed and displayed on your profile at
              healthgrades.com.
            </p>
          </div>

          {/* <Tip
            currentTip='cinebody'
            onTabsChangeHandler={onTabsChangeHandlerForVideo}
            content={constants.cinebodyTip}
            infoObj={providerProfileInfo.NavigationModel}
          /> */}

          {videoGuidelinesVisibility && _videoBestPracticesGuidelines}
        </div>
        <div className='profile-video-hide-link' ref={linkShowHideGuidelines}>
          <a onClick={() => toggleVideoGuidelinesVisibility(!videoGuidelinesVisibility)}>
            {videoGuidelinesVisibility ? 'Hide' : 'Show'} Best Practices and Guidelines
          </a>
        </div>
        <div className='profile-video-upload-wrapper'>
          <div className='section-video-preview' ref={sectionVideoPreview}>
            {minifyCurrentVideo && (
              <div className='div-header-current-video'>
                <span>Your Current Video</span>
              </div>
            )}
            {_showCurrentVideo}
          </div>
          <div className='section-video-upload' ref={sectionVideoUpload}>
            {minifyCurrentVideo && (
              <div className='div-header-upload-new-video'>
                <span>Upload New Video</span>
                <a
                  onClick={() => {
                    sectionVideoPreview.current.scrollIntoView({
                      behavior: 'smooth',
                      block: 'center',
                      inline: 'nearest'
                    });
                    setMinifyCurrentVideo(false);
                  }}>
                  Cancel
                </a>
              </div>
            )}
            {_youtubeUrlContainer}
            {isYoutubeVideoUpload && _youtubeVideoUpload}
            {isLocalVideoUpload && _localVideoUpload}
            {_dragAndUploadContainer}
          </div>
        </div>
      </div>
      <ReactModal
        overlayClassName='modal-overlay delete-modal'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={isDeleteModalOpen}
        contentLabel='Remove Profile Photo'
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container'>
          <div className='modal-header'>
            <div className='modal-close' onClick={() => setIsDeleteModalOpen(false)}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>
          <div className='modal-body'>
            <span>Are you sure, you want to delete your</span>
            <strong>Profile Video?</strong>
          </div>
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText='Cancel'
              cancelClickHandler={() => setIsDeleteModalOpen(false)}
              confirmText='Confirm'
              confirmClickHandler={() => {
                currentVideoDeleteHandler();
                setIsDeleteModalOpen(false);
              }}
            />
          </div>
        </div>
      </ReactModal>
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </>
  );
};

export default ProfileVideo;
