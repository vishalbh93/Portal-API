import React from 'react';

//stylesheet imports
import './_profilePhotoVideo.less';

//component imports
import ProfilePhoto from './ProfilePhoto/ProfilePhoto';
import ProfileVideo from './ProfileVideo/ProfileVideo';

const ProfilePhotoVideo = (props) => {
  const onTabsChangeHandlerForVideo = (selection) => {
    props.onTabsChangeHandler(selection);
  };

  return (
    <main className='profile-photo-video-main'>
      <section className='profile-photo-section'>
        <ProfilePhoto />
      </section>
      <hr />
      <section className='profile-video-section'>
        <ProfileVideo onTabsChangeHandler={onTabsChangeHandlerForVideo} />
      </section>
    </main>
  );
};

export default ProfilePhotoVideo;
