import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//stylesheet imports
import './_commonQuestionaire.less';

//components import
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import { RadioGroup } from '../../FormComponents/RadioGroup';
import Button from '@hg/joy/src/components/Button';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';

//helper imports
import { _radioOptionsYesNo } from '../../../utils/constant-data';
import isEmpty from '../../../utils/validation/isEmpty';

const CommonQuestionaire = () => {
  // setup
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const crowdSourceJson = JSON.parse(providerProfileInfo.CrowdSourceJson);
  const crowdSourceContent = providerProfileInfo.Content.CrowdSourceContent;
  const dispatch = useDispatch();

  //states
  const [INIT_STATE, UPDATE_INIT_STATE] = useState({
    ProviderId: JSON.parse(providerProfileInfo.InformationJson).ProviderId,
    Questions: crowdSourceJson.map((questions) => ({
      OwnerOverrideAnswer: questions.ownerOverrideAnswer,
      QuestionModel: {
        Question: questions.questionModel.question,
        QuestionType: questions.questionModel.questionType
      }
    }))
  });
  const [crowdSourceQuestionsObj, setCrowdSourceQuestionsObj] = useState(INIT_STATE);

  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);

  //isValid => ClassName => CTA
  const _ctaValid = crowdSourceQuestionsObj.Questions.every(
    (value, index) => value.OwnerOverrideAnswer == crowdSourceJson[index].ownerOverrideAnswer
  )
    ? ''
    : 'valid';

  //event handlers
  const radioGroupChangeHandler = (event, index) => {
    event.persist();

    let value = event.target.value;
    let _tempCrowdSourceQuestions = [...crowdSourceQuestionsObj.Questions];

    let _tempQuestionToUpdate = {
      ..._tempCrowdSourceQuestions[index],
      OwnerOverrideAnswer: value.toLowerCase()
    };
    _tempCrowdSourceQuestions[index] = _tempQuestionToUpdate;

    setCrowdSourceQuestionsObj((prev) => ({
      ...prev,
      Questions: _tempCrowdSourceQuestions
    }));
  };

  const _updateCrowdSourceData = () => {
    service
      .post(`/api/provider/update-crowdsource`, crowdSourceQuestionsObj)
      .then((res) => {
        if (res.Success) {
          let _tempCrowdSourceJson = crowdSourceJson.map((question, index) => ({
            ...question,
            ownerOverrideAnswer: crowdSourceQuestionsObj.Questions[index].OwnerOverrideAnswer
          }));
          let _tempProviderProfileInfo = {
            ...providerProfileInfo,
            CrowdSourceJson: JSON.stringify(_tempCrowdSourceJson)
          };
          dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
          toaster.Success('Success');
        }
      })
      .catch(() => toaster.Error('Some error occurred, please try again!!'))
      .finally(() => setSpinnerVisibility(false));
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //effects
  useEffect(() => {
    let _crowdSourceJson = JSON.parse(providerProfileInfo.CrowdSourceJson);
    UPDATE_INIT_STATE({
      ProviderId: JSON.parse(providerProfileInfo.InformationJson).ProviderId,
      Questions: _crowdSourceJson.map((questions) => ({
        OwnerOverrideAnswer: questions.ownerOverrideAnswer,
        QuestionModel: {
          Question: questions.questionModel.question,
          QuestionType: questions.questionModel.questionType
        }
      }))
    });
  }, [providerProfileInfo]);

  return (
    <section id='provider-profile-common-questionaire-section'>
      <LayoutInfo
        identifier='provider-profile-common-questionaire'
        title='Common Questionnaire'
        description={crowdSourceContent}
        bullets={{
          title: 'Missing Fields',
          data: []
        }}>
        {crowdSourceQuestionsObj.Questions.map((question, index) => (
          <div className='div-provider-profile-common-questionaire-list' key={index}>
            <label className='provider-profile-common-questionaire-question-label'>
              {question.QuestionModel.Question}
            </label>
            <div className='provider-profile-common-questionaire-question-option'>
              <RadioGroup
                radioGroup={_radioOptionsYesNo}
                selectedOption={
                  isEmpty(question.OwnerOverrideAnswer)
                    ? ''
                    : `${question.OwnerOverrideAnswer.charAt(
                        0
                      ).toUpperCase()}${question.OwnerOverrideAnswer.slice(1)}`
                }
                onChangeHandler={(event) => radioGroupChangeHandler(event, index)}
              />
            </div>
          </div>
        ))}
      </LayoutInfo>
      <div className='action-section'>
        <Button
          id='btn-cancel'
          text='Cancel'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-cancel ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            setCrowdSourceQuestionsObj(INIT_STATE);
          }}
        />
        <Button
          id='btn-save'
          text='Save'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-save ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            setSpinnerVisibility(true);
            _updateCrowdSourceData();
          }}
        />
      </div>
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </section>
  );
};

export default CommonQuestionaire;
