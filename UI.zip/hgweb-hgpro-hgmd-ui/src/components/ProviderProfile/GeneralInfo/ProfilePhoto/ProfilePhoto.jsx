import React, { useState, useRef, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//stylesheet imports
import './_profilePhoto.less';
import 'react-image-crop/dist/ReactCrop.css';

//component imports
import ProviderImage from '@hg/joy/src/components/ProviderImage';
import UploadInput from '@hg/joy/src/components/formElements/UploadInput';
import ReactModal from 'react-modal';
import Button from '@hg/joy/src/components/Button';
import ReactCrop, { centerCrop, makeAspectCrop } from 'react-image-crop';
import Toast from '../../../Common/Toast/Toast';
import Spinner from '../../../Spinner/Spinner';
import LayoutInfo from '../../../Common/Layouts/LayoutInfo';
import isEmpty from '../../../../utils/validation/isEmpty';
import Cta from '../../../Common/Form/CTA/Cta';

//svg imports
import Close from '../../../../assets/images/ProviderProfile/svg-cross.svg';
import svgTrash from '../../../../assets/images/ProviderProfile/svg-trash.svg';
import alert from '../../../../assets/images/ProviderProfile/alert.svg';

//service
import * as service from '../../../../utils/service';
import * as actions from '../../../../store/actions';
import { getGenderCode } from '../../../../utils/utils';

//helper fn
function centerAspectCrop(mediaWidth, mediaHeight, aspect) {
  return centerCrop(
    makeAspectCrop(
      {
        unit: 'px',
        width: 240
      },
      aspect,
      mediaWidth,
      mediaHeight
    ),
    mediaWidth,
    mediaHeight
  );
}

const ProfilePhoto = () => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const providerInformation = JSON.parse(providerProfileInfo.InformationJson);
  const dispatch = useDispatch();

  //states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRemovePhotoModalOpen, setIsRemovePhotoModalOpen] = useState(false);
  const [providerInfoObj, setProviderInfoObj] = useState({
    HasImage: providerInformation.HasImage,
    ImageUrl: providerInformation.ImageUrl
  });
  const [fileInformation, setFileInformation] = useState({ name: '', size: null });

  const modalRef = useRef(null);

  //states for image-crop
  const [imgSrc, setImgSrc] = useState('');
  const imgRef = useRef(null);
  const [crop, setCrop] = useState();
  const [completedCrop, setCompletedCrop] = useState();
  const [aspect] = useState(3 / 4);

  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);
  const [error_Message, setError_Message] =useState('');
  let isMobileView = window.innerWidth <= 768;

  //service events
  const checkImage = (file) => {
    let IMAGE_UPLOAD_URL = '/image/upload';
    let IMAGE_CHECK_URL = '/api/image/check-image';

    const fd = new FormData();
    fd.append('file', file);

    return fetch(
      `${IMAGE_UPLOAD_URL}?id=${providerInformation.ProviderId}&isScaledImplementationRequired=false`,
      {
        method: 'POST',
        body: fd
      }
    )
      .then((res) => res.json())
      .then((resJson) => {
        if (resJson.Success) {
          return fetch(`${IMAGE_CHECK_URL}?id=${providerInformation.ProviderId}`);
        } else return new Promise((resolve, reject) => reject(resJson));
      });
  };

  const saveCroppedImage = () => {
    setSpinnerVisibility(true);
    let scaleFactor = imgRef.current.naturalWidth / imgRef.current.clientWidth;
    scaleFactor = Math.floor(scaleFactor * 10) / 10;
    let payload = {
      ProviderId: providerInformation.ProviderId,
      image: {
        xCoord:
          Math.floor(completedCrop.x * scaleFactor) < 0
            ? 0
            : Math.floor(completedCrop.x * scaleFactor),
        yCoord:
          Math.floor(completedCrop.y * scaleFactor) < 0
            ? 0
            : Math.floor(completedCrop.y * scaleFactor),
        width: Math.floor(completedCrop.width * scaleFactor) - 1,
        height: Math.floor(completedCrop.height * scaleFactor) - 1,
        providerId: providerInformation.ProviderId
      }
    };
    service
      .post('/api/image/crop-image', payload)
      .then((res) => {
        if (res.Success) {
          let returnData = JSON.parse(res.ReturnData);
          updateProviderProfileInfoStore(returnData.imageUrl);
          toaster.Success('Success');
        } else {
          setError_Message(res.ErrorMessage);
        }
      })
      .catch((err) => toaster.Error('There was a problem uploading your image'))
      .finally(() => {
        setSpinnerVisibility(false);
        handleProfilePhotoModalClose();
      });
  };

  const removeImage = () => {
    setSpinnerVisibility(true);
    service
      .post('/api/image/remove-image', {
        providerId: providerInformation.ProviderId
      })
      .then((res) => {
        if (res.Success) {
          updateProviderProfileInfoStore('');
          toaster.Success('Success');
        } else toaster.Error(res.ErrorMessage);
      })
      .catch((err) => toaster.Error('There was a problem removing your image'))
      .finally(() => {
        setSpinnerVisibility(false);
        setIsRemovePhotoModalOpen(false);
      });
  };

  const updateProviderProfileInfoStore = (imageUrl) => {
    let _tempProviderInformationObj = {
      ...providerInformation,
      ImageUrl: imageUrl,
      HasImage: !isEmpty(imageUrl)
    };
    let _tempProviderProfileInfo = {
      ...providerProfileInfo,
      InformationJson: JSON.stringify(_tempProviderInformationObj)
    };
    dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
  };

  //helpers
  const clearUploadInputButton = () => {
    let uploadInputEle = document.getElementById('upload-input--for-upload-profile-photo');
    isEmpty(uploadInputEle) ? null : (uploadInputEle.value = null);
    let uploadInputInnerEle = document.getElementById('upload-input--for-upload-profile-photo-new');
    isEmpty(uploadInputInnerEle) ? null : (uploadInputInnerEle.value = null);
  };

  //event handlers
  const handleProfilePhotoSelection = (id, files) => {
    setError_Message('') ;
    setSpinnerVisibility(true);
    checkImage(files[0])
      .then((res) => res.json())
      .then((data) => {
        if (data.Success) {
          let returnData = JSON.parse(data.ReturnData);
          if (returnData.width >= 240 && returnData.height >= 320) {
            setFileInformation({ name: files[0].name, size: Math.round(files[0].size / 1024) });
            setCrop(undefined);
            setImgSrc('');
            const reader = new FileReader();
            reader.addEventListener('load', () => setImgSrc(reader.result.toString() || ''));
            reader.readAsDataURL(files[0]);
            setIsModalOpen(true);
          } else toaster.Error('The image is top small');
        } else {
          setError_Message(data.ErrorMessage);
        }
      })
      .catch((err) =>
        isEmpty(err.ErrorMessage)
          ? toaster.Error('Some error occured!!')
          : setError_Message(err.ErrorMessage)   
      )
      .finally(() => { 
        clearUploadInputButton();
        setSpinnerVisibility(false);
      });
  };

  const handleProfilePhotoModalClose = () => {
    clearUploadInputButton();
    setFileInformation({ name: '', size: null });
    setIsModalOpen(false);
  };

  const onImageLoad = (e) => {
    if (aspect) {
      const { width, height } = e.currentTarget;
      setCrop(centerAspectCrop(width, height, aspect));
    }
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  //effects
  useEffect(() => {
    let providerInformation = JSON.parse(providerProfileInfo.InformationJson);
    setProviderInfoObj({
      HasImage: providerInformation.HasImage,
      ImageUrl: providerInformation.ImageUrl
    });
  }, [providerProfileInfo]);

  //jsx
  const _removeProfileImageJSX = (
    <img
      className='profile-photo-trash'
      src={svgTrash}
      alt='Delete Profile Image'
      onClick={() => setIsRemovePhotoModalOpen(true)}
    />
  );

  return (
    <div className={`profile-photo-container ${providerInfoObj.HasImage ? 'has-image' : ''}`}>
      <div className='profile-photo-header'>
        <h2 className='profile-photo-heading'>Profile Photo</h2>
        <p className='profile-photo-content'>This will be displayed on your profile</p>
      </div>
      <div className='profile-photo-subheader'>
        <div className='profile-photo-guidelines'>
          <h5 className='profile-photo-subheading'>Photo upload Guidelines :</h5>
          <ul className='profile-photo-guidelines-list'>
            <li className='profile-photo-guidelines-list-item'>
              For best results, use a high-resolution photo in a portrait format (e.g. cropped for a
              3x4 portrait or 768 x 1024 pixels, or larger)
            </li>
            <li className='profile-photo-guidelines-list-item'>
              File should be a JPEG, JPG or PNG (we can't accept GIF, BMP, TIFF and other photo
              types)
            </li>
            <li className='profile-photo-guidelines-list-item'>The maximum file size is 10MB</li>
            <li className='profile-photo-guidelines-list-item'>
              Use a professional headshot of this provider only
            </li>
            <li className='profile-photo-guidelines-list-item'>No other people in the photo</li>
            <li className='profile-photo-guidelines-list-item'>
              No practice or facility photos in this section
            </li>
            <li className='profile-photo-guidelines-list-item'>No logos in this photo</li>
            <li className='profile-photo-guidelines-list-item'>
              No pictures depicting patient outcomes
            </li>
          </ul>
        </div>
        <div className='profile-photo-upload-wrapper'>
          <ProviderImage
            providerName={providerInformation.Name.DisplayName}
            providerGender={getGenderCode(providerInformation.Gender)}
            src={providerInfoObj.ImageUrl}
            size='lg'
          />
          {providerInfoObj.HasImage && _removeProfileImageJSX}
          <UploadInput
            acceptedFileTypes='image/png, image/jpeg'
            id='upload-profile-photo'
            buttonText='Upload New Photo'
            multiple={false}
            onChange={handleProfilePhotoSelection}
            required
            showValidation={false}
          />
        </div>
        {isMobileView && <div className='error_message'>{error_Message !='' &&<span><img src={alert} className='warning-image'></img>{error_Message}</span>} </div>}
      </div>
      {!isMobileView && <div className='error_message'>{error_Message !='' &&<span><img src={alert} className='warning-image'></img>{error_Message}</span>} </div>}

      <ReactModal
        overlayClassName='modal-overlay'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={isModalOpen}
        onAfterOpen={() =>
          modalRef.current.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
            inline: 'nearest'
          })
        }
        contentLabel='Profile Photo'
        onRequestClose={handleProfilePhotoModalClose}
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container' ref={modalRef}>
          <div className='modal-header'>
            <h4 className='modal-title'>Upload Photo</h4>
            <div className='modal-close' onClick={handleProfilePhotoModalClose}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>
          <div className='modal-body'>
            <ReactCrop
              className='react-crop-container'
              crop={crop}
              onChange={(_, percentCrop) => setCrop(percentCrop)}
              onComplete={(c) => setCompletedCrop(c)}
              aspect={aspect}
              minWidth={
                isEmpty(imgRef.current)
                  ? '240'
                  : `${240 / (imgRef.current.naturalWidth / imgRef.current.clientWidth)}`
              }
              minHeight='320'>
              <div className='image-cropper-container'>
                <img ref={imgRef} alt='Crop Area' src={imgSrc} onLoad={onImageLoad} />
              </div>
            </ReactCrop>
            <LayoutInfo
              identifier='upload-photo-details'
              title={fileInformation.name}
              description={`Size: ${fileInformation.size} KB`}
              bullets={{ title: 'Missing Fields', data: [] }}>
              <UploadInput
                acceptedFileTypes='image/png, image/jpeg'
                id='upload-profile-photo-new'
                buttonText='Upload New'
                multiple={false}
                onChange={handleProfilePhotoSelection }
                required
                showValidation={false}
              />
            </LayoutInfo>
          </div>
          <hr />
          <div className='modal-footer'>
            <div className='action-section'>
              <Button
                id='btn-cancel'
                text='Cancel'
                className='provider-profile-cancel valid'
                size='lg'
                style='ghost'
                onClick={handleProfilePhotoModalClose}
              />
              <Button
                id='btn-save'
                text='Confirm'
                className='provider-profile-save valid'
                size='lg'
                style='ghost'
                disabled={crop == undefined || (crop.height == 0 && crop.width == 0)}
                onClick={saveCroppedImage}
              />
            </div>
          </div>
        </div>
      </ReactModal>
      <ReactModal
        overlayClassName='modal-overlay alert-box'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={isRemovePhotoModalOpen}
        contentLabel='Remove Profile Photo'
        shouldCloseOnOverlayClick={false}>
        <div className='modal-container'>
          <div className='modal-header'>
            <div className='modal-close' onClick={() => setIsRemovePhotoModalOpen(false)}>
              <img className='close-icon' src={Close} alt='Close' />
            </div>
          </div>
          <div className='modal-body'>
            <span>Are you sure, you want to delete your</span>
            <strong>Profile Photo?</strong>
          </div>
          <div className='modal-footer'>
            <Cta
              ctaValid={true}
              cancelText='Cancel'
              cancelClickHandler={() => setIsRemovePhotoModalOpen(false)}
              confirmText='Confirm'
              confirmClickHandler={removeImage}
            />
          </div>
        </div>
      </ReactModal>

      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </div>
  );
};

export default ProfilePhoto;
