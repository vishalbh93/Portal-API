import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';

//service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';

//stylesheet imports
import './_basicInfo.less';

//components import
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
import SelectInput from '@hg/joy/src/components/formElements/SelectInput';
import SingleDateInput from '@hg/joy/src/components/formElements/SingleDateInput';
import Button from '@hg/joy/src/components/Button';
import Tags from '../../Common/Form/AutoSuggest/Tags';
import Toast from '../../Common/Toast/Toast';
import Spinner from '../../Spinner/Spinner';

//constant imports
import { genderOptions, suffixOptions } from '../../../utils/constant-data';

//helper
import isEmpty from '../../../utils/validation/isEmpty';
import isDateValid from '../../../utils/validation/isDateValid';
import AutoSuggest from '../../Common/Form/AutoSuggest/AutoSuggest';
import * as dateFormat from '../../../utils/dateFormat';

const BasicInfo = (props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const providerInformation = JSON.parse(providerProfileInfo.InformationJson);
  const languageInformation = JSON.parse(providerProfileInfo.LanguageJson);
  let { Content } = providerProfileInfo;
  const dispatch = useDispatch();
  const UpdatedDegree =
    (props.displayName != undefined || props.displayName != null) &&
    (props.displayName.split(',')[1] != null || props.displayName.split(',')[1] != undefined)
      ? props.displayName.split(',')[1].trim()
      : providerInformation.Name.Degree.trim();

  const acceptingNewPatientsJson = JSON.parse(providerProfileInfo.AcceptingNewPatientsJson);

  let genderJsonOptions = genderOptions;

  try {
    const genderJsonData = JSON.parse(providerProfileInfo.ApplicationConfigJson);
    genderJsonOptions =
      genderJsonData.Genders !== undefined && genderJsonData.Genders !== null
        ? genderJsonData.Genders
        : genderOptions;
  } catch (e) {
    genderJsonOptions = genderOptions;
  }

  // state
  const [INIT_STATE_PI, UPDATE_INIT_STATE_PI] = useState({
    firstName: providerInformation.Name.FirstName,
    lastName: providerInformation.Name.LastName,
    gender: providerInformation.Gender,
    suffix: providerInformation.Name.Suffix,
    dob: isEmpty(providerInformation.DateOfBirth)
      ? ''
      : new Date(providerInformation.DateOfBirth).toLocaleDateString('en-US'),
    degree: providerInformation.Name.Degree.trim(),
    errors: {
      firstName: isEmpty(providerInformation.Name.FirstName) ? 'Enter First Name' : '',
      lastName: isEmpty(providerInformation.Name.LastName) ? 'Enter Last Name' : '',
      dob: isEmpty(providerInformation.DateOfBirth) ? 'Enter Date of Birth' : ''
    }
  });
  const [personalInformation, setPersonalInformation] = useState(INIT_STATE_PI);
  const [degreeAutoSuggest, setDegreeAutoSuggest] = useState([]);
  const [INIT_STATE_LS, UPDATE_INIT_STATE_LS] = useState(
    languageInformation.Items.map((language) => ({ ...language, Text: language.Language }))
  );
  const [languagesSpokenObj, setLanguagesSpokenObj] = useState(INIT_STATE_LS);
  const [languagesSpokenAutoSuggest, setLanguagesSpokenAutoSuggest] = useState([]);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [spinnerVisibility, setSpinnerVisibility] = useState(false);

  //Personal Info Validating State(s)
  const [validating, setValidating] = useState({
    firstName: false,
    lastName: false,
    dob: false
  });
  const [PAGE_HAS_ERRORS, SET_PAGE_HAS_ERRORS] = useState(
    document.querySelectorAll('[id$=error-message]').length > 0
  );

  //isValid => ClassName => CTA
  const _ctaPersonalInformationEqual =
    providerInformation.Name.FirstName == personalInformation.firstName &&
    providerInformation.Name.LastName == personalInformation.lastName &&
    providerInformation.Name.Suffix == personalInformation.suffix &&
    providerInformation.Gender == personalInformation.gender &&
    (providerInformation.Name.Degree == personalInformation.degree ||
      personalInformation.degree == UpdatedDegree) &&
    new Date(providerInformation.DateOfBirth).toString() ==
      new Date(personalInformation.dob).toString();

  const _ctaLanguagesSpokenEqual =
    languageInformation.Items.length ===
    languagesSpokenObj.filter((lang) => lang.UpdateType !== 'Delete').length
      ? languageInformation.Items.every(
          (value, index) => value.UpdateType === languagesSpokenObj[index].UpdateType
        )
      : false;

  const _ctaValid =
    _ctaPersonalInformationEqual && _ctaLanguagesSpokenEqual ? '' : PAGE_HAS_ERRORS ? '' : 'valid';

  // handlers
  const handlePersonalInformationInputChange = (event) => {
    const { value, name } = event.target;

    // valdiation(s)
    let _errors = personalInformation.errors;
    switch (name) {
      case 'firstName':
        _errors.firstName = value.length > 0 ? '' : 'Enter First Name';
        break;
      case 'lastName':
        _errors.lastName = value.length > 0 ? '' : 'Enter Last Name';
        break;
      // case 'gender':
      //   _errors.gender = value.length > 0 ? '' : 'Enter Gender';
      //   break;
      case 'dob':
        _errors.dob = value.length > 0 ? '' : 'Enter Date of Birth';
        break;
      // case 'degree':
      //   _errors.degree = value.length > 0 ? '' : 'Enter Degree';
      //   break;

      default:
        break;
    }

    setPersonalInformation((prev) => ({
      ...prev,
      errors: _errors,
      [name]: value
    }));
  };

  const degreeInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length > 0) {
      service
        .get(`/api/autosuggest?term=${value}&type=Degree`)
        .then((res) => {
          let _tempDegreeData = res.length > 0 ? res : [];
          setDegreeAutoSuggest(_tempDegreeData);
        })
        .catch((err) => {});
    } else {
      handlePersonalInformationInputChange({ target: { value: '', name: 'degree' } });
      setDegreeAutoSuggest([]);
    }
  };

  const degreeSelectHandler = (degreeObj) => {
    handlePersonalInformationInputChange({ target: { value: degreeObj.Id, name: 'degree' } });
    setDegreeAutoSuggest([]);
  };

  const languageInputChangeHandler = (event) => {
    let value = event.target.value.toLowerCase();
    if (value.length > 0) {
      service
        .get(`/api/autosuggest?term=${value}&type=Language`)
        .then((res) => {
          let _tempLangObj = languagesSpokenObj
            .filter((e) => e.UpdateType != 'Delete')
            .map((e) => e.Text);
          let _tempLanguagesData =
            res.length > 0
              ? res.map((e) => {
                  if (_tempLangObj.includes(e.Text)) {
                    return { ...e, Disabled: true };
                  } else return { ...e, Disabled: false };
                })
              : [];

          setLanguagesSpokenAutoSuggest(_tempLanguagesData);
        })
        .catch((err) => {});
    } else setLanguagesSpokenAutoSuggest([]);
  };

  const languageSelectHandler = (languageObj) => {
    let _tempLanguagesSpoken = [...languagesSpokenObj];
    if (_tempLanguagesSpoken.findIndex((lang) => lang.Id === languageObj.Id) == -1) {
      _tempLanguagesSpoken.push({ ...languageObj, Language: languageObj.Id, UpdateType: 'Add' });
      setLanguagesSpokenObj(_tempLanguagesSpoken);
    } else if (
      _tempLanguagesSpoken.find((lang) => lang.Id === languageObj.Id).UpdateType == 'Delete'
    ) {
      _tempLanguagesSpoken = _tempLanguagesSpoken.map((lang) => {
        if (lang.Id === languageObj.Id) return { ...lang, UpdateType: 'None' };
        else {
          return lang;
        }
      });
      setLanguagesSpokenObj(_tempLanguagesSpoken);
    }
    //Todo: Add Notification for already exists
    setLanguagesSpokenAutoSuggest([]);
  };

  const languageDeSelectHandler = (languageObj) => {
    let _tempLanguagesSpoken = languagesSpokenObj;
    setLanguagesSpokenObj(
      _tempLanguagesSpoken.map((lang) => {
        if (lang.Id == languageObj.Id) {
          return { ...lang, UpdateType: 'Delete' };
        } else {
          return lang;
        }
      })
    );
    setLanguagesSpokenAutoSuggest([]);
  };

  const _updateBasicInfo = async () => {
    let personalInformationPayload = {
      ProviderId: providerInformation.ProviderId,
      Name: {
        FirstName: personalInformation.firstName,
        MiddleName: !_.isEmpty(providerInformation.Name.MiddleName)
          ? providerInformation.Name.MiddleName
          : '',
        LastName: personalInformation.lastName,
        Degree: personalInformation.degree,
        Suffix: personalInformation.suffix
      },
      DateOfBirth: personalInformation.dob,
      Gender: personalInformation.gender,

      AcceptingNewPatients:
        providerInformation.AcceptingNewPatients == null
          ? providerInformation.AcceptingNewPatients == null
            ? false
            : providerInformation.AcceptingNewPatients
          : acceptingNewPatientsJson.AcceptingNewPatients
    };
    let languagesPayload = {
      Items: languagesSpokenObj,
      ProviderId: providerInformation.ProviderId
    };

    let _promises = [];

    if (!_ctaPersonalInformationEqual) {
      _promises.push(service.post(`/api/provider/update-info`, personalInformationPayload));
    }
    if (!_ctaLanguagesSpokenEqual)
      _promises.push(service.post(`/api/provider/update-languages`, languagesPayload));

    const _result = await Promise.allSettled(_promises);

    if (_result.every((res) => res.status === 'fulfilled')) {
      let providerInformationJson = providerProfileInfo.InformationJson;
      let languageInformationJson = providerProfileInfo.LanguageJson;

      if (!_ctaPersonalInformationEqual) {
        let _tempProviderInformationObj = {
          ...providerInformation,
          MissingData: false,
          Name: {
            ...providerInformation.Name,
            FirstName: personalInformation.firstName,
            LastName: personalInformation.lastName,
            Degree: personalInformation.degree,
            Suffix: personalInformation.suffix
          },
          Gender: personalInformation.gender,
          Suffix: personalInformation.suffix,
          DateOfBirth: new Date(personalInformation.dob).toISOString()
        };
        providerInformationJson = JSON.stringify(_tempProviderInformationObj);
      }
      if (!_ctaLanguagesSpokenEqual) {
        let _tempLanguagesSpoken = {
          ...languageInformation,
          Items: languagesSpokenObj
            .filter((obj) => obj.UpdateType != 'Delete')
            .map((obj) => {
              return { Id: obj.Id, Language: obj.Language, UpdateType: obj.UpdateType };
            })
        };
        languageInformationJson = JSON.stringify(_tempLanguagesSpoken);
      }
      let _tempProviderProfileInfo = {
        ...providerProfileInfo,
        InformationJson: providerInformationJson,
        LanguageJson: languageInformationJson
      };
      dispatch(actions.loadProviderProfileData(_tempProviderProfileInfo, false));
      toaster.Success('Success');
      props.bannerChangeHandler(personalInformation.degree, JSON.parse(providerInformationJson));
    } else {
      toaster.Error('Some error occurred, please try again!!');
    }
    setSpinnerVisibility(false);
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  useEffect(() => {
    const providerInformation = JSON.parse(providerProfileInfo.InformationJson);
    const languageInformation = JSON.parse(providerProfileInfo.LanguageJson);
    UPDATE_INIT_STATE_PI({
      firstName: providerInformation.Name.FirstName,
      lastName: providerInformation.Name.LastName,
      gender: providerInformation.Gender,
      suffix: providerInformation.Name.Suffix,
      dob: new Date(providerInformation.DateOfBirth).toLocaleDateString('en-US'),
      degree: providerInformation.Name.Degree,
      errors: {
        firstName: isEmpty(providerInformation.Name.FirstName) ? 'Enter First Name' : '',
        lastName: isEmpty(providerInformation.Name.LastName) ? 'Enter Last Name' : '',
        dob: isEmpty(providerInformation.DateOfBirth) ? 'Enter Date of Birth' : ''
      }
    });
    UPDATE_INIT_STATE_LS(
      languageInformation.Items.map((language) => ({ ...language, Text: language.Language }))
    );
  }, [providerProfileInfo]);

  useEffect(() => {
    if (document.querySelectorAll('[id$=error-message]').length > 0) SET_PAGE_HAS_ERRORS(true);
    else {
      SET_PAGE_HAS_ERRORS(
        isEmpty(personalInformation.firstName) ||
          isEmpty(personalInformation.lastName) ||
          isEmpty(personalInformation.dob)
      );
    }
  }, [personalInformation]);

  //useEffect for updates in --about-credentials-degree ---should update here
  useEffect(() => {
    let displayNameSplitArray = props.displayName.split(',');
    let degree = '';
    if (displayNameSplitArray.length > 1) degree = displayNameSplitArray[1];
    setPersonalInformation((prev) => ({
      ...prev,
      degree:
        props.displayName != undefined || props.displayName != null
          ? degree.trim()
          : providerInformation.Name.Degree
    }));
  }, [props.displayName]);
 


  return (
    <section id='provider-profile-basic-info-section'>
      <LayoutInfo
        identifier='provider-profile-basic-info-personal-info'
        title='Personal Info'
        description='This will be displayed on your profile.'>
        <TextInput
          id='input-provider-profile-basic-info-personal-info-fname'
          name='firstName'
          label='First Name*'
          placeholder='Enter First Name'
          onChange={(name, value) =>
            handlePersonalInformationInputChange({ target: { name: name, value: value } })
          }
          value={personalInformation.firstName}
          required={true}
          requiredErrorMessage='Please enter First Name'
          onBlur={() => {
            setValidating((prev) => ({ ...prev, firstName: true }));
          }}
          validating={validating.firstName}
          valid={
            !isEmpty(personalInformation.firstName) &&
            personalInformation.firstName.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/) == null
          }
        />
        <TextInput
          id='input-provider-profile-basic-info-personal-info-lname'
          name='lastName'
          label='Last Name*'
          placeholder='Enter Last Name'
          onChange={(name, value) =>
            handlePersonalInformationInputChange({ target: { name: name, value: value } })
          }
          value={personalInformation.lastName}
          required={true}
          requiredErrorMessage='Please enter Last Name'
          onBlur={() => {
            setValidating((prev) => ({ ...prev, lastName: true }));
          }}
          validating={validating.lastName}
          valid={
            !isEmpty(personalInformation.lastName) &&
            personalInformation.lastName.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/) == null
          }
        />
        <SelectInput
          id='input-provider-profile-basic-info-personal-info-suffix'
          name='suffix'
          label='Suffix'
          options={suffixOptions}
          onChange={(name, value) =>
            handlePersonalInformationInputChange({ target: { name: name, value: value } })
          }
          emptyValueText='Select Suffix'
          value={personalInformation.suffix}
        />

        <SelectInput
          id='input-provider-profile-basic-info-personal-info-gender'
          name='gender'
          label='Gender*'
          options={genderJsonOptions}
          onChange={(name, value) =>
            handlePersonalInformationInputChange({ target: { name: name, value: value } })
          }
          emptyValueText='Select Gender'
          value={personalInformation.gender}
          required={true}
          requiredErrorMessage='Select a Gender'
        />
        <SingleDateInput
          name='dob'
          id='input-provider-profile-basic-info-personal-info-dob'
          className={`input-provider-profile-basic-info-personal-info-dob componentRoot ${
            isEmpty(personalInformation.dob) || !isDateValid(personalInformation.dob)
              ? 'invalid'
              : ''
          }`}
          label='Date of Birth*'
          onChange={(name, value) =>
            handlePersonalInformationInputChange({
              target: { name: name, value: value }
            })
          }
          value={personalInformation.dob}
          required={true}
          requiredErrorMessage='Enter Date of Birth'
          onBlur={() => {
            setValidating((prev) => ({ ...prev, dob: true }));
          }}
          validating={validating.dob}
          valid={isDateValid(personalInformation.dob)}
        />
        <label
          htmlFor='input-provider-profile-basic-info-personal-info-dob'
          className='input-provider-profile-basic-info-personal-info-dob-label desc-label'>
          Used only to calculate and display your age.
        </label>
        <AutoSuggest
          id='basic-info-degree'
          label='Degree'
          name='degree'
          placeholder='Enter Degree'
          initialValue={personalInformation.degree}
          onInputChangeHandler={degreeInputChangeHandler}
          data={degreeAutoSuggest}
          onSuggestSelectHandler={degreeSelectHandler}
          setCurrentSelection={true}
          showValidationMsg={true}
          isSearch={true}
        />
        <label htmlFor='input-auto-suggest-basic-info-degree' className='desc-label'>
          We can only accept one degree at this time.
        </label>
      </LayoutInfo>
      <LayoutInfo
        identifier='provider-profile-basic-info-languages-spoken'
        title='Languages Spoken'
        description={Content.LanguageContent != undefined ? Content.LanguageContent : ''}
        bullets={{ title: 'Missing Fields', data: [] }}>
        <AutoSuggest
          id='basic-info-languages-spoken'
          label=''
          name='languages-spoken'
          placeholder='Add language'
          initialValue=''
          onInputChangeHandler={languageInputChangeHandler}
          data={languagesSpokenAutoSuggest}
          onSuggestSelectHandler={languageSelectHandler}
          isSearch={true}
        />
        {languagesSpokenObj.length > 0 ? (
          <Tags
            tagList={languagesSpokenObj.filter((lang) => lang.UpdateType !== 'Delete')}
            clickHandler={languageDeSelectHandler}
          />
        ) : null}
      </LayoutInfo>
      <div id='basic-info-cta' className='action-section'>
        <Button
          id='btn-cancel'
          text='Cancel'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-cancel ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            setPersonalInformation(INIT_STATE_PI);
            setLanguagesSpokenObj(INIT_STATE_LS);
          }}
        />
        <Button
          id='btn-save'
          text='Save'
          disabled={_ctaValid != 'valid'}
          className={`provider-profile-save ${_ctaValid}`}
          size='lg'
          style='ghost'
          onClick={() => {
            setSpinnerVisibility(true);
            _updateBasicInfo();
          }}
        />
      </div>
      <>
        <Toast
          toastList={notifyProperties}
          position='bottom-center'
          autoDelete={true}
          autoDeleteTime={5000}
        />
        {spinnerVisibility && <Spinner cta={true} />}
      </>
    </section>
  );
};

export default BasicInfo;
