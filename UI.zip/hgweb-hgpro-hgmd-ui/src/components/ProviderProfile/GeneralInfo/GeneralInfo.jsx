import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

//Component imports
import LayoutA from '../../Common/Layouts/LayoutA';
import NavTabs from '../../Common/Navigation/Tab/Tabs';
import BasicInfo from './BasicInfo';
import ProfilePhotoVideo from './ProfilePhotoVideo';
import AcceptingNewPatients from './AcceptingNewPatients';
import CommonQuestionaire from './CommonQuestionaire';

//styling imports
import './_generalInfo.less';

const GeneralInfo = (props) => {
  // selector
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  const providerInformation = JSON.parse(providerProfileInfo.InformationJson);

  //states
  const [basicInfoMissingData, setBasicInfoMissingData] = useState(
    providerInformation.DateOfBirth == null || providerInformation.DateOfBirth == ''
      ? true
      : providerInformation.Name.Degree == ''
      ? true
      : providerInformation.Gender == ''
      ? true
      : false
  );

  const [acceptingNewPatientsMissingData, setAcceptingNewPatientsMissingData] = useState(
    providerInformation.AcceptingNewPatientsMissing
  );
  const [providerImgMissingData, setProviderImgMissingData] = useState(
    !providerInformation.HasImage
  );

  //Navigation Tabs Section Start
  const navTabData = [
    {
      label: 'Basic Info',
      badgeEnabled: basicInfoMissingData,
      value: 'basicinfo'
    },
    {
      label: 'Profile Photo & Video',
      badgeEnabled: providerImgMissingData,
      value: 'profilephoto&video'
    },
    {
      label: 'Accepting New Patients',
      badgeEnabled: acceptingNewPatientsMissingData,
      value: 'acceptingnewpatients'
    },
    {
      label: 'Common Questionnaire',
      badgeEnabled: false,
      value: 'commonquestionnaire'
    }
  ];

  const [currentSelection, setCurrentSelection] = useState(navTabData[0]);

  const onTabsChangeHandlerForVideo = (section) => {
    props.onTabsChangeHandler(section);
  };

  useEffect(() => {
    let currSel = navTabData.filter((e) =>
      e.value.toLowerCase().includes(props.selectTab.toLowerCase())
    )[0];
    if (currSel != undefined) setCurrentSelection(currSel);
    else setCurrentSelection(navTabData[0]);
  }, [props.selectTab]);

  const tabSelectionhandler = (tab) => {
    setCurrentSelection(tab);
    props.onTabsChangeHandler(tab.value);
  };

  useEffect(() => {
    let providerInformation = JSON.parse(providerProfileInfo.InformationJson);

    //setBasicInfoMissingData(providerInformation.MissingData);
    if (providerInformation.DateOfBirth == null || providerInformation.DateOfBirth == '')
      setBasicInfoMissingData(true);
    if (providerInformation.Name.Degree == '') setBasicInfoMissingData(true);
    if (providerInformation.Gender == '') setBasicInfoMissingData(true);

    setAcceptingNewPatientsMissingData(providerInformation.AcceptingNewPatientsMissing);
    setProviderImgMissingData(!providerInformation.HasImage);
  }, [providerProfileInfo]);

  //Navigation Tabs Section End

  // jsx constant(s)
  const _header = (
    <NavTabs
      tabs={navTabData}
      onSelectHandler={tabSelectionhandler}
      selectedTab={currentSelection}
    />
  );
  const _footer = <></>;
  const _main = (selection) => {
    switch (selection) {
      case 'Basic Info':
        return (
          <BasicInfo
            bannerChangeHandler={props.bannerChangeHandler}
            displayName={props.bannerDisplayName}
          />
        );
      case 'Profile Photo & Video':
        return <ProfilePhotoVideo onTabsChangeHandler={onTabsChangeHandlerForVideo} />;
      case 'Accepting New Patients':
        return <AcceptingNewPatients />;
      case 'Common Questionnaire':
        return <CommonQuestionaire />;
      default:
        break;
    }
  };

  return (
    <LayoutA identifier='provider-profile-general-info' header={_header} footer={_footer}>
      <div id='div-provider-profile-general-info-main'>{_main(currentSelection.label)}</div>
    </LayoutA>
  );
};

GeneralInfo.defaultProps = {
  selectTab: 'Basic Info'
};

GeneralInfo.propTypes = {};

export default GeneralInfo;
