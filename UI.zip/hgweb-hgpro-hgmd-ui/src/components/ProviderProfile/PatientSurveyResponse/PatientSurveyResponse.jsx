import React, { useState, Fragment } from 'react';

//styling imports
import '@hg/joy/src/globalstyles';

const PatientSurveyResponse = (props) => {
  return (
    <Fragment>
      <h1>PatientSurveyResponse-content</h1>
    </Fragment>
  );
};

PatientSurveyResponse.propTypes = {};

export default PatientSurveyResponse;
