import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

//helper
import * as constants from '../../../../utils/constant-data';

//component
import OfficeDayAndHour from '../OfficeDayAndHour/OfficeDayAndHour';
import isEmpty from '../../../../utils/validation/isEmpty';

function OfficeHours(props) {
  const {
    officeLocationData,
    defaultOfficeHour,
    showHours,
    applyToAll,
    type,
    clearDefault,
    isOldOHour,
    isOldHoursUsed,
    oldData,
    radioUsed,
    radioLocationInputValue
  } = props;

  const [isHrChecked, setIsHrChecked] = useState(false);
  const [mondayHourChanges, setMondayHourChanges] = useState(defaultOfficeHour);
  const officeHourArray = constants.officeHoursArray;
  const init = officeHourArray;
  const [officeHoursValidArr, setOfficeHoursValidationArr] = useState(officeHourArray);
  const [officeLocationDetails, setOfficeLocationDetails] = useState(officeLocationData);
  let showApplyToAll =
    officeHoursValidArr[0].isValid &&
    officeLocationDetails.OfficeHours != undefined &&
    officeLocationDetails.OfficeHours.length > 0 &&
    [0].StartTime != '' &&
    officeLocationDetails.OfficeHours[0].EndTime != '';

  const hourCheckBoxHandler = (event, index, st, et) => {
    setIsHrChecked(event.target.checked);
    var objIndex = officeLocationDetails.OfficeHours.findIndex((p) => p.DayOfWeek === index);
    if (objIndex > -1 && !event.target.checked) {
      officeLocationDetails.OfficeHours[objIndex].StartTime = '';
      officeLocationDetails.OfficeHours[objIndex].EndTime = '';
      officeLocationDetails.OfficeHours[objIndex].OpenCloseSelected = 'Closed';
      officeHoursValidArr[objIndex].isValid = true;
      officeHoursValidArr[objIndex].error = '';
    }
    timeValidationHandler(st, et, index, event.target.checked);
    props.EnableOfficeHourCheckboxChange(true);
  };

  const setOfficeHours = (day, starttime, endtime) => {
    const arr = clearDefault ? [...officeHourArray] : [...officeLocationDetails.OfficeHours];
    const tempOfficeHrArr = constants.officeHoursArray;
    const objIndex = tempOfficeHrArr.findIndex((object) => object.DayOfWeek === day);
    arr.length == 0 ? (officeLocationDetails.OfficeHours = [...tempOfficeHrArr]) : null;
    if (
      starttime != '' &&
      endtime != '' &&
      objIndex > -1 &&
      type != 'Add New' &&
      officeLocationDetails.OfficeHours.length > 0
    ) {
      officeLocationDetails.OfficeHours[objIndex].StartTime = starttime;
      officeLocationDetails.OfficeHours[objIndex].EndTime = endtime;
      officeLocationDetails.OfficeHours[objIndex].OpenCloseSelected = 'Open';
    }
  };

  const convertStrTofloatTime = (time) => {
    return parseFloat(time.replace(':', '.').split(':')[0]);
  };

  const validateOfficeHour = (sTime, eTime, day, isChecked) => {
    if (isChecked != undefined && isChecked && (isEmpty(sTime) || isEmpty(eTime))) {
      setOfficeHoursValidationArr(
        officeHoursValidArr.map((v) => ({
          ...v,
          isValid: day == v.DayOfWeek ? !isEmpty(sTime) && !isEmpty(eTime) : v.isValid,
          error: day == v.DayOfWeek ? 'If the office is open, hours are required.' : v.error
        }))
      );
    } else if ((isChecked != undefined && sTime == '' && isChecked) || (eTime == '' && isChecked)) {
      setOfficeHoursValidationArr(
        officeHoursValidArr.map((v) => ({
          ...v,
          isValid: day == v.DayOfWeek && isChecked ? false : true,
          error: day == v.DayOfWeek && isChecked ? 'If the office is open, hours are required.' : ''
        }))
      );
    } else if (isChecked != undefined && !isChecked) {
      setOfficeHoursValidationArr(
        officeHoursValidArr.map((v) => ({
          ...v,
          isValid: day == v.DayOfWeek ? true : v.isValid,
          error: day == v.DayOfWeek ? '' : v.error,
          sTime: day === v.DayOfWeek ? '' : v.sTime,
          eTime: day === v.DayOfWeek ? '' : v.eTime
        }))
      );
    } else if (sTime != '' && eTime != '' && day != '') {
      let start_time = sTime.toUpperCase().split(' ');
      let end_time = eTime.toUpperCase().split(' ');
      if (start_time != undefined && end_time != undefined) {
        let time = start_time[0].split(':');
        let stime = time[0];
        if (start_time[1] == 'PM' && stime < 12) stime = parseInt(stime) + 12;
        else if (start_time[1] == 'PM' && stime == 12) stime = parseInt(stime);
        else if (start_time[1] == 'AM' && stime == 12) stime = 0;
        start_time = stime + ':' + time[1] + ':00';
        let time1 = end_time[0].split(':');
        let etime = time1[0];
        if (end_time[1] == 'PM' && etime < 12) etime = parseInt(etime) + 12;
        else if (end_time[1] == 'PM' && etime == 12) etime = parseInt(etime);
        else if (end_time[1] == 'AM' && etime == 12) etime = 0;
        end_time = etime + ':' + time1[1] + ':00';
        if (start_time != '' && end_time != '') {
          let isEndTimeLess = convertStrTofloatTime(end_time) <= convertStrTofloatTime(start_time);
          let tempofficeHoursValidArray = officeHoursValidArr.map((v) => ({
            ...v,
            RowError: day === v.DayOfWeek ? isEndTimeLess : v.RowError,
            isValid: day === v.DayOfWeek ? !isEndTimeLess : v.isValid,
            error:
              day === v.DayOfWeek && isEndTimeLess
                ? 'The office closing time must be greater than the opening time.'
                : day === v.DayOfWeek
                ? ''
                : v.error,
            sTime: day === v.DayOfWeek && isEndTimeLess ? sTime : v.sTime,
            eTime: day === v.DayOfWeek && isEndTimeLess ? eTime : v.eTime
          }));
          setOfficeHoursValidationArr([...tempofficeHoursValidArray]);
        }
      }
    }
  };

  const defaultDropDownChangeHandler = (val) => {
    let objIndex = officeLocationDetails.OfficeHours.findIndex(
      (p) => p.DayOfWeek === val.DayOfWeek
    );

    officeLocationDetails.OfficeHours[objIndex].StartTime = val.StartTime;
    officeLocationDetails.OfficeHours[objIndex].EndTime = val.EndTime;
    officeLocationDetails.OfficeHours[objIndex].OpenCloseSelected = 'Open';
    setMondayHourChanges(val);
  };

  const timeValidationHandler = (sTime, eTime, day, checked) => {
    if (showHours) validateOfficeHour(sTime, eTime, day, checked);
  };

  const applyAllClickHandler = () => {
    let array = officeHoursValidArr[0];
    let tempofficeHoursValidArray = officeHoursValidArr.map((i) => {
      i.StartTime = array.isValid ? array.StartTime : i.StartTime;
      i.EndTime = array.isValid ? array.EndTime : i.EndTime;
      i.isValid = array.isValid;
      i.error = array.isValid ? '' : array.error;
      return i;
    });
    setOfficeHoursValidationArr([...tempofficeHoursValidArray]);
    array != undefined && array.isValid && props.applyToAllClickHandler(mondayHourChanges);
  };

  useEffect(() => {
    if (clearDefault) {
      setOfficeLocationDetails(officeLocationData);
    }
  }, [clearDefault]);

  useEffect(() => {
    props.hourValidationHandler(officeHoursValidArr);
  }, [officeHoursValidArr]);

  useEffect(() => {
    setOfficeLocationDetails(officeLocationData);
  }, [officeLocationData]);

  useEffect(() => {
    setMondayHourChanges(defaultOfficeHour);
  }, [defaultOfficeHour]);

  const timeConverter = (str) => {
    if (!isEmpty(str)) {
      let hour = Number(str.toString().split(':')[0]);
      if (hour === 0) {
        hour = 12;
      }
      let min = str.toString().split(':')[1];
      let time;
      if (
        str.toString().toLowerCase().includes('pm') ||
        str.toString().toLowerCase().includes('am')
      ) {
        time = Number(hour) > 12 ? ((hour + 11) % 12) + 1 + min : str;
      } else {
        time =
          Number(hour) > 12 ? ((hour + 11) % 12) + 1 + ':' + min + ' pm' : hour + ':' + min + ' am';
      }
      return time.replace(/^0+/, '');
    } else return '';
  };

  const generateOfficeDayAndHour = (weekDay) => {
    if (
      officeLocationDetails.OfficeHours != undefined &&
      officeLocationDetails.OfficeHours.length > 0
    ) {
      if (
        isOldOHour &&
        officeLocationDetails != undefined &&
        officeLocationData != undefined &&
        isOldHoursUsed
      ) {
        const updatedOfficeHours = officeLocationDetails.OfficeHours.map((officeHour) => {
          const matchingAddressHour = officeLocationData.OfficeHours.find((addressHour) =>
            oldData
              ? addressHour.DayOfWeek === officeHour.DayOfWeek
              : addressHour.Day === officeHour.Day
          );

          if (matchingAddressHour) {
            if (oldData) {
              return {
                ...officeHour,
                DayOfWeek: matchingAddressHour.DayOfWeek,
                StartTime: matchingAddressHour.StartTime,
                EndTime: matchingAddressHour.EndTime,
                OpenCloseSelected: matchingAddressHour.OpenCloseSelected
              };
            } else {
              return {
                ...officeHour,
                DayOfWeek: matchingAddressHour.Day,
                StartTime: matchingAddressHour.start,
                EndTime: matchingAddressHour.end,
                OpenCloseSelected: matchingAddressHour.OpenCloseSelected
              };
            }
          } else {
            return officeHour;
          }
        });
        officeLocationDetails.OfficeHours = updatedOfficeHours;
      }
      let offHours = officeLocationDetails.OfficeHours.find((item) => item.DayOfWeek === weekDay);
      if (offHours != undefined && offHours.DayOfWeek === weekDay) {      
        return (
          <OfficeDayAndHour
            key={offHours.DayOfWeek}
            id={offHours.DayOfWeek}
            dayOfWeek={offHours.DayOfWeek}
            isSelected={
              (offHours.OpenCloseSelected == 'Open' ||
                offHours.OpenCloseSelected == 'Open24Hours') &&
              offHours.StartTime != '' &&
              offHours.EndTime != ''
            }
            ItemSelectedOnChange={hourCheckBoxHandler}
            startTime={
              offHours.OpenCloseSelected == 'Open24Hours'
                ? '12:00 am'
                : timeConverter(offHours.StartTime)
            }
            endTime={
              offHours.OpenCloseSelected == 'Open24Hours'
                ? '11.45 pm'
                : timeConverter(offHours.EndTime)
            }
            defaultValue={defaultOfficeHour}
            applyToAll={applyToAll}
            setOfficeHours={setOfficeHours}
            defaultDropDownChangeHandler={defaultDropDownChangeHandler}
            timeValidationHandler={timeValidationHandler}
            isOldOHour={isOldOHour}
            isOldHoursUsed={isOldHoursUsed}
          />
        );
      }
    } else {
      return (
        <OfficeDayAndHour
          key={weekDay}
          id={weekDay}
          dayOfWeek={weekDay}
          isSelected={false}
          ItemSelectedOnChange={hourCheckBoxHandler}
          defaultValue={defaultOfficeHour}
          applyToAll={applyToAll}
          setOfficeHours={setOfficeHours}
          defaultDropDownChangeHandler={defaultDropDownChangeHandler}
          timeValidationHandler={timeValidationHandler}
        />
      );
    }
  };
  useEffect(() => {
    if (isOldOHour && isOldHoursUsed) {
      setIsHrChecked(false);
    } else {
      setIsHrChecked(true);
    }
  }, [isOldOHour, officeLocationDetails, generateOfficeDayAndHour]);

  const[isAddOffHourDisp,setisAddOffHourDisp] = useState(true);

  useEffect(()=>
  {
    if(radioLocationInputValue == "oldAddress" && !isOldHoursUsed &&  type != 'Edit')
    {
      setisAddOffHourDisp(false);
    }
    else if(radioLocationInputValue == "oldAddress" && isOldHoursUsed)
    {
      setisAddOffHourDisp(true);
    }
    else if (radioLocationInputValue == "newAddress" || radioLocationInputValue == 'enteredAddress')
    {
      setisAddOffHourDisp(true)
      
    }
    
  },[radioLocationInputValue,isOldHoursUsed])


  return (
    isAddOffHourDisp &&
    <div className='common-prac-container hour-container'>
      <div className='hour-description'>
        <div className='hour-common-container day-select-container'>
          <span className='span-title'>Add Office Hours</span>
          {!isOldHoursUsed && (
            <div className='buttons-container'>
              {showHours && (
                <button
                  id={`btn-apply-all-apply-${officeLocationData.Address}`}
                  className={`btn-apply-all ${!showApplyToAll ? 'disabled' : ''}`}
                  value={applyToAll}
                  onClick={applyAllClickHandler}
                  disabled={isOldHoursUsed ? true : !showApplyToAll}>
                  Apply to all
                </button>
              )}
              <button
                id={`btn-apply-all-remove-${officeLocationData.Address}`}
                className='btn-apply-all remove-all-office-hours'
                disabled={radioUsed ? false : true}
                onClick={() => {
                  props.removeClickHandler(showHours ? 'Remove' : 'Add');
                  showHours ? setOfficeHoursValidationArr([...init]) : null;
                }}>
                {showHours ? 'Remove' : 'Add'}
              </button>
            </div>
          )}

          {isOldOHour && !officeHoursValidArr.every((v) => v.isValid == true) && (
            <div id='error-message-hour'>
              {officeHoursValidArr.find(
                (i) => i.error == 'If the office is open, hours are required.'
              ) != undefined
                ? 'If the office is open, hours are required.'
                : 'The office closing time must be greater than the opening time.'}
            </div>
          )}

          {showHours && (
            <div className='day-select'>
              {constants.daysOfWeek.map((weekDay) => {
                return generateOfficeDayAndHour(weekDay);
              })}
            </div>
          )}
        </div>
      </div>
    </div>

  );
}

OfficeHours.defaultProps = {
  officeLocationData: {},
  defaultOfficeHour: {},
  showHours: true,
  applyToAll: false
};

OfficeHours.propTypes = {
  officeLocationData: PropTypes.object,
  defaultOfficeHour: PropTypes.object,
  showHours: PropTypes.bool,
  applyToAll: PropTypes.bool
};
export default OfficeHours;
