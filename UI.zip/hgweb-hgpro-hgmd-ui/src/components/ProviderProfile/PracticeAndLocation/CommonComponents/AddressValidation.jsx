import React, { useEffect, useState } from 'react';
import './_addressValidation.less';
import DayHour from '../OfficeHour/DayHour';
import isEmpty from '../../../../utils/validation/isEmpty';

const AddressValidation = (props) => {
  const officeData = props;
  const { type, radioInputValue } = props;
  const [radioValue, setRadioValue] = useState(radioInputValue || '');

  const addressHandler = (val) => {
    setRadioValue(val);
    props.addressHandler(val);
  };
  const timeConverter = (str) => {
    if (!isEmpty(str)) {
      let hour = Number(str.toString().split(':')[0]);
      if (hour === 0) {
        hour = 12;
      }
      let min = str.toString().split(':')[1];
      let time;
      if (
        str.toString().toLowerCase().includes('pm') ||
        str.toString().toLowerCase().includes('am')
      ) {
        time = Number(hour) > 12 ? ((hour + 11) % 12) + 1 + min : str;
      } else {
        time =
          Number(hour) > 12 ? ((hour + 11) % 12) + 1 + ':' + min + ' pm' : hour + ':' + min + ' am';
      }
      return time.replace(/^0+/, '');
    } else return '';
  };

  return (
    <div className='address-val-main'>
      <div className='address-val-inner'>
        <div className='address-val-header'>
          We have identified that the address you have entered exists in our records.
        </div>
        <div className='practice-data'>
          {officeData != undefined && officeData.pName != undefined && officeData.pName != null && (
            <p className='practice-existing-name'>{officeData.pName}</p>
          )}
          {officeData != undefined && officeData.pUrl != undefined && officeData.pUrl != null && (
            <p className='practice-existing-url'>{officeData.pUrl}</p>
          )}
        </div>
        <div className='address-data'>
          {officeData != undefined &&
            officeData.existingOfficeName != undefined &&
            officeData.existingOfficeName != null && (
              <p className='office-existing-item'>{officeData.existingOfficeName}</p>
            )}
          {officeData != undefined &&
            officeData.addressList != undefined &&
            officeData.addressList != null &&
            officeData.addressList.Text != undefined && (
              <p className='office-text'>{officeData.addressList.Text}</p>
            )}
        </div>
        <div className='address-phone-fax'>
          {officeData != undefined && officeData.addressList.PhoneNum != undefined && (
            <div className='address-phone-num'>
              <p className='ph-no'>
                <b>Phone Number : </b>
                {officeData.addressList.PhoneNum}
              </p>
            </div>
          )}
          {officeData != undefined && officeData.addressList.FaxNum != undefined && (
            <div className='address-fax-num'>
              <p className='fx-no'>
                <b>Fax Number : </b>
                {officeData.addressList.FaxNum}
              </p>
            </div>
          )}
        </div>

        {props.officeHours != undefined && props.officeHours.length > 0 && (
          <div className='address-day-hour'>
            {props.officeHours.map((officeHour, index) => (
              <DayHour
                key={index}
                dayOfWeek={props.isOldDataUsed ? officeHour.DayOfWeek : officeHour.Day}
                startTime={
                  props.isOldDataUsed
                    ? timeConverter(officeHour.StartTime)
                    : timeConverter(officeHour.start)
                }
                endTime={
                  props.isOldDataUsed
                    ? timeConverter(officeHour.EndTime)
                    : timeConverter(officeHour.end)
                }
                isActive={
                  props.isOldDataUsed
                    ? officeHour.OpenCloseSelected == 'Open'
                      ? true
                      : false
                    : officeHour.Closed != '0'
                    ? false
                    : true
                }
              />
            ))}
          </div>
        )}

        <div className='address-action'>
          What action you would like to perform?
          <div className='continue-address'>
            <label>
              {type != 'Edit' ? 'Continue with this address?' : 'Select Existing Address'}
            </label>
            <input
              type='radio'
              name='radiobutton'
              onChange={(e) => addressHandler(e.target.value)}
              value='oldAddress'
              checked={radioValue === 'oldAddress'}></input>
          </div>
          <div className='enter-new-address'>
            <label>
              {type != 'Edit'
                ? ' Enter New Address' + ' ' + '(Will reset your above entered details)'
                : ' Continue with entered address?'}
            </label>
            <input
              type='radio'
              name='radiobutton'
              onChange={(e) => addressHandler(e.target.value)}
              value={type != 'Edit' ? 'newAddress' : 'enteredAddress'}
              checked={radioValue === 'newAddress' || radioValue === 'enteredAddress'}></input>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AddressValidation;
