import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { debounce } from 'lodash';

//helper
import TextValidation from '../../../../utils/validation/isTextValid';
import TextInput from '@hg/joy/src/components/formElements/TextInput';
import AddressValidation from './AddressValidation';

import * as service from '../../../../utils/service';
import isEmpty from '../../../../utils/validation/isEmpty';
import * as constants from '../../../../utils/constant-data';

import { currentPage } from '../../../Practice/Utils/Helpers';
import { PROVIDER_PROFILE_PAGE } from '../../../Practice/Utils/Constants';
import { searchV2 } from '../../../../utils/serviceCalls/practice';

//components
import DropDown from '../DropDownWithSearch/DropDownWithSearch';

//style
import './_officeAddress.less';

function OfficeLocation(props) {
  const { officeLocationData, type } = props;
  //state
  const [isPrimaryChecked, setIsChecked] = useState(
    type === 'Edit' && officeLocationData.IsPrimary
  );
  const [dataChange, updateDataChange] = useState(0);

  const isPrimaryFlag = type === 'Edit' && officeLocationData.IsPrimary ? true : false;
  //validation
  const isEmptyField = { isValid: false, error: 'This field is required' };
  const [isOfficeNameValid, setOfficeNameValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isAddressValid, setAddressValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isSuiteValid, setSuiteValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isCityValid, setCityValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isStateValid, setStateValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isZipCodeValid, setZipCodeValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isPhoneValid, setPhoneValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isFaxValid, setFaxValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isOfficeHoursValid, setOfficeHoursValidation] = useState({
    isValid: false,
    error: null
  });
  const [validating, setValidating] = useState({
    Name: false,
    Address: false,
    City: false,
    State: false,
    ZipCode: false,
    Phone: false,
    Fax: false
  });

  const [isOfficeAddressValid, setIsOfficeAddressValid] = useState(false);
  const [isCardUsed, setIsCardUsed] = useState(false);

  const fetchLocationAutoSuggestData = (address, suite, city, state, zipCode) => {
    let url = `/api/provider/getAddressFromSolr?addressLine=${address.trim()}&suite=${suite}&city=${city.trim()}&state=${state}&zipCode=${zipCode.trim()}`;
    return service._get(url, true);
  };

  const [addressList, setAddressList] = useState([]);

  const [pName, setPName] = useState('');
  const [pUrl, setpUrl] = useState('');
  const [pCode, setpCode] = useState('');
  const [pGuid, setpguid] = useState('');

  const [officeName, setofficeName] = useState();
  const [address, setAddress] = useState();
  const [suite, setSuite] = useState();
  const [city, setCity] = useState();
  const [state, setState] = useState();
  const [zipCode, setZipCode] = useState();
  const [officePhone, setOfficePhone] = useState();
  const [officeFax, setOfficeFax] = useState();

  const [existingOfficeName, setExistingOfficeName] = useState();
  const [isnewAddress, setIsNewAddress] = useState(false);
  const [officeHours, setOfficeHours] = useState();
  const [isOldOfficeHourUsed, setOfficeHour] = useState(false);
  const [isFirstTimeLoadForNewAddress, setIsFirstTimeLoadForNewAddress] = useState(false);
  const [isSuiteEntered, setEnteredSuite] = useState(false);
  const [isOldDataUsed, setOldDataUsed] = useState(false);
  const [cardRadioUsed, setCardRadioUsed] = useState(false);
  const [radioInputValue, setRadioInputValue] = useState('');
  const [initialization, setInitialization] = useState(false);
  const [isOfficeNameChanged, setIsOfficeNameChanged] = useState(false);
  const [isDataChanged, setIsDataChanged] = useState(false);
  
  const SEARCH_RECORDS_PER_PAGE = 10;

  let stateValue = constants.statesList.filter((i) => {
    return i.Id === officeLocationData.State;
  });
   
  const [selectedState, setSelectedState] = useState(stateValue.length != 0 ? stateValue[0].Text:'');

  //handlers
  const handleLocationInputChange = (e) => {
    updateDataChange(dataChange + 1);
    setInitialization(true);
    const { value, name } = e.target;
    switch (name) {
      case 'officeName':
        if (type === 'Edit') {
          setIsOfficeNameChanged(true);
          setIsDataChanged(true);
        } else {
          setIsOfficeNameChanged(false);
          setIsDataChanged(false);
        }
        props.locationDataChangeHandler({ ...officeLocationData, Name: value }, isDataChanged);

        //props.locationDataChangeHandler({ ...officeLocationData, Name: value }, isDataChanged);
        if (isEmpty(value)) {
          setOfficeNameValidation(isEmptyField);
          setofficeName(null);
        } else {
          setofficeName(value);
          setOfficeNameValidation(TextValidation(value, 'name'));
        }
        break;
      case 'address':
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, Address: value }, isDataChanged);
        setIsOfficeNameChanged(false);
        if (isEmpty(value)) {
          setAddress(null);
          setAddressValidation(isEmptyField);
        } else {
          setAddress(value.trim());
          setAddressValidation(TextValidation(value, 'name'));
        }
        break;
      case 'suite':
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, Suite: value }, isDataChanged);
        setIsOfficeNameChanged(false);
        if (!isEmpty(value)) {
          setSuite(value);
          setEnteredSuite(true);
        } else {
          setSuite(null);
          setEnteredSuite(false);
        }
        break;
      case 'city':
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, City: value }, isDataChanged);

        setIsOfficeNameChanged(false);
        if (isEmpty(value)) {
          setCityValidation(isEmptyField);
          setCity(null);
        } else {
          setCity(value);
          setCityValidation(TextValidation(value, 'name'));
        }
        break;
      case 'state':
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, State: value }, isDataChanged);

        setIsOfficeNameChanged(false);
        if (isEmpty(value)) {
          setState(null);
          setStateValidation(isEmptyField);
        } else {
          setState(value);
          setStateValidation(TextValidation(value, 'name'));
        }
        break;
      case 'zipCode':
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, ZipCode: value }, isDataChanged);

        setIsOfficeNameChanged(false);
        if (isEmpty(value) || value.length < 5) {
          setZipCode(null);
          setZipCodeValidation(isEmptyField);
        } else {
          setZipCode(value);
          setZipCodeValidation(TextValidation(value, 'pwid'));
        }
        break;
      case 'oficePhone':
        setIsDataChanged(false);
        let phNumber = phoneFormatHandler(value);
        props.locationDataChangeHandler(
          {
            ...officeLocationData,
            Phone: phNumber != null ? phNumber : ''
          },
          isDataChanged
        );
        setIsOfficeNameChanged(false);
        if (isEmpty(value)) {
          setPhoneValidation(isEmptyField);
        } else {
          setOfficePhone(value);
          setPhoneValidation(TextValidation(value, 'phonenumber'));
        }
        break;
      case 'officeFax':
        let faxNumber = phoneFormatHandler(value);
        if  (faxNumber === null || faxNumber.length === 0 || faxNumber.length === 14) {
          setIsDataChanged(true);
        } else {
          setIsDataChanged(false);
        }
        props.locationDataChangeHandler({ ...officeLocationData, Fax: faxNumber }, isDataChanged);
        setIsOfficeNameChanged(false);
        if (!isEmpty(value)) {
          setOfficeFax(value);
        }
        break;
    }
  };

  const handlerStateChange=(value) => {
      setSelectedState(value);

        updateDataChange(dataChange + 1);
        setInitialization(true); 
        setIsDataChanged(false);
        props.locationDataChangeHandler({ ...officeLocationData, State: value }, isDataChanged);

        setIsOfficeNameChanged(false);
        if (isEmpty(value)) {
          setState(null);
          setStateValidation(isEmptyField);
        } else {
          setState(value);
          setStateValidation(TextValidation(value, 'name'));
        }
  }

  const cardDetails = async (address, v = 1, SEARCH_RECORDS_PER_PAGE) => {
    try {
      const res = await searchV2(address, 1, SEARCH_RECORDS_PER_PAGE);
      if (res.status === 200) {
        return res.data.PracticeResults;
      }
    } catch (err) {
      console.log(err);
    }
  };

  const fetchData = async (
    address,
    city,
    state,
    zipCode,
    officePhone,
    officeName,
    radioInputValue
  ) => {
    let isOldPracticeUsed = false;
    if (
      !isEmpty(address) &&
      !isEmpty(city) &&
      !isEmpty(state) &&
      !isEmpty(zipCode) &&
      !isEmpty(officePhone) &&
      !isEmpty(officeName) &&
      zipCode.length >= 5 &&
      radioInputValue != 'oldAddress'
    ) {
      setCardRadioUsed(false);
      setRadioInputValue('');
      const results = await cardDetails(address, 1, SEARCH_RECORDS_PER_PAGE);
      if (results != undefined && results.length != undefined && results.length > 1) {
        const addressData = results
          .map((p) => {
            return p.Offices.map((add) => {
              return {
                practiceCode: p.PracticeCode,
                practiceName: p.Name,
                //practiceUrl: p.WebSiteUrl,
                addressLine1: add.Address,
                practiceGuid: p.Id,
                city: add.City,
                lat: add.Latitude,
                long: add.Longitude,
                Id: add.OfficeCode,
                officeName: add.Name,
                state: add.State,
                zip: add.ZipCode,
                officeGuid: add.OrigId,
                suite: add.Suite,
                PhoneNum: add.Phone && add.Phone.length > 0 ? add.Phone : null,
                FaxNum: add.Fax && add.Fax.length > 0 ? add.Fax : null,
                OfficeHours: add.OfficeHours,
                OfficeCode: add.OfficeCode,
                Text: [
                  add.Address,
                  add.Suite != undefined && add.Suite != null && add.Suite,
                  add.City,
                  add.State,
                  add.ZipCode
                ]
                  .filter(Boolean)
                  .join(', ')
              };
            });
          })
          .flat();

        let validAddress = addressData
          .filter(
            (obj) =>
              obj.addressLine1 !== null &&
              obj.addressLine1.trim() !== '' &&
              obj.PhoneNum !== null &&
              obj.state !== null &&
              obj.city !== null &&
              obj.zip !== null &&
              obj.officeName != null
          )
          .find(
            (obj) =>
              obj.addressLine1 !== undefined &&
              obj.addressLine1.trim() === address.trim() &&
              obj.PhoneNum !== undefined &&
              obj.PhoneNum.trim() === officePhone.trim() &&
              obj.state !== undefined &&
              obj.state === state &&
              obj.city !== undefined &&
              obj.city.trim() === city.trim() &&
              obj.zip !== undefined &&
              obj.zip.trim() === zipCode.trim() &&
              obj.officeName !== undefined &&
              obj.officeName.trim() === officeName.trim()
          );
        let isSuitNull = addressData.some((s) => s.suite === null);
        if (isSuiteEntered) {
          if (isSuitNull) {
            validAddress = null;
            isOldPracticeUsed = false;
            setOldDataUsed(false);
          }
        } else if (!isSuiteEntered) {
          if (!isSuitNull) {
            validAddress = null;
            isOldPracticeUsed = false;
            setOldDataUsed(false);
          }
        }
        if (
          validAddress != undefined &&
          validAddress != null &&
          validAddress.practiceGuid != undefined &&
          validAddress.officeGuid != undefined &&
          validAddress.practiceGuid != '00000000-0000-0000-0000-000000000000' &&
          validAddress.officeGuid != '00000000-0000-0000-0000-000000000000' &&
          validAddress.practiceGuid != null &&
          validAddress.officeGuid != null &&
          validAddress.OfficeCode != null
        ) {
          isOldPracticeUsed = true;
          setOldDataUsed(true);
        } else {
          isOldPracticeUsed = false;
          setOldDataUsed(false);
        }
        if (!_.isEmpty(validAddress) && isOldPracticeUsed) {
          setAddressList(validAddress);
          setIsCardUsed(true);
          setCardRadioUsed(false);
          setPName(validAddress.practiceName);
          setpUrl(validAddress.practiceUrl);
          setpCode(validAddress.practiceCode);
          setpguid(validAddress.practiceUrl);
          setpguid(validAddress.practiceGuid);
          setOfficeHours(validAddress.OfficeHours);
          setIsOfficeAddressValid(true);
          setIsDataChanged(true);
        }
      }
      if (!isOldPracticeUsed) {
        setOldDataUsed(false);
        await fetchLocationAutoSuggestData(address, suite, city, state, zipCode).then((res) => {
          if (res.status == 200) {
            const addressdata = res.data.PracticeOfficeDetails.map((practice) => {
              return practice.OfficeAddresses.map((add) => {
                return {
                  practiceCode: practice.PracticeCode,
                  practiceName: practice.PracticeName,
                  practiceUrl: practice.pUrl,
                  addressLine1: add.AddressLine1,
                  addressType: add.AddressType,
                  practiceGuid: practice.PracticeGuId,
                  city: add.City,
                  lat: add.Latitude,
                  long: add.Longitude,
                  Id: add.OfficeId,
                  officeName: add.OfficeName,
                  state: add.State,
                  zip: add.Zip,
                  PhoneNum: add.PhoneNum && add.PhoneNum.length > 0 ? add.PhoneNum[0] : null,
                  FaxNum: add.FaxNum && add.FaxNum.length > 0 ? add.FaxNum[0] : null,
                  OfficeHours: add.OfficeHours,
                  suite: add.Suite,
                  Text: [
                    add.AddressLine1,
                    add.Suite != undefined && add.Suite != null && add.Suite,
                    add.City,
                    add.State,
                    add.Zip
                  ]
                    .filter(Boolean)
                    .join(', ')
                };
              });
            }).flat();
            let validAddress = addressdata.find(
              (obj) =>
                obj.addressLine1 != undefined &&
                obj.addressLine1 != null &&
                obj.addressLine1.trim() === address.trim() &&
                obj.city != undefined &&
                obj.city != null &&
                obj.city.trim() === city.trim() &&
                obj.state != undefined &&
                obj.state != null &&
                obj.state.trim() === state.trim() &&
                obj.zip != undefined &&
                obj.zip != null &&
                obj.zip.trim() === zipCode.trim() &&
                obj.PhoneNum != undefined &&
                obj.PhoneNum != null &&
                obj.PhoneNum.trim() === officePhone.trim() &&
                obj.officeName != undefined &&
                obj.officeName != null &&
                obj.officeName.trim() === officeName.trim()
            );
            let isSuitNull = addressdata.some((s) => s.suite === null);

            if (isSuiteEntered) {
              if (isSuitNull) {
                validAddress = null;
              }
            } else if (!isSuiteEntered) {
              if (!isSuitNull) {
                validAddress = null;
              }
            }
            if (!_.isEmpty(validAddress)) {
              setAddressList(validAddress);
              setIsCardUsed(true);
              setPName(validAddress.practiceName);
              setpCode(validAddress.practiceCode);
              setpguid(validAddress.practiceUrl);
              setpguid(validAddress.practiceGuid);
              setOfficeHours(validAddress.OfficeHours);
              setIsOfficeAddressValid(true);
              setIsDataChanged(true);
            } else {
              setAddressList(null);
              setIsOfficeAddressValid(false);
              setIsCardUsed(false);
              setIsDataChanged(true);
            }
          }
        });
      }
    } else if (
      isEmpty(address) ||
      isEmpty(city) ||
      isEmpty(state) ||
      isEmpty(zipCode) ||
      isEmpty(officePhone) ||
      zipCode.length >= 5
    ) {
      setIsOfficeAddressValid(false);
      setIsCardUsed(false);
      setIsDataChanged(true);
    } else {
      setIsCardUsed(false);
      setIsDataChanged(true);
    }
    setIsDataChanged(true);
  };

  const phoneFormatHandler = (value) => {
    if (!value) return null;
    const phoneNumber = value.replace(/[^\d]/g, '');
    const phoneNumberLength = phoneNumber.length;
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `${phoneNumber.slice(0, 3)}-${phoneNumber.slice(3)}`;
    }
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
  };

  const checkboxOnChangeHandler = (event) => {
    let itemChecked = event.target.checked;
    setIsChecked(itemChecked);
    setIsDataChanged(true);
    props.locationDataChangeHandler(
      { ...officeLocationData, AddEditIsPrimary: itemChecked },
      isDataChanged
    );
  };

  
  const onStateDropDownSelectHandler = (item) => {
    if (!isEmpty(item.Text)) {
      setSelectedState(item.Text);
      setState(item.Id);
    } else {
      setState(null);
    }
  };

  const addressHandler = (value) => {
    props.addressLocationHandler(value);
    props.EnableSaveButtonHandler(true);
    if (value === 'oldAddress') {
      setRadioInputValue(value);
      props.practiceNameHandler(pName, pUrl, pCode, pGuid);
      setIsNewAddress(true);
      setOfficeHour(true);
      setCardRadioUsed(true);
      const updatedOfficeData = {
        ...officeLocationData,
        Name: addressList.officeName,
        Phone: addressList.PhoneNum,
        Fax: addressList.FaxNum,
        OfficeHours: addressList.OfficeHours
      };
      setofficeName(addressList.officeName);
      setOfficePhone(addressList.PhoneNum);
      setOfficeFax(addressList.FaxNum);
      props.locationDataChangeHandler(updatedOfficeData);
      props.OfficeHourValidation(value, updatedOfficeData, isOldDataUsed);
    } else if (value === 'newAddress') {
      setRadioInputValue(value);
      setIsFirstTimeLoadForNewAddress(true);
      setIsOfficeAddressValid(false);
      const updatedData = {
        ...officeLocationData,
        Name: '',
        Address: '',
        City: '',
        State: '',
        ZipCode: '',
        Phone: '',
        Fax: '',
        OfficeHours: []
      };
      setAddressList(null);
      setIsNewAddress(false);
      setCardRadioUsed(true);
      setofficeName('');
      setAddress('');
      setState('');
      setCity('');
      setZipCode('');
      setOfficePhone('');
      setOfficeFax('');
      setValidating({
        Name: false,
        Address: false,
        City: false,
        State: false,
        ZipCode: false,
        Phone: false,
        Fax: false
      });
      props.locationDataChangeHandler(updatedData);
      setIsFirstTimeLoadForNewAddress(false);
      setOfficeHour(false);
      props.OfficeHourValidation(isOldOfficeHourUsed);
    } else if (value === 'enteredAddress') {
      setCardRadioUsed(true);
    }
  };

  const debouncedFetchChangeHandler = useMemo(() => debounce(fetchData, 2000), []);

  useEffect(() => {
    isFirstTimeLoadForNewAddress && !isnewAddress
      ? setValidating({
          Name: false,
          Address: false,
          City: false,
          State: false,
          ZipCode: false,
          Phone: false,
          Fax: false
        })
      : null;
  }, [isFirstTimeLoadForNewAddress, isnewAddress]);

  useEffect(() => {
    if (type === 'Edit') {
      setofficeName(officeLocationData.Name);
      setAddress(officeLocationData.Address);
      setSuite(officeLocationData.Suite);
      setCity(officeLocationData.City);
      setState(officeLocationData.State);
      setZipCode(officeLocationData.ZipCode);
      setOfficePhone(officeLocationData.Phone);
    }
  }, [type]);

  useEffect(() => {
    if (addressList != undefined) {
      if (addressList.officeName != undefined && addressList.officeName != null) {
        setExistingOfficeName(addressList.officeName);
      } else {
        setExistingOfficeName(null);
      }
      if (addressList.PhoneNum != undefined && addressList.PhoneNum != null) {
      }
      props.locationDataChangeHandler({
        ...officeLocationData,
        OfficeCode: type != 'Edit' ? addressList.Id : officeLocationData.OfficeCode
      });
    }
  }, [addressList]);

  props.CardChangeHandler(isCardUsed, cardRadioUsed);

  useEffect(() => {
    if (
      !isEmpty(address) &&
      !isEmpty(city) &&
      !isEmpty(state) &&
      !isEmpty(zipCode) &&
      !isEmpty(officePhone) &&
      !isEmpty(officeName) &&
      initialization &&
      zipCode.length >= 5 &&
      radioInputValue != 'oldAddress' &&
      !isOfficeNameChanged
    ) {
      debouncedFetchChangeHandler(
        address,
        city,
        state,
        zipCode,
        officePhone,
        officeName,
        radioInputValue
      );
    }
  }, [address, suite, city, state, zipCode, officePhone, officeName, initialization]);

  useEffect(() => {
    props.EnableSaveButtonHandler(isDataChanged);
  }, [isDataChanged]);

  return (
    <div className='common-prac-container location-container'>
      <TextInput
        id='input-location-office-name'
        name='officeName'
        label='Office Name*'
        placeholder='Enter Office Name'
        value={!isEmpty(officeLocationData.Name) ? officeLocationData.Name : ''}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={true}
        requiredErrorMessage='Office Name is required'
        onBlur={() => {
          setValidating((prev) => ({ ...prev, Name: true }));
        }}
        disabled={isnewAddress ? (isEmpty(addressList.officeName) ? false : true) : false}
        validating={validating.Name}
        valid={
          !isEmpty(officeLocationData.Name) &&
          officeLocationData.Name.match(/[^ 0-9A-Za-zÀ-ÿ'.&-]/) == null
        }
      />
      <TextInput
        id='input-location-address'
        name='address'
        label='Address*'
        placeholder='Enter Address'
        value={officeLocationData.Address}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={true}
        requiredErrorMessage='Address is required'
        onBlur={() => {
          setValidating((prev) => ({ ...prev, Address: true }));
        }}
        validating={validating.Address}
        valid={
          !isEmpty(officeLocationData.Address) &&
          officeLocationData.Address.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/) == null
        }
        disabled={isnewAddress ? true : false}
      />
      <TextInput
        id='input-location-suite'
        className='half-width'
        name='suite'
        label='Suite'
        placeholder='Enter Suite'
        disabled={isnewAddress ? true : false}
        value={!isEmpty(officeLocationData.Suite) ? officeLocationData.Suite : ''}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
      />
      <TextInput
        id='input-location-city'
        className='half-width'
        name='city'
        label='City*'
        placeholder='Enter City'
        value={officeLocationData.City}
        disabled={isnewAddress ? true : false}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={true}
        requiredErrorMessage='City is required'
        onBlur={() => {
          setValidating((prev) => ({ ...prev, City: true }));
        }}
        validating={validating.City}
        valid={
          !isEmpty(officeLocationData.City) &&
          officeLocationData.City.match(/[^ 0-9A-Za-zÀ-ÿ'.-]/) == null
        }
      />
      <div className='componentRoot half-width' name='State' id='input-location-state'>
        <label htmlFor='office-location-state'>State*</label>
        <DropDown
          id={isnewAddress ? 'office-location-state-disabled' : 'office-location-state'}
          list={constants.statesList}
          selectedName={selectedState}
          onDropDownSelectHandler={onStateDropDownSelectHandler}
          disabled={isnewAddress ? true : false}
          handlerStateChange={handlerStateChange}
          setSelectedState ={setSelectedState}
        />
      </div>

      <TextInput
        id='input-location-zip-code'
        className='half-width'
        name='zipCode'
        label='Zip Code*'
        placeholder='Enter Zip Code'
        value={officeLocationData.ZipCode}
        disabled={isnewAddress ? true : false}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={true}
        requiredErrorMessage='Zip Code is required'
        onBlur={() => {
          setValidating((prev) => ({ ...prev, ZipCode: true }));
        }}
        validating={validating.ZipCode}
        valid={
          !isEmpty(officeLocationData.ZipCode) &&
          officeLocationData.ZipCode.match(/[^0-9]/) == null &&
          officeLocationData.ZipCode.length < 6
        }
      />
      <TextInput
        id='input-location-office-phone'
        className='half-width'
        name='oficePhone'
        label='Office Phone*'
        placeholder='Enter Office Phone'
        value={officeLocationData.Phone}
        disabled={isnewAddress ? (isEmpty(addressList.PhoneNum) ? false : true) : false}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={true}
        requiredErrorMessage='Phone is required'
        onBlur={() => {
          setValidating((prev) => ({ ...prev, Phone: true }));
        }}
        validating={validating.Phone}
        valid={
          !isEmpty(officeLocationData.Phone) &&
          officeLocationData.Phone.replace(/[^\d]/g, '').match(/[^ 0-9]/) == null &&
          officeLocationData.Phone.replace(/[^\d]/g, '').length == 10
        }
      />
      <TextInput
        id='input-location-office-fax'
        className='half-width'
        name='officeFax'
        label='Office Fax (Optional)'
        placeholder='Enter Office Fax'
        value={officeLocationData.Fax}
        disabled={isnewAddress ? (isEmpty(addressList.FaxNum) ? false : true) : false}
        onChange={(name, value) =>
          handleLocationInputChange({ target: { name: name, value: value } })
        }
        required={false}
        onBlur={() => {
          setValidating((prev) => ({ ...prev, Fax: true }));
        }}
        validating={validating.Fax}
        valid={
          !isEmpty(officeLocationData.Fax)
            ? officeLocationData.Fax.replace(/[^\d]/g, '').match(/[^ 0-9]/) == null &&
              officeLocationData.Fax.replace(/[^\d]/g, '').length == 10
            : true
        }
      />
      {isOfficeAddressValid &&
        addressList != undefined &&
        addressList != null &&
        address != '' &&
        !cardRadioUsed && (
          <AddressValidation
            addressList={addressList}
            addressHandler={addressHandler}
            existingOfficeName={existingOfficeName}
            pName={pName}
            pUrl={pUrl}
            officeHours={officeHours}
            isOldDataUsed={isOldDataUsed}
            type={type}
            radioInputValue={radioInputValue}
          />
        )}
      {currentPage === PROVIDER_PROFILE_PAGE && (
        <div className='location-checkbox'>
          <input
            id={`checkbox-primary-location`}
            type='checkbox'
            className={isPrimaryFlag ? 'primary-checkbox-disabled' : ''}
            disabled={isPrimaryFlag}
            checked={isPrimaryChecked}
            onChange={(event) => checkboxOnChangeHandler(event)}
          />
          <label
            htmlFor={`checkbox-primary-location`}
            className={officeLocationData.IsPrimary ? 'primary-checkbox-disabled' : ''}>
            This is my Primary Office
          </label>
        </div>
      )}
    </div>
  );
}

OfficeLocation.defaultProps = {
  officeLocationData: {
    Address: '',
    City: '',
    Fax: '',
    Id: '00000000-0000-0000-0000-000000000000',
    IsPrimary: false,
    JustAdded: false,
    Name: '',
    OfficeCode: '',
    OfficeHours: [],
    Phone: '',
    PracticeId: '00000000-0000-0000-0000-000000000000',
    State: '',
    Suite: '',
    UpdateOnlyOfficeHours: false,
    UpdatePracticeOnly: false,
    UpdateType: 'None',
    ZipCode: ''
  },
  type: 'Add'
};

OfficeLocation.propTypes = {
  officeLocationData: PropTypes.object,
  type: PropTypes.string
};

export default OfficeLocation;
