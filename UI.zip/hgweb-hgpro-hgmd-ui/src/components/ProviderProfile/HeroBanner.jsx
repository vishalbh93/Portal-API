import React, { useState, useEffect, Fragment } from 'react';
import { HG3Tracker } from '../../utils/tracking';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import * as actions from '../../store/actions';

//helper
import { upgradeToPremiumContent, providerCodeArray } from '../../utils/constant-data';

//styling imports
import './_index.less';
import './_herobanner.less';

//Import Component
import ProviderImage from '@hg/joy/src/components/ProviderImage';
import StarRating from '@hg/joy/src/components/StarRating';
import ProfileEdit from '../NewDashboard/MainContent/ProfileEdit';
import UpdateNotification from './UpdateNotification';

//media imports
import line from '../../assets/images/ProfileEdit/icon-line.png';
import logo from '../../assets/images/ProfileEdit/icon-logo.svg';
import noImage from '../../assets/images/ProfileEdit/icon-no-sponsor.png';
import RightArrow from '../../assets/images/ProfileEdit/icon-right-arrow.svg';
import LeftArrow from '../../assets/images/ProfileEdit/icon-left-arrow.svg';
import DownArrow from '../../assets/images/ProfileEdit/icon-down-arrow.svg';
import SvgPen from '../../assets/images/ProviderProfile/svg-pen.svg';
import { getGenderCode } from '../../utils/utils';
import ConfirmationModelPopUp from '../Common/ConfirmationModelPopUp/ConfirmationModelPopUp';

const HeroBanner = (props) => {
  const {
    providerProfileInfo,
    landingPageHandler,
    windowDimensions,
    islanding,
    dropDownHandler,
    selectedTabForMobile,
    notify,
    degreeAfterChange,
    profilePictureEditClick
  } = props;

  const [flag, setFlag] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [isClickedPre, setIsClickedPre] = useState(false);
  const [isClickedRedirc, setIsClickedRedirc] = useState(false)
  const [redirectUrl, setRedirectUrl] = useState();
  const [isClickedVid, setIsClickedVid] = useState(false);

  const redirectToPremium = () => {
    validatePage();
    setIsClickedPre(true);        
  }; 

  let infoObject = JSON.parse(providerProfileInfo.InformationJson);
  let specialtyObj = JSON.parse(providerProfileInfo.SpecialtyJson);
  let obj =
    providerProfileInfo.SponsorImage.response.docs.length != 0
      ? providerProfileInfo.SponsorImage.response.docs[0]
      : null;
  let sponsorAddress =
    obj != null
      ? obj.has_sponsorship_xml
        ? JSON.parse(providerProfileInfo.OfficeJson).Practices[0].Offices
        : ''
      : '';
  let sponsorImage =
    providerProfileInfo.sponsorImg == '' ? noImage : providerProfileInfo.sponsorImg;
  let sponsorInfo = providerProfileInfo.sponsorName;
  let star = 0;
  if (
    providerProfileInfo.Ratings != undefined &&
    providerProfileInfo.Ratings != null &&
    providerProfileInfo.Ratings.SurveyScore != undefined &&
    providerProfileInfo.Ratings.SurveyScore != null
  )
    star = Math.round(providerProfileInfo.Ratings.SurveyScore * 2) / 2;

  const dispatch = useDispatch();
  const { results } = useSelector((state) => state.getDashboardInfo);
  const providerCodesRemoveFromSponsorship = providerCodeArray;

  const validatePage = () => {     
    let photoVidButton = document.getElementsByClassName('profile-photo-video-main');
    let isProfilePage = document.getElementById('provider-profile-container');
    if (isProfilePage == null || photoVidButton.length !== 0) {
      setShowModal(false);
      setFlag(true);
    }else{
      let eleValidButton = document.getElementsByClassName('provider-profile-save valid');
    let eleValidButton_1 = document.getElementsByClassName('provider-profile-appointments-save valid');
    if (eleValidButton.length !== 0 || eleValidButton_1.length !== 0){
      setShowModal(true);
      setFlag(false);
    }      
    else{
      setShowModal(false);
      setFlag(true);      
    } 
    } 
  };

  const redirectFunc=(value)=>{
    validatePage();
    setRedirectUrl(value);
    setIsClickedRedirc(true);
  };

   const onhandleConfirm =(value) =>{    
    setFlag(value);
    setShowModal(false);
    if(!value){
      setIsClickedPre(false);
      setIsClickedRedirc(false);
      setIsClickedVid(false);
    };       
  };
  
  useEffect(() => {
    if (flag) { 
      if(isClickedPre){           
        HG3Tracker.OmnitureTrackLink('hgmd:selfservice:landing');
        let fullPath = providerProfileInfo.premiumSiteURL;
        window.open(fullPath, '_blank') || window.location.replace(fullPath);
      }
      {isClickedRedirc && (window.location.href = redirectUrl)}
      {isClickedVid && profilePictureEditClick()}
       }
  },[isClickedPre,isClickedRedirc,isClickedVid,flag]);



  useEffect(() => {
    dispatch(
      actions.getDashboardInfo(providerProfileInfo.ProviderCode, providerProfileInfo.CurrentUserId)
    );
  }, []);

  let showSponsorLogo =
    providerProfileInfo.SponsorImage.response.docs[0] != undefined &&
    providerProfileInfo.SponsorImage.response.docs[0].sponsorship_xml_json != null &&
    providerProfileInfo.SponsorImage.response.docs[0].sponsorship_xml_json.sponsorL.filter((i) =>
      providerCodesRemoveFromSponsorship.find((code) => code.id === i.prCd)
    ).length <= 0;

  return (
    <Fragment>
      <div
        className={`herobanner-section ${islanding ? 'herobanner-section-landing-container' : ''}`}>
        <div className='herobanner-section herobanner-inner-section'>
          {Object.keys(providerProfileInfo).length != 0 && (
            <>
              <div className={`provider-info ${islanding ? 'provider-info-landing' : ''}`}>
                {/* <img
                  className='provider-profile-picture'
                  src={infoObject.ImageUrl}
                  alt='profileImage'
                /> */}
                <div className='profile-photo-container'>
                  <ProviderImage
                    providerName={infoObject.Name.DisplayName}
                    providerGender={getGenderCode(infoObject.Gender)}
                    className='provider-profile-picture'
                    src={infoObject.ImageUrl}
                    size='lg'
                  />
                  <img
                    className='profile-photo-edit'
                    src={SvgPen}
                    alt='Edit Profile Image'
                    onClick={()=> { validatePage(); setIsClickedVid(true);}}
                  />
                </div>
                <div className='profile-brief'>
                  <div className='profile-brief-name'>{degreeAfterChange}</div>
                  <div className='profile-brief-ratings'>
                    <span className='speciality'>
                      {specialtyObj.Specialties.map((i) => (i.IsPrimary == true ? i.Name : ''))}
                    </span>

                    <div className='rating-container'>
                      <StarRating type='display' size='xl' stars={star} />
                      {providerProfileInfo.IncludePatientExperience && (
                        <>
                          <img className='rating-divider' src={line} alt='logo' />
                          <a
                            className='rating-survey-count'
                            onClick={()=>redirectFunc(`/patientexperience/reviews/${providerProfileInfo.ProviderCode}`)}                            
                            >
                            <span className='rating-survey-count'>
                              {providerProfileInfo.Ratings != undefined &&
                              providerProfileInfo.Ratings != null
                                ? providerProfileInfo.Ratings.SurveyCount
                                : 0}{' '}
                              Ratings
                            </span>
                          </a>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {windowDimensions < 769 && (
                  <div
                    id={`${islanding ? 'toggle-landing-page-right' : 'toggle-landing-page-left'}`}
                    onClick={() => landingPageHandler()}>
                    <img src={` ${islanding ? RightArrow : LeftArrow}`} alt='logo-arrow' />
                  </div>
                )}

                {providerProfileInfo.displaySelfServiceLink ? (
                  <div className='upgrade-to-premium-container'>
                    {upgradeToPremiumContent.map((value, index) => (
                      <Fragment key={index}>
                        <p className='stand-out-with-health-premium'>{value.title}</p>
                        <p className='stand-out-with-health-subtext'>{value.content}</p>
                      </Fragment>
                    ))}

                    <div className='btn-container'>
                      <button id='upgrade' onClick={() => redirectToPremium()}>
                        <span className='upgrade-button'>Upgrade Today!</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`sponsor-by-container ${
                      providerProfileInfo.SponsorImage.response.docs.length > 0
                        ? showSponsorLogo
                          ? 'sponsor-details-container'
                          : ''
                        : ''
                    }`}>
                    {providerProfileInfo.SponsorImage.response.docs.length > 0 &&
                    showSponsorLogo ? (
                      <>
                        <div className='sponsor-by-text'>Your profile is sponsored by</div>
                        <div
                          className={`sponsor-logo sponsor-info${
                            sponsorImage == noImage ? '-no-image' : ''
                          }`}>
                          <img
                            className={`sponsors-logo ${sponsorImage == noImage ? 'no-image' : ''}`}
                            src={sponsorImage}
                            alt='Logo'
                          />
                        </div>
                        <div className='sponsor-name'>
                          <span className='sponsor-name-label'>{sponsorInfo}</span>
                          {sponsorAddress != '' && (
                            <span className='sponsor-name-sublabel'>
                              {sponsorAddress.map(
                                (i, key) =>
                                  i.IsPrimary == true && (
                                    <Fragment key={key}>
                                      <span>
                                        {i.Address}, {i.City}
                                      </span>
                                      <span>
                                        {i.ZipCode}, {i.Fax}
                                      </span>
                                    </Fragment>
                                  )
                              )}
                            </span>
                          )}
                        </div>
                      </>
                    ) : (
                      <img className='right-align-logo' src={logo} alt='Logo' />
                    )}
                  </div>
                )}
              </div>

              {!islanding && windowDimensions <= 768 ? (
                <ProfileEdit
                  providerCode={results.ProviderCode}
                  profileCompletePercentage={results.ProfileCompletePercentage}
                />
              ) : (
                windowDimensions < 769 && (
                  <div className='tabs-dropdown' onClick={dropDownHandler}>
                    <div className='dropdown-header'>{selectedTabForMobile}</div>
                    <div className='logo-arrow-right'>
                      <img src={DownArrow} alt='logo-arrow-right' />
                    </div>
                  </div>
                )
              )}
            </>
          )}
        </div>
        {notify && (
          <div className='notification-section'>
            <UpdateNotification notify={notify} />
          </div>
        )}
      </div>     

      <svg
        className='hero-background-svg'
        data-qa-target='hero-background-svg'
        preserveAspectRatio='none'
        viewBox='0 0 1442 149'>
        <path
          d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
          fill='#F7F7F7'></path>
      </svg>

      <svg
        className={`hero-background-svg-mobile ${
          islanding ? 'hero-background-svg-mobile-landing' : ''
        }`}
        data-qa-target='hero-background-svg-mobile'
        preserveAspectRatio='none'
        viewBox='0 0 375 120'>
        <path
          d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
          fill='#F7F7F7'></path>
      </svg>

      {showModal && (<ConfirmationModelPopUp showModal = {showModal} onhandleConfirm = {onhandleConfirm}></ConfirmationModelPopUp>)}
  
    </Fragment>
  );
};

HeroBanner.propTypes = {};

export default HeroBanner;
