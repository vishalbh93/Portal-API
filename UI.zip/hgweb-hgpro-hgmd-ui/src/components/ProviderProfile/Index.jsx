import React, { useState, useEffect, Fragment } from 'react';
import { useSelector } from 'react-redux';
import _, { isEmpty } from 'lodash';

//components imports
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import ProviderProfile from './ProviderProfile';
import Banner from './HeroBanner';
import Spinner from '../Spinner/Spinner';

const Index = (props) => {
  const [currentTab, setCurrentTab] = useState('landing');
  const [islanding, setIsLanding] = useState(true);
  const [showSpinner, setShowSpinner] = useState(true);
  const [openDropdown, setOpenDropdown] = useState(false);
  const [selectedTabForMobile, setSelectedTabForMobile] = useState('Profile Overview');
  const [tab, setTab] = useState('');
  const [notify, setNotify] = useState(false);
  const [isProfilePictureEdit, setIsProfilePictureEdit] = useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  const menuClick = (section) => {
    setCurrentTab(section);
  };
  const { providerProfileInfo } = useSelector((state) => state.loadProviderProfileData);
  let menuItems = providerProfileInfo.Navigations;
  const [displayName, setDisplayName] = useState(
    providerProfileInfo.InformationJson.length > 0
      ? Object.keys(providerProfileInfo).length != 0
        ? JSON.parse(providerProfileInfo.InformationJson).Name.DisplayName
        : ''
      : ''
  );
  let infoObject = JSON.parse(providerProfileInfo.InformationJson);

  const providerDetails = () => {
    let info = JSON.parse(providerProfileInfo.InformationJson);

    let details = {
      DisplayFullName: info.Name.DisplayName,
      ImageUrl: info.ImageUrl,
      PrimarySpecialty: info.PrimarySpeciality,
      Gender: info.Gender,
      Age: info.Age,
      Pwid: info.ProviderId
    };

    return details;
  };
  let navigationModelObject = providerProfileInfo.NavigationModel;
  const getWindowDimensions = () => {
    const { innerWidth: width, innerHeight: height } = window;
    return width;
  };

  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());
  useEffect(() => {
    const handleResize = () => {
      setWindowDimensions(getWindowDimensions());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  });

  const landingPageHandler = () => {
    setIsLanding(!islanding);
  };

  const dropDownHandler = (e, type) => {
    setOpenDropdown(!openDropdown);
    !_.isEmpty(type) ? setSelectedTabForMobile(type) : '';
  };

  const subMenuHandler = (type)=> {
    !_.isEmpty(type) ? setSelectedTabForMobile(type) : '';
  };

  const TabsHandler = (e) => {
    setTab(e);
    e == 'overview' ? setNotify(false) : setNotify(true);
  };

  const handleScroll = () => {
    const offset = window.scrollY;
    if (offset > 220) {
      setScrolled(true);
    } else {
      setScrolled(false);
    }
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  });

  //To update banner degree after updation in credentials-degree
  const bannerChangeHandler = (degree, providerInformation) => {
    let dispName = `${providerInformation.Name.FirstName} ${providerInformation.Name.LastName}${
      providerInformation.Name.Suffix != '' ? ' ' + providerInformation.Name.Suffix : ''
    }${degree != '' ? ', ' + degree : ''}`;

    setDisplayName(dispName);
  };

  useEffect(() => {
    if (providerProfileInfo != null || providerProfileInfo != undefined) {
      setTimeout(() => {
        setShowSpinner(false);
      }, 1000);
    } else if (Object.keys(providerProfileInfo).length === 0) {
      setShowSpinner(true);
    }
  }, [providerProfileInfo]);

  useEffect(() => {}, [openDropdown]);

  return (
    <Fragment>
      <MenuComponent
        menuClick={menuClick}
        showMenus={true}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        providerInfo={providerDetails()}
        showSponsorSection={true}
        showUpgrade={providerProfileInfo.displaySelfServiceLink}
      />
      <div className={`banner-container ${islanding ? 'banner-container-landing' : ''}`}>
        <div className={`banner-inner-container ${scrolled ? 'banner-inner-container-hide' : ''}`}>
          <Banner
            providerProfileInfo={providerProfileInfo}
            landingPageHandler={landingPageHandler}
            windowDimensions={windowDimensions}
            islanding={islanding}
            dropDownHandler={dropDownHandler}
            selectedTabForMobile={selectedTabForMobile}
            notify={notify}
            degreeAfterChange={displayName}
            profilePictureEditClick={() => {
              setIsProfilePictureEdit(true);
            }}
          />
        </div>
      </div>

      <div
        className={`main-container ${
          scrolled && windowDimensions > 768 ? 'main-container-scrolled-view' : ''
        }`}>
        <div className='inner-container'>
          <ProviderProfile
            providerProfileInfo={providerProfileInfo}
            islanding={islanding}
            windowDimensions={windowDimensions}
            openDropdown={openDropdown}
            dropDownHandler={dropDownHandler}
            TabsHandler={TabsHandler}
            bannerChangeHandler={bannerChangeHandler}
            bannerDisplayName={displayName}
            notify={notify}
            isProfilePictureEdit={isProfilePictureEdit}
            setIsProfileEdit={setIsProfilePictureEdit}
            subMenuHandler={subMenuHandler}
          />
        </div>
      </div>

      <Footer />
      {showSpinner && <Spinner cta={true} />}
    </Fragment>
  );
};

Index.propTypes = {};

export default Index;
