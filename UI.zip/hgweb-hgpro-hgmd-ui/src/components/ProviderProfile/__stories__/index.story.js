import React from 'react';
import { storiesOf } from '@storybook/react';
import ProviderProfile from '../ProviderProfile';
import AdminStore from '../../../../.storybook/store';

const providerProfileInfo = {
  ProviderCode: 'XYLHG2F',
  currentUserId: '09734255-8027-42bb-a757-cf1b1ba863a7',
  HasLargeRoster: true,
  InformationJson:
    '{"ProviderId":"2XXDS","MissingData":false,"MissingDataText":"","Name":{"DisplayName":"Mark Test IV, DC","FirstName":"Mark","MiddleName":"A","LastName":"Test","Suffix":"IV","Degree":"DC","ImageUrl":null,"MmpPhotoUploadUrl":null},"DateOfBirth":"1973-05-28T00:00:00","DobDateDisplay":"5/28/1973","DobWordDisplay":"May 28, 1973","ImageUrl":"//d1ffafozi03i4l.cloudfront.net/img/prov/2/x/x/2xxds_w120h160_vS11jrPvkc.jpg","HasImage":true,"Gender":"M","GenderDisplay":"Male","AcceptingNewPatients":false,"AcceptingNewPatientsDisplay":"No","AcceptingNewPatientsMissing":false,"MissingAvailability":false,"Age":49,"PrimarySpeciality":"Dentistry","Address":"1309 S Federal Hwy"}',
  CrowdSourceJson:
    '[{"ownerOverrideAnswer":null,"questionModel":{"question":"Communicate via email?","questionDisplayName":"Does #displayName communicate via email?","questionType":"communicateViaEmail","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0},{"ownerOverrideAnswer":null,"questionModel":{"question":"Offer telehealth services or virtual visits?","questionDisplayName":"Does #displayName offer telehealth services or virtual visits?","questionType":"offerTelehealth","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0},{"ownerOverrideAnswer":null,"questionModel":{"question":"Offer an online patient portal?","questionDisplayName":"Does #displayName offer an online patient portal?","questionType":"offerOnlinePortal","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0},{"ownerOverrideAnswer":null,"questionModel":{"question":"Have free onsite parking?","questionDisplayName":"Does #displayName have free onsite parking?","questionType":"offerOnsiteParking","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0},{"ownerOverrideAnswer":null,"questionModel":{"question":"Offer weekend visits?","questionDisplayName":"Does #displayName offer weekend visits?","questionType":"offerWeekendVisits","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0},{"ownerOverrideAnswer":null,"questionModel":{"question":"Offer evening visits?","questionDisplayName":"Does #displayName offer evening visits?","questionType":"offerEveningVisits","answerType":"multipleChoice","answerSchema":[{"answer":"yes","answerText":"Yes","isPositive":true},{"answer":"no","answerText":"No","isPositive":false},{"answer":"idontknow","answerText":"I don\'t know","isPositive":false}]},"totalAnswers":0,"totalPositiveAnswers":0}]',
  SpecialtyJson:
    '{"ProviderId":"2XXDS","ProviderType":"Alternative","SectionTitle":"Specialties","AddPlaceholder":"+ Add Specialty","RelatedModalTitle":"Related Specialties","RelatedModalSubTitle":"Select from the list below the specialties you want on your profile","Specialties":[{"Code":"PS328","Name":"Dentistry","IsPrimary":true,"HasRelated":true,"SpecialtyGroupCode":"GDNT","LegacyId":"92","UpdateType":"None"},{"Code":"PS019","Name":"Child & Adolescent Psychiatry","IsPrimary":false,"HasRelated":true,"SpecialtyGroupCode":"APPP","LegacyId":"10","UpdateType":"None"},{"Code":"PS645","Name":"Ear, Nose, and Throat","IsPrimary":false,"HasRelated":true,"SpecialtyGroupCode":"OTLG","LegacyId":"36","UpdateType":"None"}]}',
  ConditionJson:
    '{"ProviderId":"2XXDS","MissingData":false,"RelatedModalTitle":"Select Related Conditions","RelatedModalSubTitle":"Select from the list below the conditions you want on your profile","TopModalTitle":"Top 20 Conditions for Your Specialty","Items":[{"Code":"52050","Name":"Affairs and Infidelity","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"1060","Name":"Age Spots","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"1572","Name":"Age-Related Cognitive Decline","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"1253","Name":"Ankle Instability","ActualName":null,"NameExtension":null,"HasRelated":true,"UpdateType":"None","HmsSourced":false},{"Code":"50737","Name":"Ascending Thoracic Aortic Aneurysm","ActualName":null,"NameExtension":null,"HasRelated":true,"UpdateType":"None","HmsSourced":false},{"Code":"4320","Name":"Atrial Septal Defect 2 (ASD 2)","ActualName":null,"NameExtension":null,"HasRelated":true,"UpdateType":"None","HmsSourced":false},{"Code":"51885","Name":"Earwax Buildup","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"18765","Name":"Head and Neck Tumor","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"2153","Name":"Hemorrhoids","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"11818","Name":"Lower Back Muscle Strain","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"420","Name":"Migraine","ActualName":null,"NameExtension":null,"HasRelated":true,"UpdateType":"None","HmsSourced":false}]}',
  ProcedureJson:
    '{"ProviderId":"2XXDS","MissingData":false,"RelatedModalTitle":"Related Procedures","RelatedModalSubTitle":"Select from the list below the procedures you want on your profile","TopModalTitle":"Top 20 Procedures for your Specialty","Items":[{"Code":"95","Name":"Acupuncture","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"50699","Name":"ADHD Testing","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"52194","Name":"Aftercare for Substance Abuse","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"50945","Name":"Chronic Pain Management","ActualName":null,"NameExtension":null,"HasRelated":false,"UpdateType":"None","HmsSourced":false}]}',
  TopProceduresJson:
    '[{"Id":"1249","Name":"Amalgam Dental Fillings","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1258","Name":"Composite Fillings","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2200","Name":"Cosmetic Procedure","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"51410","Name":"Dental Cleaning","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1262","Name":"Dental Crown","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"51309","Name":"Dental Hygiene Services","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2778","Name":"Dental Implant","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1265","Name":"Dental Inlays","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1210","Name":"Invisalign®","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"50815","Name":"Lower Dentures","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1301","Name":"Non-Surgical Gum Treatment","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1305","Name":"Porcelain Veneers","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1231","Name":"Root Canal","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1311","Name":"Root Planing","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1313","Name":"Simple Tooth Extractions","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"50976","Name":"Teeth Extraction","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1232","Name":"Teeth Scaling","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1317","Name":"Teeth Whitening","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"51552","Name":"Tooth-Conserving Dentistry","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"50875","Name":"Upper Dentures","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null}]',
  TopConditionsJson:
    '[{"Id":"51704","Name":"Broken Tooth","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1783","Name":"Cavity","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2857","Name":"Chipped Tooth","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"7629","Name":"Dental Disorders","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1465","Name":"Gingivitis","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"133","Name":"Grinding of Teeth","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2536","Name":"Gum Disease","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"51749","Name":"Loose Teeth","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2366","Name":"Misaligned Teeth","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"17088","Name":"Tempormandibular Joint Pain","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"50680","Name":"TMJ","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"17263","Name":"Tooth Abrasion","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"7628","Name":"Tooth Abscess","Selected":false,"IsDisabled":false,"HasRelated":true,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"17266","Name":"Tooth Attrition","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"51727","Name":"Tooth Damage","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1521","Name":"Tooth Decay","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"17267","Name":"Tooth Demineralization","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"1938","Name":"Tooth Discoloration","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"2858","Name":"Tooth Loss","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null},{"Id":"17268","Name":"Toothache","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":null,"NameExtension":null}]',
  InsuranceJson: '{"ProviderId":"2XXDS","MissingData":true,"Insurance":[]}',
  TopInsuranceJson:
    '[{"PayorId":"4E544541-0041-0000-0000-000000000000","PayorCode":"AETNA","Name":"Aetna","PlanCount":1575,"Selected":false},{"PayorId":"30595048-3030-3730-3637-000000000000","PayorCode":"HPY0000767","Name":"Ambetter","PlanCount":6,"Selected":false},{"PayorId":"52454D41-5449-0000-0000-000000000000","PayorCode":"AMERIT","Name":"Ameritas","PlanCount":4,"Selected":false},{"PayorId":"30595048-3030-3730-3638-000000000000","PayorCode":"HPY0000768","Name":"Anthem","PlanCount":1631,"Selected":false},{"PayorId":"454D5641-0044-0000-0000-000000000000","PayorCode":"AVMED","Name":"AvMed","PlanCount":48,"Selected":false},{"PayorId":"45554C42-4743-0000-0000-000000000000","PayorCode":"BLUECG","Name":"Blue Cross Blue Shield","PlanCount":135,"Selected":false},{"PayorId":"45554C42-5743-0000-0000-000000000000","PayorCode":"BLUECW","Name":"Blue Cross Blue Shield of Florida","PlanCount":7,"Selected":false},{"PayorId":"45524143-4146-0000-0000-000000000000","PayorCode":"CAREFA","Name":"CareFirst Blue Cross Blue Shield","PlanCount":82,"Selected":false},{"PayorId":"4E474943-0041-0000-0000-000000000000","PayorCode":"CIGNA","Name":"Cigna","PlanCount":398,"Selected":false},{"PayorId":"45484F43-4143-0000-0000-000000000000","PayorCode":"COHECA","Name":"Coventry Health Care","PlanCount":190,"Selected":false},{"PayorId":"414F4E44-0000-0000-0000-000000000000","PayorCode":"DNOA","Name":"Dental Network of America","PlanCount":6,"Selected":false},{"PayorId":"53524946-4254-0000-0000-000000000000","PayorCode":"FIRSTB","Name":"First Health (Coventry Health Care)","PlanCount":7,"Selected":false},{"PayorId":"52554147-4944-0000-0000-000000000000","PayorCode":"GAURDI","Name":"Guardian","PlanCount":30,"Selected":false},{"PayorId":"414D5548-414E-0000-0000-000000000000","PayorCode":"HUMANA","Name":"Humana","PlanCount":443,"Selected":false},{"PayorId":"4144454D-4449-0000-0000-000000000000","PayorCode":"MEDAID","Name":"Medicaid","PlanCount":19,"Selected":false},{"PayorId":"4C54454D-4649-0000-0000-000000000000","PayorCode":"METLIF","Name":"MetLife","PlanCount":324,"Selected":false},{"PayorId":"544C554D-5049-0000-0000-000000000000","PayorCode":"MULTIP","Name":"MultiPlan","PlanCount":31,"Selected":false},{"PayorId":"46495250-5247-0000-0000-000000000000","PayorCode":"PRIFGR","Name":"Principal Financial Group","PlanCount":8,"Selected":false},{"PayorId":"43495254-5241-0000-0000-000000000000","PayorCode":"TRICAR","Name":"Tricare","PlanCount":39,"Selected":false},{"PayorId":"54494E55-4348-0000-0000-000000000000","PayorCode":"UNITHC","Name":"UnitedHealthCare","PlanCount":579,"Selected":false}]',
  AffiliatedHospitalJson:
    '{"ProviderId":"2XXDS","MissingData":false,"RelatedModalTitle":null,"RelatedModalSubTitle":null,"TopModalTitle":"Nearby Hospitals","Items":[{"Code":"1A7682","Name":"Abrazo Arrowhead Campus, Glendale, AZ","ActualName":"Abrazo Arrowhead Campus","NameExtension":"Glendale, AZ","HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"679F1C","Name":"AdCare Hospital, Worcester, MA","ActualName":"AdCare Hospital","NameExtension":"Worcester, MA","HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"0C3E4E","Name":"Caddo Oaks Hospital Affiliated Health, Shreveport, LA","ActualName":"Caddo Oaks Hospital Affiliated Health","NameExtension":"Shreveport, LA","HasRelated":false,"UpdateType":"None","HmsSourced":false},{"Code":"924AD9","Name":"Mayo Clinic Hospital, Phoenix, Arizona, Phoenix, AZ","ActualName":"Mayo Clinic Hospital, Phoenix, Arizona","NameExtension":"Phoenix, AZ","HasRelated":false,"UpdateType":"None","HmsSourced":false}]}',
  TopAffiliatedHospitalJson:
    '[{"Id":"5EC1CD","Name":"Broward Health Coral Springs, Coral Springs, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Broward Health Coral Springs","NameExtension":"Coral Springs, FL"},{"Id":"950C1E","Name":"Broward Health Imperial Point, Fort Lauderdale, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Broward Health Imperial Point","NameExtension":"Fort Lauderdale, FL"},{"Id":"72D9CA","Name":"Broward Health Medical Center, Fort Lauderdale, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Broward Health Medical Center","NameExtension":"Fort Lauderdale, FL"},{"Id":"33038A","Name":"Broward Health North, Pompano Beach, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Broward Health North","NameExtension":"Pompano Beach, FL"},{"Id":"53C50E","Name":"Cleveland Clinic Florida, Weston, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Cleveland Clinic Florida","NameExtension":"Weston, FL"},{"Id":"CEA447","Name":"Florida Medical Center, Lauderdale Lakes, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Florida Medical Center","NameExtension":"Lauderdale Lakes, FL"},{"Id":"6E1D9D","Name":"HCA Florida Aventura Hospital, Aventura, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"HCA Florida Aventura Hospital","NameExtension":"Aventura, FL"},{"Id":"FA22D5","Name":"HCA Florida Northwest Hospital, Margate, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"HCA Florida Northwest Hospital","NameExtension":"Margate, FL"},{"Id":"HG7556","Name":"HCA Florida University Hospital, Davie, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"HCA Florida University Hospital","NameExtension":"Davie, FL"},{"Id":"54F042","Name":"HCA Florida Westside Hospital, Plantation, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"HCA Florida Westside Hospital","NameExtension":"Plantation, FL"},{"Id":"60D11C","Name":"HCA Florida Woodmont Hospital, Tamarac, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"HCA Florida Woodmont Hospital","NameExtension":"Tamarac, FL"},{"Id":"F40750","Name":"Holy Cross Hospital, Fort Lauderdale, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Holy Cross Hospital","NameExtension":"Fort Lauderdale, FL"},{"Id":"7E47F8","Name":"Jackson North Medical Center, North Miami Beach, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Jackson North Medical Center","NameExtension":"North Miami Beach, FL"},{"Id":"97011A","Name":"Joe DiMaggio Children\'s Hospital, Hollywood, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Joe DiMaggio Children\'s Hospital","NameExtension":"Hollywood, FL"},{"Id":"9D6BB8","Name":"Memorial Hospital Miramar, Miramar, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Memorial Hospital Miramar","NameExtension":"Miramar, FL"},{"Id":"8D986B","Name":"Memorial Hospital Pembroke, Pembroke Pines, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Memorial Hospital Pembroke","NameExtension":"Pembroke Pines, FL"},{"Id":"5A43B1","Name":"Memorial Hospital West, Pembroke Pines, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Memorial Hospital West","NameExtension":"Pembroke Pines, FL"},{"Id":"BC1256","Name":"Memorial Regional Hospital South, Hollywood, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Memorial Regional Hospital South","NameExtension":"Hollywood, FL"},{"Id":"10CBBE","Name":"Memorial Regional Hospital, Hollywood, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Memorial Regional Hospital","NameExtension":"Hollywood, FL"},{"Id":"100338","Name":"Open Access Vascular Access Center, Miami, FL","Selected":false,"IsDisabled":false,"HasRelated":false,"GroupCode":null,"LegacyId":null,"ActualName":"Open Access Vascular Access Center","NameExtension":"Miami, FL"}]',
  AcceptingNewPatientsJson:
    '{"ProviderId":"2XXDS","MissingAvailability":false,"GeneralMissingText":"","AcceptingNewPatients":false,"AcceptingNewPatientsDisplay":"No"}',
  AvailabilityJson:
    '{"ProviderId":"2XXDS","MissingData":false,"AvailabilityStatement":"","AppointmentServices":[{"AvailabilityCode":"AA0000C352","AvailabilityDescription":"Same Day","ItemSelected":false},{"AvailabilityCode":"AA0000C351","AvailabilityDescription":"Next Day","ItemSelected":true},{"AvailabilityCode":"AA0000C350","AvailabilityDescription":"Evening","ItemSelected":false},{"AvailabilityCode":"AA0000C353","AvailabilityDescription":"Saturday","ItemSelected":false}]}',
  LanguageJson:
    '{"ProviderId":"2XXDS","Items":[{"Id":"Chamorro","Language":"Chamorro","UpdateType":"None"},{"Id":"Hindi","Language":"Hindi","UpdateType":"None"},{"Id":"Malayalam","Language":"Malayalam","UpdateType":"None"},{"Id":"Spanish","Language":"Spanish","UpdateType":"None"},{"Id":"Tamil","Language":"Tamil","UpdateType":"None"}]}',
  EducationJson:
    '{"ProviderId":"2XXDS","MissingData":true,"Educations":[{"EducationType":"UNDUNI","Title":"Undergraduate School","Institutions":[]},{"EducationType":"MEDSCH","Title":"Medical School","Institutions":[]},{"EducationType":"INTERN","Title":"Internship","Institutions":[]},{"EducationType":"RESIDE","Title":"Residency","Institutions":[]},{"EducationType":"FELLOW","Title":"Fellowship","Institutions":[]},{"EducationType":"EDUTRA","Title":"Other Education","Institutions":[]}]}',
  CredentialJson:
    '{"ProviderId":"2XXDS","MissingData":false,"DisplayName":"Mark Test IV, DC","Degree":"DC","StateLicenses":[{"Id":"CO","StateName":"Colorado","UpdateType":"None"}]}',
  TelehealthInformationJson:
    '{"ProviderId":"2XXDS","IsTelehealthServiceEnabled":true,"ServiceName":null,"ServiceLink":"https://update-alpha-testaws.healthgrades.com/provider/profile/X6JGD/admin","ServicePhone":"234-567-8976"}',
  VideoInformationJson:
    '{"ProviderId":"2XXDS","ProviderName":"Dr. Mark Test IV","Url":"https://testaws.healthgrades.com/video/0000017d-c55c-d7c0-af7f-cd7e9c620000","Size":0.0,"Duration":0.0,"VideoHostCode":"BRIGHTSPOT"}',
  BrandingInformationJson:
    '{"ProviderId":"2XXDS","BrandingInfo":{"BrandingLogoInfo":[],"BrandingBannerInfo":[]}}',
  BoardCertificationJson: '{"ProviderId":"2XXDS","Certifications":[]}',
  BoardCertificationAgencyListJson: '[]',
  AboutMeJson:
    '{"ProviderId":"2XXDS","AboutMeList":[{"SectionType":"About","SectionText":"<p>Bio goes here...</p>","MaxCharacters":4000,"HasText":true},{"SectionType":"CarePhilosophy","SectionText":"<p>We are Care Philosophy..</p>","MaxCharacters":1000,"HasText":true},{"SectionType":"ConditionsTreated","SectionText":"","MaxCharacters":1000,"HasText":false},{"SectionType":"ProceduresPerformed","SectionText":"","MaxCharacters":1000,"HasText":false},{"SectionType":"ResponseToPes","SectionText":"<p>Excellent&hellip;</p>","MaxCharacters":1000,"HasText":true}]}',
  OfficeJson:
    '{"ProviderId":"2XXDS","Practices":[{"PracticeCode":"MP0000EFE3","Id":"3030504d-3030-4645-4533-000000000000","OriginalId":null,"Name":"Geriatric Internal Medicine Specialists, LLC","Description":"","WebSiteUrl":"","LockPracticeEdit":false,"OriginalDescription":"","OriginalWebSiteUrl":"","ProviderCount":1,"IsPractice":true,"IsNew":false,"HasOffices":true,"editMode":false,"Offices":[{"OfficeCode":"X839LS","PracticeId":"3030504d-3030-4645-4533-000000000000","Name":"Hawthorn Medical Associates","Address":"530 Faunce Corner Rd ","Suite":"Ste 1","City":"N Dartmouth","State":"MA","ZipCode":"02747","Latitude":41.671642,"Longitude":-70.990784,"Phone":"(508) 996-3991","Fax":"(509) 998-3881","HasOfficeHours":false,"UpdateOnlyOfficeHours":false,"UpdatePracticeOnly":false,"OfficeHours":[],"Providers":null,"TwoColumns":false,"DisplayProviders":null,"ContainsLastOffice":false,"AssociatedPractice":false,"IsPrimary":false,"HasPrimary":false,"Id":"39333858-534c-0000-0000-000000000000","OrigId":"39333858-534c-0000-0000-000000000000","OrigSolrId":"39333858-534c-0000-0000-000000000000","ProviderCount":0,"FacetCount":0,"OrigIdCount":0,"OrigIdTotal":0,"IsOasOffice":false,"IsAddPlaceholder":false,"JustAdded":false,"UpdateType":"None"}],"OfficeHasHours":false,"JustAdded":false,"AssociatedToUser":false,"UpdateType":"None","UserId":null},{"PracticeCode":"MP0005251C","Id":"3030504d-3530-3532-3143-000000000000","OriginalId":null,"Name":"Test & Validate2","Description":"","WebSiteUrl":"","LockPracticeEdit":false,"OriginalDescription":"","OriginalWebSiteUrl":"","ProviderCount":3,"IsPractice":true,"IsNew":false,"HasOffices":true,"editMode":false,"Offices":[{"OfficeCode":"X7RMYT","PracticeId":"3030504d-3530-3532-3143-000000000000","Name":"Testing HGMD","Address":"1309 S Federal Hwy","Suite":"# 200","City":"Ft Lauderdale","State":"FL","ZipCode":"33316","Latitude":26.105679,"Longitude":-80.137344,"Phone":"(606) 246-2242","Fax":"","HasOfficeHours":false,"UpdateOnlyOfficeHours":false,"UpdatePracticeOnly":false,"OfficeHours":[],"Providers":null,"TwoColumns":false,"DisplayProviders":null,"ContainsLastOffice":false,"AssociatedPractice":false,"IsPrimary":true,"HasPrimary":false,"Id":"4d523758-5459-0000-0000-000000000000","OrigId":"4d523758-5459-0000-0000-000000000000","OrigSolrId":"4d523758-5459-0000-0000-000000000000","ProviderCount":0,"FacetCount":0,"OrigIdCount":0,"OrigIdTotal":0,"IsOasOffice":false,"IsAddPlaceholder":false,"JustAdded":false,"UpdateType":"None"}],"OfficeHasHours":false,"JustAdded":false,"AssociatedToUser":false,"UpdateType":"None","UserId":null},{"PracticeCode":"MP0000E810","Id":"3030504d-3030-3845-3130-000000000000","OriginalId":null,"Name":"Test and practice","Description":"","WebSiteUrl":"","LockPracticeEdit":false,"OriginalDescription":"","OriginalWebSiteUrl":"","ProviderCount":2,"IsPractice":true,"IsNew":false,"HasOffices":true,"editMode":false,"Offices":[{"OfficeCode":"X9MBL5","PracticeId":"3030504d-3030-3845-3130-000000000000","Name":"HG Test-Check","Address":"4915 E Baseline Rd","Suite":null,"City":"Gilbert","State":"AZ","ZipCode":"85234","Latitude":33.37905,"Longitude":-111.72595,"Phone":"(301) 143-1433","Fax":"(802) 332-7203","HasOfficeHours":false,"UpdateOnlyOfficeHours":false,"UpdatePracticeOnly":false,"OfficeHours":[],"Providers":null,"TwoColumns":false,"DisplayProviders":null,"ContainsLastOffice":false,"AssociatedPractice":false,"IsPrimary":false,"HasPrimary":false,"Id":"424d3958-354c-0000-0000-000000000000","OrigId":"424d3958-354c-0000-0000-000000000000","OrigSolrId":"424d3958-354c-0000-0000-000000000000","ProviderCount":0,"FacetCount":0,"OrigIdCount":0,"OrigIdTotal":0,"IsOasOffice":false,"IsAddPlaceholder":false,"JustAdded":false,"UpdateType":"None"}],"OfficeHasHours":false,"JustAdded":false,"AssociatedToUser":false,"UpdateType":"None","UserId":null},{"PracticeCode":"MP000121CB","Id":"3030504d-3130-3132-4342-000000000000","OriginalId":null,"Name":"Test and practice Inc","Description":"","WebSiteUrl":"","LockPracticeEdit":false,"OriginalDescription":"","OriginalWebSiteUrl":"","ProviderCount":2,"IsPractice":true,"IsNew":false,"HasOffices":true,"editMode":false,"Offices":[{"OfficeCode":"X8BFFM","PracticeId":"3030504d-3130-3132-4342-000000000000","Name":"HG Office","Address":"1309 S Federal Hwy","Suite":"Ste 100","City":"Fort Lauderdale","State":"FL","ZipCode":"33316","Latitude":26.10554,"Longitude":-80.13734,"Phone":"(707) 777-7777","Fax":"(802) 332-7202","HasOfficeHours":false,"UpdateOnlyOfficeHours":false,"UpdatePracticeOnly":false,"OfficeHours":[],"Providers":null,"TwoColumns":false,"DisplayProviders":null,"ContainsLastOffice":false,"AssociatedPractice":false,"IsPrimary":false,"HasPrimary":false,"Id":"46423858-4d46-0000-0000-000000000000","OrigId":"46423858-4d46-0000-0000-000000000000","OrigSolrId":"46423858-4d46-0000-0000-000000000000","ProviderCount":0,"FacetCount":0,"OrigIdCount":0,"OrigIdTotal":0,"IsOasOffice":false,"IsAddPlaceholder":false,"JustAdded":false,"UpdateType":"None"}],"OfficeHasHours":false,"JustAdded":false,"AssociatedToUser":false,"UpdateType":"None","UserId":null}],"PracticeList":[{"Id":"3030504d-3030-4645-4533-000000000000","Name":"Geriatric Internal Medicine Specialists, LLC"},{"Id":"3030504d-3530-3532-3143-000000000000","Name":"Test & Validate2"},{"Id":"3030504d-3030-3845-3130-000000000000","Name":"Test and practice"},{"Id":"3030504d-3130-3132-4342-000000000000","Name":"Test and practice Inc"},{"Id":"00000000-0000-0000-0000-000000000000","Name":"Not affiliated with a practice"}],"OfficeMessage":"","ShowOfficeHours":true,"LockOfficeEdit":true,"LockPracticeEdit":true,"EditOnPracticePage":true,"UpdateAllProviders":false,"messageValue":null,"ProviderCount":0}',
  StateListJson:
    '[{"Id":"AL","Name":"Alabama (AL)"},{"Id":"AK","Name":"Alaska (AK)"},{"Id":"AS","Name":"American Samoa (AS)"},{"Id":"AZ","Name":"Arizona (AZ)"},{"Id":"AR","Name":"Arkansas (AR)"},{"Id":"AA","Name":"Armed Forces Americas (AA)"},{"Id":"AE","Name":"Armed Forces Europe (AE)"},{"Id":"AP","Name":"Armed Forces Pacific (AP)"},{"Id":"CA","Name":"California (CA)"},{"Id":"CO","Name":"Colorado (CO)"},{"Id":"CT","Name":"Connecticut (CT)"},{"Id":"DE","Name":"Delaware (DE)"},{"Id":"DC","Name":"District of Columbia (DC)"},{"Id":"FM","Name":"Federated States of Micronesia (FM)"},{"Id":"FL","Name":"Florida (FL)"},{"Id":"GA","Name":"Georgia (GA)"},{"Id":"GU","Name":"Guam (GU)"},{"Id":"HI","Name":"Hawaii (HI)"},{"Id":"ID","Name":"Idaho (ID)"},{"Id":"IL","Name":"Illinois (IL)"},{"Id":"IN","Name":"Indiana (IN)"},{"Id":"IA","Name":"Iowa (IA)"},{"Id":"KS","Name":"Kansas (KS)"},{"Id":"KY","Name":"Kentucky (KY)"},{"Id":"LA","Name":"Louisiana (LA)"},{"Id":"ME","Name":"Maine (ME)"},{"Id":"MH","Name":"Marshall Islands (MH)"},{"Id":"MD","Name":"Maryland (MD)"},{"Id":"MA","Name":"Massachusetts (MA)"},{"Id":"MI","Name":"Michigan (MI)"},{"Id":"MN","Name":"Minnesota (MN)"},{"Id":"MS","Name":"Mississippi (MS)"},{"Id":"MO","Name":"Missouri (MO)"},{"Id":"MT","Name":"Montana (MT)"},{"Id":"NE","Name":"Nebraska (NE)"},{"Id":"NV","Name":"Nevada (NV)"},{"Id":"NH","Name":"New Hampshire (NH)"},{"Id":"NJ","Name":"New Jersey (NJ)"},{"Id":"NM","Name":"New Mexico (NM)"},{"Id":"NY","Name":"New York (NY)"},{"Id":"NC","Name":"North Carolina (NC)"},{"Id":"ND","Name":"North Dakota (ND)"},{"Id":"MP","Name":"Northern Mariana Islands (MP)"},{"Id":"OH","Name":"Ohio (OH)"},{"Id":"OK","Name":"Oklahoma (OK)"},{"Id":"OR","Name":"Oregon (OR)"},{"Id":"PW","Name":"Palau (PW)"},{"Id":"PW","Name":"Palau (PW)"},{"Id":"PA","Name":"Pennsylvania (PA)"},{"Id":"PR","Name":"Puerto Rico (PR)"},{"Id":"RI","Name":"Rhode Island (RI)"},{"Id":"SC","Name":"South Carolina (SC)"},{"Id":"SD","Name":"South Dakota (SD)"},{"Id":"TN","Name":"Tennessee (TN)"},{"Id":"TX","Name":"Texas (TX)"},{"Id":"UT","Name":"Utah (UT)"},{"Id":"VT","Name":"Vermont (VT)"},{"Id":"VI","Name":"Virgin Islands (VI)"},{"Id":"VA","Name":"Virginia (VA)"},{"Id":"WA","Name":"Washington (WA)"},{"Id":"WV","Name":"West Virginia (WV)"},{"Id":"WI","Name":"Wisconsin (WI)"},{"Id":"WY","Name":"Wyoming (WY)"}]',
  OfficeHoursTemplate: {
    OfficeHours:
      '[{"DayOfWeek":"Monday","DisplayOrder":1,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Tuesday","DisplayOrder":2,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Wednesday","DisplayOrder":3,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Thursday","DisplayOrder":4,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Friday","DisplayOrder":5,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Saturday","DisplayOrder":6,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false},{"DayOfWeek":"Sunday","DisplayOrder":7,"StartTime":"","EndTime":"","OpenCloseSelected":"Open","RowError":false}]',
    OpenCloseSelect:
      '[{"Id":"Open","Value":"Open"},{"Id":"Closed","Value":"Closed"},{"Id":"Open24Hours","Value":"Open 24 Hours"}]',
    TimeSelect:
      '[{"Id":"","Value":""},{"Id":"12:00 am","Value":"12:00 am"},{"Id":"12:15 am","Value":"12:15 am"},{"Id":"12:30 am","Value":"12:30 am"},{"Id":"12:45 am","Value":"12:45 am"},{"Id":"1:00 am","Value":"1:00 am"},{"Id":"1:15 am","Value":"1:15 am"},{"Id":"1:30 am","Value":"1:30 am"},{"Id":"1:45 am","Value":"1:45 am"},{"Id":"2:00 am","Value":"2:00 am"},{"Id":"2:15 am","Value":"2:15 am"},{"Id":"2:30 am","Value":"2:30 am"},{"Id":"2:45 am","Value":"2:45 am"},{"Id":"3:00 am","Value":"3:00 am"},{"Id":"3:15 am","Value":"3:15 am"},{"Id":"3:30 am","Value":"3:30 am"},{"Id":"3:45 am","Value":"3:45 am"},{"Id":"4:00 am","Value":"4:00 am"},{"Id":"4:15 am","Value":"4:15 am"},{"Id":"4:30 am","Value":"4:30 am"},{"Id":"4:45 am","Value":"4:45 am"},{"Id":"5:00 am","Value":"5:00 am"},{"Id":"5:15 am","Value":"5:15 am"},{"Id":"5:30 am","Value":"5:30 am"},{"Id":"5:45 am","Value":"5:45 am"},{"Id":"6:00 am","Value":"6:00 am"},{"Id":"6:15 am","Value":"6:15 am"},{"Id":"6:30 am","Value":"6:30 am"},{"Id":"6:45 am","Value":"6:45 am"},{"Id":"7:00 am","Value":"7:00 am"},{"Id":"7:15 am","Value":"7:15 am"},{"Id":"7:30 am","Value":"7:30 am"},{"Id":"7:45 am","Value":"7:45 am"},{"Id":"8:00 am","Value":"8:00 am"},{"Id":"8:15 am","Value":"8:15 am"},{"Id":"8:30 am","Value":"8:30 am"},{"Id":"8:45 am","Value":"8:45 am"},{"Id":"9:00 am","Value":"9:00 am"},{"Id":"9:15 am","Value":"9:15 am"},{"Id":"9:30 am","Value":"9:30 am"},{"Id":"9:45 am","Value":"9:45 am"},{"Id":"10:00 am","Value":"10:00 am"},{"Id":"10:15 am","Value":"10:15 am"},{"Id":"10:30 am","Value":"10:30 am"},{"Id":"10:45 am","Value":"10:45 am"},{"Id":"11:00 am","Value":"11:00 am"},{"Id":"11:15 am","Value":"11:15 am"},{"Id":"11:30 am","Value":"11:30 am"},{"Id":"11:45 am","Value":"11:45 am"},{"Id":"12:00 pm","Value":"12:00 pm"},{"Id":"12:15 pm","Value":"12:15 pm"},{"Id":"12:30 pm","Value":"12:30 pm"},{"Id":"12:45 pm","Value":"12:45 pm"},{"Id":"1:00 pm","Value":"1:00 pm"},{"Id":"1:15 pm","Value":"1:15 pm"},{"Id":"1:30 pm","Value":"1:30 pm"},{"Id":"1:45 pm","Value":"1:45 pm"},{"Id":"2:00 pm","Value":"2:00 pm"},{"Id":"2:15 pm","Value":"2:15 pm"},{"Id":"2:30 pm","Value":"2:30 pm"},{"Id":"2:45 pm","Value":"2:45 pm"},{"Id":"3:00 pm","Value":"3:00 pm"},{"Id":"3:15 pm","Value":"3:15 pm"},{"Id":"3:30 pm","Value":"3:30 pm"},{"Id":"3:45 pm","Value":"3:45 pm"},{"Id":"4:00 pm","Value":"4:00 pm"},{"Id":"4:15 pm","Value":"4:15 pm"},{"Id":"4:30 pm","Value":"4:30 pm"},{"Id":"4:45 pm","Value":"4:45 pm"},{"Id":"5:00 pm","Value":"5:00 pm"},{"Id":"5:15 pm","Value":"5:15 pm"},{"Id":"5:30 pm","Value":"5:30 pm"},{"Id":"5:45 pm","Value":"5:45 pm"},{"Id":"6:00 pm","Value":"6:00 pm"},{"Id":"6:15 pm","Value":"6:15 pm"},{"Id":"6:30 pm","Value":"6:30 pm"},{"Id":"6:45 pm","Value":"6:45 pm"},{"Id":"7:00 pm","Value":"7:00 pm"},{"Id":"7:15 pm","Value":"7:15 pm"},{"Id":"7:30 pm","Value":"7:30 pm"},{"Id":"7:45 pm","Value":"7:45 pm"},{"Id":"8:00 pm","Value":"8:00 pm"},{"Id":"8:15 pm","Value":"8:15 pm"},{"Id":"8:30 pm","Value":"8:30 pm"},{"Id":"8:45 pm","Value":"8:45 pm"},{"Id":"9:00 pm","Value":"9:00 pm"},{"Id":"9:15 pm","Value":"9:15 pm"},{"Id":"9:30 pm","Value":"9:30 pm"},{"Id":"9:45 pm","Value":"9:45 pm"},{"Id":"10:00 pm","Value":"10:00 pm"},{"Id":"10:15 pm","Value":"10:15 pm"},{"Id":"10:30 pm","Value":"10:30 pm"},{"Id":"10:45 pm","Value":"10:45 pm"},{"Id":"11:00 pm","Value":"11:00 pm"},{"Id":"11:15 pm","Value":"11:15 pm"},{"Id":"11:30 pm","Value":"11:30 pm"},{"Id":"11:45 pm","Value":"11:45 pm"}]'
  },
  LatLon: '26.105679,-80.137344',
  PercentComplete: 74,
  ProfileViewsText: '42 Profile views (last 12 months)',
  ProfileViewsString: {
    Value: 'Your profile has been viewed <strong>42</strong> times in the last 12 months'
  },
  displayName: 'Dr. Mark Test IV',
  IncludePatientExperience: true,
  IncludeOnlineAppointments: true,
  OasMmpLink:
    'http://update-testaws.healthgrades.com/account/provider-oas?token=128017100121173050177218234164055118240000210091082147050170160247159148164017245103118036207145226135219140241003233239078174040000139098152236',
  PatientExperience: {
    SurveyCount: 1,
    SurveyScore: 5,
    RatingClass: 'fill-to-10',
    ButtonText: 'View Patient Reviews',
    PatientExperienceLink: '/patientexperience/reviews/2xxds'
  },
  ProfessionalType: 2,
  Content: {
    SpecialtyContent:
      'Help patients locate you via search. List all branches of medicine in which you actively practice, both specialties and sub-specialties. If you list more than one, select the main specialty you practice as your primary specialty.  At least one specialty is required.',
    SpecialtyNote:
      'You may delete your current primary specialty if you first select another specialty as primary.',
    ConditionContent: 'Patients and physicians search conditions. Select conditions you treat.',
    ProcedureContent: 'Patients and physicians search procedures. Select procedures you perform.',
    InsuranceContent:
      'List the insurance carriers you accept. Patients filter by insurance carrier. Keep your list up to date.',
    AffiliatedHospitalContent: 'Include all hospitals where you actively admit and write orders.',
    AcceptingNewPatientsContent:
      'If you are not accepting new patients at this time, please indicate that here.  Your profile will still be available for the benefit of existing patients, but it will show you are not accepting new patients.',
    AvailabilityContent:
      'Tell patients about your availability. Your availability will be applied to all of your locations.',
    LanguageContent: 'List languages in which you can effectively communicate with patients.',
    TelehealthServiceContent:
      'Indicate whether or not you’d like to display a Telehealth Badge on your profile. If applicable, provide additional information to enable viewers to access your telehealth offerings.',
    EducationContent:
      'List schools, degrees, institutions, state licenses or accredited hospitals where you completed additional education.',
    BoardCertificationContent:
      'List all active board certifications, choosing from the list of certifying agencies that Healthgrades currently supports.',
    DegreeContent:
      'Provide the academic degree or certification you have achieved that you consider most important to show potential patients and other providers. We can only accept one degree at this time.',
    StateLicenseContent:
      'List states &amp; U.S. territories where you currently hold an active, professional license to provide care.',
    BiographyContent:
      'Your biography appears at the top of your profile.  Tell patients &amp; referring physicians what is most important about you.  Information you might want to share could include: why you became a doctor, your clinical background and experience, or your awards and recognition.',
    CarePhilosophyContent:
      'Describe your approach to treating &amp; caring for patients.  Information you might want to share include: how you support a patient’s decision about their treatment plan, how you listen and value a patient’s input, how you communicate, or how you educate and encourage patients to be involved in all aspects of their care.',
    ProcedureStatementContent:
      'Describe what is unique about your expertise in the procedures you perform. Information you might share in this section could include: specific training or credentials, volume and outcomes of procedures you perform, or specific patient populations for whom you provide treatment.',
    ConditionStatementContent: 'This field is not currently used.',
    PesStatementContent:
      'You may post a general message that will appear alongside your Patient Survey scores.',
    CrowdSourceContent:
      'These questions appear on your profile in the “Help Improve Healthgrades” section and your patients are able to respond. Your response below will override the public responses.',
    ProfileVideoContent:
      'You can add a link of your video from sites like youtube or upload the video from your computer. Approved videos will be processed and displayed on your profile at healthgrades.com.',
    ProfileBrandingContent: 'Branding Content',
    ProfileAssociationContent: 'Profile User Association Content',
    SectionDisabled:
      'Editing is disabled for this section at the moment, please check back after couple of days!'
  },
  NavigationModel: {
    PageType: 2,
    CurrentPage: 'profile',
    UserIsProvider: false,
    UserIsAdmin: true,
    UserIsClientAdmin: false,
    ProviderCount: 47,
    ProviderId: '2xxds',
    SubNav: {
      MyProfile: [
        {
          ScrollValue: '#general-info',
          NavName: 'Basic Information',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#specialty',
          NavName: 'Specialties',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#insurance',
          NavName: 'Insurance',
          ShowIndicator: true,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#patient-experience',
          NavName: 'Response to Patient Surveys',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#practice-locations',
          NavName: 'Practice & Office Locations',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#telehealth',
          NavName: 'Telehealth',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#procedures-performed',
          NavName: 'Procedures Performed',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#conditions',
          NavName: 'Conditions Treated',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#hospitals',
          NavName: 'Hospital Affiliations',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#availability',
          NavName: 'Appointment Availability',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#education',
          NavName: 'Education',
          ShowIndicator: true,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#credentials',
          NavName: 'Credentials',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#languages',
          NavName: 'Languages Spoken',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '#online-appointments',
          NavName: 'Online Appointments',
          ShowIndicator: false,
          IndicatorValue: 0
        }
      ],
      PatientExperience: [
        {
          ScrollValue: '/patientexperience/reviews/',
          NavName: 'Patient Reviews',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '/patientexperience/analytics/',
          NavName: 'Analytics',
          ShowIndicator: false,
          IndicatorValue: 0
        },
        {
          ScrollValue: '/patientexperience/resources/',
          NavName: 'Resources',
          ShowIndicator: false,
          IndicatorValue: 0
        }
      ]
    },
    PesPagesOn: true,
    SponsoredUser: true,
    BetaMode: false,
    OptOutUrl: null,
    BetaSignOutUrl: 'http://update-testaws.healthgrades.com',
    KnowledgeOwlOn: false,
    NewCommentsCount: 0,
    ShowPracticeRoster: true,
    HasSponsorship: false,
    SponsorCode: 'ARIAHLT',
    HasProviderReporting: false,
    ProfileViewsText: null,
    ProfileViewsString: null,
    FirstName: 'Dinakaran',
    LastName: 'G',
    DisplayName: 'Dinakaran G',
    ImageUrl: '//d1ffafozi03i4l.cloudfront.net/img/prov/2/x/x/2xxds_w120h160_vS11jrPvkc.jpg',
    IsApplicableForPremium: false,
    HasEnhancedSubcription: false,
    HasPremiumSubcription: false,
    PremiumSiteURL: 'http://selfservetest.healthgrades.com/',
    ProviderEmail: 'dg@healthgrades.com',
    ShowChatBot: false,
    DesignationType: 1
  },
  NavigationJson:
    '{"PageType":2,"CurrentPage":"profile","UserIsProvider":false,"UserIsAdmin":true,"UserIsClientAdmin":false,"ProviderCount":47,"ProviderId":"2xxds","SubNav":{"MyProfile":[{"ScrollValue":"#general-info","NavName":"Basic Information","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#specialty","NavName":"Specialties","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#insurance","NavName":"Insurance","ShowIndicator":true,"IndicatorValue":0},{"ScrollValue":"#patient-experience","NavName":"Response to Patient Surveys","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#practice-locations","NavName":"Practice & Office Locations","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#telehealth","NavName":"Telehealth","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#procedures-performed","NavName":"Procedures Performed","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#conditions","NavName":"Conditions Treated","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#hospitals","NavName":"Hospital Affiliations","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#availability","NavName":"Appointment Availability","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#education","NavName":"Education","ShowIndicator":true,"IndicatorValue":0},{"ScrollValue":"#credentials","NavName":"Credentials","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#languages","NavName":"Languages Spoken","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"#online-appointments","NavName":"Online Appointments","ShowIndicator":false,"IndicatorValue":0}],"PatientExperience":[{"ScrollValue":"/patientexperience/reviews/","NavName":"Patient Reviews","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"/patientexperience/analytics/","NavName":"Analytics","ShowIndicator":false,"IndicatorValue":0},{"ScrollValue":"/patientexperience/resources/","NavName":"Resources","ShowIndicator":false,"IndicatorValue":0}]},"PesPagesOn":true,"SponsoredUser":true,"BetaMode":false,"OptOutUrl":null,"BetaSignOutUrl":"http://update-testaws.healthgrades.com","KnowledgeOwlOn":false,"NewCommentsCount":0,"ShowPracticeRoster":true,"HasSponsorship":false,"SponsorCode":"ARIAHLT","HasProviderReporting":false,"ProfileViewsText":null,"ProfileViewsString":null,"FirstName":"Dinakaran","LastName":"G","DisplayName":"Dinakaran G","ImageUrl":"//d1ffafozi03i4l.cloudfront.net/img/prov/2/x/x/2xxds_w120h160_vS11jrPvkc.jpg","IsApplicableForPremium":false,"HasEnhancedSubcription":false,"HasPremiumSubcription":false,"PremiumSiteURL":"http://selfservetest.healthgrades.com/","ProviderEmail":"dg@healthgrades.com","ShowChatBot":false,"DesignationType":1}',
  RedirectUrl: null,
  PageTracking: {
    Account: 'hgspadev',
    PageName: 'provider: edit',
    Channel: 'edit',
    CampaignId: null,
    Server: 'hgmd: desktop',
    ContextData: {
      'hg.VisitorID': '2551298f-513c-4194-866e-7e21d0761b15',
      'hg.VisitorType': 'practice administrator',
      'hg.VisitorStatus': 'authenticated',
      'hg.AuthorizationStatus': 'authorized',
      'hg.Login': '1',
      'hg.ProfileID': '2xxds',
      'hg.ClientID': 'ariahlt',
      'hg.Specialty': 'ps328',
      'hg.RollupSpecialtyID': 'gdnt'
    }
  },
  FullStoryData: {
    IncludeFullStory: false,
    UseIdentity: true,
    UserId: '2551298f-513c-4194-866e-7e21d0761b15',
    UserEmail: 'dg@healthgrades.com'
  },
  SignOutModel: {
    BetaMode: false,
    OptOutUrl: null,
    BetaSignOutUrl: null
  },
  PrimarySpecialtyGroupCode: 'GDNT',
  PrimarySpecialtyCode: 'PS328',
  PrimarySpecialtyLegacyId: '92',
  PrimaryOfficeCityState: 'Ft Lauderdale, FL',
  SponsorCode: 'ARIAHLT',
  Email: 'dg@healthgrades.com',
  HasVideo: true,
  ProfileHeader: 'Provider',
  SessionTimeout: 3480000,
  HasImpersonate: false,
  HasRosterImpersonate: false,
  UserId: '2551298f-513c-4194-866e-7e21d0761b15',
  NationalAdLidsAndSponsorship: {
    response: {
      numFound: 1,
      start: 0,
      docs: [
        {
          has_national_ad_xml: false,
          national_ad_xml_json: null,
          has_sponsorship_xml: false,
          sponsor_code: null,
          sponsorship_xml_json: null
        }
      ]
    }
  },
  SponsorshipJson: null,
  UserAssociationInformationJson:
    '{"ProviderId":"2XXDS","UserCount":29,"Users":[{"Id":"9a851da9-76f6-403d-87f6-034d9196bf86","FirstName":"MAP","LastName":"Test3","UserName":"maptest3@hgweb.com","CreatedDate":"06/10/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"b80ddba1-6930-4526-9413-133744ce89df","FirstName":"Stephen","LastName":"Laughlin","UserName":"slaughlin@healthgrades.com","CreatedDate":"07/07/2020","UserType":"Roster Manager","IsActive":"True"},{"Id":"e4f7a7fd-8055-4a86-a9b8-30d1f31434f1","FirstName":"Mark","LastName":"Test 11","UserName":"abczz@hgweb.com","CreatedDate":"07/31/2022","UserType":"Provider","IsActive":"True"},{"Id":"4e468628-50b8-4006-ade2-3496bc047936","FirstName":"x","LastName":"x","UserName":"markolsanabc@hgweb.com","CreatedDate":"08/11/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"0f262cbc-ed5a-4318-bf4c-3704c696b50c","FirstName":"Mani","LastName":"Ramamoorthy","UserName":"smani","CreatedDate":"06/16/2020","UserType":"Roster Manager","IsActive":"True"},{"Id":"a2753244-17fe-4f91-8d8a-432de4a2ca02","FirstName":"Mark","LastName":"Testa","UserName":"tvk0@healthgrades.com","CreatedDate":"08/30/2017","UserType":"Provider","IsActive":"True"},{"Id":"cdc3e1f1-91ce-4c74-870a-499d51fa366f","FirstName":"x","LastName":"x","UserName":"'HgSans'@hgweb.com","CreatedDate":"08/23/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"5fcafae8-251d-43da-bb74-4bfe113eadb5","FirstName":"Mark","LastName":"Test","UserName":"marktest@hgweb.com","CreatedDate":"08/24/2022","UserType":"Provider","IsActive":"True"},{"Id":"da676821-37de-4609-aedd-58946abfba95","FirstName":"Annie","LastName":"Foreman","UserName":"apforma@hendricks.org","CreatedDate":"07/20/2017","UserType":"Roster Manager","IsActive":"True"},{"Id":"80c287ff-63e1-497b-b2f2-59c88546fccc","FirstName":"RoleTest","LastName":"Automation","UserName":"RoleTest@hgweb.com","CreatedDate":"06/06/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"e913c990-8f2b-4d90-a11a-6acade631071","FirstName":"Job","LastName":"Abraham","UserName":"SCNETI\\\\job.abraham","CreatedDate":"05/14/2015","UserType":"Roster Manager","IsActive":"True"},{"Id":"8e18b45a-29ac-4659-9671-6cd192c4d439","FirstName":"Nicolle","LastName":"Barnes","UserName":"SCNETI\\\\nicolle.barnes","CreatedDate":"05/14/2015","UserType":"Roster Manager","IsActive":"True"},{"Id":"81027aac-71bb-40df-b658-6d1ccfd235f2","FirstName":"ProviderRole","LastName":"Test","UserName":"ProviderRoleTest@hgweb.com","CreatedDate":"05/05/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"1a0bf6ab-b8f6-48f0-8085-7a5e3b5d06f3","FirstName":"Alexis","LastName":"Johnson","UserName":"alexis.johnson@mclaren.org","CreatedDate":"12/07/2018","UserType":"Roster Manager","IsActive":"True"},{"Id":"ec0923b9-e5f7-4a88-aaee-7c7a768a3592","FirstName":"Mark","LastName":"Test","UserName":"aldo3@hgweb.com","CreatedDate":"07/30/2022","UserType":"Provider","IsActive":"True"},{"Id":"2551298f-513c-4194-866e-7e21d0761b15","FirstName":"Dinakaran","LastName":"G","UserName":"SCNETI\\\\dg","CreatedDate":"06/07/2021","UserType":"Roster Manager","IsActive":"True"},{"Id":"1e51c5db-e882-460d-9229-8fa1c49f82b8","FirstName":"Mark","LastName":"Testa","UserName":"tvk304@healthgrades.com","CreatedDate":"08/31/2017","UserType":"Provider","IsActive":"True"},{"Id":"7b5bfae1-727a-4f01-b250-9929aebf276b","FirstName":"Lorna","LastName":"Gordon","UserName":"SCNETI\\\\lorna.gordon","CreatedDate":"05/14/2015","UserType":"Roster Manager","IsActive":"True"},{"Id":"8981fd8a-329d-40b1-8b63-9d1871f6e35d","FirstName":"Rutuja","LastName":"Test","UserName":"rutuja@hgweb.com","CreatedDate":"04/13/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"f54c981d-5922-4075-a403-a9a73469b71d","FirstName":"Mark","LastName":"Test 11","UserName":"abcz1@hgweb.com","CreatedDate":"08/01/2022","UserType":"Provider","IsActive":"True"},{"Id":"f09ec60a-f2f1-45f1-b56a-acd6a5d7bb46","FirstName":"Mark","LastName":"Test 11","UserName":"abcqq@hgweb.com","CreatedDate":"07/31/2022","UserType":"Provider","IsActive":"True"},{"Id":"4ccc6872-b86a-4477-b73d-ba3589218b3d","FirstName":"UCMS","LastName":"test","UserName":"ucmstest@hgweb.com","CreatedDate":"07/21/2020","UserType":"Roster Manager","IsActive":"True"},{"Id":"9ab5804b-00d2-4619-90c6-bc2e6706553b","FirstName":"x","LastName":"x","UserName":"markolsanabc123@hgweb.com","CreatedDate":"08/12/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"27a11136-e63c-491a-a8d6-bcf49bde8a21","FirstName":"Aastha","LastName":"Test","UserName":"","CreatedDate":"04/21/2022","UserType":"Roster Manager","IsActive":"False"},{"Id":"922acf43-d515-4d10-8ef8-c11e45dd3b56","FirstName":"Test","LastName":"Roster","UserName":"TestRoster@hgweb.com","CreatedDate":"05/31/2022","UserType":"Roster Manager","IsActive":"True"},{"Id":"6209b5d7-fb23-4746-831f-c123a01374c6","FirstName":"Mark","LastName":"Test","UserName":"updatemark@hgweb.com","CreatedDate":"08/24/2022","UserType":"Provider","IsActive":"True"},{"Id":"b8538dc5-c9b7-400e-bafb-c2b604b48861","FirstName":"Mark","LastName":"Test 11","UserName":"aiibc@hgweb.com","CreatedDate":"07/31/2022","UserType":"Provider","IsActive":"True"},{"Id":"68f22708-2ba1-4458-bb07-d5a731307b46","FirstName":"Laronza","LastName":"Scott","UserName":"SCNETI\\\\laronza.scott","CreatedDate":"05/14/2015","UserType":"Roster Manager","IsActive":"True"},{"Id":"6195f17a-a0df-4a3d-8711-dd4820ab6b6c","FirstName":"Mark","LastName":"Test","UserName":"markabcd@hgweb.com","CreatedDate":"08/23/2022","UserType":"Provider","IsActive":"True"}]}',
  PrimaryOfficeAddress: '1309 S Federal Hwy , # 200 Ft Lauderdale, FL 33316',
  Navigations: [
    {
      Id: -1,
      ParentId: -1,
      Name: 'Healthgrades News Feeds',
      Url: '',
      IsExternal: true,
      IconClass: '',
      Order: 0,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 11,
      ParentId: 11,
      Name: 'Support Portal',
      Url: '/admin/index',
      IsExternal: false,
      IconClass: '',
      Order: 3,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 12,
      ParentId: 12,
      Name: 'Audits',
      Url: '/audit/index',
      IsExternal: false,
      IconClass: '',
      Order: 4,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 1,
      ParentId: 1,
      Name: 'Providers',
      Url: '/roster',
      IsExternal: false,
      IconClass: '',
      Order: 5,
      IsActive: false,
      SubMenu: []
    },
    {
      Id: 14,
      ParentId: 14,
      Name: 'My Tools',
      Url: '',
      IsExternal: false,
      IconClass: '',
      Order: 6,
      IsActive: false,
      SubMenu: [
        {
          Id: 1,
          ParentId: 14,
          Name: 'Help Center',
          Url: 'https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center',
          IsExternal: true,
          IconClass: '',
          Order: 0,
          IsActive: false
        }
      ]
    },
    {
      Id: 6,
      ParentId: 6,
      Name: 'Patient Experience',
      Url: '',
      IsExternal: false,
      IconClass: '',
      Order: 7,
      IsActive: false,
      SubMenu: [
        {
          Id: 0,
          ParentId: 6,
          Name: 'Patient Reviews',
          Url: '/patientexperience/Reviews/2xxds',
          IsExternal: false,
          IconClass: '',
          Order: 0,
          IsActive: false
        },
        {
          Id: 1,
          ParentId: 6,
          Name: 'Analytics',
          Url: '/patientexperience/Analytics/2xxds',
          IsExternal: false,
          IconClass: '',
          Order: 1,
          IsActive: false
        },
        {
          Id: 2,
          ParentId: 6,
          Name: 'Resources',
          Url: '/patientexperience/Resources/2xxds',
          IsExternal: false,
          IconClass: '',
          Order: 2,
          IsActive: false
        }
      ]
    },
    {
      Id: 8,
      ParentId: 8,
      Name: 'Setting',
      Url: '#',
      IsExternal: false,
      IconClass: '',
      Order: 9,
      IsActive: false,
      SubMenu: [
        {
          Id: 4,
          ParentId: 8,
          Name: 'Add Providers',
          Url: '#',
          IsExternal: false,
          IconClass: '',
          Order: 4,
          IsActive: false
        },
        {
          Id: 5,
          ParentId: 8,
          Name: 'Practices',
          Url: '/practice/roster',
          IsExternal: false,
          IconClass: '',
          Order: 5,
          IsActive: false
        },
        {
          Id: 7,
          ParentId: 8,
          Name: 'My Account Settings',
          Url: '/account/settings',
          IsExternal: false,
          IconClass: '',
          Order: 7,
          IsActive: false
        },
        {
          Id: 8,
          ParentId: 8,
          Name: 'Change Password',
          Url: '/account/ChangePassword',
          IsExternal: false,
          IconClass: '',
          Order: 8,
          IsActive: false
        },
        {
          Id: 9,
          ParentId: 8,
          Name: 'Sign Out',
          Url: '/account/sign-out',
          IsExternal: false,
          IconClass: '',
          Order: 9,
          IsActive: false
        }
      ]
    }
  ],
  NavigationsJson:
    '[{"Id":-1,"ParentId":-1,"Name":"Healthgrades News Feeds","Url":"","IsExternal":true,"IconClass":"","Order":0,"IsActive":false,"SubMenu":[]},{"Id":11,"ParentId":11,"Name":"Support Portal","Url":"/admin/index","IsExternal":false,"IconClass":"","Order":3,"IsActive":false,"SubMenu":[]},{"Id":12,"ParentId":12,"Name":"Audits","Url":"/audit/index","IsExternal":false,"IconClass":"","Order":4,"IsActive":false,"SubMenu":[]},{"Id":1,"ParentId":1,"Name":"Providers","Url":"/roster","IsExternal":false,"IconClass":"","Order":5,"IsActive":false,"SubMenu":[]},{"Id":14,"ParentId":14,"Name":"My Tools","Url":"","IsExternal":false,"IconClass":"","Order":6,"IsActive":false,"SubMenu":[{"Id":1,"ParentId":14,"Name":"Help Center","Url":"https://helpcenter.healthgrades.com/help?utm_source=hgmd&utm_medium=footer&utm_campaign=help-center","IsExternal":true,"IconClass":"","Order":0,"IsActive":false}]},{"Id":6,"ParentId":6,"Name":"Patient Experience","Url":"","IsExternal":false,"IconClass":"","Order":7,"IsActive":false,"SubMenu":[{"Id":0,"ParentId":6,"Name":"Patient Reviews","Url":"/patientexperience/Reviews/2xxds","IsExternal":false,"IconClass":"","Order":0,"IsActive":false},{"Id":1,"ParentId":6,"Name":"Analytics","Url":"/patientexperience/Analytics/2xxds","IsExternal":false,"IconClass":"","Order":1,"IsActive":false},{"Id":2,"ParentId":6,"Name":"Resources","Url":"/patientexperience/Resources/2xxds","IsExternal":false,"IconClass":"","Order":2,"IsActive":false}]},{"Id":8,"ParentId":8,"Name":"Setting","Url":"#","IsExternal":false,"IconClass":"","Order":9,"IsActive":false,"SubMenu":[{"Id":4,"ParentId":8,"Name":"Add Providers","Url":"#","IsExternal":false,"IconClass":"","Order":4,"IsActive":false},{"Id":5,"ParentId":8,"Name":"Practices","Url":"/practice/roster","IsExternal":false,"IconClass":"","Order":5,"IsActive":false},{"Id":7,"ParentId":8,"Name":"My Account Settings","Url":"/account/settings","IsExternal":false,"IconClass":"","Order":7,"IsActive":false},{"Id":8,"ParentId":8,"Name":"Change Password","Url":"/account/ChangePassword","IsExternal":false,"IconClass":"","Order":8,"IsActive":false},{"Id":9,"ParentId":8,"Name":"Sign Out","Url":"/account/sign-out","IsExternal":false,"IconClass":"","Order":9,"IsActive":false}]}]'
};
const islanding = true;
const windowDimensions = 1024;
const openDropdown = true;
const dropDownHandler = () => {
  return true;
};
const TabsHandler = () => {
  return true;
};

storiesOf('Provider Profile Edit|Provider Profile', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Provider Profile', () => (
    <ProviderProfile
      providerProfileInfo={providerProfileInfo}
      TabsHandler={TabsHandler}
      dropDownHandler={dropDownHandler}
      islanding={islanding}
      windowDimensions={windowDimensions}
      openDropdown={openDropdown}
    />
  ));
