import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

//import support file
import * as actions from '../../store/actions';

//import supported components
import './ForgotPasswordForm.less';
import isEmpty from '../../utils/validation/isEmpty';
import Spinner from '../Spinner/Spinner';
import TextValidation from '../../utils/validation/isTextValid';
import { HG3Tracker } from '../../utils/tracking';

//import img
import emailSent from '../../assets/images/ForgotPassword/SentEmail.png';
import notification from '../../assets/images/ForgotPassword/notification-circle.png';

//import joycomponenta
import EmailInput from '@hg/joy/src/components/formElements/EmailInput';
import Button from '@hg/joy/src/components/Button';

const ForgotPassword = (props) => {
  const { forgotPasswordInfo } = useSelector((state) => state.loadForgotPassword);

  const [_isSentMail, setIsSentMail] = useState(false);
  const [_isError, setIsError] = useState(false);
  const [emailUser, setEmailUser] = useState('');
  const [_msgError, setMsgError] = useState('');
  const [_isValidEmail, setIsValidEmail] = useState(true);
  const [_req, setReq] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);

  const dispatch = useDispatch();

  const onInputChangeHandler = (userEmailId) => {
    if (!isEmpty(userEmailId)) {
      setReq(false);
      setEmailUser(userEmailId);
      validateInput(userEmailId);
    } else {
      setReq(true);
      setEmailUser('');
    }
  };

  const validateInput = (userId) => {
    var checkValidateEmail = TextValidation(userId, 'emailaddress');
    if (!checkValidateEmail.isValid) {
      setIsValidEmail(false);
    } else {
      setIsValidEmail(true);
    }
  };

  const onClickHandler = () => {
    if (_isValidEmail) {
      HG3Tracker.OmnitureTrackLink('forgotPassword');
      setShowSpinner(true);
      dispatch(actions.forgotPasswordConfirm(emailUser, setShowSpinner));
    }
  };

  const handleKeyPress = (e) => {
    let code = e.keyCode || e.which;
    if (code === 13) {
      e.preventDefault();
      onClickHandler(e);
    }
  };

  useEffect(() => {
    if (
      !isEmpty(forgotPasswordInfo.ErrorMessage) ||
      !isEmpty(forgotPasswordInfo.HasError) ||
      !isEmpty(forgotPasswordInfo.EmailSent) ||
      !isEmpty(forgotPasswordInfo.UserEmail)
    ) {
      setMsgError(forgotPasswordInfo.ErrorMessage);
      setIsSentMail(forgotPasswordInfo.EmailSent);
      setIsError(forgotPasswordInfo.HasError);
      onInputChangeHandler(forgotPasswordInfo.UserEmail);
    }
  }, [forgotPasswordInfo]);

  return (
    <div className={_isSentMail ? 'email-confirm-main' : 'forgot-password-main'}>
      {!_isSentMail ? (
        <div className={_isError ? 'forgot-password-error-box' : 'forgot-password-success-box'}>
          <div className='form-header'>
            <span className='form-label'>Forgot Your Password?</span>
          </div>
          {_isError && (
            <div className='forgot-error-message'>
              <img className='notification-symbol' src={notification} alt='one' /> {_msgError}
            </div>
          )}
          <div className='form-label-box'>
            <div className='form-label'>
              Enter your email below and we'll email you a link to reset your password.
            </div>
          </div>
          <div className='user-email'>
            <EmailInput
              name='user-email'
              placeholder='Enter your email'
              id='email'
              type='email'
              label='Enter Email'
              value={!isEmpty(emailUser) ? emailUser : ''}
              valid={_isValidEmail}
              required={_req}
              validating={true}
              onChange={(name, value) => onInputChangeHandler(value)}
              requiredErrorMessage={'Email is required'}
              invalidErrorMessage={'Please enter a valid email address'}
              onKeyPress={(e) => handleKeyPress(e)}
            />
          </div>
          <div className='form-button-box'>
            <Button
              text='Continue'
              id='primary-button'
              onClick={onClickHandler}
              className='form-button'
            />
          </div>
          <div className='contact-us'>
            <p>
              Please{' '}
              <a href='/contactus' target='_blank' rel='noreferrer'>
                <u>contact us</u>
              </a>{' '}
              if you need assistance.</p>
          </div>
          <>{showSpinner && <Spinner />}</>
        </div>
      ) : (
        <div className='email-confirmation-form-box'>
          <img className='forgot-image' src={emailSent} alt='one' />
          <div className='form-header'>
            <span className='form-label'>Password reset email sent</span>
          </div>
          <div className='form-label-box'>
            <div className='form-label'>
              If you don't see the email in your inbox after a few minutes check you spam or junk
              folder.
            </div>
          </div>
          <div className='contact-us'>
            Please{' '}
            <a href='/contactus' target='_blank' rel='noreferrer'>
              <u>contact us</u>
            </a>{' '}
            if you need assistance.
          </div>
        </div>
      )}
    </div>
  );
};
export default ForgotPassword;
