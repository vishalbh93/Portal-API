import React from "react";
// import ForgotPassword from "../ForgotPasswordForm";
import AdminStore from "../../../../.storybook/store";
import { storiesOf } from "@storybook/react";
import Index from "../Index";
// const forgotPasswordinfo = {
//   UserEmail : '',
//   EmailSent : false,
//   ErrorMessage : ''
// }
 storiesOf('ForgotPassword', module)
   .addDecorator((story) => <AdminStore story={story()} />)
    .add('ForgotPassword', () => <Index />);