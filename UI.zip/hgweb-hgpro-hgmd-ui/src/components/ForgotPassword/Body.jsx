import React from 'react';
import ForgotPassword from './ForgotPasswordForm';

//stylesheet imports
import './_body.less';

const Body = () => {
  return (
    <>
      <div className='body-section'>
        <div className='body-inner-section'>
          <div className='main-wrapper'>
            <div className='login-form-section login-form-mobile'>
              <ForgotPassword />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Body;
