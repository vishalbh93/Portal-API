import React, { useState, Fragment } from 'react';
// import { useSelector } from 'react-redux';
import './_index.less';

//styling imports
import '@hg/joy/src/globalstyles';

//components imports
import HeroSection from '../Common/HeroSection';
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import Body from './Body';


const Index = (props) => {
  const [currentTab, setCurrentTab] = useState('landing');
  const menuClick = (section) => {
    setCurrentTab(section);
  };
  return (
    <Fragment>
      <MenuComponent menuClick={menuClick} showMenus={false} showClaim={false} showLogin={true} />
      <HeroSection showDoctorImage={false} />
      <Body/>
      <Footer />
    </Fragment>
  );
};

Index.propTypes = {};

export default Index;
