import React, { Fragment, Suspense, lazy } from 'react';
import './_banner.less';
import large from '../../../assets/images/large_hexagon.png';

//helper imports
import isEmpty from '../../../utils/validation/isEmpty';

//component imports
// import ProviderImage from '@hg/joy/src/components/ProviderImage';
// import ProfileEdit from '../MainContent/ProfileEdit';
import { getGenderCode } from '../../../utils/utils';

const ProviderImage = lazy(() => import('@hg/joy/src/components/ProviderImage'));
const ProfileEdit = lazy(() => import('../MainContent/ProfileEdit'))

const Banner = (props) => {
  const {
    providerCode,
    providerDisplayName,
    providerGender,
    profileOverviewPeriod,
    profilePicture,
    profileCompletePercentage,
    windowDimensions
  } = props;

  return (
    <Fragment>
      <div className='banner-container'>
        <div className='banner-inner-container'>
          <div className='herobanner-section'>
            <div className='herobanner-section herobanner-inner-section'>
              <Suspense fallback=''>
                <div className='provider-info'>
                  {/* <img className='provider-profile-picture' src={profilePicture} alt='profileImage' /> */}
                  {!isEmpty(providerDisplayName) && (
                    <ProviderImage
                      providerName={providerDisplayName}
                      providerGender={getGenderCode(providerGender)}
                      src={profilePicture}
                      size='lg'
                      className='provider-profile-picture'
                    />
                  )}
                  <div className='profile-brief'>
                    <div className='profile-brief-name'>Hello {providerDisplayName}</div>
                    <div className='profile-brief-period'>
                      Your Healthgrades Profile Overview <br />
                      <span>Year at a glance ({profileOverviewPeriod})</span>
                    </div>
                  </div>

                  {/* This is related with sponsored -- Once confirmed can be added later  
                    <div className='sponsor-by-container'>
                      <div className='sponsor-by-text'>Your profile is sponsored by</div>
                      <div className='sponsor-logo'>
                        <img className='right-align-sponsor-logo' src={logo} alt='Logo' />
                      </div>
                      <div className='sponsor-name'>
                        <span className='sponsor-name-label'>Metropolitan Regional </span>
                        <span className='sponsor-name-sublabel'>Medical Center</span>
                      </div>
                    </div> */}
                </div>
              </Suspense>
            </div>
            <div className='right-align-large-hexagon'>
              <img src={large} alt='hexagon' />
            </div>
          </div>

          <svg
            className='hero-background-svg'
            data-qa-target='hero-background-svg'
            preserveAspectRatio='none'
            viewBox='0 0 1442 149'>
            <path
              d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
              fill='#F7F7F7'></path>
          </svg>

          <svg
            className='hero-background-svg-mobile'
            data-qa-target='hero-background-svg-mobile'
            preserveAspectRatio='none'
            viewBox='0 0 375 120'>
            <path
              d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
              fill='#F7F7F7'></path>
          </svg>

          {windowDimensions <= 770 && (
            <Suspense fallback=''>
              <ProfileEdit
                providerCode={providerCode}
                profileCompletePercentage={profileCompletePercentage}
              />
            </Suspense>
          )}
        </div>
      </div>
    </Fragment>
  );
};

Banner.propTypes = {};
Banner.defaultProps = {
  providerGender: 'M'
};

export default Banner;
