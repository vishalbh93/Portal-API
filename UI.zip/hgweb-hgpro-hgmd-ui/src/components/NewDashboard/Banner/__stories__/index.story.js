import React from 'react';
import Banner from '../Banner';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../../.storybook/store';

const providerDetails = {
  providerDisplayName: 'Dr. Ciccotelli, MD',
  profileOverviewPeriod: 'January 1 - December 31, 2021'
};

storiesOf('New Dashboard|Banner', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('Banner', () => (
    <Banner {...providerDetails} />
  ));
