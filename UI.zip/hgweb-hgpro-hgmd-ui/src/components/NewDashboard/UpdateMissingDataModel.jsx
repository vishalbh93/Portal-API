import React from 'react';
import PropTypes from 'prop-types';
import LayoutA from '../Common/Layouts/LayoutA';
import ReactModal from 'react-modal';


//Stylesheet impor
import './_updateMissingDataModel.less';

//helper
import _ from 'lodash';

//Media imports
import cross from '../../assets/images/ProviderProfile/Vector.svg';

/* #region Joy Component import */
import Button from '@hg/joy/src/components/Button/Button';

const UpdateMissingDataModel = (props) => {
  const {openModel, officeData, specialtyData, providerCode} = props;


  const onCloseHandler = () => {
      props.closeModal();
    };
  
  const onClickUpdateHandler = (valueFlag) =>{
    let userCode = !_.isEmpty(providerCode)? providerCode : window.location.href.split('/').slice(-1);
    window.location.href = `${window.location.origin}/provider/profile/${userCode}${valueFlag == 'specialty'?'#specialties':'#offices'}`;
  };

  return (
    <>
    <LayoutA>
      <ReactModal
        overlayClassName='roster-modal-overlay missing-fields-modal-popup'
        className='modal-dialog'
        ariaHideApp={false}
        isOpen={openModel}
        contentLabel='hospital-model'
        onRequestClose={onCloseHandler}
        shouldCloseOnOverlayClick={false}>
        <div className='model-window-section'>
          <div className='model-container'>
            <div className='close'>
              <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
            </div>
            <div className='modal-row'>
              <div className='model-title'>
                <div className='header'>Update Missing Data</div>
              </div>
              <div className='main-container'>
                <div className='message-display'>
                  <span className='notification-msg'>{`Due to missing data that is required, your profile is not able to be shown on Healthgrades.com. Please update 
                  your [${officeData ?' address' : ''} ${officeData && specialtyData ? 'and' : ''} ${specialtyData? 'specialty ' : ''}] to resolve this issue.`}</span>
                </div>
              </div>
              <div className='button-section'>
                {officeData &&
                  <Button
                      id='btn-office'
                      text={`Update Address`}
                      className={`${specialtyData?'btn-update':'btn-update btn-resize'}`}
                      size='lg'
                      style='ghost'
                      onClick={() =>onClickUpdateHandler('office')}
                    />
                }
                {specialtyData && 
                  <Button
                      id='btn-refer-provider'
                      text={`Update Specialty`}
                      className={`${officeData?'btn-update':'btn-update btn-resize'}`}
                      size='lg'
                      style='ghost'
                      onClick={() => onClickUpdateHandler('specialty')}
                    />
                }
              </div>
            </div>
          </div>
        </div>
      </ReactModal>
    </LayoutA>
    </>
  );
};
UpdateMissingDataModel.propTypes = {
  openModel: PropTypes.bool,
  officeData: PropTypes.bool,
  specialtyData: PropTypes.bool,
  providerCode: PropTypes.string
};

UpdateMissingDataModel.defaultProps = {
  openModel: false,
  officeData: false,
  specialtyData: false,
  providerCode: ''
};

export default UpdateMissingDataModel;