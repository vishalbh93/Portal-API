import React from 'react';
import { storiesOf } from '@storybook/react';
import AdminStore from '../../../../.storybook/store';
import Index from '../Index';

const providerDetails = {
  results: {
    ProviderCode: '3CR4M',
    ProviderGuidId: '78326d68-3273-0037-0000-000000000000',
    FirstName: 'Michael',
    MiddleName: null,
    LastName: 'Test',
    DisplayName: 'Dr. Michael Test V, DO',
    ProviderImageUrl: '//photos.healthgrades.com/img/prov/3/c/r/3cr4m_w120h160_vSJ6hTeOxK.jpg',
    NationalRank: 62.0,
    StateRank: 77.0,
    StateCode: 'ND',
    StateName: 'North Dakota',
    ProfileViewOneYear: 48,
    NPI: 1790780922,
    PrimarySpecialityGroupId: '544e4447-0000-0000-0000-000000000000',
    ProfileCompletePercentage: 100,
    PatientReviews: 15,
    TotalPatientComments: 3,
    AverageStarRating: 3.1,
    ProfileOverviewPeriod: 'July-2021 - June-2022',
    CurrentYear: 2022,
    MissingFields: {
      photos: true,
      aboutme: true,
      degree: true,
      conditions: true,
      procedures: true,
      insurance: true,
      gender: true,
      dateofbirth: true,
      acceptsnewpatients: true,
      licenses: true,
      offices: true,
      affiliatedhospitals: true,
      education: true
    },
    ProfileCompletedCount: 13,
    PrimarySpecialityName: 'Dentistry'
  }
};
storiesOf('New Dashboard|Dashboard', module)
  .addDecorator((story) => <AdminStore story={story()} />)
  .add('New Dashboard', () => <Index {...providerDetails} />);
