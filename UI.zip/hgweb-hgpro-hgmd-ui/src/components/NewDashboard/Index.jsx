import React, { Fragment, useState, useEffect, Suspense, lazy } from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import Cookies from 'js-cookie';

// stylesheet imports
import './_index.less';
import '@hg/joy/src/globalstyles';

//Components imports
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import Banner from './Banner/Banner';
// import Content from './MainContent/Index';
import Spinner from '../Spinner/Spinner';
import SmartReferralNotification from '../Common/Notifications/SmartReferralNotification';

// import MissingModel from './UpdateMissingDataModel';
import _ from 'lodash';
import ReactModal from 'react-modal';
import { missingFields } from '../../utils/constant-data';
const Content = lazy(() => import('./MainContent/Index'));
const MissingModel = lazy(() => import('./UpdateMissingDataModel'));

import { HG3Tracker } from '../../utils/tracking';

const Index = (props) => {
  const [showSpinner, setShowSpinner] = useState(true);
  const { results, dashboardData } = useSelector((state) => state.getDashboardInfo);

  const [menuItems, setMenuItems] = useState([]);
  const [navigationModelObject, setNavigationModelObject] = useState({});
  const [providerInfo, setProviderInfo] = useState({});
  const [toggleMissingFieldsModel, setToggleMissingFieldsModel] = useState(false);
  const [isOffice, setIsOffice] = useState(false);
  const [isSpecialty, setIsSpecialty] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const missingFieldsInfo = ['offices', 'specialty'];
  const menuClick = (section) => {
    setCurrentTab(section);
  };

  const providerCode = !_.isEmpty(dashboardData.ProviderCode) ? dashboardData.ProviderCode : '';

  // To get width of screen
  const getWindowDimensions = () => {
    const { innerWidth: width, innerHeight: height } = window;
    return width;
  };
  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());
  const closeModel = () => {
    setToggleMissingFieldsModel(false);
  };

  const displayMissingDataModel = () => {
    var missingData = !_.isEmpty(results.MissingFields) ? results.MissingFields : [];
    if (!_.isEmpty(missingData)) {
      var fieldsInfo = Object.keys(missingData).filter((key) => missingData[key] === false);
      var filterData = missingFieldsInfo.filter((x) => fieldsInfo.includes(x));
      if (!_.isEmpty(filterData)) {
        var setOffice = filterData.includes('offices');
        var setSpecialty = filterData.includes('specialty');
        if (setOffice || setSpecialty) {
          setIsOffice(setOffice);
          setIsSpecialty(setSpecialty);
          setToggleMissingFieldsModel(true);
        } else {
          setToggleMissingFieldsModel(false);
        }
      }
    }
  };

  const handleCloseSmartReferralPopup = () => {
    HG3Tracker.OmnitureTrackLink('dashboard|close-referral-popup');
    Cookies.set('Show_Referral_Popup_Cookie', 'false');
    setShowPopup(false);
  };

  const handleMakeReferralPopup = () => {
    Cookies.set('Show_Referral_Popup_Cookie', 'false');
    HG3Tracker.OmnitureTrackLink('dashboard|make-referral-now');
    window.location.href = `${window.location.origin}/providerReferral/index`;
    setShowPopup(false);
  };
  useEffect(() => {
    const handleResize = () => {
      setWindowDimensions(getWindowDimensions());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if ((results != null || results != undefined) && dashboardData != undefined) {
      setMenuItems(dashboardData.Navigations);
      setNavigationModelObject(dashboardData.NavigationModel);
      setProviderInfo(dashboardData.ProviderDetailsJson);
      setShowSpinner(false);
    } else if (Object.keys(results).length === 0) {
      setShowSpinner(true);
    }
    displayMissingDataModel();
  }, [results]);

  useEffect(() => {
    const checkCookie = () => {
      const showReferralCookie = Cookies.get('Show_Referral_Popup_Cookie');
      if (!showReferralCookie || showReferralCookie === 'true') {
        setShowPopup(true);
      } else {
        setShowPopup(false);
      }
    };
    checkCookie();
  }, [showPopup]);

  return (
    <Fragment>
      <div className='Provider-Referral-Popup'>
        <ReactModal
          overlayClassName='roster-modal-overlay'
          className='modal-dialog-affirming'
          ariaHideApp={true}
          isOpen={showPopup}
          contentLabel=''>
          <SmartReferralNotification
            handleCloseSmartReferralPopup={handleCloseSmartReferralPopup}
            handleMakeReferralPopup={handleMakeReferralPopup}></SmartReferralNotification>
        </ReactModal>
      </div>

      <MenuComponent
        menuClick={menuClick}
        showMenus={true}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        providerInfo={
          providerInfo != undefined && Object.keys(providerInfo).length > 0
            ? JSON.parse(providerInfo)
            : {}
        }
      />
      <Banner
        providerCode={!_.isEmpty(results.ProviderCode) ? results.ProviderCode : providerCode}
        providerDisplayName={results.DisplayName}
        providerGender={results.Gender}
        profileOverviewPeriod={results.ProfileOverviewPeriod}
        profilePicture={results.ProviderImageUrl}
        profileCompletePercentage={results.ProfileCompletePercentage}
        windowDimensions={windowDimensions}
      />
      <Suspense fallback=''>
        <Content results={results} providerCode={providerCode} />
      </Suspense>

      <Suspense fallback=''>
        {toggleMissingFieldsModel && (
          <MissingModel
            openModel={toggleMissingFieldsModel}
            closeModal={closeModel}
            officeData={isOffice}
            specialtyData={isSpecialty}
            providerCode={providerCode}
          />
        )}
      </Suspense>
      <Footer />
      {showSpinner && <Spinner cta={true} />}
    </Fragment>
  );
};

Index.propTypes = {};

export default Index;
