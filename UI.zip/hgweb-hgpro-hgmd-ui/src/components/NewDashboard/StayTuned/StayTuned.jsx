import React, { Fragment } from 'react';
import { HG3Tracker } from '../../../utils/tracking';

//Styling import
import './_stayTuned.less';

//Media imports
import Visitors from '../../../assets/images/Dashboard/icon-staytuned.svg';
import RatingIcon from '../../../assets/images/Dashboard/icon-staytuned-rating.svg';
import ConsumerDelayIcon from '../../../assets/images/stay_3.svg';
import GoogleForIcon from '../../../assets/images/stay_1.svg';

const StayTuned = (props) => {
  const redirectToProfile = () => {
    HG3Tracker.OmnitureTrackLink('dashboard|update-your-profile');
    let fullPath = `/provider/profile/${props.providerId}`;
    window.location.href = fullPath;
  };
  return (
    <Fragment>
      <div className='blue-container stay-tuned-container'>
        <div className='blue-inner stay-tuned-inner'>
          <h1>
            <span className='text-inline-accent'>Stay Tuned</span>
          </h1>
          <p>
            As the nation continues to reflect on 2021, and transitions back to life a little more
            like it used to be, here’s a look at what we’re seeing now in consumer behavior and
            traffic to Healthgrades.com
          </p>
          <div className='inner-section'>
            <div className='cols'>
              <img src={Visitors} alt='search' className='icons first-sec' />
              <p className='heading'>
                #1 in Provider Search 200 million annual visitors to healthgrades.com
              </p>
            </div>
            <div className='cols'>
              <img src={RatingIcon} alt='search' className='icons middle-sec' />
              <p className='heading'>9.3 MILLION ratings and reviews</p>
            </div>
            <div className='cols'>
              <img src={ConsumerDelayIcon} alt='search' className='icons middle-sec' />
              <p className='heading head2'>83% of consumers are not delaying treatment.</p>
            </div>
            <div className='cols'>
              <img src={GoogleForIcon} alt='search' className='icons last-sec' />
              <p className='heading'>Top 3 Ranking on Google for physician name searches.</p>
            </div>
          </div>
          <p>
            Healthgrades continues to see dramatic traffic increases week over week. Patients are
            relaizing how important their health is and begining to search for healthcare
            professional once again. View the latest{' '}
            <a
              href='https://b2b.healthgrades.com/insights/blog/healthgrades-patient-confidence-study-shows-highest-consumer-comfort-since-onset-of-covid-19/?tpc=partners'
              target='_blank'
              rel='noreferrer'>
              COVID-19-Patient Consumer Study to learn more.
            </a>
          </p>
          <p>
            Healthgrades commitment to provide trusted information that helps consumers and
            providers make meaningful connections continues to remain at the forefront of our
            mission-now and always.
          </p>
          <h2 className='center-item'>Be Found. Be Seen.</h2>
          <div className='btn-container center-item'>
            <button onClick={() => redirectToProfile()}>Update Your Profile</button>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default StayTuned;
