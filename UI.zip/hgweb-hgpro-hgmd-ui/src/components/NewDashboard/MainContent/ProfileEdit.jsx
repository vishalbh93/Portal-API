import React, { Fragment } from 'react';

// component imports
import { HG3Tracker } from '../../../utils/tracking';
import ellipse from '../../../assets/images/Dashboard/icon-ellipse.svg';
import Gauge from '../Gauge/Gauge';

// style Imports
import './_profileCompare.less';
import './_profileEdit.less';

const ProfileEdit = (props) => {
  const { providerCode, profileCompletePercentage, pendingCount } = props;

  const redirectToProfile = () => {
    HG3Tracker.OmnitureTrackLink('dashboard|update-your-profile');
    let fullPath = `/provider/profile/${providerCode}`;
    window.location.href = fullPath;
  };
  
  return (
    <Fragment>
      <div className='profile-compare-subcontainer  percentage-guage-btn-group-banner '>
        <div className='profile-description'>
          <div className='profile-percentage'>
            <img className='outer-ellipse' src={ellipse} />
            <Gauge
              radius={pendingCount == 0 ? 150.5 : 129.5}
              percent={profileCompletePercentage}
              backgroundColor={'#FFFFFF'}
              font={'64px'}
            />
          </div>
          <button className={`btn update-button`} onClick={() => redirectToProfile()}>
            Edit Profile
          </button>
        </div>
      </div>
    </Fragment>
  );
};

export default ProfileEdit;
