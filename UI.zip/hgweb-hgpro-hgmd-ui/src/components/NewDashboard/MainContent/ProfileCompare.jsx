import React, { Fragment } from 'react';
import PropTypes from 'prop-types';

//Media imports
import tooltip_icon from '../../../assets/images/Dashboard/icon-info-circle.svg';
import nationalRank from '../../../assets/images/Dashboard/icon-award.svg';
import ScrolledHeader from './ScrolledHeader';
import ProfileEdit from './ProfileEdit';

// style Imports
import './_profileCompare.less';

//import components
import ToolTip, { TooltipContent, TooltipTrigger } from '../../Common/ToolTip/Index';
import ProfileStats from '../../Common/ProfileStats/ProfileStats';

const ProfileCompare = (props) => {
  const { results, pendingCount } = props;

  const ordinal = (number) => {
    const english_ordinal_rules = new Intl.PluralRules('en', {
      type: 'ordinal'
    });
    const suffixes = {
      one: 'st',
      two: 'nd',
      few: 'rd',
      other: 'th'
    };
    const suffix = suffixes[english_ordinal_rules.select(number)];
    return suffix;
  };

  return (
    <Fragment>
      <div className='profile-compare-main-container'>
        <div className='profile-title main-title'>How My Profile Compares</div>
        <div className='profile-sub-title'>Profile View Percentile Ranking by Specialty</div>

        <div className={`${pendingCount == 0 ? 'col' : ''}`}>
          <div className='profile-compare-subcontainer national-ranking'>
            <div className='rank'>
              <div className='national-rank-text'>
                National Ranking
                <ToolTip id='shippingInfo'>
                  <TooltipTrigger as='img' imgsrc={tooltip_icon}></TooltipTrigger>
                  <TooltipContent placement='bottom'>
                    <p>
                      The statistic looks at your specialty, and based on profile views, returns a
                      percentile ranking both nationally and by the state in which you practice.
                      Your {results.ProfileViewOneYear} visits place you in the{' '}
                      {results.NationalRank}
                      {ordinal(results.NationalRank)} Percentile for {results.PrimarySpecialityName}{' '}
                      Physicians nationality and place you in the{' '}
                      <span className='tooltip-state-rank'>
                        {results.StateRank}
                        {ordinal(results.StateRank)} Percentile for {results.StateName}
                      </span>
                    </p>
                  </TooltipContent>
                </ToolTip>
              </div>
              <div>
                <img className='goals-card-image' src={nationalRank} alt='icon' />
              </div>
            </div>

            <div className='percentile profile-title'>
              <span>{results.NationalRank}</span>
              {ordinal(results.NationalRank)} Percentile
            </div>

            <div className='state-rank'>
              <span>{results.StateRank}</span>
              {ordinal(results.StateRank)} Percentile for {results.StateName}
            </div>
          </div>
          {pendingCount == 0 && (
            <div className='profile-compare-subcontainer-col-for-edit'>
              <ProfileEdit
                providerCode={results.ProviderCode}
                profileCompletePercentage={results.ProfileCompletePercentage}
                pendingCount={pendingCount}
              />
            </div>
          )}
        </div>

        <div className={`divider ${pendingCount == 0 && 'divider-all-complete'}`}></div>

        <div
          className={`profile-compare-subcontainer ${
            pendingCount == 0 && 'profile-compare-subcontainer-all-complete'
          }`}>
          <ProfileStats results={results} pendingCount={pendingCount} isProfileEdit={false} />
        </div>

        {props.scrolled && <ScrolledHeader results={results} />}
      </div>
    </Fragment>
  );
};

export default ProfileCompare;
