import React, { Fragment } from 'react';

//Media imports
import profileViews from '../../../assets/images/Dashboard/icon-views.svg';
import patientReview from '../../../assets/images/Dashboard/icon-review.svg';
import comments from '../../../assets/images/Dashboard/icon-comment.svg';
import rating from '../../../assets/images/Dashboard/icon-rating.svg';

// style Imports
import './_profileCompare.less';

const ProfileStats = (props) => {
  const { results, pendingCount } = props;

  return (
    <Fragment>
      <div
        className={`profile-compare-subcontainer ${
          pendingCount == 0 && 'profile-compare-subcontainer-all-complete'
        }`}>
        <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
          <span className='image-container'>
            <img className='profile-compare-image' src={profileViews} alt='icon' />
          </span>
          <div className='count-details'>
            <span className='count'>{results.ProfileViewOneYear}</span>
            <span className='count-description'>Profile Views</span>
          </div>
        </div>

        <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
          <span className='image-container'>
            <img className='profile-compare-image' src={patientReview} alt='icon' />
          </span>
          <div className='count-details'>
            <span className='count'>{results.PatientReviews}</span>
            <span className='count-description'>Patient Reviews</span>
          </div>
        </div>

        <div className={`divisions ${pendingCount == 0 && 'divisions-all-complete'}`}>
          <span className='image-container'>
            <img className='profile-compare-image' src={comments} alt='icon' />
          </span>
          <div className='count-details'>
            <span className='count'>{results.TotalPatientComments}</span>
            <span className='count-description'>Patient Comments</span>
          </div>
        </div>

        <div className={`divisions  ${pendingCount == 0 && 'divisions-all-complete'}`}>
          <span className='image-container'>
            <img className='profile-compare-image' src={rating} alt='icon' />
          </span>
          <div className='count-details'>
            <span className='count'>{results.AverageStarRating}</span>
            <span className='count-description'>
              Average Rating <span className='rating-out-of'>(out of 5 stars)</span>
            </span>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default ProfileStats;
