import React, { Fragment } from 'react';

// style Imports
import './_scrolledHeader.less';

const ScrolledHeader = (props) => {
  const { results } = props;

  return (
    <Fragment>
      <div className='scrolled-header-container'>
        <div className='scrolled-outer'>
          <div className='scrolled-inner'>
            <div className='divisions compress-division'>
              <div className='scrolled-count-details'>
                <span className='scrolled-count'>{results.ProfileViewOneYear}</span>
                <span className='scrolled-count-title'>Profile Views</span>
              </div>
            </div>

            <div className='divisions compress-division'>
              <div className='scrolled-count-details'>
                <span className='scrolled-count'>{results.PatientReviews}</span>
                <span className='scrolled-count-title'>Patient Reviews</span>
              </div>
            </div>

            <div className='divisions compress-division'>
              <div className='scrolled-count-details'>
                <span className='scrolled-count'>{results.TotalPatientComments}</span>
                <span className='scrolled-count-title'>Patient Comments</span>
              </div>
            </div>

            <div className='divisions expand-division'>
              <div className='scrolled-count-details'>
                <span className='scrolled-count'>{results.AverageStarRating}</span>
                <span className='scrolled-count-title'>Average Rating out of 5 stars</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default ScrolledHeader;
