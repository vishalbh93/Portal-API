import React, { Fragment } from 'react';

//Media imports
import chat from '../../../assets/images/Dashboard/icon-chat.svg';
import doctorsicon from '../../../assets/images/Dashboard/icon-survey.svg';
import monitor from '../../../assets/images/Dashboard/icon-monitor.svg';

// style Imports
import './_patientEngagementScore.less';

const PatientEngagementScore = (props) => {
  return (
    <Fragment>
      <div className='patient-engagement-score-main-container'>
        <div className='profile-title'>Tips to Increase Patient Engagement Scores</div>
        <div className='tips-container'>
          <div className='card card-space'>
            <img className='patient-engagement-picture' src={chat} alt='icon' />
            <div className='patient-engagement-text'>
              Respond to patient comments (both positive and negative) in a timely and professional
              manner.
            </div>
          </div>
          <div className='card card-space'>
            <img className='patient-engagement-picture' src={doctorsicon} alt='icon' />
            <div className='patient-engagement-text'>Seek feedback from your patients.</div>
            <div className='patient-engagement-text survey-click'>
              <a href={`/patientexperience/reviews/${props.providerId}`} alt={props.providerId}>
                Get the free survey acquisition tools!
              </a>
            </div>
          </div>
          <div className='card'>
            <img className='patient-engagement-picture' src={monitor} alt='icon' />
            <div className='patient-engagement-text'>
              Monitor and review patient comments on a regular Basis.
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default PatientEngagementScore;
