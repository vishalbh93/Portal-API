import React, { Fragment } from 'react';

//components imports
import Gauge from '../Gauge/Gauge';
import { HG3Tracker } from '../../../utils/tracking';
import { missingFields } from '../../../utils/constant-data';
import Cards from '../../Common/PendingTaskCards/Cards';

// style Imports
import './_profileCompletness.less';

const ProfileCompleteness = (props) => {
  const { percentage, providerId, missingProviderFields, profileCompletedCount, providerCode } = props;
  let pendingCount = missingFields.length - (profileCompletedCount-1);

  const redirectToProfile = () => {
    HG3Tracker.OmnitureTrackLink('dashboard|update-your-profile');
    let fullPath = `/provider/profile/${!_.isEmpty(providerId)?providerId: providerCode}`;
    window.location.href = fullPath;
  };

  return (
    <Fragment>
      <div className='profile-completeness-main-container'>
        <div className='profile-title main-title'>Profile Completeness</div>
        <div className='profile-completeness-sub-container'>
          <div className='percentage-guage-btn-group'>
            <div className='profile-description'>
              <div className='profile-percentage'>
                <Gauge
                  radius={150.5}
                  percent={percentage}
                  backgroundColor={'#FFFFFF'}
                  font={'64px'}
                />
              </div>
            </div>
            <button className={`btn update-button`} onClick={() => redirectToProfile()}>
              Update Profile
            </button>
          </div>

          <p className='profile-visit'>
            Complete your pending tasks to increase patient visits. Patients are more likely to book
            an appointment if your profile is complete.
          </p>
        </div>

        <div className='profile-title main-title pending-task'>
          Pending Tasks {`(${pendingCount})`}
        </div>

        <div className='profile-completeness-sub-container pending-task-container'>
          <Cards
            providerId={!_.isEmpty(providerId) ?providerId: providerCode}
            missingProviderFields={missingProviderFields}
            pendingCount={pendingCount}
            isProfileEdit={false}
          />
        </div>
      </div>
    </Fragment>
  );
};
export default ProfileCompleteness;
