import React, { Fragment, useState, useEffect } from 'react';

// components imports
import ProfileCompleteness from './ProfileCompletness';
import ProfileCompare from './ProfileCompare';
import PatientEngagementScore from './PatientEngagementScore';
import StayTuned from '../StayTuned/StayTuned';
import { missingFields } from '../../../utils/constant-data';

// style Imports
import './_index.less';

import small from '../../../assets/images/small_hexagon.png';

const Content = (props) => {
  const { results, providerCode} = props;
  let pendingCount = missingFields.length - results.ProfileCompletedCount;
  const [scrolled, setScrolled] = useState(false);
  let mainClasses = ['profile-compare sub-container-column'];

  if (scrolled) {
    mainClasses.push(pendingCount == 0 ? 'all-complete-profile' : '');
  }

  const handleScroll = () => {
    setTimeout(() => {
      const offset = window.scrollY;
      if (offset >= 850) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    }, 5);
  };

  useEffect(() => {
    setScrolled(scrolled);
  }, [scrolled]);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
  });

  useEffect(() => {
    window.onunload = function () {
      window.scrollTo(0, 0);
    };
  }, []);

  return (
    <Fragment>
      <div className='main-container'>
        <div className='white-container'>
          <div
            className={`white-container-inner main-container-row ${
              pendingCount == 0 ? 'all-complete-profile' : ''
            }`}>
            {pendingCount != 0 && (
              <div className='profile-completeness sub-container-column'>
                <ProfileCompleteness
                  percentage={results.ProfileCompletePercentage}
                  providerId={results.ProviderCode}
                  missingProviderFields={results.MissingFields}
                  profileCompletedCount={results.ProfileCompletedCount}
                  providerCode={providerCode}
                />
              </div>
            )}
            <div className={mainClasses.join(' ')}>
              <ProfileCompare scrolled={scrolled} results={results} pendingCount={pendingCount} />
            </div>
            <div className='right-align-small-hexagon'>
              <img src={small} alt='hexagon' />
            </div>
          </div>

          <div className='white-container-inner main-container-row-eng-score'>
            <PatientEngagementScore providerId={results.ProviderCode} />
          </div>
        </div>
        <StayTuned providerId={results.ProviderCode} />
      </div>
    </Fragment>
  );
};

export default Content;
