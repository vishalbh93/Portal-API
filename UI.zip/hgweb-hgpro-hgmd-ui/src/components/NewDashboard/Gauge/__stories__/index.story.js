import React from 'react';
import Gauge from '../Gauge';
import { storiesOf } from '@storybook/react';

const percent = 50;

storiesOf('Common|NewGauge', module).add('NewGauge', () => (
  <Gauge
    radius={80}
    percent={percent}
    backgroundColor={'#E3E3E3'}
    fillColor={'#74D9E2'}
    font={'36px'}
  />
));
