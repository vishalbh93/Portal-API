import React from 'react';
import './_gauge.less';
import PropTypes from 'prop-types';

const Gauge = (props) => {
  const { radius, percent = 0, fillColor, backgroundColor, font } = props;
  const strokeWidth = radius * 0.12;
  const innerRadius = radius - strokeWidth / 2;
  const circumferenceOuter = innerRadius * 2 * Math.PI;
  const circumference = innerRadius * 0.93 * 2 * Math.PI;
  const arcOuter = circumferenceOuter * (180 / 360);
  const arc = circumference * (180 / 360);
  const dashArrayOuter = `${arcOuter} ${circumferenceOuter}`;
  const dashArray = `${arc} ${circumference}`;
  const transform = `rotate(180, ${radius}, ${radius})`;
  const offset = arc - (percent / 100) * arc;

  return (
    <svg height={radius * 2} width={radius * 2} className='gauge_base'>
      <defs>
        <linearGradient id='linearColors' x1='8%' y1='6%' x2='105%' y2='0%'>
          <stop offset='60%' stopColor='#0202EA' stopOpacity='0.8'></stop>
          <stop offset='100%' stopColor='#6f6fff00' stopOpacity='0.8'></stop>
        </linearGradient>
      </defs>
      <g>
        <circle
          cx={radius}
          cy={radius}
          fill='transparent'
          r={innerRadius}
          stroke='#F7F7F7'
          strokeDasharray={dashArrayOuter}
          strokeWidth={radius * 0.04}
          transform={transform}
          strokeLinecap='round'
          className='outer-circle'
        />
        <circle
          cx={radius}
          cy={radius}
          fill='transparent'
          r={innerRadius * 0.93}
          stroke='url(#linearColors)'
          strokeDasharray={dashArray}
          strokeDashoffset={offset}
          strokeWidth={strokeWidth - 2}
          style={{
            transition: 'stroke-dashoffset 0.3s'
          }}
          transform={transform}
          strokeLinecap='round'
        />
        <text
          x='50%'
          y='37%'
          dominantBaseline='start'
          textAnchor='middle'
          className='percentage'
          fontSize={font}>
          {percent}
          <tspan className='percentage-symbol'>%</tspan>
        </text>
        <text
          x='50%'
          y='48%'
          dominantBaseline='middle'
          textAnchor='middle'
          className='percentage'
          fontSize={font}>
          <tspan className='profile-complete-text'>Profile Complete</tspan>
        </text>
        <rect width='96%' height='2.8%' x='2%' y='51%' className='rectangle' />
      </g>
    </svg>
  );
};

Gauge.propTypes = {
  radius: PropTypes.number,
  percent: PropTypes.number,
  fillColor: PropTypes.string,
  backgroundColor: PropTypes.string,
  font: PropTypes.string
};

export default Gauge;
