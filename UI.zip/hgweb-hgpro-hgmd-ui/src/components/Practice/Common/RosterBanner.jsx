import React from 'react';

/* #region  Stylesheet Imports */
import './_rosterBanner.less';
/* #endregion */

/* #region  Component Imports */
import UpdateNotification from '../../ProviderProfile/UpdateNotification';
/* #endregion */

const RosterBanner = () => {
  return (
    <div id='banner-main-container'>
      <div className='banner-inner-conainer'>
        <svg
          className='background-svg'
          data-qa-target='hero-background-svg'
          preserveAspectRatio='none'
          viewBox='0 0 1442 149'>
          <path
            d='M0 149H1442C1294.8 56 922.421 -33.1384 616.576 36.3702C310.73 105.879 78.0896 49.1638 0 0V149Z'
            fill='#F7F7F7'></path>
        </svg>
        <svg
          className='background-svg-mobile'
          data-qa-target='hero-background-svg-mobile'
          preserveAspectRatio='none'
          viewBox='0 0 375 120'>
          <path
            d='M0.0958797 7.28809C31.3141 43.007 103.471 68.0182 187.5 68.0182C271.528 68.0182 343.685 43.007 374.903 7.28809H375V139.313H0V7.28809H0.0958797Z'
            fill='#F7F7F7'></path>
        </svg>
        <div className='notification-section'>
          <div className='notification-section-inner'>
            <UpdateNotification />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RosterBanner;
