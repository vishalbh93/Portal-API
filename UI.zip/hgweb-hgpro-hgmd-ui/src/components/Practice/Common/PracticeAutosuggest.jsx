import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

import './_practiceAutosuggest.less';

import PracticeCard from '../../ProviderProfile/PracticeAndLocation/PracticeCard';
import PaginationUI from '../../Pagination/Pagination';

/* #region import service */
import { searchV2 } from '../../../utils/serviceCalls/practice';
/* #endregion */

/* #region CONSTANTS */
const SEARCH_RECORDS_PER_PAGE = 10;
const SEARCH_KEYWORD_MIN_LENGTH = 2;
/* #endregion */

const PracticeAutosuggest = (props) => {
  const { setIsSearching, practiceCardProps, triggerFetch } = props;
  const _mainWrapper = useRef(null);

  // const [refreshData, setRefreshData] = useState(false);
  const [currentValue, setCurrentValue] = useState('');
  const [searchedPractices, setSearchedPractices] = useState([]);
  const [isSearchResponseEmpty, setIsSearchResponseEmpty] = useState(false);

  const [totalSearchResultCount, setTotalSearchResultCount] = useState(0);
  const [paginationActivePage, setPaginationActivePage] = useState(1);

  const handleSearchTextChange = (event) => {
    let _value = event.target.value;
    setCurrentValue(_value);
  };

  const handleSearchInputKeyDown = (event) => {
    currentValue.length >= SEARCH_KEYWORD_MIN_LENGTH &&
      event.key === 'Enter' &&
      fetchPracticeCards(1);
  };

  const fetchPracticeCards = (pageIndex = paginationActivePage) => {
    pageIndex = Number.isInteger(pageIndex) ? pageIndex : 1;
    setIsSearching(true);
    let searchTerm = encodeURIComponent(currentValue);
    searchV2(searchTerm, pageIndex - 1, SEARCH_RECORDS_PER_PAGE)
      .then((res) => {
        if (res.status == 200) {
          const { PracticeResults, TotalSearchResultCount } = res.data;
          setSearchedPractices(PracticeResults || []);
          setTotalSearchResultCount(TotalSearchResultCount || 0);
          //setRefreshData(false);
          setPaginationActivePage(pageIndex);
        }
      })
      .catch((err) => {
        //setRefreshData(false);
      });
  };

  const handlePageChange = (pageIndex) => {
    fetchPracticeCards(pageIndex);
  };

  useEffect(() => {
    setIsSearchResponseEmpty(searchedPractices.length === 0 && currentValue.length !== 0);
  }, [searchedPractices]);

  useEffect(() => {
    if (currentValue.length === 0) {
      setIsSearching(false);
      setSearchedPractices([]);
      setTotalSearchResultCount(0);
      setPaginationActivePage(1);
    }
  }, [currentValue]);

  useEffect(() => {
    if (currentValue !== '') fetchPracticeCards(1);
  }, [triggerFetch]);

  // useEffect(() => {
  //   if (refreshData) {
  //     fetchPracticeCards();
  //   }
  // }, [refreshData]);

  // useEffect(() => {
  //   setRefreshData(refreshAgain);
  // }, [refreshAgain]);

  const jsxNoResultsFound = <div>{/* <span>No results found!</span> */}</div>;

  return (
    <>
      <div ref={_mainWrapper} id={`wrapper-div-search-practice`} className={`wrapper-div-search`}>
        <input
          id='input-practice-auto-suggest'
          className='search-input'
          type='text'
          name='input-auto-suggest'
          placeholder='Search by practice name, office name or address'
          onChange={handleSearchTextChange}
          onKeyDown={handleSearchInputKeyDown}
          value={currentValue}
          autoComplete='off'
          disabled={false}
        />
        <button
          className='search-input-icon-space'
          onClick={() => fetchPracticeCards(1)}
          disabled={currentValue.length < SEARCH_KEYWORD_MIN_LENGTH}
          aria-label='search-button'
        />
      </div>
      <div className='searched-practice-card-list'>
        {isSearchResponseEmpty
          ? jsxNoResultsFound
          : searchedPractices.map((prac, index) => (
              <PracticeCard
                practiceData={{...prac, WebSiteUrl: '' }}
                showModalHandler={practiceCardProps.showModalHandler}
                getLocationHourData={practiceCardProps.getLocationHourData}
                removeLocationHandler={practiceCardProps.removeLocationHandler}
                isAdmin={practiceCardProps.isAdmin}
                removePracticeHandler={practiceCardProps.removePracticeHandler}
                lockPracticeEdit={practiceCardProps.lockPracticeEdit}
                practiceLength={searchedPractices.length}
                disableOfficeEdit={practiceCardProps.disableOfficeEdit}
                providerCount={practiceCardProps.providerCount}
                addNewPracticeClickHandler={practiceCardProps.addNewPracticeClickHandler}
                handleMoveLocation={practiceCardProps.handleMoveLocation}
                allowPracticeSearch={practiceCardProps.allowPracticeSearch}
                setSessionPracticeValues={practiceCardProps.setSessionPracticeValues}
                editPracticeSaveClick={practiceCardProps.editPracticeSaveClick}
                fetchPracticeDataByPage={fetchPracticeCards}
                key={index}
                editOnPracticePage={practiceCardProps.lockPracticeEdit}
              />
            ))}
      </div>
      {totalSearchResultCount > SEARCH_RECORDS_PER_PAGE && (
        <PaginationUI
          recordsFound={totalSearchResultCount}
          onPageChange={handlePageChange}
          recordsPerPage={SEARCH_RECORDS_PER_PAGE}
          currentPage={paginationActivePage}
        />
      )}
    </>
  );
};

// PracticeAutosuggest.propTypes = {
//   reloadPracList: PropTypes.func
// };

export default PracticeAutosuggest;
