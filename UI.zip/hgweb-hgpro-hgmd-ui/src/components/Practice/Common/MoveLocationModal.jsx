import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import ReactModal from 'react-modal';
import { useSelector } from 'react-redux';

//Stylesheet import
import './_moveLocationModal.less';

//helper
import isEmpty from '../../../utils/validation/isEmpty';

//Media imports
import cross from '../../../assets/images/ProviderProfile/Vector.svg';
import Cta from '../../Common/Form/CTA/Cta';
import LayoutA from '../../Common/Layouts/LayoutA';

//import service
import * as service from '../../../utils//service';

const MoveLocationModal = (props) => {
  const {
    id,
    isMoveAll,
    title,
    officeObj,
    confirmationText,
    show,
    confirmClickHandler,
    closeModal,
    addNewPracticeClickHandler,
    handleMoveLocation,
    totalObject
  } = props;

  const practiceData = useSelector((state) => state.loadPracticeData);
  const practiceList =
    JSON.parse(practiceData.OfficeJson) != undefined
      ? JSON.parse(practiceData.OfficeJson).PracticeList
      : [];
  let providerCount =
    JSON.parse(practiceData.OfficeJson) != undefined
      ? JSON.parse(practiceData.OfficeJson).ProviderList.length
      : 1;

  let practicesArr =
    JSON.parse(practiceData.OfficeJson) != undefined
      ? JSON.parse(practiceData.OfficeJson).Practices.filter((i) => i.Id != null)
      : {};
  const [practiceAutoSuggestData, setPracticeAutoSuggestData] = useState([]);
  const [showNoResultFoundFor, setNoResultFoundFor] = useState('');
  const [selectedPractice, setSelectedPractice] = useState({});
  const _addPracticeSearch = useRef(null);

  const onSaveClick = (id) => {
    let payload = {};
    if (Object.keys(selectedPractice).length > 0) {
      if (!isMoveAll) {
        let tempPracticeObj = practicesArr.find(
          (practice) => practice.Id.toLowerCase() === selectedPractice.Id.toLowerCase()
        );
        if (tempPracticeObj == undefined) {
          tempPracticeObj = totalObject;
          tempPracticeObj.Id = selectedPractice.Id;
          tempPracticeObj.OriginalId = id;
          tempPracticeObj.Name = selectedPractice.Text;
        }
        payload = {
          ...tempPracticeObj,
          Offices: [{ ...officeObj, UpdateType: 'Change' }]
        };
      } else {
        payload = {
          ...totalObject,
          PracticeCode: null,
          Id: selectedPractice.Id,
          OriginalId: id,
          Name: selectedPractice.Text,
          UpdateType: 'Change'
        };
      }
      let updateType = isMoveAll ? 'practice' : 'office';
      handleMoveLocation(payload, updateType);
    }
    confirmClickHandler(id);
  };

  const onCloseHandler = () => {
    closeModal(id);
  };

  const getPractice = (value) => {
    let searchedPractices = practiceList.filter(
      (i) => i.Id != id && i.Name.toLowerCase().includes(value.toLowerCase())
    );
    let practices = searchedPractices.map((prac) => {
      let officeObj = practicesArr.filter((i) => i.Id === prac.Id);
      return {
        Id: prac.Id.toLowerCase(),
        Text: prac.Name,
        OfficeInfo:
          officeObj.length > 0
            ? officeObj[0].Offices.map((i) => {
                return {
                  Id: i.PracticeId,
                  name: i.Name,
                  address: i.Address,
                  city_state: `${i.City}, ${i.State}  ${i.ZipCode}`,
                  phone: i.Phone,
                  provider_count: !isEmpty(i.Providers) && i.Providers.length,
                  alreadyInList: prac.Id.toLowerCase() === i.PracticeId.toLowerCase()
                };
              })
            : []
      };
    });
    practices.length > 0 ? setNoResultFoundFor('') : setNoResultFoundFor(value);
    return practices;
  };

  const onSearchpracticeHandler = (event) => {
    let { value } = event.target;
    if (value.length > 1) {
      let excludePracticeId = id;
      let url = `/api/practice/search-practice?excludePractice=${excludePracticeId}&term=${value}`;
      if (!isEmpty(practiceData)) {
        service._get(url, false).then((res) => {
          if (res.status == 200) {
            let data =
              res.data.length == 0
                ? getPractice(value)
                : res.data.map((practice) => {
                    return {
                      Id: practice.practice_id.toLowerCase(),
                      Text: practice.item_name,
                      OfficeInfo: practice.office_list_json,
                      alreadyInList:
                        Object.keys(selectedPractice).length > 0 &&
                        selectedPractice.Id.toLowerCase() === practice.practice_id.toLowerCase()
                    };
                  });
            setPracticeAutoSuggestData(data);
          }
        });
      } else {
        let data = getPractice(value);
        setPracticeAutoSuggestData(data);
      }
    } else {
      setPracticeAutoSuggestData([]);
    }
  };

  const handleClickOutside = (event) => {
    if (_addPracticeSearch.current && !_addPracticeSearch.current.contains(event.target)) {
      setPracticeAutoSuggestData([]);
    }
  };

  const onSelectPracticeHandler = (prac) => {
    if (!isEmpty(practicesArr) && Object.keys(prac).length > 0) {
      let tempObj = practiceAutoSuggestData.filter((i) => i.Id.toLowerCase() === prac.Id)[0];
      setSelectedPractice(tempObj);
      setPracticeAutoSuggestData([]);
      document.getElementById('input-auto-suggest-move-location').value = '';
    }
  };

  const removePracticeHandler = () => {
    setSelectedPractice({});
  };

  useEffect(() => {
    practiceAutoSuggestData != undefined && practiceAutoSuggestData.length > 0
      ? document.addEventListener('click', handleClickOutside, true)
      : document.removeEventListener('click', handleClickOutside, true);
  }, [practiceAutoSuggestData]);

  return (
    <LayoutA>
      {show && (
        <ReactModal
          overlayClassName='roster-modal-overlay move-location-ovelay'
          className='modal-dialog'
          ariaHideApp={false}
          isOpen={show}
          contentLabel='move-location-modal'
          onRequestClose={onCloseHandler}
          shouldCloseOnOverlayClick={false}>
          <div className='modal-window-section'>
            <div className='modal-container'>
              <div className='close'>
                <img className='close-icon' src={cross} alt='close' onClick={onCloseHandler} />
              </div>

              <div className='modal-row'>
                <div className='container'>
                  <div className='title'>
                    <span className='main-title-bold'>
                      {isMoveAll
                        ? 'Move all Office Locations from '
                        : title != ''
                        ? 'Move Office Location from '
                        : 'Move Office Location'}
                    </span>
                    {title}
                  </div>

                  {!isMoveAll && (
                    <div className='location-address'>
                      <div className='location-address-line location-address-coloumn1'>
                        {officeObj.Address != null && (
                          <>
                            <span>{officeObj.Name || ''}</span>
                            <span className='span-address-line'>
                              {`${officeObj.Address},${
                                officeObj.Suite != null && officeObj.Suite != ''
                                  ? officeObj.Suite + ','
                                  : ''
                              }`}
                            </span>
                            <span className='span-address-line'>{`${officeObj.City}, ${officeObj.State} ${officeObj.ZipCode}`}</span>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  <div className='modal-body modal-common'>
                    To move all Office Locations, select one of the existing practices available in
                    your list or
                    <button
                      className='add-new-practice-button modal-button'
                      onClick={() => {
                        let obj =
                          !isEmpty(officeObj) && officeObj.Address == undefined
                            ? officeObj
                            : officeObj;
                        addNewPracticeClickHandler(obj, isMoveAll, totalObject);
                        closeModal();
                      }}>
                      Add New Practice
                    </button>
                  </div>

                  <div className='modal-body modal-common'>
                    <input
                      className='search'
                      type='text'
                      placeholder={''}
                      id={`input-auto-suggest-move-location`}
                      onChange={onSearchpracticeHandler}
                      autoComplete='off'
                      disabled={false}></input>

                    {practiceAutoSuggestData != undefined && practiceAutoSuggestData.length > 0 && (
                      <div className='list-wrapper' ref={_addPracticeSearch}>
                        <ul className='list-group'>
                          {practiceAutoSuggestData.map((prac, index) => {
                            return (
                              <li
                                key={index}
                                className='list-item'
                                onClick={() => {
                                  prac.alreadyInList ? null : onSelectPracticeHandler(prac);
                                }}
                                disabled={prac.alreadyInList}>
                                <span className='list-item-text' key={index}>
                                  {prac.Text != undefined ? prac.Text : ''}
                                  {prac.alreadyInList ? <strong> ( already in list )</strong> : ''}
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}

                    {/* {showNoResultFoundFor.length > 0 && (
                      <div className='list-wrapper'>
                        <ul className='list-group'>
                          <li key={showNoResultFoundFor}>
                            <span className='list-item-text'>
                              {`No result found for ${showNoResultFoundFor}`}
                            </span>
                          </li>
                        </ul>
                      </div>
                    )} */}

                    <span>Find Another Practice in Your Roster</span>

                    {Object.keys(selectedPractice).length > 0 && (
                      <div className='modal-common offices-list-main'>
                        <div className='office-name'>
                          <span>{selectedPractice.Text}</span>
                          <button className='modal-button' onClick={removePracticeHandler}>
                            Remove
                          </button>
                        </div>

                        {selectedPractice.OfficeInfo.length > 0 &&
                          selectedPractice.OfficeInfo.map((val, index) => {
                            return (
                              val.address != null && (
                                <li key={`${val.Id}${index}`}>
                                  <div className='offices-list'>
                                    <div className='left-side'>
                                      <span>{`${val.name != null ? val.name : ''}`}</span>
                                      <span>{`${val.address}`}</span>
                                      <span>{`${val.city_state},`}</span>
                                      {val.phone != null && val.phone != '' && (
                                        <span>Phone: {val.phone}</span>
                                      )}
                                    </div>
                                    <div className='right-side'>
                                      {val.provider_count}{' '}
                                      {val.provider_count > 1 ? 'Providers' : 'Provider'}
                                    </div>
                                  </div>
                                </li>
                              )
                            );
                          })}
                      </div>
                    )}
                  </div>

                  <div className='modal-footer modal-common'>
                    <Cta
                      ctaValid={selectedPractice != undefined && !isEmpty(selectedPractice.Id)}
                      cancelText='Cancel'
                      disabled={false}
                      className={`add-new-practice-save ${id}`}
                      cancelClickHandler={(e) => {
                        onCloseHandler();
                      }}
                      confirmText={confirmationText}
                      confirmClickHandler={() => onSaveClick(id)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ReactModal>
      )}
    </LayoutA>
  );
};

MoveLocationModal.defaultProps = {
  officeObj: {},
  addNewPracticeClickHandler: function () {},
  handleMoveLocation: function () {}
};

MoveLocationModal.propTypes = {
  id: PropTypes.string,
  isMoveAll: PropTypes.bool,
  title: PropTypes.string,
  officeObj: PropTypes.object,
  confirmationText: PropTypes.string,
  show: PropTypes.bool,
  confirmClickHandler: PropTypes.func,
  closeModal: PropTypes.func,
  addNewPracticeClickHandler: PropTypes.func,
  handleMoveLocation: PropTypes.func
};

export default MoveLocationModal;
