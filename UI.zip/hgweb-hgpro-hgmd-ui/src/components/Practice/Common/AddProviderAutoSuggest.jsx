import React, { Fragment, useRef } from 'react';

//style
import './_addProviderAutoSuggest.less';

//Component import
import AutoSuggestWithCheckboxList from '../../Common/Form/AutoSuggest/AutoSuggestWithCheckboxList';

const AddProviderAutoSuggest = (props) => {
  const { autosuggestOptions, onShowItemlist, onDeleteitem } = props;
  const _autosuggestList = useRef(null);

  let providersLength = onShowItemlist.filter((list) => list.Checked);

  const checklength = () => {
    return providersLength.length == 1 ? true : false;
  };

  return (
    <div className='search-autosuggest-label' ref={_autosuggestList}>
      <div className='top-text'>{autosuggestOptions.topLabel}</div>
      <div className='search-provider-group'>
        <div className='input-auto-suggest'>
          <AutoSuggestWithCheckboxList
            id={`provider-autosuggest`}
            label=''
            name=''
            placeholder={autosuggestOptions.placeholder}
            initialValue={autosuggestOptions.initialValue}
            data={autosuggestOptions.data}
            onInputChangeHandler={autosuggestOptions.onInputChangeHandler}
            onSuggestSelectHandler={autosuggestOptions.onSuggestSelectHandler}
            setCurrentSelection={autosuggestOptions.setCurrentSelection}
            showValidationMsg={autosuggestOptions.showValidationMsg}
            isSearch={autosuggestOptions.isSearch}
            buttonNames={['Add Providers', 'Clear']}
            onSaveClick={autosuggestOptions.onSaveClick}
            onCancelClick={autosuggestOptions.onCancelClick}
            showList='enable'
            isProviderListInPractice={true}
          />
        </div>
      </div>
      <div className='bottom-text'>{autosuggestOptions.bottomLabel}</div>

      {providersLength.length != 0 && (
        <div className={`${checklength() ? 'provider-single' : 'providers-container'}`}>
          {providersLength.map(
            (provider, ind) =>
              provider.Checked && (
                <Fragment key={ind}>
                  <ul>
                    <li>
                      {provider.Name != undefined ? provider.Name : provider.ProviderName}
                      {provider.IsPrimary ? (
                        <div className='primary-badge-container'>
                          <span id='primary-specialty'> PRIMARY </span>
                        </div>
                      ) : (
                        <button href='#' onClick={() => onDeleteitem(provider)}>
                          Remove
                        </button>
                      )}
                    </li>
                  </ul>
                  {!checklength() ? <hr /> : ''}
                </Fragment>
              )
          )}
        </div>
      )}
    </div>
  );
};

export default AddProviderAutoSuggest;
