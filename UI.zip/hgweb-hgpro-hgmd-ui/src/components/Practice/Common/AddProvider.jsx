import React, { useState, useEffect, useRef, Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
//styles
import './_addProvider.less';

//media
import svgMenuDots from '../../../assets/images/icon-menu-dots.svg';

//import service
import * as service from '../../../utils/service';
import * as actions from '../../../store/actions';
import Toast from '../../Common/Toast/Toast';
import * as trackingService from '../../ProviderProfile/trackingServices';
import { currentPage } from '../../../components/Practice/Utils/Helpers';

//component
import LayoutInfo from '../../Common/Layouts/LayoutInfo';
import DeleteProviderList from '../../Common/Form/ModelPopUp/DeleteProviderList';

//helper
import isEmpty from '../../../utils/validation/isEmpty';
import { PROVIDER_PROFILE_PAGE } from '../Utils/Constants';

const AddProvider = (props) => {
  const {
    associatedProvidersList,
    clickHandler,
    officeObj,
    currentPracticeData,
    fetchPracticeDataByPage
  } = props;

  const practiceData = useSelector((state) => state.loadPracticeData);
  let providersList =
    JSON.parse(practiceData.OfficeJson) != undefined
      ? JSON.parse(practiceData.OfficeJson).ProviderList
      : [];

  const _practiceUserId = practiceData.UserId != undefined ? practiceData.UserId : null;
  const dispatch = useDispatch();
  const [providerAutoSuggestData, setProviderAutoSuggestData] = useState([]);
  const [_associatedProviders, _setAssociatedProviders] = useState(
    associatedProvidersList.map((prov) => ({ ...prov, Selected: false })) || []
  );
  const providerInRoster = providersList != undefined ? providersList.length : 0;
  const associatedProvidersArr = associatedProvidersList.map((i) => i.ProviderId);
  const [showDelete, setShowDelete] = useState('');
  const [showRemoveModalPopUp, setShowRemoveModalPopup] = useState(false);
  const [notifyProperties, setNotifyProperties] = useState([]);
  const [showInput, setShowInput] = useState([]);
  const _sideMenu = useRef(null);
  const _addProviderSearch = useRef(null);

  const onSelectInputSearchHandler = (event) => {
    setShowInput(event.target.value.toLowerCase());
    onSearchProviderHandler(event);
  };

  //event handlers
  const onSearchProviderHandler = (event) => {
    let value = event.target.value.toLowerCase();

    if (value.length > 1) {
      let excludeProviderArr = associatedProvidersArr;
      let userId = practiceData.UserId;
      let url = `/api/roster/search?userId=${userId}`;
      let reqPayload = { term: value, excludeProviders: excludeProviderArr };
      trackingService.editPageTracking('office', 'edit', 'office-providers');
      if (currentPage !== PROVIDER_PROFILE_PAGE) {
        service._post(url, reqPayload, false).then((res) => {
          if (res.status == 200) {
            if (res.data.length > 0) {
              setProviderAutoSuggestData(res.data);
            } else {
              setProviderAutoSuggestData([]);
            }
          } else {
            setProviderAutoSuggestData([]);
          }
        });
      } else {
        let filteredValue = providersList;
        filteredValue = filteredValue.filter((o) =>
          o.Name.toLowerCase().includes(value.toLowerCase())
        );
        setProviderAutoSuggestData(filteredValue);
      }
    } else {
      setProviderAutoSuggestData([]);
    }
  };

  const onSelectHandler = (Provider) => {
    document.getElementById('input-auto-suggest').value = Provider.ProviderName;
    let _updateassociate = '';
    let _temAddProvider = {
      ProviderId: Provider.ProviderId,
      Name: Provider.Name ? Provider.Name : Provider.ProviderName,
      IsPrimary: false,
      IsOasOffice: false,
      IsOnlyLocation: false,
      IsSponsored: Provider.IsSponsored,
      UpdateType: 'New',
      Selected: true
    };
    _updateassociate = _associatedProviders.map((provider) => {
      return provider.Selected === true
        ? { ...provider, Selected: false }
        : { ...provider, Selected: true };
    });
    _updateassociate.push(_temAddProvider);
    getPayloadData(_updateassociate);
    setProviderAutoSuggestData([]);
    if (Provider.ProviderId != null) {
      setShowInput('');
    }
  };

  const checkboxOnChangeHandler = (event) => {
    let tempAssociatedProviders = _associatedProviders.map((provider) => {
      return provider.ProviderId === event.currentTarget.id
        ? { ...provider, Selected: event.currentTarget.checked }
        : { ...provider };
    });
    _setAssociatedProviders(tempAssociatedProviders);
  };

  const handleClickOutside = (event) => {
    if (event.target && event.target.type !== 'checkbox' && !event.target.hasAttribute('href')) {
      if (_sideMenu.current && !_sideMenu.current.contains(event.target)) {
        setShowDelete('');
      }
      if (_addProviderSearch.current && !_addProviderSearch.current.contains(event.target)) {
        setProviderAutoSuggestData([]);
      }
    }
  };

  const fetchPracDataByPage = () => {
    fetchPracDataByPage();
  };

  const getPayloadData = (getPayloaddata) => {
    let updateOfficeType = checkData(getPayloaddata);
    let payload = '';
    payload = {
      PracticeCode: currentPracticeData.PracticeCode,
      Id: currentPracticeData.Id,
      OriginalId: currentPracticeData.OriginalId,
      Name: currentPracticeData.Name,
      Description: currentPracticeData.Description,
      WebSiteUrl: currentPracticeData.WebSiteUrl,
      LockPracticeEdit: currentPracticeData.LockPracticeEdit,
      OriginalDescription: currentPracticeData.OriginalDescription,
      OriginalWebSiteUrl: currentPracticeData.OriginalWebSiteUrl,
      ProviderCount: currentPracticeData.ProviderCount,
      IsPractice: currentPracticeData.IsPractice,
      IsNew: currentPracticeData.IsNew,
      HasOffices: currentPracticeData.HasOffices,
      editMode: currentPracticeData.editMode,
      Offices: [
        {
          OfficeCode: officeObj.OfficeCode,
          PracticeId: officeObj.PracticeId,
          Name: officeObj.Name,
          Address: officeObj.Address,
          Suite: officeObj.Suite,
          City: officeObj.City,
          State: officeObj.State,
          ZipCode: officeObj.ZipCode,
          Latitude: officeObj.Latitude,
          Longitude: officeObj.Longitude,
          Phone: officeObj.Phone,
          Fax: officeObj.Fax,
          HasOfficeHours: officeObj.HasOfficeHours,
          UpdateOnlyOfficeHours: officeObj.UpdateOnlyOfficeHours,
          UpdatePracticeOnly: officeObj.UpdatePracticeOnly,
          OfficeHours: [],
          Providers: getPayloaddata,
          TwoColumns: officeObj.TwoColumns,
          DisplayProviders: officeObj.DisplayProviders,
          ContainsLastOffice: officeObj.ContainsLastOffice,
          AssociatedPractice: officeObj.AssociatedPractice,
          IsPrimary: officeObj.IsPrimary,
          HasPrimary: officeObj.HasPrimary,
          Id: officeObj.Id,
          OrigId: officeObj.OrigId,
          OrigSolrId: officeObj.OrigSolrId,
          ProviderCount: officeObj.ProviderCount,
          FacetCount: officeObj.FacetCount,
          OrigIdCount: officeObj.OrigIdCount,
          OrigIdTotal: officeObj.OrigIdTotal,
          IsOasOffice: officeObj.IsOasOffice,
          IsAddPlaceholder: officeObj.IsAddPlaceholder,
          JustAdded: officeObj.JustAdded,
          UpdateType: updateOfficeType ? 'Delete' : 'Update'
        }
      ],
      OfficeHasHours: currentPracticeData.OfficeHasHours,
      JustAdded: currentPracticeData.JustAdded,
      AssociatedToUser: currentPracticeData.AssociatedToUser,
      UpdateType: currentPracticeData.UpdateType,
      UserId: _practiceUserId
    };
    updateProviders(payload, updateOfficeType);
  };

  const deleteProvidersHandler = () => {
    let _updateassociate = '';
    _updateassociate = _associatedProviders.map((provider) => {
      return provider.Selected === true
        ? { ...provider, Selected: false }
        : { ...provider, Selected: true };
    });
    getPayloadData(_updateassociate);
    trackingService.editPageTracking('practice', 'remove', '');
    setShowRemoveModalPopup(false);
  };

  const deleteOnlyProviderHandler = (e, pwid) => {
    if (pwid != undefined) {
      trackingService.editPageTracking('practice', 'edit-delete', 'office');
      let tempAssociatedProviders = _associatedProviders.map((provider) => {
        return provider.ProviderId === pwid
          ? { ...provider, Selected: true }
          : { ...provider, Selected: false };
      });
      _setAssociatedProviders(tempAssociatedProviders);
      setShowRemoveModalPopup(true);
    }
  };

  const updateProviders = (payload, typeCheck) => {
    if (!isEmpty(_associatedProviders) && _associatedProviders != undefined)
      !typeCheck
        ? service
            ._post('/api/practice/update-providers?isOldImplementation=false', payload, true)
            .then((res) => {
              if (res.status === 200) {
                let result = res.data;
                if (!result.IsError) {
                  toaster.Success('Success!');
                  trackingService.editPageTracking('practice', 'save', 'office-providers');
                  fetchPracticeDataByPage();
                } else {
                  const errorMesaage = { __html: result.ErrorMessage };
                  toaster.Error(<div dangerouslySetInnerHTML={errorMesaage} />);
                }
              } else {
                let data = res.data;
                const errorMesaage = { __html: data.ErrorMessage };
                toaster.Error(<div dangerouslySetInnerHTML={errorMesaage} />);
              }
            })
            .catch((err) => {
              toaster.Error('Some error occured!!');
            })
        : service
            ._post('/api/practice/update-office?isOldImplementation=false', payload, true)
            .then((res) => {
              if (res.status === 200) {
                toaster.Success('Success!');
                trackingService.editPageTracking('practice', 'save', 'office');
                fetchPracticeDataByPage();
              } else {
                let data = res.data;
                toaster.Error(data.ErrorMessage);
              }
            })
            .catch((err) => {
              toaster.Error('Some error occured!!');
            });
  };

  const updateProvidersInStore = (practicesJson) => {
    let _tempProviderProfileInfo = {
      ...practiceData,
      OfficeJson: practicesJson
    };
    dispatch(actions.loadPracticeData(_tempProviderProfileInfo, false));
    document.getElementById('input-auto-suggest').value = '';
  };

  const makePrimaryHandler = (provider) => {
    if (!isEmpty(provider.ProviderId)) {
      let payload = {
        OfficeId: officeObj.Id,
        ProviderId: provider.ProviderId,
        UserId: practiceData.UserId
      };
      service._post('/api/practice/update-primary-office', payload, true).then((res) => {
        if (res.status == 200) {
          fetchPracticeDataByPage();
          trackingService.editPageTracking('office', 'save', 'primary-office');
          toaster.Success(`The primary location for ${provider.Name} has been updated.`);
        } else {
          toaster.Error(res.data.ErrorMessage);
        }
      });
    }
  };

  const checkData = (getValue) => {
    return getValue.length == 1 && getValue.findIndex((k) => k.Selected == false) > -1
      ? true
      : false;
  };

  //Notify
  const toaster = {
    Success: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Success',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    },
    Error: (msg = '') => {
      let notifyObj = {
        id: Math.floor(Math.random() * 101 + 1),
        title: 'Error',
        description: msg
      };
      setNotifyProperties([notifyObj]);
    }
  };

  useEffect(() => {
    showDelete != '' ? document.addEventListener('click', handleClickOutside, true) : '';
  }, [showDelete]);

  useEffect(() => {
    providerAutoSuggestData != undefined && providerAutoSuggestData.length > 0
      ? document.addEventListener('click', handleClickOutside, true)
      : '';
  }, [providerAutoSuggestData]);

  useEffect(() => {
    let UpdatepracticeJson = JSON.parse(practiceData.OfficeJson).Practices;
    const UpdatePractices =
      UpdatepracticeJson.filter(
        (i) => i.Name === currentPracticeData.Name && i.Id === currentPracticeData.Id
      ) || [];
    const [getUpdateOffices] =
      UpdatePractices != undefined ? UpdatePractices.map((P) => P.Offices) : [];
    const UpdateOffices =
      getUpdateOffices != undefined ? getUpdateOffices.filter((k) => k.Name == officeObj.Name) : [];
    const [getProviders] =
      UpdateOffices != undefined && UpdateOffices.length > 0
        ? UpdateOffices.map((u) => u.Providers)
        : [];
    let _updateProviders =
      getProviders != undefined && getProviders.length > 0
        ? getProviders.map((prov) => ({ ...prov, Selected: false } || []))
        : [];
    _setAssociatedProviders(_updateProviders);
  }, [practiceData]);

  useEffect(() => {
    _setAssociatedProviders(associatedProvidersList.map((prov) => ({ ...prov, Selected: false })));
  }, [associatedProvidersList]);

  return (
    <LayoutInfo identifier='add-Provider-card' title={'Add Providers'} description=''>
      <input
        className='search'
        type='text'
        placeholder={'Add Provider'}
        id={`input-auto-suggest`}
        onChange={onSelectInputSearchHandler}
        autoComplete='off'
        disabled={false}
        value={showInput}></input>

      {providerAutoSuggestData != undefined && providerAutoSuggestData.length > 0 && (
        <div className='list-wrapper' ref={_addProviderSearch}>
          <ul className='list-group'>
            {providerAutoSuggestData.map((tag, index) => (
              <li key={index} className='list-item'>
                {associatedProvidersArr.find((j) => j == tag.ProviderId) == tag.ProviderId ? (
                  <span className='list-item-text' key={index} disabled={true}>
                    <strong>
                      {tag.Name == undefined ? tag.ProviderName : tag.Name}
                      <span className='already-in-list'> - already in list</span>
                    </strong>
                  </span>
                ) : (
                  <span
                    className='list-item-text'
                    key={index}
                    onClick={() => {
                      tag.ProviderId != null ? onSelectHandler(tag) : null;
                      clickHandler(tag);
                    }}>
                    {tag.Name == undefined ? tag.ProviderName : tag.Name}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      {_associatedProviders != undefined && (
        <>
          <div className='div-associated-providers-list'>
            Providers ({_associatedProviders.length}):
            {_associatedProviders.some((prov) => prov.Selected) && (
              <button
                className='remove-btn'
                onClick={() => {
                  trackingService.editPageTracking('practice', 'remove', 'office-providers');
                  setShowRemoveModalPopup(true);
                }}>
                Remove Providers
              </button>
            )}
          </div>
          {_associatedProviders.length > 0 ? (
            <div className='providers-container'>
              {_associatedProviders.map((provider, ind) => (
                <Fragment key={ind}>
                  <div
                    className={`div-provider-select ${
                      provider.IsPrimary ? 'primary-for-mobile-ui' : ''
                    }`}>
                    {!provider.IsPrimary && (
                      <input
                        id={provider.ProviderId}
                        type='checkbox'
                        className='provider-checkbox'
                        checked={provider.Selected}
                        onChange={(event) => checkboxOnChangeHandler(event)}
                      />
                    )}

                    <label
                      htmlFor={provider.ProviderId}
                      id={provider.ProviderId}
                      key={ind}
                      className={`${provider.IsPrimary ? 'no-checkbox' : ''} associated-provider`}>
                      {provider.Name !== undefined ? provider.Name : provider.ProviderName}
                    </label>

                    {provider.IsPrimary && (
                      <div className='primary-badge-container'>
                        <span id='primary-specialty'> PRIMARY </span>
                      </div>
                    )}

                    {(!provider.IsPrimary || !provider.IsOnlyLocation) && (
                      <div className='right-hand-menu'>
                        <div
                          className='delete-edit-menu'
                          ref={_sideMenu}
                          onClick={() => setShowDelete(provider.ProviderId)}>
                          <span className='delete-edit-span'>
                            <img src={svgMenuDots} alt='close' />
                          </span>

                          {showDelete != '' && provider.ProviderId === showDelete && (
                            <div className='delete-edit-items'>
                              {!provider.IsPrimary && (
                                <a
                                  href='#'
                                  onClick={(e) => {
                                    e.preventDefault();
                                    makePrimaryHandler(provider);
                                  }}>
                                  Make Primary
                                </a>
                              )}
                              {!provider.IsOnlyLocation && (
                                <a
                                  href='#'
                                  onClick={(e) => {
                                    e.preventDefault();
                                    deleteOnlyProviderHandler(e, provider.ProviderId);
                                  }}>
                                  Delete Provider
                                </a>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  <hr />
                </Fragment>
              ))}
            </div>
          ) : null}
        </>
      )}

      {showRemoveModalPopUp && (
        <DeleteProviderList
          showModalPopUp={showRemoveModalPopUp}
          showModallist={_associatedProviders.map((removeProviders) => {
            return removeProviders.Selected === true ? removeProviders.Name : '';
          })}
          buttonName='Remove Providers'
          showOfficeName={officeObj != null || officeObj != undefined ? officeObj.Name : ''}
          headMessage='Are you sure, you want to remove the following providers from '
          onRequestClose={() => {
            setShowRemoveModalPopup(false);
            trackingService.editPageTracking('practice', 'cancel', '');
          }}
          handleremoveProviders={deleteProvidersHandler}
          isDeleteAll={
            _associatedProviders.length ===
            _associatedProviders.filter((i) => i.Selected === true).length
          }></DeleteProviderList>
      )}

      <Toast
        toastList={notifyProperties}
        position='bottom-center'
        autoDelete={true}
        autoDeleteTime={5000}
      />
    </LayoutInfo>
  );
};

AddProvider.propTypes = {
  fetchPracticeDataByPage: PropTypes.func
};

export default AddProvider;
