import React from 'react';

/* #region style import */
import './_landing.less';
/* #endregion */

/* #region  component import */
import Tab from './Sidebar';
import PracticeAndLocation from '../../ProviderProfile/PracticeAndLocation/PracticeAndLocation';
/* #endregion */

/* #region  JSX */
const Landing = ({ practiceData }) => {
  return (
    <div className='practice-profile-container'>
      <div className='inner-container'>
        <div className='practice-main-container'>
          <div className='practice-inner-container'>
            <Tab />
            <PracticeAndLocation practiceData={practiceData}/>
          </div>
        </div>
      </div>
    </div>
  );
};

Landing.propTypes = {};

export default Landing;
