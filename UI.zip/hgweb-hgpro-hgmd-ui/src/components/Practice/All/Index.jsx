import React from 'react';
import { useSelector } from 'react-redux';

/* #region  Stylesheet Imports */
import './_index.less';
/* #endregion */

/* #region  Components Import */
import MenuComponent from '../../Common/Menu/Menu';
import RosterBanner from '../Common/RosterBanner';
import Landing from './Landing';
import Footer from '../../Common/Footer/Footer';
/* #endregion */

const Index = () => {
  /* #region  Access Store */
  const practiceData = useSelector((state) => state.loadPracticeData);
  /* #endregion */

  /* #region  Setting Local Variables */
  let menuItems = practiceData.Navigations;
  let navigationModelObject = practiceData.NavigationModel;
  /* #endregion */

  return (
    <section>
      <MenuComponent
        menuClick={() => {}}
        showMenus={true}
        menuItems={menuItems}
        infoObject={navigationModelObject}
      />
      <RosterBanner />
      <Landing practiceData={practiceData} />
      <Footer />
    </section>
  );
};

export default Index;
