import React from 'react';

/* #region  Stylesheet Imports */
import './_sidebar.less';
/* #endregion */

/* #region  Media Imports */
import BackArrow from '../../../assets/images/back-arrow.svg';
/* #endregion */

const Sidebar = () => {
  /* #region  Event Handlers */
  const handleBackClick = () => window.history.back();
  /* #endregion */

  return (
    <div id='roster-practice-tab' className='roster-common-div'>
      <div id='div-roster-practice-tab' className='back-btn' onClick={handleBackClick}>
        <button className='btns-sub-menu-dismiss'>
          <img className='back-arrow' src={BackArrow} alt='logo' />
          <span>Back</span>
        </button>
        <button className='btns-sub-menu active-tab'>
          <span>Practice & Office Location </span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
