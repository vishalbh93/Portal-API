export const PRACTICE_PAGE = 'PRACTICE';
export const PROVIDER_PROFILE_PAGE = 'PROFILE';
export const ROSTER_PAGE = 'ROSTER';
export const CLIENTPORTAL_PAGE = 'CLIENTPORTAL';
export const CLIENT_ADMIN_PAGE = 'CLIENTADMINPORTAL';
export const RESIDENTIAL_ADDRESS_ERROR_MESSAGE = 'Our system has identified this as a residential address!';
