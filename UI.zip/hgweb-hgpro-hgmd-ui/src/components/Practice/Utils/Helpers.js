/* #region  Required Imports */
import { PRACTICE_PAGE, PROVIDER_PROFILE_PAGE, ROSTER_PAGE, CLIENT_ADMIN_PAGE } from './Constants';
/* #endregion */

/* #region  Helper Functions */
export const currentPage = window.location.pathname
  .split('/')
  .map((val) => val.toLowerCase())
  .includes('practice')
  ? PRACTICE_PAGE
  : PROVIDER_PROFILE_PAGE;
/* #endregion */

/* #region  Helper Functions For Roster */
export const rosterPage = window.location.pathname
  .split('/')
  .map((val) => val.toLowerCase())
  .includes('roster')
  ? ROSTER_PAGE
  : '';
/* #endregion */

/* #region  Helper Functions For Roster */
export const clientAdminPage = window.location.pathname.toLowerCase() == '/clientportal' ? CLIENT_ADMIN_PAGE : '';
/* #endregion */
