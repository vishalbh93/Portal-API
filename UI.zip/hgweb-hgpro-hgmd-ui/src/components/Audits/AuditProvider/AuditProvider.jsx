/* eslint-disable react/prop-types */
import React from 'react';
import './_auditProvider.less';
import PropTypes from 'prop-types';
import expandRow from '/public/images/auditPage/chevron-down.svg';


const StatusOfAudit = (status, showStatus) => {
  if (showStatus != true) return '';
  let className = 'status-label-rejected';
  if (status == 'READY' || status == 'Ready') {
    className = 'status-label-approved';
    status = 'approved';
  }
  return <p className={className}>({status.toLowerCase()})</p>;
};

const AuditProvider = (props) => {
  const {
    LastModifiedDateString,
    LastModifiedTimeString,
    ProviderFullName,
    ProfileManagerAuditRecord,
    ProviderAddress,
    Type,
    SubmittedByFullName,
    UserName,
    ClientName,
    showStatus,
    AuditedByUsername,
    Pwid,
    AuditedByFullname,
  } = props;

const auditor =AuditedByFullname && AuditedByFullname.split('@')
  const getHistoryColumns = () => {
    return (
      <div className='audit-provider-details'>
        <div className='history-date'>
        <div className='mobile-history-date'>Date Audited</div>
          {LastModifiedDateString}{' '}{LastModifiedTimeString}
        </div>

        <div className='history-auditor'>
        <div className='mobile-history-auditor'>Auditor</div>
          <span>
            {auditor[0]}
          </span>
        </div>
        <div className='history-provider'>
          <span>
            <a
              href={`/provider/profile/${Pwid}/admin`}
              alt={Pwid}
              target='_blank'
              rel='noopener noreferrer'
            >
              {ProviderFullName}
            </a>
          </span>
          <span>{ProviderAddress}</span>
        </div>
        <div className='history-default'>
        <div className='mobile-history-type'>Type/ID</div>
          <span className={Type}>{Type}</span>
          {ClientName != '' && <span className='type-tag'>{ClientName}</span>}
        </div>
        <div className='history-changes'>
          <div className='history-class-mobile'>
        <div className='mobile-history-changes'>Changes Requested</div>
          {ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'approved' || auditData.Items[0].ActionTaken.toLowerCase() == 'ready').length>0&&<div className='history-approved-ul'>
            {ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'approved' || auditData.Items[0].ActionTaken.toLowerCase() == 'ready').length>0 &&<div className='approved-mobile'>Approved:</div>}
            <ul className='approved-ul'>{ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'approved' || auditData.Items[0].ActionTaken.toLowerCase() == 'ready').map((value, index) => (
            <li key={index} className='list-item-approved'>
                {value.SectionName}
            </li>
          ))}</ul>
          </div>}
         {ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'rejected' || auditData.Items[0].ActionTaken.toLowerCase() == 'rejected') &&  <div className='history-rejected-ul'>
              {ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'rejected').length>0 &&<div className='rejected-mobile'>Rejected:</div>}
              <ul className='rejected-ul'>{ProfileManagerAuditRecord.AuditSection.filter(auditData=>auditData.Items[0].ActionTaken.toLowerCase() == 'rejected').map((value, index) => (
              <li key={index} className='list-item-rejected'>
                  {value.SectionName}
              </li>
            ))}</ul>
            </div>}
          </div>
        </div>
        <div className='noof-history-requests'>
        <div className='mobile-history-requests'>Number of Requestes:</div>
          <span className='history-requests'>
          {ProfileManagerAuditRecord.AuditSection.length}
          </span>
          <div className='history-requests-img'>
            <img src={expandRow} alt='expand'/>
          </div>
        </div>
      </div>
    );
  };

  const getQueueColumns = () => {
    return (
      <div className='audit-provider-details'>
        <div className='queue-date'>
          <div className='mobile-queue-date'>Date submitted</div>
          {LastModifiedDateString}{' '}{LastModifiedTimeString}
        </div>
        <div className='queue-provider'>
          <span>
            <a
              href={`/provider/profile/${Pwid}/admin`}
              alt={Pwid}
              target='_blank'
              rel='noopener noreferrer'
            >
              {ProviderFullName}
            </a>
          </span>
          <span>{ProviderAddress}</span>
        </div>
        <div className='queue-default'>
        <div className='mobile-queue-type'>Type/ID</div>
          <span className={Type}>{Type}</span>
          {ClientName != '' && <span className='type-tag'>{ClientName}</span>}
        </div>
        <div className='queue-changes'>
        <div className='mobile-queue-changes'>Changes Requested</div>
          {ProfileManagerAuditRecord.AuditSection.map((value, index) => (
            <ul key={index}>
              <li>
                {value.SectionName}
                {StatusOfAudit(value.ActionTaken, props.showStatus)}
              </li>
            </ul>
          ))}
        </div>
        <div className='no-of-requests'>
        <div className='mobile-queue-requests'>No of Requests:</div>
          <span className='mobile-requests'>
          {ProfileManagerAuditRecord.AuditSection.length}
          </span>
          <div className='queue-requests-img'>
            <img src={expandRow} alt='expand'/>
          </div>
        </div>
      </div>
    );
  };
  return showStatus == true ? getHistoryColumns() : getQueueColumns();
};
AuditProvider.propTypes = {
  LastModifiedDateString: PropTypes.string,
  LastModifiedTimeString: PropTypes.string,
  ProfileManagerAuditRecord: PropTypes.object,
  ProviderFullName: PropTypes.string,
  ProviderAddress: PropTypes.string,
  Type: PropTypes.string,
  SubmittedByFullName: PropTypes.string,
  UserName: PropTypes.string,
  ClientName: PropTypes.string,
  showStatus: PropTypes.bool,
};

export default AuditProvider;
