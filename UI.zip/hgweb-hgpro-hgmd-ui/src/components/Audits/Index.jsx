//#React component
import React, { Fragment, useState } from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';

//#import styles Component
import './_index.less';

//#import joy component
import '@hg/joy/src/globalstyles';

//#Component
import HeroSection from '../Common/HeroSection';
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import AuditsContainer from './AuditsContainer/AuditsContainer';

const Index = (props) => { 
 const {   
  auditModel
} = useSelector((state) => state.loadAuditModelData);
   let menuItems = !_.isEmpty(auditModel)?!_.isEmpty(auditModel.Navigations)?auditModel.Navigations:[]:[];
   let navigationModelObject =!_.isEmpty(auditModel)?!_.isEmpty( auditModel.NavigationModel)? auditModel.NavigationModel:[]:[];

  const [currentTab, setCurrentTab] = useState('landing');

  const menuClick = (section) => {
    setCurrentTab(section);
  };

  return (
    <Fragment>
      <MenuComponent
        menuClick={menuClick}
        menuItems={menuItems}
        infoObject={navigationModelObject}
        showMenus={true}
      />
      <div className='banner-container-search'>
        <div className='banner-inner-container-search'>
          <HeroSection 
              showDoctorImage={false}
              src=''
              header1='Audits'
              backgroundColor='#FFFFFF' />
        </div>
      </div>
      <AuditsContainer/>
      <div className='audit-page-footer'>
        <Footer />
      </div>     
    </Fragment>
  );
};

Index.propTypes = {
  providers: PropTypes.object
};

export default Index;
