import React, { useState, useEffect, Fragment } from 'react';
import './_auditSearch.less';
import { useDispatch , useSelector} from 'react-redux';
import * as actions from '../../../store/actions';
import { RadioGroup } from '../../FormComponents/RadioGroup';
import Select from 'react-select';
import Spinner from '../../Spinner/Spinner';
import PropTypes from 'prop-types';
import expandRow from '/public/images/auditPage/chevron-down.svg';
import crossicon from '/public/images/auditPage/cross.svg';
import _ from 'lodash';
const AuditSearch = (props) => {
  const {type, value, currentUserId, searchBy, radioOptions, searchTab ,redirectHistory} =
    props;
  const [radioSelect, setRadioSelect] = useState('providers');
  const [radioSelect1, setRadioSelect1] = useState('pwid');
  const [inputValue, setinputValue] = useState('');
  const [clearInput, setclearInput] = useState(false);
  const [inputType, setinputType] = useState('');
  const [status, setStatus] = useState('READY');
  const [showSpinner, setShowSpinner] = useState(false);
  const dispatch = useDispatch();
  const [searchFrom, setSearchFrom] = useState('queue');
  const [option, setOption] = useState({
    value: 'all',
    label: 'All update types',
  });
  const [dropDownState ,setDropDownState] = useState(false);
  const [searchCrossIcon , setSearchCrossIcon] = useState(false);
  const [isError, setIsError] = useState(false);
  const options = [
    {
      value: 'all',
      label: 'All update types',
      allowedLength: 200,
    },
    {
      value: 'LegalName',
      label: 'Legal Name',
      allowedLength: 10,
    },
    {
      value: 'License',
      label: 'State License',
      allowedLength: 200,
    },
    {
      value: 'Certification',
      label: 'Board Certification',
      allowedLength: 200,
    },
    {
      value: 'Video',
      label: 'Video',
      allowedLength: 200,
    }
    
    /// Todo Not required these filed if we need enable it here.
    // {
    //   value: 'AboutMe',
    //   label: 'Care Philosophy',
    //   allowedLength: 200,
    // },
    // {
    //   value: 'Office',
    //   label: 'Office',
    //   allowedLength: 200,
    // },
    // {
    //   value: 'Practice Description',
    //   label: 'Practice Description',
    //   allowedLength: 200,
    // },
    // {
    //   value: 'Practice Website',
    //   label: 'Practice Website',
    //   allowedLength: 200,
    // },
    // {
    //   value: 'Photo',
    //   label: 'Photo',
    //   allowedLength: 200,
    // },
    // {
    //   value: 'education',
    //   label: 'Education',
    //   allowedLength: 200,
    // }    
  ];

  const [dropDownOptions, setDropDownOptions] = useState(options);

  const [filterOption, setFilterOption] = useState({
    value: 'pwid',
    label: 'PWID',
    textPlaceHolder: 'e.g. 33L3G',
    allowedLength: 10,
  });
  const filterOptions = [
    {
      value: 'pwid',
      label: 'PWID',
      textPlaceHolder: 'e.g. 33L3G',
      allowedLength: 10,
      Show:true
    },
    {
      value: 'npi',
      label: 'NPI',
      textPlaceHolder: 'e.g. 1659668416',
      allowedLength: 10,
      Show:true
    },
  ];
  const [filterDropDownOptions, setFilterDropDownOptions] =
    useState(filterOptions);

  const [textMaxLength, setTextMaxLength] = useState(10);

  useEffect(() => {
    setinputValue(value);
    setinputType(type);
    setRadioOption();
    setStatus('READY');
    setTextMaxLength(100);
    setSearchFrom(searchTab);
  }, [type, value, searchTab]);

  const setRadioOption = () => {
    setDropDownOptions(options);
    setFilterDropDownOptions(filterOptions);
  };

  const setSelectedOption = (e) => {
    setRadioSelect(e.target.value);
    setRadioSelect1(e.target.value)
    setinputValue('');
    setinputType(e.target.value);
    let data = filterOptions.filter(optionsData=>optionsData.value === e.target.value)
    if(data) setFilterOption(data[0]);
    setclearInput(true);
  };

  const changeHandler = (e) => {
    setIsError(false);
    if(filterOption != undefined && filterOption.label.toLowerCase() === 'npi'){
      let valRegex = /^[0-9\b]+$/;
      if(_.isEmpty(e.target.value))
        setinputValue('');
      else if(valRegex.test(e.target.value) && e.target.value.length <= 10)
        setinputValue(e.target.value);
    }else{
      setinputValue(e.target.value);
    }
  };

  const onKeyPressed = (e) => {
    let code = e.keyCode || e.which;
    if (code === 13) {
      onServiceHandler();
    }
  };

  const NPIValidation = (val)=>{
    let npiRegex = /^[0-9]{10}$/;
    if(npiRegex.test(val))
      return true;
    else
      return false;
  };
  const onServiceHandler = () => {
    if(filterOption != undefined){
      if(filterOption.label.toLowerCase() === 'npi'){
        if (NPIValidation(inputValue) && !_.isEmpty(inputValue))
          searchData();
        else
          setIsError(true);
      } 
      if (filterOption.label.toLowerCase() === 'pwid') {
        searchData();
      }
    }
    else{
      searchData();
    }
  }

  const clearInputValue = () =>{
    setinputValue('');
    setclearInput(true);
    setSearchCrossIcon(false)
    setIsError(false);
  }
  useEffect(()=>{
    if(clearInput) {
      setinputValue('');
      searchData();
    }
  },[clearInput]);

  const searchData = () => {
    if(inputValue){
      setSearchCrossIcon(true)
    }
    setShowSpinner(true);
    setclearInput(false);
    if (searchFrom == 'queue') {
      dispatch(
        actions.getAuditRecords(
          inputType,
          inputValue,
          setShowSpinner,
          status,
          1,
          '',
          'asc',
          'all',
          currentUserId          
        )
      );
    } else {
      dispatch(
        actions.getAuditRecordsHistory(
          filterOption.value,
          inputValue,
          setShowSpinner,
          'COMPLETED',
          1,
          '',
          'asc',
          'all',
          currentUserId
        )
      );
    }
    // }
  };

  const handleChange = (data) => {
    if (searchFrom == 'queue') {
      setOption(data);
      setShowSpinner(true);
      dispatch(
        actions.getAuditRecords(
          inputType,
          inputValue,
          setShowSpinner,
          status,
          1,
          '',
          'asc',
          data.value,
          currentUserId
        )
      );
    }
    if (searchFrom == 'history') {
      setFilterOption(data);
    }
  };

  const confirmReset = () => {
    setinputValue('');
    setinputType('providers');
    setRadioSelect('providers');
    let defaultValue = options.find((option) => option.value == 'all');
    setDropDownOptions(options);
    setOption(defaultValue);
    dataRefresh('providers', '');
  };

  const dataRefresh = (search_type, search_value) => {
    setShowSpinner(true);
    if (searchFrom == 'queue') {
      dispatch(
        actions.getAuditRecords(
          search_type,
          search_value,
          setShowSpinner,
          status,
          1,
          '',
          'asc',
          'all',
          currentUserId
        )
      );
    } else {
      dispatch(
        actions.getAuditRecordsHistory(
          filterOption.value,
          inputValue,
          setShowSpinner,
          'COMPLETED',
          1,
          '',
          'asc',
          'all',
          currentUserId
        )
      );
    }
  };

  const customStyles = {
    option:(provided , state)=>({
      ...provided,
      backgroundColor:state.isSelected?'#6B6EB3':'white',
      color:state.isSelected?'white':'#4A4A4D',
      fontSize:'16px',
    })
  }

  return (
    <Fragment>
      <div className='top-search-container'>
        <div className={redirectHistory?'search-container search-align':'search-container'}>
          <div className='inner-container'>
            <span className='search-label'>Search for :</span>
            <div className='radiobtn-container'>
              <RadioGroup
                radioGroup={props.redirectHistory ? filterOptions : radioOptions}
                selectedOption={props.redirectHistory ? radioSelect1 : radioSelect}
                onChangeHandler={setSelectedOption}
                redirectHistory = {props.redirectHistory}
              />
            </div>
          </div>

          <div className={redirectHistory ? ' search-width-history margin-top-15':'margin-top-15'}>
            <div className={redirectHistory ? 'search-wrapper-history1' : 'search-wrapper'}>
              <div className={'search-provider ' + searchFrom}>
                <div className='height-fix'>
                  <input
                    className='input'
                    id='searchProvider'
                    type='text'
                    value={inputValue}
                    onChange={changeHandler}
                    onKeyPress={onKeyPressed}
                    maxLength='50'
                    placeholder={`Search for ${searchFrom == 'history'
                    ? ' ' +
                      filterOption.label +
                      ' ' +
                      filterOption.textPlaceHolder
                    : ' ' + radioSelect}`}
                  />
                  {/* <label htmlFor='searchProvider' className='floating-label'>
                    Search for
                    {searchFrom == 'history'
                      ? ' ' +
                        filterOption.label +
                        ' ' +
                        filterOption.textPlaceHolder
                      : ' ' + radioSelect}
                  </label> */}
                  {isError && <div className='div-display-error'>
                        <span className='error-msg-npi'>Please enter a valid NPI number</span>
                    </div>}
                </div>
                <div className={'search-section ' + searchFrom}>
                 {!searchCrossIcon&& <span className='search-icon'>
                    <i className='icon' onClick={onServiceHandler}></i>
                  </span>}
                  {searchCrossIcon && <img src={crossicon} alt="" className='search-icon'  onClick={clearInputValue}/>}
                </div>
              </div>
              {searchFrom == 'queue' && (
                <Fragment>
                  <div className='drop-down' onClick={()=>setDropDownState(!dropDownState)}>
                    <Select
                      id='filterBy'
                      className='select-box'
                      value={option}
                      isSearchable={false}
                      options={dropDownOptions}
                      onChange={(value) => handleChange(value)}
                      aria-label='all update types'
                    />
                    <label
                      htmlFor='filterBy'
                      className='floating-label-dropdown'
                    >
                      Filter By
                    </label>
                  </div>                  
                </Fragment>
              )}
            </div>
          </div>
        </div>
      </div>

      {showSpinner && <Spinner cta={true} />}
    </Fragment>
  );
};

AuditSearch.propTypes = {
  type: PropTypes.string,
  value: PropTypes.string,
  currentUserId: PropTypes.string,
  searchBy: PropTypes.string,
  radioOptions: PropTypes.array,
  searchTab: PropTypes.string,
};
export default AuditSearch;
