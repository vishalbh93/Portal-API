import React, { useState, Fragment, useEffect } from 'react';
import { useSelector } from 'react-redux';
import './_index.less';

//styling imports
import '@hg/joy/src/globalstyles';

//media imports

//components imports
import HeroSection from '../Common/HeroSection';
import Body from './Body';
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';

const Index = (props) => {
  const [currentTab, setCurrentTab] = useState('landing');
  const menuClick = (section) => {
    setCurrentTab(section);
  };

  const [heading, setHeading] = useState('Welcome to Healthgrades for ');
  const [header2, setHeader2] = useState('Professionals');
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [showDoctorImage, setShowDoctorImage] = useState(false);

  const { pageData: { isClaimRegistrationSuccess } } = useSelector((state) => state.loadLoginPageData);

  useEffect(() => {
    let preUrl = document.referrer;
    if (preUrl.includes('account/verify-code') || !!isClaimRegistrationSuccess) {
      setHeading('Congratulations');
      setHeader2('');
      setRegistrationSuccess(true);
      setShowDoctorImage(false);
    }
  }, []);

  return (
    <Fragment>
      <MenuComponent menuClick={menuClick} showMenus={false} showClaim={true} showLogin={false} />
      <HeroSection
        header1={heading}
        header2={header2}
        registrationSuccess={registrationSuccess}
        showDoctorImage={showDoctorImage}
      />
      <Body />
      <Footer />
    </Fragment>
  );
};

Index.propTypes = {};

export default Index;
