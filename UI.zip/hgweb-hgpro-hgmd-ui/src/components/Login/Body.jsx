import React, { Suspense, lazy } from 'react';
// import LoginForm from './LoginForm';
import BrandingLogos from '../Common/BrandingLogos';
const LoginForm = lazy(() => import('./LoginForm'));

//stylesheet imports
import './_body.less';

const Body = () => {
  return (
    <>
      <div className='body-section'>
        <div className='body-inner-section'>
          <div className='main-wrapper'>
            <div className='login-form-section login-form-mobile'>
              <Suspense fallback=''>
                <LoginForm />
              </Suspense>
            </div>
          </div>
        </div>
      </div>
      <BrandingLogos />
    </>
  );
};

export default Body;
