import React, { useState, useEffect, Fragment } from 'react';

import * as actions from '../../store/actions';
import { useDispatch, useSelector } from 'react-redux';
import isEmpty from '../../utils/validation/isEmpty';
import TextValidation from '../../utils/validation/isTextValid';
import ValidationErrorMessage from '../FormComponents/ValidationErrorMessage';
import showPassword from '../../assets/images/show_password.svg';
import hidePassword from '../../assets/images/icon_hidepassword.svg';
import { getQueryStringArray } from '../../utils/utils';
import './_loginForm.less';
import warning from '../../../public/images/warning.png';
//component import
import Spinner from '../Spinner/Spinner';

//tracker import
import { HG3Tracker } from '../../utils/tracking';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  //const [rememberMe, setRememberMe] = useState('');
  const [displaySpinner, setDisplaySpinner] = useState(false);
  const dispatch = useDispatch();
  const { loginsuccess, loginerrorMsg, redirectUrl } = useSelector((state) => state.loginReducer);

  const { loginModelInfo } = useSelector((state) => state.loadLoginModel);

  const [showErrorModal, setShowErrorModal] = useState(false);

  const [togglePassword, setTogglePassword] = useState(true);

  const isEmptyField = { isValid: false, error: 'This field is required' };
  const isPasswordEmptyField = { isValid: false, error: 'The password is required' };
  const isUserNameRequired = {
    isValid: false,
    error: 'The email or user name is required'
  };

  const [loginModel, setLoginModel] = useState({
    email: '',
    password: '',
    rememberMe: false,
    returnUrl: '',
    userName: ''
  });
  let queryString = getQueryStringArray();

  const [isEmailEmpty, setEmailValidation] = useState({
    isValid: true,
    error: ''
  });

  const [isPasswordEmpty, setPasswordValidation] = useState({
    isValid: true,
    error: ''
  });

  const validateInput = () => {
    if (isEmpty(loginModel.userName)) {
      setEmailValidation(isUserNameRequired);
    } else {
      userNameValidation(loginModel.userName.trim());
    }

    if (isEmpty(loginModel.password)) {
      setPasswordValidation(isPasswordEmptyField);
    }

    return !isEmpty(loginModel.userName) && !isEmpty(loginModel.password);
  };

  const userNameValidation = (userName) => {
    let regex = /[^0-9A-Za-zÀ-ÿ'_@.\+\\-]/g;
    const result = userName.match(regex);
    const isObject = (value) => typeof value === 'object' && value !== null;
    if (isObject(result) === true) {
      setEmailValidation({
        isValid: false,
        error: `Your username contains invalid characters ( ${result.join(' ')})`
      });
    } else if (userName.indexOf('@') != -1) {
      setEmailValidation(TextValidation(userName, 'emailaddress'));
    } else {
      setEmailValidation({
        isValid: false,
        error: ''
      });
    }
  };

  const changeHandler = (e) => {
    switch (e.target.id) {
      case 'userName':
        setLoginModel({ ...loginModel, email: e.target.value, userName: e.target.value });
        if (isEmpty(e.target.value)) {
          setEmailValidation(isUserNameRequired);
        } else {
          userNameValidation(e.target.value.trim());
        }
        break;

      case 'password':
        setLoginModel({ ...loginModel, password: e.target.value });
        if (isEmpty(e.target.value)) {
          setPasswordValidation(isPasswordEmptyField);
        } else setPasswordValidation({ isValid: false, error: '' });
        break;

      case 'rememberMe':
        setLoginModel({ ...loginModel, rememberMe: e.currentTarget.checked });
        break;
    }
  };

  const pageTracker = (type) => {
    HG3Tracker.OmnitureTrackLink(type !== undefined && type !== null ? type : '');
  };
  const loginClickHandler = (e) => {
    setDisplaySpinner(false);
    e.preventDefault();
    if (validateInput()) {
      setDisplaySpinner(true);
      dispatch(actions.login(loginModel, setDisplaySpinner));
    }
  };

  const onKeyPressed = (e) => {
    let code = e.keyCode || e.which;
    if (code === 13) {
      e.preventDefault();
      loginClickHandler(e);
    }
  };

  const isValidURL = (url) => {
    var regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
    if (!regex.test(url)) {
      return false;
    } else {
      return true;
    }
  };

  useEffect(() => {
    if (queryString.returnurl != undefined && queryString.returnurl != '')
      setLoginModel({ ...loginModel, returnUrl: queryString.returnurl });
  }, []);

  useEffect(() => {
    if (loginsuccess) {
      let url = redirectUrl;
      url = decodeURIComponent(url);
      if (url.charAt(0) == '/') {
        url = url.slice(1);
      }
      setDisplaySpinner(false);
      if (isValidURL(url)) {
        window.location.replace(url);
      } else {
        window.location.href = `${window.location.origin}/${url}`;
      }
    } else if (loginerrorMsg != '') {
      setDisplaySpinner(false);
      setShowErrorModal(true);
    }
  }, [loginsuccess, redirectUrl, loginerrorMsg]);

  useEffect(() => {
    if (loginModelInfo.userName != null) {
      setLoginModel({
        ...loginModel,
        rememberMe: false,
        userName: loginModelInfo.userName
      });
    } else {
      setLoginModel({
        ...loginModel,
        email: '',
        password: '',
        rememberMe: false,
        returnUrl: '',
        userName: ''
      });
    }

    if (queryString.returnurl != undefined && queryString.returnurl != '')
      setLoginModel({ ...loginModel, returnUrl: queryString.returnurl });
  }, [loginModelInfo]);

  return (
    <div id='login-form' className='login-form-group'>
      <h1 className='login-header'>Log in below to get started</h1>
      <div className='input-group' title='Email or username'>
        <label htmlFor='userName'>Email or Username</label>
        <input
          id='userName'
          placeholder='Your Email or Username'
          type='text'
          autoComplete='off'
          onChange={changeHandler}
          value={loginModel.userName}
        />
        {!isEmailEmpty.isValid && <ValidationErrorMessage message={isEmailEmpty.error} />}
      </div>
      <div className='input-group' title='Password'>
        <label htmlFor='password'>Password</label>
        <input
          id='password'
          placeholder='Enter Password'
          type={togglePassword ? 'password' : 'text'}
          autoComplete='off'
          className='password'
          onKeyPress={onKeyPressed}
          onChange={changeHandler}
          value={loginModel.password}
        />
        <div className={`pswd-toggle`}>
          <div className='toggle-password' id='togglePassword'>
            <label htmlFor='togglePassword'>
              <div>
                {!togglePassword ? (
                  <img
                    className='hidePassword'
                    src={hidePassword}
                    alt='hidePassword'
                    onClick={() => setTogglePassword(!togglePassword)}
                  />
                ) : (
                  <img
                    className='showPassword'
                    src={showPassword}
                    alt='showPassword'
                    onClick={() => setTogglePassword(!togglePassword)}
                  />
                )}
              </div>
            </label>
          </div>
        </div>
        {!isPasswordEmpty.isValid && <ValidationErrorMessage message={isPasswordEmpty.error} />}
      </div>

      <div className='input-group' title='RememberMe' id='div-remember-me'>
        <input
          id='rememberMe'
          type='checkbox'
          onChange={changeHandler}
          checked={loginModel.rememberMe}
          value={loginModel.rememberMe}></input>
        <label id='rememberMeLabel' className='remember' htmlFor='rememberMe'>
          Remember me for 30 days
        </label>
      </div>
      <div className='provider-info-button-section'>
        {showErrorModal && (
          <Fragment>
            {/* <img className='icons' src={warning} alt='warning' /> */}
            <div className='warning-msg' dangerouslySetInnerHTML={{ __html: loginerrorMsg }}></div>
          </Fragment>
        )}
        <button
          className='login-btn'
          type='button'
          id='btn-login'
          name='login'
          title='Login'
          onClick={loginClickHandler}>
          Login
        </button>
      </div>
      <div className='forgot-section'>
        <a href='/account/forgot-password' alt='Forgot Password' className='forgot-password'>
          Forgot Password?
        </a>
      </div>
      <>{displaySpinner && <Spinner />}</>
    </div>
  );
};

export default LoginForm;
