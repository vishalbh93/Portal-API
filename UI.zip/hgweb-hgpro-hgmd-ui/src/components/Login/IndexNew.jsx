import React, {  Fragment } from 'react';
import './_index.less';

//styling imports
import '@hg/joy/src/globalstyles';

//media imports

//components imports

import Body from './Body';
import Footer from '../Common/Footer/Footer';

const IndexNew = (props) => { 
return (
    <Fragment>      
      <Body />
      <Footer />
    </Fragment>
  );
};

IndexNew.propTypes = {};

export default IndexNew;
