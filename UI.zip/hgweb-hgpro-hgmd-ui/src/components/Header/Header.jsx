import React from 'react';
import './_header.less';
import PropTypes from 'prop-types';
import { useState } from 'react';

//#import joy component
import CheckboxInput from '@hg/joy/src/components/formElements/CheckboxInput';

const Header = (props) => {
  const { columns, isCheckBox } = props;
  const [sortOrder, setSortOrder] = useState('asc');
  const [sortBy, setSortBy] = useState('date');
  const showPanel = props.isShow;
  const [value, setValue] = useState('');

  const onSortHandler = (sortOption, sortBy) => {
    setSortOrder(sortOption);
    const sortType = sortBy.split(' ');
    setSortBy(sortType[1]);
    props.onSort(sortOption, sortType[1]);
  };

  return (
    <div className='header-section'>
      <div className='header-container'>
        <div className='header'>
          {columns.map((column, index) =>
            !column.isShow && showPanel ? null : column.IsSortBy ? (
              <div key={index} className={column.ClassName}>
                {isCheckBox && column.ClassName == 'provider-search name' && (
                  <CheckboxInput
                    id='provider-name-checkbox'
                    label={''}
                    onChange={(name, value) => setValue(value)}
                    value={value}
                  />
                )}
                <div
                  onClick={() =>
                    onSortHandler(sortOrder == 'asc' ? 'desc' : 'asc', column.ClassName)
                  }>
                  <span className='sort'>{column.ColumnName}</span>

                  {sortOrder == 'asc' ? (
                    <span
                      id={column.ColumnName}
                      className={column.IsSorted ? 'icon_down' : ''}></span>
                  ) : (
                    <span
                      id={column.ColumnName}
                      className={column.IsSorted ? 'icon_up' : ''}></span>
                  )}
                </div>
              </div>
            ) : (
              <div key={index} className={column.ClassName}>
                <div>
                  <span className='no-sort'>{column.ColumnName}</span>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

Header.propTypes = {
  columns: PropTypes.array,
  onSort: PropTypes.func,
  isShow: PropTypes.bool
};
Header.defaultProps = {
  onSort: () => {}
};

export default Header;
