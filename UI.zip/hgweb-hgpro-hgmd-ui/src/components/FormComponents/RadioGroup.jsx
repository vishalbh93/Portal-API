import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Radio } from './Radio';

export const RadioGroup = (props) => {
  const { radioGroup, selectedOption, onChangeHandler, disabled ,redirectHistory} = props;

  return radioGroup.map((radioOption) => (
    <Fragment key={radioOption.Value}>
      {radioOption.Show && (
        <Radio
          optionLabel={redirectHistory?radioOption.label:radioOption.Name}
          optionValue={redirectHistory?radioOption.value:radioOption.Value}
          selectedOption={selectedOption}
          onChangeHandler={onChangeHandler}
          disabled={disabled || radioOption.disabled}
          showAudits={props.showAudits}
        />
      )}
    </Fragment>
  ));
};
RadioGroup.defaultProps = {
  disabled: false
};

RadioGroup.propTypes = {
  radioGroup: PropTypes.array,
  selectedOption: PropTypes.string,
  onChangeHandler: PropTypes.func,
  disabled: PropTypes.bool
};
