import React, { useState, Fragment, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import './_createRoster.less';
import close from '../../assets/images/ProviderProfile/Vector.svg';
import showPassword from '../../assets/images/show_password.svg';
import hidePassword from '../../assets/images/icon_hidepassword.svg';
import * as actions from '../../store/actions';
import ValidationErrorMessage from '../FormComponents/ValidationErrorMessage';
import TextValidation from '../../utils/validation/isTextValid';
import isEmpty from '../../utils/validation/isEmpty';
import PropTypes from 'prop-types';
import * as constants from '../../utils/constant-data';
import AutoComplete from '../FormComponents/AutoComplete/AutoComplete';
import EmailInput from '@hg/joy/src/components/formElements/EmailInput';
import * as _pService from '../../utils/serviceCalls/clientPortal';
import { objectToCamel } from '../../utils/utils';
import _ from 'lodash';

const CreateRoster = (props) => {
  const { currentUserId, clientCodes } = props;

  const { createRosterResponse } = useSelector((state) => state.createRoster);
  const isEmptyField = { isValid: false, error: 'This field is required' };
  const [password, togglePassword] = useState(false);
  const dispatch = useDispatch();
  const [disableButton, setdisablebutton] = useState(true);
  //const { results } = useSelector((state) => state.getClientCodeReducer);

  const [suggestData, setSuggestData] = useState(Array);
  const [suggestValue, setSuggestValue] = useState('');
  const [selectedClientData, setSelectedClientData] = useState({
    clientCode: '',
    clientName: ''
  });
  const [clientDataCode, setClientDataCode] = useState([]);

  useEffect(() => {
    setSuggestData(clientCodes);
  }, [clientCodes]);

  useEffect(() => {
    if (selectedClientData != null && selectedClientData != undefined) {
      if (selectedClientData.clientCode != '' && selectedClientData.clientName != '') {
        let cliName = selectedClientData.clientName.split(':');
        setRoster({
          ...roster,
          clientCode: selectedClientData.clientCode,
          clientName: cliName[0]
        });
      }
    }
  }, [selectedClientData]);

  const [isFirstnameValid, setFirstnameValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isLastnameValid, setLastnameValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isEmailValid, setEmailValidation] = useState({
    isValid: false,
    error: ''
  });
  const [isPasswordValid, setPasswordValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isAdminRoleValid, setAdminRoleValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isClientCodeValid, setClientCodeValidation] = useState({
    isValid: true,
    error: ''
  });
  const [isChecked, setCheckboxValidation] = useState({
    isValid: false,
    error: null
  });
  const [isThresholdValid, setIsThresholdValid] = useState({
    isValid: false,
    error: null
  });
  const [isMinimumCountValid, setIsMinimumCountValid] = useState({
    isValid: false,
    error: null
  });
  const [isMaximumCountValid, setIsMaximumCountValid] = useState({
    isValid: false,
    error: null
  });

  const [roster, setRoster] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: 'Healthgrades1',
    adminRole: '',
    clientCode: '',
    clientName: '',
    pMinimum: 0,
    pMaximum: 0
  });
  useEffect(() => {
    if (
      isFirstnameValid.isValid == true &&
      isLastnameValid.isValid == true &&
      isEmailValid.isValid == true &&
      isPasswordValid.isValid == true &&
      isAdminRoleValid.isValid == true &&
      isClientCodeValid.isValid == true &&
      isChecked.isValid == true &&
      !isMinimumCountValid.isValid &&
      !isMaximumCountValid.isValid 
    ) {
      setdisablebutton(false);
    } else {
      setdisablebutton(true);
    }
  }, [
    isFirstnameValid,
    isLastnameValid,
    isPasswordValid,
    isAdminRoleValid,
    isClientCodeValid,
    isChecked,
    isEmailValid,
    isMinimumCountValid,
    isMaximumCountValid
  ]);

  const validateInput = () => {
    if (isEmpty(roster.firstName)) {
      setFirstnameValidation(isEmptyField);
    } else {
      setFirstnameValidation(TextValidation(roster.firstName, 'name'));
    }

    if (isEmpty(roster.lastName)) {
      setLastnameValidation(isEmptyField);
    } else {
      setLastnameValidation(TextValidation(roster.lastName, 'name'));
    }

    if (isEmpty(roster.email)) {
      setEmailValidation(isEmptyField);
    } else {
      setEmailValidation(TextValidation(roster.email, 'emailaddress'));
    }

    if (isEmpty(roster.password)) {
      setPasswordValidation(isEmptyField);
    } else {
      setPasswordValidation(TextValidation(roster.password, 'password'));
    }
    if (isEmpty(roster.adminRole) || roster.adminRole == 'Select Role' || roster.adminRole == '-') {
      setAdminRoleValidation(isEmptyField);
    } else {
      setAdminRoleValidation({ isValid: true, error: '' });
    }

    if (roster.adminRole === 'Client_Admin') {
      if (isEmpty(roster.clientCode)) {
        setClientCodeValidation(isEmptyField);
      } else {
        setClientCodeValidation({ isValid: true, error: '' });
      }
      if (roster.pMinimum == 0 || roster.pMinimum == '') {
        setIsMinimumCountValid({
          isValid: true,
          error: 'Minimum provider should not be 0'
        });
      }
      if (roster.pMaximum == 0 || roster.pMinimum == '') {
        setIsMaximumCountValid({
          isValid: true,
          error: 'Maximum provider should not be 0'
        });
      } else if (roster.pMaximum <= roster.pMinimum) {
        setIsThresholdValid({
          isValid: true,
          error: 'Maximum provider should be greater than Minimum provider'
        });

        setIsMaximumCountValid({
          isValid: false,
          error: null
        });
      }
    } else {
      setClientCodeValidation({
        isValid: true,
        error: ''
      });
    }

    if (!isChecked.isValid) {
      setCheckboxValidation({
        isValid: false,
        error: 'Please verify the identity of this user'
      });
    }
  };

  const isRosterInValid = () => {
    return (
      isEmpty(roster.firstName) ||
      isEmpty(roster.lastName) ||
      isEmpty(roster.email) ||
      isEmpty(roster.password) ||
      isEmpty(roster.adminRole) ||
      (roster.adminRole === 'Client_Admin' && roster.pMinimum >= roster.pMaximum) ||
      (roster.adminRole === 'Client_Admin' && roster.pMaximum == '') ||
      (roster.adminRole === 'Client_Admin' && roster.pMinimum == '') ||
      (roster.adminRole === 'Client_Admin' && roster.pMinimum == 0) ||
      (roster.adminRole === 'Client_Admin' && roster.pMaximum == 0) ||
      !isChecked.isValid ||
      (roster.adminRole === 'Client_Admin' && isEmpty(roster.clientCode))
    );
  };

  const changeHandler = (e) => {
    switch (e.target.id) {
      case 'firstname':
        setRoster({ ...roster, firstName: e.target.value });
        if (isEmpty(e.target.value)) {
          setFirstnameValidation(isEmptyField);
        } else {
          setFirstnameValidation(TextValidation(roster.firstName, 'name'));
        }
        break;

      case 'lastname':
        setRoster({ ...roster, lastName: e.target.value });
        if (isEmpty(e.target.value)) {
          setLastnameValidation(isEmptyField);
        } else {
          setLastnameValidation(TextValidation(roster.lastName, 'name'));
        }
        break;

      case 'password':
        setRoster({ ...roster, password: e.target.value });
        setPasswordValidation(TextValidation(e.target.value, 'password'));
        break;

      case 'adminRole':
        setRoster({ ...roster, adminRole: e.target.value });
        setAdminRoleValidation({
          isValid: e.target.value != '-' || e.target.value != undefined ? true : false,
          error: 'Please Select Any Role'
        });
        if (roster.adminRole !== 'Client_Admin') {
          setSuggestValue('');
          let clientDataElement = document.getElementById('clientData');
          if (clientDataElement) {
            document.getElementById('clientData').value = '';
          }
        }
        break;

      case 'verifycheckBox':
        setCheckboxValidation({
          isValid: !isChecked.isValid,
          error: 'Please verify the identity of this user'
        });
        if(!isChecked.isValid)
        {
          setdisablebutton(false);
        }
        else 
        {
          setdisablebutton(true);
        }
        break;

      case 'minimum':
        if (e.target.value < 0) {
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider count is invalid'
          });
        } else {
          setRoster({ ...roster, pMinimum: e.target.value });
          if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMinimumCountValid({
              isValid: true,
              error: 'Minimum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          } else if (Number(e.target.value) >= roster.pMaximum) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
          } else {
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
          }
        }
        break;

      case 'maximum':
        if (e.target.value < 0) {
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider count is invalid'
          });
          setdisablebutton(true);
        } else {
          setRoster({ ...roster, pMaximum: e.target.value });
           if (Number(e.target.value) == '' || Number(e.target.value) == 0) {
            setIsMaximumCountValid({
              isValid: true,
              error: 'Maximum provider should not be 0'
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setdisablebutton(true);
          } else if (roster.pMinimum >= Number(e.target.value)) {
            setIsThresholdValid({
              isValid: true,
              error: 'Maximum provider should be greater than Minimum provider'
            });
            setIsMinimumCountValid({
              isValid: false,
              error: null
            });
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setdisablebutton(true);
          } else {
            setIsMaximumCountValid({
              isValid: false,
              error: null
            });
            setIsThresholdValid({
              isValid: false,
              error: null
            });
            setdisablebutton(false);
          }
        }
        break;
    }
  };

  const onCreateHandler = (e) => {
    e.preventDefault();
    validateInput();
    if (!isRosterInValid()) {
      if (roster.adminRole !== 'Client_Admin') {
        setRoster({ ...roster, clientCode: '' });
        setRoster({ ...roster, clientName: '' });
      }
      props.showSpinnerModel(true);
      dispatch(actions.createRoster(roster, currentUserId, props.showSpinnerModel));
    }
  };

  const clientsTextBoxData = {
    id: 'clientData',
    name: 'clientData',
    placeholder: 'Client Code'
  };
  const searchClientCodeChange = (e) => {
    setSuggestValue(e.target.value);
    if (e.currentTarget.value.length <= 1) {
      selectedClientData.clientCode = null;
      setRoster({
        ...roster,
        clientCode: ''
      });
      return;
    }

    let filteredClients = clientCodes.filter(function (v) {
      if (
        v.ClientName.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1 ||
        v.ClientCode.toLowerCase().indexOf(e.target.value.toLowerCase()) > -1
      ) {
        return v;
      }
    });
    let clientsData = filteredClients.slice(0, 5);

    setSuggestData(clientsData);
    return clientsData;
  };

  const onSelectedItem = (data) => {
    if (!_.isEmpty(data)) {
      setSelectedClientData({
        ...selectedClientData,
        clientCode: data[0].values,
        clientName: data[0].text
      });
      var clientData =
        clientDataCode != undefined && clientDataCode != null
          ? clientDataCode.filter((x) => x.clientCode == data[0].values)
          : [];
      if (clientData.length > 0) {
        setRoster({
          ...roster,
          pMinimum:
            clientData[0].minProviderCount != undefined && clientData[0].minProviderCount != null
              ? clientData[0].minProviderCount
              : 0,
          pMaximum:
            clientData[0].maxProviderCount != undefined && clientData[0].maxProviderCount != null
              ? clientData[0].maxProviderCount
              : 0
        });
        if (clientData[0].minProviderCount == 0 || clientData[0].minProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMinimumCountValid({
            isValid: true,
            error: 'Minimum provider should not be 0'
          });
        }
        if (clientData[0].maxProviderCount == 0 || clientData[0].maxProviderCount == '') {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: true,
            error: 'Maximum provider should not be 0'
          });
        } else {
          setIsThresholdValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
          setIsMaximumCountValid({
            isValid: false,
            error: null
          });
        }
      } else {
        setRoster({
          ...roster,
          pMinimum: 0,
          pMaximum: 0
        });
      }
      setSuggestValue(data[0].text);
      if (isEmpty(data[0].values)) {
        setClientCodeValidation(isEmptyField);
      } else {
        setClientCodeValidation({ isValid: true, error: '' });
      }
    }
  };

  useEffect(() => {
    setRoster({ ...roster, clientCode: '' });
    setClientCodeValidation({
      isValid: true,
      error: ''
    });
  }, [roster.adminRole]);

  const emailChangeHandler = (value) => {
    roster.email = value;
    setRoster({ ...roster, email: value });
    setEmailValidation(TextValidation(value, 'emailaddress'));
  };

  const handleKeyPress = (e) => {
    let code = e.keyCode || e.which;
    if (code === 13) {
      e.preventDefault();
      onCreateHandler(e);
    }
  };

  useEffect(() => {
    _pService
      .clientDetails()
      .then((res) => {
        if (res.status == 200) {
          let clientData = objectToCamel(res.data || []);
          setClientDataCode(objectToCamel(JSON.parse(clientData.returnData)));
        }
      })
      .catch((error) => console.error(error));
  }, [clientCodes]);

  return (
    <Fragment>
      <div className='roster-modal-account'>
        <form id='rosterForm' autoComplete='off'>
          <div className='close'>
            <img className='close-icon' onClick={props.action} src={close} alt='close' />
          </div>

          <div className='roster-modal-container'>
            <div className='error-response'>
              {!createRosterResponse.Status && (
                <ValidationErrorMessage
                  className='error-response'
                  message={createRosterResponse.Message}></ValidationErrorMessage>
              )}
            </div>

            <div className='roster-modal-header'>
              <h1> Create User Account</h1>
            </div>

            <div className='roster-modal-content'>
              <div className='input-inline'>
                <div className='firstname'>
                  <div className='height-fix'>
                    <label htmlFor='firstname' className='floating-label'>
                      First Name*
                    </label>
                    <input
                      className='input'
                      id='firstname'
                      type='text'
                      value={roster.firstName}
                      onChange={changeHandler}
                      onKeyDown={(e) => handleKeyPress(e)}
                    />
                  </div>
                  {!isFirstnameValid.isValid && (
                    <ValidationErrorMessage message={isFirstnameValid.error} />
                  )}
                </div>

                <div className='lastname'>
                  <div className='height-fix'>
                    <label htmlFor='lastname' className='floating-label'>
                      Last Name*
                    </label>
                    <input
                      className='input'
                      id='lastname'
                      type='text'
                      value={roster.lastName}
                      onChange={changeHandler}
                      onKeyDown={(e) => handleKeyPress(e)}
                    />
                  </div>
                  {!isLastnameValid.isValid && (
                    <ValidationErrorMessage message={isLastnameValid.error} />
                  )}
                </div>
              </div>

              <div className='input-block'>
                <div className='email'>
                  <div className='height-fix'>
                    <EmailInput
                      label='Enter Email*'
                      name='email'
                      id='email'
                      value={roster.email}
                      type='text'
                      // onChange={changeHandler}
                      onChange={(name, value) => emailChangeHandler(value)}
                      onKeyPress={(e) => handleKeyPress(e)}
                    />
                  </div>

                  {!isEmailValid.isValid && (
                    <ValidationErrorMessage message={isEmailValid.error} className='email-error' />
                  )}
                </div>

                <div className='password'>
                  <div className='height-fix'>
                    <label htmlFor='password' className='floating-label'>
                      Password*
                    </label>
                    <input
                      id='password'
                      type={password ? 'password' : 'text'}
                      className='block-password'
                      value={roster.password}
                      onChange={changeHandler}
                      onKeyDown={(e) => handleKeyPress(e)}
                    />
                  </div>

                  {!isPasswordValid.isValid && (
                    <ValidationErrorMessage message={isPasswordValid.error} />
                  )}
                  <div className='pswd-toggle'>
                    <div className='toggle-password' id='togglePassword'>
                      <label htmlFor='togglePassword'>
                        <div>
                          {password ? (
                            <img
                              src={showPassword}
                              alt='showpassword'
                              onClick={() => togglePassword(!password)}
                              onKeyDown={(e) => handleKeyPress(e)}
                            />
                          ) : (
                            <img
                              src={hidePassword}
                              alt='hidepassword'
                              onClick={() => togglePassword(!password)}
                              onKeyDown={(e) => handleKeyPress(e)}
                            />
                          )}
                        </div>
                      </label>
                    </div>
                  </div>
                </div>

                <div className='admin-role'>
                  <p>
                    <label>Select Role</label>
                    <select
                      name='adminRole'
                      id='adminRole'
                      onChange={changeHandler}
                      onKeyDown={(e) => handleKeyPress(e)}
                      value={roster.adminRole}>
                      {constants.createUserRoles.map((data, index) => (
                        <option key={index} value={data.value}>
                          {data.label}
                        </option>
                      ))}
                    </select>
                    {!isAdminRoleValid.isValid && (
                      <ValidationErrorMessage message={isAdminRoleValid.error} />
                    )}
                  </p>
                </div>
                {roster.adminRole === 'Client_Admin' && (
                  <div className='client-code'>
                    <p>
                      <label>Client Code</label>
                      <AutoComplete
                        textBoxData={clientsTextBoxData}
                        suggestData={suggestData}
                        searchValue={suggestValue}
                        onChangeHandler={searchClientCodeChange}
                        searchType='clientData'
                        onSelectedItem={onSelectedItem}
                      />
                      {!isClientCodeValid.isValid && (
                        <ValidationErrorMessage message={isClientCodeValid.error} />
                      )}
                    </p>
                  </div>
                )}
                {selectedClientData.clientCode != null &&
                  selectedClientData.clientCode != '' &&
                  !_.isEmpty(suggestValue) && (
                    <>
                      <div className='provider-threshold'>
                        <div className='min-provider'>
                          <label className='text-minimum '>Minimum Provider</label>
                          <input
                            className='input'
                            id='minimum'
                            type='number'
                            min={0}
                            value={roster.pMinimum}
                            onChange={changeHandler}
                            onKeyDown={(e) => handleKeyPress(e)}
                          />
                          {isMinimumCountValid.isValid && (
                            <div className='validation-message'>
                              <ValidationErrorMessage message={isMinimumCountValid.error} />
                            </div>
                          )}
                        </div>
                        <div className='max-provider'>
                          <label className='text-maximum '>Maximum Provider</label>
                          <input
                            className='input'
                            id='maximum'
                            type='number'
                            min={0}
                            value={roster.pMaximum}
                            onChange={changeHandler}
                            onKeyDown={(e) => handleKeyPress(e)}
                          />
                          {isMaximumCountValid.isValid && (
                            <div className='validation-message'>
                              <ValidationErrorMessage message={isMaximumCountValid.error} />
                            </div>
                          )}
                        </div>
                      </div>
                      {isThresholdValid.isValid && (
                        <div className='validation-message'>
                          <ValidationErrorMessage message={isThresholdValid.error} />
                        </div>
                      )}
                    </>
                  )}
              </div>

              <div className='user-verification'>
                <div className='checkbox'>
                  <input
                    id='verifycheckBox'
                    type='checkbox'
                    onClick={changeHandler}
                    onKeyDown={(e) => handleKeyPress(e)}></input>
                  <label htmlFor='verifycheckBox'></label>
                </div>
                <div className='text'>
                  {isChecked.error == null && !isChecked.isValid && (
                    <label htmlFor='verifycheckBox' className='verified'>
                      User Verification
                    </label>
                  )}
                  {isChecked.error && (
                    <label
                      htmlFor='verifycheckBox'
                      className={isChecked.isValid ? 'verified' : 'not-verified'}>
                      User Verification
                    </label>
                  )}
                  <br />
                  {roster.adminRole === 'HG_Audit_Admin' ? (
                    <span>
                      I confirm that the identity of this user has been verified and that they are
                      authorized to manage profiles on behalf of providers.
                    </span>
                  ) : (
                    <span>
                      I have confirmed that a signed DLA is on file and they are authorized to
                      manage profiles on behalf of providers.
                    </span>
                  )}
                  <div className='error-wrapper'>
                    {!isChecked.isValid && <ValidationErrorMessage message={isChecked.error} />}
                  </div>
                </div>
              </div>
            </div>
            <div className='roster-modal-footer'>
              <button onClick={props.action} className='cancel-btn'>
                Cancel
              </button>

              <button
                className={disableButton ? 'button-disabled' : ''}
                disabled={disableButton}
                onClick={onCreateHandler}>
                Create
              </button>
            </div>
          </div>
        </form>
      </div>
    </Fragment>
  );
};
CreateRoster.propTypes = {
  action: PropTypes.func,
  showSpinnerModel: PropTypes.func,
  currentUserId: PropTypes.string,
  clientCodes: PropTypes.array
};
export default CreateRoster;
