import React from "react";

//stylesheet imports
import './pageNotFound.less';

/* #region helper */
import * as constants from './Constants';
/* #endregion */

/* #region Joy Component import */
import Button from '@hg/joy/src/components/Button/Button';


const pagenotfound = () =>{
    const onHomeClick = () =>{
        window.location.href = `${window.location.origin}`;
      };
    return (
        <div id='container-section'>
            <div className='message-section'>
                <div className='inner-page-section'>
                    <div className='img-page-not-found'>
                        <div className='img-logo'>
                            <img className='top-img' src={constants.pageImage.image3} alt='Logo' />
                            <img className='bottom-img' src={constants.pageImage.image4} alt='Logo' />
                        </div>
                    </div>
                    <div className='inner-section'>
                        <div className='logo-section'>
                            <img className='img-logo' src={constants.pageImage.image2} alt='Logo' />
                        </div>
                        <div className='msg-info-section'>
                            <span className='msg-info'>{'Sorry, but the page you were trying to view does not exist'}</span>
                        </div>
                    <div className='hompage-btn'>
                        <Button
                        id='btn-home'
                        text={`Go to homepage`}
                        disabled={false}
                        className={`home-btn`}
                        size='lg'
                        style='ghost'
                        onClick={onHomeClick}/>
                    </div>
                    <div className='custom-note'>
                        {'To report a technical issue, please email'} <a href="/contactus">Customer Service</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default pagenotfound;