import React from 'react';

//stylesheet imports
import './_body.less';
import PageNotFound from './PageNotFound.jsx';

const Body = () => {
  return (
    <div className='body-section'>
      <div className='body-inner-section-error'>
        <PageNotFound />
      </div>
    </div>
  );
};

export default Body;
