const firstframe = '/public/images/errorPage/firstframe.png';
const secondframe = '/public/images/errorPage/secondframe.png';
const healthgreadesLogo = '/public/images/errorPage/healthgrades.png';
export const pageImage = {
    image2 : healthgreadesLogo,
    image3 : firstframe,
    image4 : secondframe
};