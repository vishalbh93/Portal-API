//#React component
import React, { Fragment } from 'react';
import PropTypes from 'prop-types';

//#import styles Component
import './_index.less';

//#import joy component
import '@hg/joy/src/globalstyles';

//#Component
import HeroSection from '../Common/HeroSection';
import MenuComponent from '../Common/Menu/Menu';
import Footer from '../Common/Footer/Footer';
import Body from './Body';

const Index = () => {

  return (
    <Fragment>
      <MenuComponent showMenus={false} showClaim={false} showLogin={false} />
      <div className='banner-container-search'>
        <div className='banner-inner-container-search'>
          <HeroSection 
              showDoctorImage={false}
              src=''
              header1=''
              backgroundColor='#FFFFFF' />
        </div>
      </div>
      <Body />
      <Footer />
    </Fragment>
  );
};

Index.propTypes = {
  providers: PropTypes.object
};

export default Index;
