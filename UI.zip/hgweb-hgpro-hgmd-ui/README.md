#  Admin

This repo serves admin functionalities for hgmd application.Components are loaded to hgmd for rendering. This application utilizes a ReactJS frontend.

## Getting Started

1. `git clone git@git.aws.healthgrades.zone:squad-hgmd/hgmd-ui.git`
2. `cd hgmd-ui`
3. `npm install`

### Run Storybook:

1. `npm start`
2. Navigate to <http://localhost:7070>

## File Structure

```
├─ assets
├─ src
   ├─ components
   │  └─ Provider etc.
   ├─ store
   ├─ utils
```

### Our tech stack

Components are created using react-hooks.Store management is done using redux.

#### Prettier

All changes should be formatted with [Prettier](https://prettier.io/) before a Merge Request is created.Used Plugin Prettier for formatting(wrapping code,line length count)

#### Linting

The ESLint Configuration is set in eslintrc.js. The script for the linter is`npm run eslint` - all warnings and errors should be resolved before changes are pushed to GitLab.

### src

The `src` directory holds all normal React components and other files that require bundling for browser-side execution. All the components are reusable ("components")

### Build Process

Builds are automatically triggered when commits are made to this repo on ''
